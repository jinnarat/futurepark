$(document).ready(function () {
	var banner_slider, product_slider, member_slider;
	$("#myBtnTop").css("display", "none");
	
	if($(".banner-slider").children().length > 0){
		var banner_lenght = $(".banner-slider").children().length;
		banner_slider = $(".banner-slider").bxSlider({mode: "fade", auto: (banner_lenght < 2) ? false : true, pause: 6000, speed: 4000, controls: true, pager: (banner_lenght < 2) ? false : true, touchEnabled: false, adaptiveHeight: true, infiniteLoop: (banner_lenght <= 1) ? false : true, onSlideAfter: function() { pause: 6000 }});
	}

	var member_lenght = $(".member-slider").children().length;
	if(media != "mobile"){
		if($(".member-slider").children().length > 0){
			member_slider = $(".member-slider").bxSlider({auto: false, speed: 1000, minSlides: 3, maxSlides: 3, slideWidth: 440, controls: true, pager: false, moveSlides: 1, infiniteLoop: (member_lenght < 4) ? false : true});
		}
	}else{
		if($(".member-slider").children().length > 0){
			member_slider = $(".member-slider").bxSlider({auto: false, speed: 1000, controls: true, pager: false, moveSlides: 1, infiniteLoop: true});
		}
	}
		
	var product_lenght = $(".product-slider").children().length;
	if(media == "mobile"){
		if($(".product-slider").children().length > 0){
			product_slider = $(".product-slider").bxSlider({auto: false, speed: 1000, controls: true, pager: false, moveSlides: 1, infiniteLoop: true});
		}
	}else if(media == "tablet"){
		if($(".product-slider").children().length > 0){
			product_slider = $(".product-slider").bxSlider({auto: false, speed: 1000, minSlides: 2, maxSlides: 2, slideWidth: 440, controls: true, pager: false, moveSlides: 1, infiniteLoop: true});
		}
	}else{
		if($(".product-slider").children().length > 0){
			product_slider = $(".product-slider").bxSlider({auto: false, speed: 1000, minSlides: 2, maxSlides: 2, slideWidth: 440, controls: true, pager: false, moveSlides: 1, infiniteLoop: true});
		}
	}
			
	$(".pie-area").mouseenter(function() {
		var svid = $(this).data("id");
		if(!$(this).hasClass("active")){
			$("#SV" + svid).css("stroke","#ffa02c");
			$("text[data-id='"+svid+"']").css("fill","#ffffff");
		}
	}).mouseleave(function() {
		var svid = $(this).data("id");
		if(!$(this).hasClass("active")){
			$("text[data-id='"+svid+"']").css("fill","#333333");
			$("#SV" + svid).css("stroke","#ffffff");
		}
	});
	
	$("textPath").mouseenter(function() {
		var svid = $(this).data("id");
		if(!$("path[data-id='"+svid+"']").hasClass("active")){
			$("#SV" + svid).css("stroke","#ffa02c");
		}
		if(!$("text[data-id='"+svid+"']").hasClass("active")){
			$("text[data-id='"+svid+"']").css("fill", "#ffffff");
		}
	}).mouseleave(function() {
		var svid = $(this).data("id");
		if(!$("path[data-id='"+svid+"']").hasClass("active")){
			$("#SV" + svid).css("stroke","#ffffff");
		}
		if(!$("text[data-id='"+svid+"']").hasClass("active")){
			$("text[data-id='"+svid+"']").css("fill", "#333333");
		}
	});
	
	$("path, textPath").click(function(){
		var svid = $(this).data("id");
		if($("path, text").hasClass("active")){
			$("path, text").removeClass("active");
			$("path").css("stroke", "#ffffff");
			$("text").css("fill", "#333333");
		}
		
		$("path[data-id='"+svid+"'], text[data-id='"+svid+"']").addClass("active");
		$("path[data-id='"+svid+"']").css("stroke", "#ffa02c");
		$("text[data-id='"+svid+"']").css("fill", "#ffffff");
		
		$("#result_service").empty();
		$.ajax({
			url: BaseUrl + "home/select_service/",
			method: "get",
			data: {'svid' : svid},
			dataType: "json"
		}).done(function(e) {
			// console.log(e);
			var svdata = e.service_data;
			$("#result_service").css("display", "none");
			$("#result_service").append(svdata).slideDown("slow");
		});
		
	});
	
	var p = $(".box-content.experience");
	var position = p.position();
	var position_experience = position.top - 400;
	// console.log(position.top);
	
	function experience(){
		if ($(window).scrollTop() > position_experience) {
			var chkCount = $("#experience_counter").attr('data-val');
			if(chkCount == 0){
				$('.counter').each(function() {
					var $this = $(this),
					countTo = $this.attr('data-count');
					// console.log(countTo);
						
					$({ countNum: $this.text()}).animate({
						countNum: countTo
					},
					{
						duration: 8000,
						easing:'linear',
						step: function() {
						  $this.text(Math.floor(this.countNum));
						},
						complete: function() {
						  var counter = this.countNum.toLocaleString();
						  $this.text(this.countNum.toLocaleString());
						  $("#experience_counter").attr("data-val", "1");
						  // alert('finished');
						}

					}); 
				});
			}
		}
	}
	
	function setHeightBG(name, block){
		var hlDiv = $(name).height();
		var hlNew;
		if(media == "desktop"){
			if(block == "service"){
				if(hlDiv > 600){
					hlNew = parseInt(hlDiv)+40;
					$(".box-content.service .bg-image .image-holder").css("padding-top", hlNew+"px");
				}
			}
		}else if(media == "mobile"){
			if(block == "service"){
				if(hlDiv > 590){
					hlNew = parseInt(hlDiv)+60;
					$(".box-content.service .bg-image .image-holder").css("padding-top", hlNew+"px");
				}
			}
		}else{
			if(block == "service"){
				if(hlDiv > 570){
					hlNew = parseInt(hlDiv)+40;
					$(".box-content.service .bg-image .image-holder").css("padding-top", hlNew+"px");
				}
			}
		}
	}
	
	experience();
	
	if($(".box-content.service .bg-image .image-holder").is("[style]")){
		$(".box-content.service .bg-image .image-holder").removeAttr("style");
	}
	setHeightBG(".service-content .inner-content", "service");
	
	$(window).on("scroll", function () {
		// console.log($(window).scrollTop());
		// console.log(position_experience);
		
		experience();
	});
	
	$(window).resize(function() {
		var windowsize = $(window).width();
		var documentwidth = $(document).width();
		var _SCREEN_ = (window.devicePixelRatio * screen.width) / window.devicePixelRatio;
		var S = window.innerWidth;
		var media = "desktop";
		if((_SCREEN_ <= 1280 && _SCREEN_ >= 768) || (S <= 1280 && S >= 768)){
			media = "tablet";
		}
		if(_SCREEN_ < 768 || S < 768){
			media = "mobile";
		}
		
		if($(".banner-slider").children().length > 0){
			var banner_lenght = $(".banner-slider").children().length;
			/* banner_slider.reloadSlider({mode: "fade", auto: (banner_lenght < 2) ? false : true, pause: 6000, speed: 4000, controls: true, pager: (banner_lenght < 2) ? false : true, touchEnabled: false, adaptiveHeight: true, infiniteLoop: (banner_lenght <= 1) ? false : true, onSlideAfter: function() { pause: 6000 }}); */
		}
		
		var member_lenght = $(".member-slider").children().length;
		if(media != "mobile"){
			if($(".member-slider").children().length > 0){
				member_slider.reloadSlider({auto: false, speed: 1000, minSlides: 3, maxSlides: 3, slideWidth: 440, controls: true, pager: false, moveSlides: 1, infiniteLoop: (member_lenght < 4) ? false : true});
			}
		}else{
			if($(".member-slider").children().length > 0){
				member_slider.reloadSlider({auto: false, speed: 1000, controls: true, pager: false, moveSlides: 1, infiniteLoop: true});
			}
		}
		
		var product_lenght = $(".product-slider").children().length;
		if(media == "mobile"){
			if($(".product-slider").children().length > 0){
				product_slider.reloadSlider({auto: false, speed: 1000, controls: true, pager: false, moveSlides: 1, infiniteLoop: true});
			}
		}else if(media == "tablet"){
			if($(".product-slider").children().length > 0){
				product_slider.reloadSlider({auto: false, speed: 1000, minSlides: 2, maxSlides: 2, slideWidth: 440, controls: true, pager: false, moveSlides: 1, infiniteLoop: true});
			}
		}else{
			if($(".product-slider").children().length > 0){
				product_slider.reloadSlider({auto: false, speed: 1000, minSlides: 2, maxSlides: 2, slideWidth: 440, controls: true, pager: false, moveSlides: 1, infiniteLoop: true});
			}
		}
		
		if($(".box-content.service .bg-image .image-holder").is("[style]")){
			$(".box-content.service .bg-image .image-holder").removeAttr("style");
		}
		
		setHeightBG(".service-content .inner-content", "service");
	});
});