// require momentjs
class CustomFunction {
  constructor() {
    this.refreshIntervalId = null;
  }
  clearCountDownTime() {
    clearInterval(this.refreshIntervalId);
  }
  countDownTime(dateCountDown, elementCounDown, elementCounDownText, elementFullDate, elementFullDateText, timeoutText, elementCard) {
    this.clearCountDownTime();
    if (!elementCounDownText) {
      elementCounDownText = "เหลือเวลา";
    }
    if (!elementFullDateText) {
      elementFullDateText = "วันเวลาหมดอายุ";
    }
    if (!timeoutText) {
      timeoutText = "หมดเวลา";
    }
    $(elementCounDown).empty().html("");

    let eventTime = moment(dateCountDown, "YYYY-MM-DD HH:mm:ss");
    let eventShowFullText = moment(dateCountDown, "YYYY-MM-DD HH:mm:ss");
    let currentTime = moment();
    if (elementFullDate) {
      $(elementFullDate).html(`${elementFullDateText} : <strong>${eventShowFullText.locale('th').add(543, 'year').format('DD MMM YYYY HH:mm')}</strong>`);
    }
    eventTime = eventTime.format("HH:mm:ss") == "00:00:00" ? eventTime.endOf("day").format("YYYY-MM-DD HH:mm:ss") : eventTime.format("YYYY-MM-DD HH:mm:ss");
    eventTime = moment(eventTime);
    let countDownCal = moment.duration(eventTime.diff(currentTime));
    if (countDownCal > 0) {
      if(countDownCal.months() == 0){
        $(elementCounDown).html(`${elementCounDownText}  <strong>${countDownCal.days()} วัน ${countDownCal.hours()} : ${countDownCal.minutes()} : ${countDownCal.seconds()}</strong>`);
      }else {
        $(elementCounDown).html(`${elementCounDownText}  <strong>${countDownCal.asDays().toFixed(0)} วัน ${countDownCal.hours()} : ${countDownCal.minutes()} : ${countDownCal.seconds()}</strong>`);
      }
      this.refreshIntervalId = setInterval(() => {
        currentTime = moment();
        countDownCal = moment.duration(eventTime.diff(currentTime));
        if (countDownCal > 0) {
          if(countDownCal.months() == 0){
            $(elementCounDown).html(`${elementCounDownText}  <strong>${countDownCal.days()} วัน ${countDownCal.hours()} : ${countDownCal.minutes()} : ${countDownCal.seconds()}</strong>`);
          }else {
            $(elementCounDown).html(`${elementCounDownText}  <strong>${countDownCal.asDays().toFixed(0)} วัน ${countDownCal.hours()} : ${countDownCal.minutes()} : ${countDownCal.seconds()}</strong>`);
          }
          // $(elementCounDown).html(`${elementCounDownText}  <strong>${countDownCal.asDays().toFixed(0)} วัน ${countDownCal.hours()} : ${countDownCal.minutes()} : ${countDownCal.seconds()}</strong>`);
        } else {
          clearInterval(this.refreshIntervalId);
          $(elementCounDown).html(timeoutText);
          if (elementCard) {
            $('#showCodeModal').modal('hide');
            elementCard.find(".use-code-text").hide();
            elementCard.removeClass('card-data-value');
          }
        }
      }, 1000);
    } else {
      clearInterval(this.refreshIntervalId);
    }
  }
}
