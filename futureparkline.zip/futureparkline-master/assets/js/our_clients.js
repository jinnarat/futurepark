$(document).ready(function () {
	var BasePage = BASE_PAGE;
	var url = window.location.href;  
	var url = $("#url_href").attr("data-row");  
	$('#client_type').selectpicker();
	
	$('#client_type').on('changed.bs.select', function (e, clickedIndex, isSelected, previousValue) {
		$(".dropdown-menu").removeClass("open");
		var typeid = clickedIndex;
		location.href = url + typeid + "/";
	});
	
});