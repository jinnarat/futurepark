function checkint(el) {
	var ex = /^[0-9]*$/;
	if (ex.test(el.value) == false) {
		el.value = el.value.substring(0, el.value.length - 1)
	}
}

function navbarMenu() {
	if (media == "tablet" || media == "mobile") {
		$(".site-description").addClass("col-xs-7");
		$(".menu").css({ "display": "none" });
		var eles = $(".navbar-default .navbar-nav > li");
		if (eles.hasClass("has-sub")) {
			var navLink = $(".navbar-default .navbar-nav > li.has-sub > a").attr("href");
			if (navLink != "") {
				$(".navbar-default .navbar-nav > li.has-sub > a").attr("href", "#");
			}
			$(".navbar-default .navbar-nav > li.has-sub").click(function () {
				if ($(this).hasClass("open")) {
					$(this).removeClass("open");
					$(".navbar-default .navbar-nav > li.has-sub > ul").css("display", "none");
				} else {
					$(this).addClass("open");
					$(".navbar-default .navbar-nav > li.has-sub > ul").css("display", "block");
				}
			});
		}
	} else {
		$(".site-description").removeClass("col-xs-6");
		$(".navbar").addClass("navbar-fixed-top");
		$(".dropdown").addClass("has-sub nav-item");
	}
}

$(document).ready(function () {
	// console.log(media);
	navbarMenu();

	if ($(window).scrollTop() > 0) {
		$(".navbar-default").addClass("scroll");
	} else {
		$(".navbar-default").removeClass("scroll");
	}

	$(window).on("scroll", function () {
		if ($(window).scrollTop() > 0) {
			$(".navbar-default").addClass("scroll");
		} else {
			$(".navbar-default").removeClass("scroll");
		}
	});

	$(window).resize(function () {
		var windowsize = $(window).width();
		var documentwidth = $(document).width();
		var documentheight = $(document).height();
		var _SCREEN_ = (window.devicePixelRatio * screen.width) / window.devicePixelRatio;
		var S = window.innerWidth;
		var media = "desktop";
		if ((_SCREEN_ <= 1280 && _SCREEN_ >= 768) || (S <= 1280 && S >= 768)) {
			media = "tablet";
		}
		if (_SCREEN_ < 768 || S < 768) {
			media = "mobile";
		}
		navbarMenu();
	});
});