function checkValidate(){
	var txtAlert = "";
	var txtFocus = "";	
	var result = new Array();
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	
	var fname = document.getElementById('fname');
	var lname = document.getElementById('lname');
	var mail = document.getElementById('email');
	var subject_contact = document.getElementById('subject_contact');
	var phone = document.getElementById('phone');
	
	if(!GetResponse){
		// alert("Please, select security code."); return false;	
	}
	if(fname.value.trim() == ""){
		txtAlert += '<p>Please, fill firstname.</p>'; txtFocus += 'fname,';
	}
	if(lname.value.trim() == ""){
		txtAlert += '<p>Please, fill lastname.</p>'; txtFocus += 'lname,';
	}
	if(subject_contact.value.trim() == "0"){
		txtAlert += '<p>Please, fill subject.</p>'; txtFocus += 'subject_contact,';
	}
	if(!mail.value.trim()){
		txtAlert += '<p>Please, fill email. </p>'; txtFocus += 'email,';
	}else{
		if(!mailformat.test(mail.value.trim())){
			txtAlert += '<p>Warning !! email format is incorrect. Please fill in again. </p>'; txtFocus += 'email,';
		}
	}
	if(!phone.value.trim()){
		txtAlert += '<p>Please, fill telephone.</p>'; txtFocus += 'phone,';
	}
	
	if(txtAlert){
		var result = new Array();
		var temp = new Array();
			temp = txtFocus.split(",");
		// alert(txtAlert); document.getElementById(temp[0]).focus(); return false;
		result['txtFocus'] = txtFocus;
		// result['txtFocus'] = temp[0];
		result['txtAlert'] = txtAlert;
		return result;
	}
}

$(document).ready(function () {
	$("#frmInquiry").submit(function(){
		$("#modal-body").empty();
		$("#modal-title").empty();
		$("#modal-title").append("Contact Us");
		$("#bg-lock__process, #box-lock__process").css("display", "block");
		if(!GetResponse){
			$("#modal-body").append("<p>Please, select security code.</p>");
			$("#myAlert").trigger("click"); 
			$("#bg-lock__process, #box-lock__process").css("display", "none");
			return false;
		}
		
		var result = checkValidate();
		if(result){	
			
			$("#modal-body").append(result["txtAlert"]);	
			$("#myAlert").trigger("click");
			// alert("Submitted" + result);	
			$("#bg-lock__process, #box-lock__process").css("display", "none");
			return false;
		}
		setTimeout(function(){ $("#bg-lock__process, #box-lock__process").css("display", "none"); }, 10000);
	});
});