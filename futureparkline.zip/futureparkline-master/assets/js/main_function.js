var baseURL = $('.nav-url').attr('href');
var getPathname = window.location.pathname;
var getCurrentUrl = window.location.href;
var getOriginUrl = window.location.origin;

function isEmpty(value) {
    if (typeof value === "undefined"
        || value === ''
        || value === ""
        || value === null) {
        return true;
    } else {
        return false;
    }
}


function checkID(id) {
    if (id.length != 13) {
        return false;
    }
    for (i = 0, sum = 0; i < 12; i++) {
        sum += parseFloat(id.charAt(i)) * (13 - i);
    }
    if ((11 - sum % 11) % 10 != parseFloat(id.charAt(12))) {
        return false;
    }
    return true;
}

function checkint(el) {
    var ex = /^[0-9]*$/;
    if (ex.test(el.value) == false) {
        el.value = el.value.substring(0, el.value.length - 1)
    }
}

function goToByScroll(id) {
    // Remove "link" from the ID
    id = id.replace("link", "");
    // Scroll
    $('html,body').animate({
        scrollTop: $("#" + id).offset().top - 100
    }, 'slow');
}

// function loading(action) {
//     if (action == "show") {
//         var loading_component = "<div class='loading-component'><img 'src= " + baseURL + "'assets/images/loading/loading.svg'><div class='overlay'></div></div>";
//         // var loading_component = "<div class='loading-component'><img src='" + getPathUrl('assets/images/loading/loading.svg') + "';/></div>";
//         $("body").append(loading_component);
//     }
//     else if (action == "hide") {
//         $("body .loading-component").remove();
//     }
// }

$(document).on("keyup", ".numberic", function () {
    this.value = this.value.replace(/[^0-9]/g, '');
})