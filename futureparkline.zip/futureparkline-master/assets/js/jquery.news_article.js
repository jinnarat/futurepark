$(document).ready(function () {
	var related_slide;
	var related_lenght = $(".related-slide").children().length;
	if(media != "mobile"){
		if($(".related-slide").children().length > 0){
			related_slide = $(".related-slide").bxSlider({auto: false, speed: 1000, minSlides: 3, maxSlides: 3, slideWidth: 380, slideMargin: 15, controls: true, pager: false, moveSlides: 1, infiniteLoop: (related_lenght < 4) ? false : true, onSliderLoad: function() { var hl = parseInt($(".bx-viewport").height()) + 15; $(".bx-viewport").css("height", hl); }});
		}
	}else{
		if($(".related-slide").children().length > 0){
			related_slide = $(".related-slide").bxSlider({auto: false, speed: 1000, controls: true, pager: false, moveSlides: 1, infiniteLoop: true});
		}
	}
	
	$(window).resize(function() {
		var windowsize = $(window).width();
		var documentwidth = $(document).width();
		var _SCREEN_ = (window.devicePixelRatio * screen.width) / window.devicePixelRatio;
		var S = window.innerWidth;
		var media = "desktop";
		if((_SCREEN_ <= 1280 && _SCREEN_ >= 768) || (S <= 1280 && S >= 768)){
			media = "tablet";
		}
		if(_SCREEN_ < 768 || S < 768){
			media = "mobile";
		}
		
		var related_lenght = $(".related-slide").children().length;
		if(media != "mobile"){
			if($(".related-slide").children().length > 0){
				related_slide.reloadSlider({auto: false, speed: 1000, minSlides: 3, maxSlides: 3, slideWidth: 380, slideMargin: 15, controls: true, pager: false, moveSlides: 1, infiniteLoop: (related_lenght < 4) ? false : true, onSliderLoad: function() { var hl = parseInt($(".bx-viewport").height()) + 15; $(".bx-viewport").css("height", hl); }});
				
			}
		}else{
			if($(".related-slide").children().length > 0){
				related_slide.reloadSlider({auto: false, speed: 1000, controls: true, pager: false, moveSlides: 1, infiniteLoop: true});
				
			}
		}
	});
});