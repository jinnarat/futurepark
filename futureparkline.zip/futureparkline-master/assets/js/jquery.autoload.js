function getMobileOperatingSystem() {
	var userAgent = navigator.userAgent || navigator.vendor || window.opera;
	if (/windows phone/i.test(userAgent)) {
		return "Windows Phone";
	}
	if (/android/i.test(userAgent)) {
		return "Android";
	}
	if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
		return "iOS";
	}
	return "unknown";
}
$(document).ready(function () {
	var track_load = 0;
	var loading = false;
	var total_groups = $("#total_groups").attr("data-row");
	var BasePage = BASE_PAGE;
	var type_id = "";
	
	if(BASE_PAGE == "clients"){
		// type_id = $("#clients_type").attr("data-row");
		// type_id = $("#client_type option:selected" ).val();
		type_id = $("#client_type").find(":selected").val();
	}

	$('#results').load(BaseUrl + BasePage + '/autoload/', {
		'group_no': track_load,
		'csrf_test_name': csrf_token,
		'menu_type': BasePage,
		'type_id': type_id
	}, function () {
		track_load++;
	});
	
	$(window).scroll(function () {
		var winTop = parseInt($(window).scrollTop() + $(window).height());
		var docTop = parseInt($(document).height());
		var systemMobile = getMobileOperatingSystem();
		var sumScroll = 0;
		if (systemMobile == "Android") {
			sumScroll = docTop - winTop;
		}
		
		// if ((($(window).scrollTop() + $(window).height()) == $(document).height()) || (sumScroll <= 200 && systemMobile == "Android")) {
		// if($(window).scrollTop() + $(window).height() == $(document).height()){
		
		// var halfHeight = Math.ceil($(document).height() * 40/100);
		/* var halfPrecent = 28;
		if(track_load == 1){
			var halfHeight = Math.ceil($(document).height() * 40/100);
		}else{
			var halfHeight = Math.ceil($(document).height() * halfPrecent/100);
		}
		if($(window).scrollTop() > $(document).height() - halfHeight){ */
		
		// if($(window).scrollTop() + $(window).height() == $(document).height()){
			
		if($(window).scrollTop() + $(window).height() > $(".ctl-content__page").height()){
			if (track_load <= total_groups && loading == false) {
				loading = true;
				$('.animation_image').show();
				$.get(BaseUrl + 'index.php' + '/' + BasePage + '/autoload/?group_no=' + track_load + '&type_id=' + type_id +'&menu_type=' + BasePage, function (data) {
					$("#results").append(data);
					$('.animation_image').hide();
					track_load++;
					loading = false;
				}).fail(function (xhr, ajaxOptions, thrownError) {
					// alert(thrownError);
					$('.animation_image').hide();
					loading = false;
				});
			}
		}
	});
});