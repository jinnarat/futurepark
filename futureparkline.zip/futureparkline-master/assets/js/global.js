var baseURL = $('.navbar-brand').attr('href');
var getPathname = window.location.pathname;
var getCurrentUrl = window.location.href;
var getOriginUrl = window.location.origin;