<?php
defined('BASEPATH') or exit('No direct script access allowed');

class PrivilegeLib
{

    protected $CI, $PrivilegeModel;

    public function __construct()
    {
        $this->CI =& get_instance();
        $this->CI->load->model('PrivilegeModel');
        $this->PrivilegeModel = $this->CI->PrivilegeModel;
    }

    public function checkPrivilege($personId, $privId, $quantity = 1, $tierId, $dateTimeNow, $checkStatus = true, $checkOldData = true)
    {
        // checkOldData สำหรับตรวจสอบข้อมูลเก่าว่ามีการใช้ไปหรือยัง
        // status 200 ใช้สิทธิได้, สร้างใหม่
        // status 202 data เก่า (ยังไม่ได้ใช้ หรือยังไม่ check-out)
        // status 204 ใช้สิทธิไม่ได้, หมดเขต, หมดเวลา, ใช้ไปแล้ว, Birthday Point ใช้สิทธิ auto
        // status 500 privilege ถูกปิด, ไม่มีอยู่, เงือนไขไม่มี
        $dataReuslt = new stdClass;
        $dateDay = date('Y-m-d', strtotime($dateTimeNow));
        $active = $this->CI->config->item('status_active');

        $masterSchedule = $this->PrivilegeModel->getMasterSchedule(date('l', strtotime($dateTimeNow)));
        if ($masterSchedule) {
            $expiredDate = date('Y-m-d H:i:s', strtotime($dateDay . ' ' . $masterSchedule->scd_endtime));
        } else {
            $expiredDate = date('Y-m-d H:i:s', strtotime($dateDay . ' 23:59:59'));
        }

        // 1.ตรวจสอบ privilege มีอยู๋ ไหม
        $privilegeData = $this->PrivilegeModel->getPrivilegeListByID($privId, $checkStatus);
        if ($privilegeData) {
            $dataReuslt->privilegeData = $privilegeData;
            $expireDay = date('Y-m-d', strtotime($privilegeData->mps_end_action_used));
            $expireTime = date('H:i:s', strtotime($privilegeData->mps_end_action_used));
            if ($expireTime == '00:00:00') {
                $expireTime = '23:59:59';
            }
            $expire_in = date('Y-m-d H:i:s', strtotime($expireDay . $expireTime));
            if ($dateTimeNow <= $expire_in) {
                $dataReuslt->status = 200;
                $dataReuslt->message = 'ใช้สิทธิ์';
            } else {
                $dataReuslt->status = 204;
                $dataReuslt->message = 'สิทธิพิเศษนี้หมดเขตแล้ว';
            }

            // code expire day
            $code_expire = date('Y-m-d', strtotime($dateTimeNow)) . ' 23:59:59';
            $masterExPireData = $this->PrivilegeModel->getMasterExpire($privilegeData->mps_expire_type);
            if($masterExPireData){
                if($masterExPireData->mpe_value == 'day')
                {
                    $code_expire = date('Y-m-d H:i:s', strtotime($dateTimeNow. ' + ' . $privilegeData->mps_expire_in . ' days'));
                }
                else if($masterExPireData->mpe_value == 'time')
                {
                    $code_expire = date('Y-m-d H:i:s', strtotime($dateTimeNow. ' + ' . $privilegeData->mps_expire_in . ' minutes'));
                }
                else if($masterExPireData->mpe_value == 'same_as_privilege')
                {
                    $code_expire = $privilegeData->mps_end_action_used;
                }
                else if($masterExPireData->mpe_value == 'within_day')
                {
                    $code_expire = date('Y-m-d', strtotime($dateTimeNow)) . ' 23:59:59';
                }
            }

            if($code_expire > $privilegeData->mps_end_action_used){
                $code_expire = $privilegeData->mps_end_action_used;
            }
            $dataReuslt->codeExpire = $code_expire;

            // 2. เต็มหรือยัง
            $conditionData = $this->PrivilegeModel->getPrivilegeListCondition($privId, $tierId, $checkStatus);
            if ($conditionData) {
                $dataReuslt->conditionData = $conditionData;
                $dataReuslt->point = $conditionData->mpc_point_redeem;
                $dataLimit = $this->_privilege_limit($personId, $conditionData->mpc_id, $quantity, $dateTimeNow);
                if ($dataLimit->status == 200) {
                    $dataReuslt->member_free_usage = isset($dataLimit->limit['member_maximum_free_usage']) ? $dataLimit->limit['member_maximum_free_usage'] : 0;
                    $dataReuslt->follow_free_usage = isset($dataLimit->limit['follower_maximum_free_usage']) ? $dataLimit->limit['follower_maximum_free_usage'] : 0;
                    if ($dataLimit->status == 200) {
                        $dataReuslt->message = 'ใช้สิทธิ์';
                    } else {
                        $dataReuslt->status = 204;
                        $dataReuslt->message = 'คุณไม่สามารถใช้สิทธิพิเศษนี้ได้';
                    }
                }else {
					$dataReuslt->status = 204;
                    $dataReuslt->message = 'คุณได้ใช้สิทธิ์ครบแล้ว';
				}
            } else {
                $dataReuslt->status = 500;
                $dataReuslt->message = 'ไม่พบรายการเงื่อนไข';
            }

            if ($privilegeData->mpt_type == 'Check-inCheck-out') {
                if ($privilegeData->mpt_value == 'Platinum Lounge') {
                    $dataReuslt->quantity = $quantity;
                    $dataReuslt->detail = '';
                }
                // check out หรือยัง
                $dataPrivilegeSetting = $this->PrivilegeModel->getProveCheckout($conditionData->mps_id, $conditionData->mpc_id, $personId, $dateTimeNow);
                if ($dataPrivilegeSetting) {
                    // แสดง checkout 
                    $dataReuslt->status = 202;
                    $dataReuslt->quantity = null;
                    $dataReuslt->message = 'เช็คเอาท์ (Check-Out)';
                    $dataReuslt->detail = '';
                    $dataReuslt->code = $dataPrivilegeSetting->mp_code;
                    $dataReuslt->qrcodeImage = $dataPrivilegeSetting->mp_qr_image;
                    $dataReuslt->mp_used_datetime = $dataPrivilegeSetting->mp_used_datetime;
                    $dataReuslt->mp_code_expired = $dataPrivilegeSetting->mp_code_expired;
					
					// ปุ่มสำหรับเจ้าหน้าที่
					if ($privilegeData->mpt_value == 'Exclusive Parking') {
						if ($dataPrivilegeSetting->mp_staff_code == NULL) {
							$dataReuslt->btnStaff = 'สำหรับเจ้าหน้าที่';
						}else {
							$dataReuslt->hideData = true;
						}
					}
                } else {
                    if ($dataReuslt->status == 200) {
                        $dataReuslt->message = 'เช็คอิน (Check-In)';
                    }
                }
				// end check out หรือยัง
            } else if ($privilegeData->mpt_type == 'Earn_point') {
                $dataReuslt->status = 204;
                $dataReuslt->message = '';
            } else {
                // Burn_point
                if ($checkOldData) {
                    $dataPrivilegeAdminUse = $this->PrivilegeModel->getProveAdminUse($privId, $personId, $dateTimeNow);
                    if ($dataPrivilegeAdminUse) {
						
                        // แสดง old data 
                        $dataReuslt->status = 202;
                        $dataReuslt->quantity = null;
                        $dataReuslt->message = '';
                        $dataReuslt->detail = '
                        <div>สามารถไปรับของสมนาคุณได้ที่</div>
                        <div><b>จุดแลกรับของสมนาคุณ</b></div>
                        <div>โดยแจ้งรหัส หรือ เบอร์โทรศัพท์ของท่านกับเจ้าหน้าที่</div>';
                        $dataReuslt->code = $dataPrivilegeAdminUse->mp_code;
                        $dataReuslt->qrcodeImage = $dataPrivilegeAdminUse->mp_qr_image;
                        $dataReuslt->mp_used_datetime = $dataPrivilegeAdminUse->mp_used_datetime;
                        $dataReuslt->mp_code_expired = $dataPrivilegeAdminUse->mp_code_expired;

						if($dataReuslt->privilegeData->mpt_value == 'Redeemed Point'){
							$dataReuslt->status = 202;
							$dataReuslt->message = '';
							if ($dataPrivilegeAdminUse->mp_shop_code == NULL || $dataPrivilegeAdminUse->mp_shop_code == '') {
								$dataReuslt->btnShop = 'สำหรับเจ้าหน้าที่';
							}
						}
                    } else {
                        // แสดง new 
                        if ($dataReuslt->status == 200) {
                            $dataReuslt->message = 'ใช้สิทธิ์';
                        }
                    }
                }
            }
        } else {
            $dataReuslt->status = 500;
            $dataReuslt->message = 'ไม่พบรายการ สิทธิพิเศษ';
        }

        return $dataReuslt;
    }

    public function _privilege_limit($person_id, $privilege_condition_id, $privilege_follower, $datetime_now)
	{
		$data = new stdClass;

		try
		{
			$limit_check_temp = true;
			$limit_check = NULL;

			$limit_member_maximum_redeem = -1;
			$limit_member_maximum_free_usage = -1;
			$limit_privilege_maximum_redeem = -1;
			$limit_follower_maximum_redeem = -1;
			$limit_follower_maximum_free_usage = -1;

			$limit_exceed_field = '';
			$limit_exceed_value = 0;
			$limit_exceed_used = 0;

			$privilege_limit = $this->PrivilegeModel->_get_privilege_limit(
				array(
					'type' => 'Privilege Limit',
					'privilege_condition_id' => $privilege_condition_id,
					'condition_status' => 'A'
				)
			);

			if($privilege_limit->num_rows() > 0)
			{
				foreach($privilege_limit->result_array() as $limit)
				{
					$transaction_start_datetime = NULL;
					$transaction_end_datetime = NULL;

					if($limit['limit_period'] == 'Day')
					{
						$transaction_start_datetime = date('Y-m-d', strtotime($datetime_now)) . ' 00:00:00';
						$transaction_end_datetime = date('Y-m-d', strtotime($datetime_now)) . ' 23:59:59';
					}
					else if($limit['limit_period'] == 'Month')
					{
						$transaction_start_datetime = date('Y-m-d', strtotime('first day of this month', strtotime($datetime_now))) . ' 00:00:00';
						$transaction_end_datetime = date('Y-m-d', strtotime('last day of this month', strtotime($datetime_now))) . ' 23:59:59';
					}
					else if($limit['limit_period'] == 'Period')
					{
						$_p =  $this->PrivilegeModel->_get(
							array(
								'type' => 'Get',
								'privilege_id' => NULL,
								'privilege_condition_id' => $privilege_condition_id
							)
						)->row_array();

						$transaction_start_datetime = $_p['privilege_start_datetime'];
						$transaction_end_datetime = $_p['privilege_end_datetime'];
					}

					if($limit['limit_level'] == 'Member')
					{
						if($limit['limit_type'] == 'Maximum')
						{
							if($limit['limit_variable'] == 'Redeemed')
							{
								if($limit['limit_period'] != 'Time')
								{
									$member_total_redeem = $this->PrivilegeModel->_get_member_privilege_limit(
										array(
											'type' => 'Member Redeem',
											'person_id' => ($person_id != '') ? $person_id : NULL,
											'privilege_condition_id' => ($privilege_condition_id != '') ? $privilege_condition_id : NULL,
											'transaction_start_datetime' => $transaction_start_datetime,
											'transaction_end_datetime' => $transaction_end_datetime,
											'condition_status' => 'A'
										)
									)->row_array();

									$limit_member_maximum_redeem = intval($limit['limit_value']) - intval($member_total_redeem['member_total_redeem']);

									if($limit_member_maximum_redeem <= 0)
									{
										$limit_exceed_field = 'member_maximum_redeem';
										$limit_exceed_value = intval($limit['limit_value']);
										$limit_exceed_used = intval($member_total_redeem['member_total_redeem']);

										$limit_check_temp = false;

										break;
									}
								}
							}
							else if($limit['limit_variable'] == 'Free Usage')
							{
								if($limit['limit_period'] != 'Time')
								{
									$member_total_free = $this->PrivilegeModel->_get_member_privilege_limit(
										array(
											'type' => 'Member Free Usage',
											'person_id' => ($person_id != '') ? $person_id : NULL,
											'privilege_condition_id' => ($privilege_condition_id != '') ? $privilege_condition_id : NULL,
											'transaction_start_datetime' => $transaction_start_datetime,
											'transaction_end_datetime' => $transaction_end_datetime,
											'condition_status' => 'A'
										)
									)->row_array();

									$limit_member_maximum_free_usage = intval($limit['limit_value']) - intval($member_total_free['member_total_free']);
									$limit_member_maximum_free_usage = ($limit_member_maximum_free_usage > 0) ? $limit_member_maximum_free_usage : 0;
								}
							}
						}
					}
					else if($limit['limit_level'] == 'Privilege')
					{
						if($limit['limit_type'] == 'Maximum')
						{
							if($limit['limit_variable'] == 'Redeemed')
							{
								if($limit['limit_period'] != 'Time')
								{
									$privilege_total_redeem = $this->PrivilegeModel->_get_member_privilege_limit(
										array(
											'type' => 'Privilege Redeem',
											'person_id' => NULL,
											'privilege_condition_id' => ($privilege_condition_id != '') ? $privilege_condition_id : NULL,
											'transaction_start_datetime' => $transaction_start_datetime,
											'transaction_end_datetime' => $transaction_end_datetime,
											'condition_status' => 'A'
										)
									)->row_array();
	
									$limit_privilege_maximum_redeem = intval($limit['limit_value']) - intval($privilege_total_redeem['privilege_total_redeem']);
	
									if($limit_privilege_maximum_redeem <= 0)
									{
										$limit_exceed_field = 'privilege_maximum_redeem';
										$limit_exceed_value = intval($limit['limit_value']);
										$limit_exceed_used = intval($privilege_total_redeem['privilege_total_redeem']);
	
										$limit_check_temp = false;
	
										break;
									}
								}
							}
						}
					}
					else if($limit['limit_level'] == 'Follower')
					{
						if($limit['limit_type'] == 'Maximum')
						{
							if($limit['limit_variable'] == 'Redeemed')
							{
								if($limit['limit_period'] != 'Time')
								{
									$follower_total_redeem = $this->PrivilegeModel->_get_member_privilege_limit(
										array(
											'type' => 'Follower Redeem',
											'person_id' => ($person_id != '') ? $person_id : NULL,
											'privilege_condition_id' => ($privilege_condition_id != '') ? $privilege_condition_id : NULL,
											'transaction_start_datetime' => $transaction_start_datetime,
											'transaction_end_datetime' => $transaction_end_datetime,
											'condition_status' => 'A'
										)
									)->row_array();

									$limit_follower_maximum_redeem = intval($limit['limit_value']) - intval($follower_total_redeem['follower_total_redeem']) - $privilege_follower;

									if($limit_follower_maximum_redeem <= 0)
									{
										$limit_exceed_field = 'follower_maximum_redeem';
										$limit_exceed_value = intval($limit['limit_value']);
										$limit_exceed_used = intval($follower_total_redeem['follower_total_redeem']);

										$limit_check_temp = false;

										break;
									}
								}
							}
							else if($limit['limit_variable'] == 'Free Usage')
							{
								if($limit['limit_period'] != 'Time')
								{
									$follower_total_free = $this->PrivilegeModel->_get_member_privilege_limit(
										array(
											'type' => 'Follower Free Usage',
											'person_id' => ($person_id != '') ? $person_id : NULL,
											'privilege_condition_id' => ($privilege_condition_id != '') ? $privilege_condition_id : NULL,
											'transaction_start_datetime' => $transaction_start_datetime,
											'transaction_end_datetime' => $transaction_end_datetime,
											'condition_status' => 'A'
										)
									)->row_array();

									$limit_follower_maximum_free_usage = intval($limit['limit_value']) - intval($follower_total_free['follower_total_free']);
									$limit_follower_maximum_free_usage = ($limit_follower_maximum_free_usage > 0) ? $limit_follower_maximum_free_usage : 0;
								}
							}
						}
					}

					if($limit_check == NULL)
					{
						$limit_check = $limit_check_temp;
					}
					else
					{
						$limit_check = ($limit_check && $limit_check_temp);
					}
				}

				if($limit_check == NULL)
				{
					$limit_check = $limit_check_temp;
				}
				else
				{
					$limit_check = ($limit_check && $limit_check_temp);
				}
			}
			else
			{
				$limit_check = true;
			}

			if($limit_check)
			{
				$data->status = 200;
				$data->limit = array(
					'member_maximum_free_usage' => $limit_member_maximum_free_usage,
					'follower_maximum_free_usage' => $limit_follower_maximum_free_usage
				);
			}
			else
			{
				$data->status = 500;
				$data->limit_exceed = array(
					'field' => $limit_exceed_field,
					'value' => $limit_exceed_value,
					'used' => $limit_exceed_used
				);
			}
		}
		catch(Exception $ex)
		{
			$data->status = 500;
			$data->message = $ex->getMessage();
		}

		return $data;
	}
}
