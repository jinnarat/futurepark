<?php
defined('BASEPATH') or exit('No direct script access allowed');

class RedemptionLib
{
	protected $ci;

	public function __construct()
	{
		$this->ci =& get_instance();
		$this->ci->load->model('RedemptionModel');
		$this->ci->load->model('Person_model', 'm_person');
		$this->ci->load->model('Redeem_model', 'm_redeem');
	}

	public function _redeem_point_limit($person_id, $mechanic_id, $item_id, $item_quantity , $datetime_now)
	{
		$data = new stdClass;
		try
		{
			$limit_check_temp = true;
			$limit_check = NULL;

			$limit_exceed_field = '';
			$limit_exceed_value = 0;
			$limit_exceed_used = 0;

			$redeem_point_limit = $this->ci->m_redeem->_get_redeem_point_limit(
				array(
					'type' => 'Redeem Point Limit',
					'mechanic_id' => $mechanic_id,
					'limit_status' => 'A'
				)
			);

			if($redeem_point_limit->num_rows() > 0)
			{
				foreach($redeem_point_limit->result_array() as $limit)
				{
					$transaction_start_datetime = NULL;
					$transaction_end_datetime = NULL;

					if($limit['limit_period'] == 'Day')
					{
						$transaction_start_datetime = date('Y-m-d', strtotime($datetime_now)) . ' 00:00:00';
						$transaction_end_datetime = date('Y-m-d', strtotime($datetime_now)) . ' 23:59:59';
					}
					else if($limit['limit_period'] == 'Month')
					{
						$transaction_start_datetime = date('Y-m-d', strtotime('first day of this month', strtotime($datetime_now))) . ' 00:00:00';
						$transaction_end_datetime = date('Y-m-d', strtotime('last day of this month', strtotime($datetime_now))) . ' 23:59:59';
					}
					else if($limit['limit_period'] == 'Period')
					{
						$_p =  $this->ci->m_redeem->_get_redeem_point_period(
							array(
								'type' => 'Get',
								'point_reference_1_id' => $mechanic_id
							)
						)->row_array();

						$transaction_start_datetime = $_p['activity_start_datetime'];
						$transaction_end_datetime = $_p['activity_end_datetime'];
					}

					if($limit['limit_level'] == 'Customer')
					{
						if($limit['limit_type'] == 'Maximum')
						{
							if($limit['limit_variable'] == 'Reward')
							{
								if($limit['limit_period'] != 'Time')
								{
									$customer_total_reward = $this->ci->m_redeem->_get_redeem_point_limit_customer_reward(
										array(
											'type' => 'Customer Maximum Reward',
											'person_id' => $person_id,
											'point_reference_1_id' => $mechanic_id,
											'point_reference_2_id' => NULL,
											'point_reference_3_id' => NULL,
											'point_reference_4_id' => $item_id,
											'point_status' => 'A'
										)
									)->row_array();

									$customer_total_reward = intval($customer_total_reward['customer_total_reward']);
								}
								else
								{
									$customer_total_reward = $item_quantity;
								}

								$limit_customer_maximum_reward = intval($limit['limit_value']) - $customer_total_reward;

								if($limit_customer_maximum_reward <= 0)
								{
									$limit_exceed_field = 'customer_maximum_reward';
									$limit_exceed_value = intval($limit['limit_value']);
									$limit_exceed_used = $customer_total_reward;

									$limit_check_temp = false;

									break;
								}
							}
						}
					}
					else if($limit['limit_level'] == 'Item')
					{
						if($limit['limit_type'] == 'Maximum')
						{
							if($limit['limit_variable'] == 'Reward')
							{
								if($limit['limit_period'] != 'Time')
								{
									$item_total_reward = $this->ci->m_redeem->_get_redeem_point_limit_item_reward(
										array(
											'type' => 'Item Maximum Reward',
											'point_reference_1_id' => $mechanic_id,
											'point_reference_2_id' => NULL,
											'point_reference_3_id' => NULL,
											'point_reference_4_id' => $item_id,
											'point_status' => 'A'
										)
									)->row_array();

									$item_total_reward = intval($item_total_reward['item_total_reward']);
								}
								else
								{
									$item_total_reward = $item_quantity;
								}

								$limit_item_maximum_reward = intval($limit['limit_value']) - $item_total_reward;

								if($limit_item_maximum_reward <= 0)
								{
									$limit_exceed_field = 'item_maximum_reward';
									$limit_exceed_value = intval($limit['limit_value']);
									$limit_exceed_used = $item_total_reward;

									$limit_check_temp = false;

									break;
								}
							}
						}
					}
				}
			}
			else
			{
				$limit_check = true;
			}

			if($limit_check)
			{
				$data->status = 200;
			}
			else
			{
				$data->status = 500;
				$data->limit_exceed = array(
					'field' => $limit_exceed_field,
					'value' => $limit_exceed_value,
					'used' => $limit_exceed_used
				);
			}
		}
		catch(Exception $ex)
		{
			$data->status = 500;
			$data->message = $ex->getMessage();
		}

		return $data;
	}
}
