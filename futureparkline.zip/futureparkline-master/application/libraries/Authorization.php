<?php
class Authorization {


    function get_token(){
        $this->load->library('oauth2');  
        $DATE_TIME = date("Y-m-d H:i:s");
		try{
			
            $token 		= trim($this->input->post('token'));
            $status 	= trim($this->input->post('status'));
			
			if($token == "")
			{
                $oauth = $this->oauth2->get_token();
                $decode_auth = json_decode($oauth);
                $access_token   = $decode_auth->access_token;
                $app_id         = $decode_auth->app_id;
                $expires_in     = $decode_auth->expires_in;
                $refresh_token  = $decode_auth->refresh_token;
                $token_type     = $decode_auth->token_type;
                $status         = 'Use';
                $starttime      = date("Y-m-d H:i:s");
                $endtime        = date('Y-m-d H:i:s', strtotime("+7 hours"));
                $pass           = 'Successfully';

                    $this->db->trans_start();
                    $dataInsert = array(					
                        'access_token' =>  $access_token ,
                        'app_id' => $app_id,
                        'expires_in' => $expires_in,
                        'refresh_token' => $refresh_token,
                        'token_type' => $token_type,
                        'status' => $status,
                        'starttime' => $starttime,
                        'endtime' => $endtime
                    );

                    $this->db->insert('log_token',$dataInsert);
                    
                    if(!$this->db->affected_rows()){
                        $this->db->trans_rollback();
                        $this->db->trans_complete();
                        $ERR_STATUS = 400; throw new exception('err write data into database');
                    }	
                    
                    $db_id	= $this->db->insert_id();
            }
            else{

                $rs = $this->Lists_model->select_token('Use')->result_array();
                // echo count($rs);
                if(count($rs) > 0){
                    foreach($rs as $r){
                        $token = htmlspecialchars_decode(trim($r['access_token']));
                        $dbid = htmlspecialchars_decode(trim($r['logId']));
                        $endtime = htmlspecialchars_decode(trim($r['endtime']));
                        $retoken = htmlspecialchars_decode(trim($r['refresh_token']));
                    }

                    if($DATE_TIME > $endtime){
                        $this->db->trans_start();
                        $dataUpdate = array(					
                            'status' => 'Expired'
                        );
                        $this->db->where(array('access_token = ' => $token,'logId = ' => $dbid));
                        $this->db->update('log_token',$dataUpdate);	
                        
                        if(!$this->db->affected_rows()){
                            $this->db->trans_rollback();
                            $this->db->trans_complete();
                            $ERR_STATUS = 400; throw new exception('err update data into database');
                        }	

                        $oauth = $this->oauth2->re_token($retoken);
                        $decode_auth = json_decode($oauth);

                        $access_token   = $decode_auth->access_token;
                        $app_id         = $decode_auth->app_id;
                        $expires_in     = $decode_auth->expires_in;
                        $refresh_token  = $decode_auth->refresh_token;
                        $token_type     = $decode_auth->token_type;
                        $status         = 'Use';
                        $starttime      = date("Y-m-d H:i:s");
                        $endtime        = date('Y-m-d H:i:s', strtotime("+7 hours"));
                        $pass           = 'Successfully';

                            $this->db->trans_start();
                            $dataInsert = array(					
                                'access_token' =>  $access_token ,
                                'app_id' => $app_id,
                                'expires_in' => $expires_in,
                                'refresh_token' => $refresh_token,
                                'token_type' => $token_type,
                                'status' => $status,
                                'starttime' => $starttime,
                                'endtime' => $endtime
                            );

                            $this->db->insert('log_token',$dataInsert);
                            
                            if(!$this->db->affected_rows()){
                                $this->db->trans_rollback();
                                $this->db->trans_complete();
                                $ERR_STATUS = 400; throw new exception('err write data into database');
                            }	
                            
                            $db_id	= $this->db->insert_id();

                    }else{
                        $pass = 'Unsuccessfully';
                        $access_token = '';
                        $refresh_token = '';
                        $token_type = '';
                    }

                }

                
            }
            
            $this->db->trans_complete();		
			if ($this->db->trans_status() === FALSE) {
				$this->db->trans_rollback();				
			} 
			else {
				$this->db->trans_commit();
			} 
			
			$dataRes	= array('STATUS' =>  $pass ,'TOKEN' => $access_token, 'RETOKEN' => $refresh_token, 'TYPE' => $token_type);

			
			// $dataRes['detail']	= $resObj;
			// $dataRes['status'] 	= array('STATUS' => 'Successfully');
			echo json_encode($dataRes);	
			
        
        }catch(exception $e){
            if($ERR_STATUS == 400)
            {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
			echo json_encode($Err);            
        }
    }
}
?>