<?php
class Sms {
	
	public function SendSMS($smstext=null, $mymobile=null){
		$mysmsmessage = urlencode($smstext);
		
		$smshost 	= SMSHOST;
		$smsuser 	= SMSUSER;
		$smspassword= SMSPASSWORD;
		$sendername	= SMSSENDER;
		
		$myurl = $smshost."/api/sendsms/plain?user=".$smsuser."&password=".$smspassword."&sender=".$sendername."&SMSText=".$mysmsmessage."&GSM=".$mymobile."&type=LongSMS&datacoding=8&encoding=UTF-8";
	   	
		$curl = curl_init();
		
		curl_setopt_array($curl, array(
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_URL => $myurl,
			CURLOPT_USERAGENT => 'SMS Alert Service'
		));		

		$resp = curl_exec($curl);	
		curl_close($curl);	
		return $resp;
	}		

	public function getResponseValue($value)
	{	

		switch($value){
			case "-1" :
				$status = "SEND_ERROR";
				$message = "Error in processing the request";
			break;
			case "-2" :
				$message = "Not enough credits on a specific account";
			break;
			case "-3" :
				$message = "Targeted network is not covered on specific account";
			break;
			case "-5" :
				$message = "Username or password is invalid";
			break;
			case "-6" :
				$message = "Destination address is missing in the request";
			break;
			case "-10" :
				$message = "Username is missing in the request";
			break;
			case "-11" :
				$message = "Password is missing in the request";
			break;
			case "-13" :
				$message = "Number is not recognized by Infobip platform";
			break;
			case "-22" :
				$message = "Incorrect XML format, caused by syntax error";
			break;
			case "-23" :
				$message = "General error, reasons may vary";
			break;
			case "-26" :
				$message = "General API error, reasons may vary";
			break;
			case "-27" :
				$message = "Invalid scheduling parametar";
			break;
			case "28" :
				$message = "Invalid PushURL in the request";
			break;
			case "-30" :
				$message = "Invalid APPID in the request";
			break;
			case "-33" :
				$message = "Duplicated MessageID in the request";
			break;
			case "-34" :
				$message = "Sender name is not allowed";
			break;
			case "-99" :
				$message = "Error in processing request, reasons may vary";
			break;
			case " " :
				$message = "Bad Request";
			break;
			default :
				$message = "Request was successful (all recipients)";
			break;
		}
		return $message;
	}
}

?>