<?php
class Oauth2 {
	
	public function SendSMS($smstext=null, $mymobile=null){
		$mysmsmessage = urlencode($smstext);
		
		$smshost 	= SMSHOST;
		$smsuser 	= SMSUSER;
		$smspassword= SMSPASSWORD;
		$sendername	= SMSSENDER;
		
		$myurl = $smshost."/sendsms/plain?user=".$smsuser."&password=".$smspassword."&sender=".$sendername."&SMSText=".$mysmsmessage."&GSM=".$mymobile."&type=LongSMS&datacoding=8&encoding=UTF-8";
		
        $curl = curl_init();
		curl_setopt_array($curl, array(
			CURLOPT_RETURNTRANSFER => 1,
			CURLOPT_URL => $myurl,
			CURLOPT_USERAGENT => 'SMS Alert Service'
		));		

		$resp = curl_exec($curl);	
		curl_close($curl);	
		return $resp;
    }	
    
    function get_token(){
        $curl = curl_init();
        $auth = base64_encode(CLIENTID.':'.CLIENTSECRET);

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/oauth2/token",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "grant type=token",
        // CURLOPT_POSTFIELDS => $type ,
        CURLOPT_HTTPHEADER => array(
            "Authorization: Basic ".$auth,
            "Content-Type: application/x-www-form-urlencoded"
        )
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return  $response;
    }

    function re_token($retoken=null){
        $curl = curl_init();
        $auth = base64_encode(CLIENTID.':'.CLIENTSECRET);

        curl_setopt_array($curl, array(
            CURLOPT_URL => OAUTHHOST."/oauth2/token",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => "grant type=refresh&refresh_token=".$retoken,
            CURLOPT_HTTPHEADER => array(
                "Authorization: Basic ".$auth,
                "Content-Type: application/x-www-form-urlencoded"
            )
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return  $response;
    }

    function send_OTP($token=null,$mobile_no=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/otp/send",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "chanel=sms&mobile_no=".$mobile_no."&source=FB-VEND-0001&type=verify_phone",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function SendOTP($token=null,$data=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/otp/send",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function verify_OTP($token=null,$phone=null,$otp=null,$ref=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/otp/verify",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "chanel=sms&mobile_no=".$phone."&otp=".$otp."&ref=".$ref."&source=FB-VEND-0001",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }
    
    function verify_OTP_Email($token=null,$mail=null,$otp=null,$ref=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/otp/verify",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "chanel=email&email=".$mail."&otp=".$otp."&ref=".$ref."&source=FB-VEND-0001",
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function check_status($token=null,$data=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/person/check_status",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function register($token=null,$data=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/person/register",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function update($token=null,$data=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => OAUTHHOST."/person/update_data",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_HTTPHEADER => array(
                "Authorization: Bearer ".$token,
                "Content-Type: application/x-www-form-urlencoded"
            ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function change_password($token=null,$data=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/person/change_password",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function login_verify($token=null,$data=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/person/verify",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        // $response = '{"response_body":{"message":"Register success."},"success":true}
        // Notice: Trying to access array offset on value of type bool in D:\www\api\app\Controllers\Person.php on line 1096';
        curl_close($curl);
        return $response;
    }

    function getProfile($token=null,$data=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/person/profile",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function UpdateAddress($token=null,$data=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/person/update_address",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function upload(){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/person/update_address",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "id=121623&address_id=121617&address_type=Current&address_no=283/1&province_code=10&district_code=1036&sub_district_code=103604&postcode=10210&session_id=MDg4ODU2NjA2OTE3Mzk5MDA1NTg4OTk%3D",
        CURLOPT_HTTPHEADER => array(
            "Content-Type: application/x-www-form-urlencoded",
            "Authorization: Bearer 3743f200bf1cf97a051f010d7ba75f1fb2ac23c12d321ba2cf88468d54f09fb9"
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

    function sendService($data=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => SENDCASE.'/CRMAPIForWeb/api/SendCase',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json'
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;

    }

    function check_line_id($token=null,$data=null){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => OAUTHHOST."/person/check_line_id",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_HTTPHEADER => array(
            "Authorization: Bearer ".$token,
            "Content-Type: application/x-www-form-urlencoded"
        ),
        ));

        $response = curl_exec($curl);
        curl_close($curl);
        return $response;
    }

}

?>