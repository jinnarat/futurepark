<link rel="stylesheet" href="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.css'); ?>">
<style>
    .his-img {
        border-radius: 5px 0 0 5px;
        height: -webkit-fill-available;
        width: auto
    }

    .his-box {
        height: 90px;
    }

    .panel-default>.panel-heading {
        border-radius: 5px;
        padding: 0px 10px;
    }

    .panel-title {
        font-size: 22px;
        text-align: left;
    }

    .panel {
        box-shadow: 4px 5px 5px grey;
    }

    .modal-dialog {
        margin-top: 0;
    }

    .header-logo {
        top: 0px;
    }

    #showCodeModal {
        overflow: auto !important;
    }

    @media (min-width: 300px) {
        .fa-clock {
            font-size: 8px !important;
        }

        img.card-img {
            max-width: 250px;
            /* max-height: 70px; */
            width: 100%;
            margin: 0 auto;
            vertical-align: middle;
        }

        .header-logo a img {
            width: 100%;
        }
    }

    @media (min-width: 768px) {
        .card-body {
            line-height: 1.6 !important;
        }

        .card-title {
            font-size: 25px;
        }

        .card-text {
            font-size: 20px;
        }

        .fa-clock {
            font-size: 8px;
        }

        img.card-img {
            max-width: 250px;
            /* max-height: 130px; */
            width: 100%;
            margin: 0 auto;
            vertical-align: middle;
        }

        .header-logo a img {
            width: 50%;
        }
    }

    @media (min-width: 1024px) {
        .card-body {
            line-height: 2 !important;
        }

        .card-title {
            font-size: 28px;
        }

        .card-text {
            font-size: 23px;
        }

        img.card-img {
            width: 100%;
            margin: 0 auto;
            vertical-align: middle;
        }
    }
</style>

<div class="container boxPage" dateNow="<?= $DATE_TIME; ?>">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>profile?c=<?php echo $person_id; ?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title"><b>ประวัติ (History) </b></p>
        </div>
    </div>
    <div>
        <?php echo $yearshow; ?>
    </div>
    <div class="top30">
        <?php echo $historyData; ?>
    </div>
</div>

<div class="modal fade" id="showCodeModal" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="filter-container-m"></div>
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
            </div>
            <div class="modal-body " style="background-color: #00c4b3;">
                <div class="row">
                    <div class="col-12 text-center text-white" id="usedDate"></div>
                    <div style="background-color: white;" class="col-12 text-center d-flex justify-content-center align-items-center hide-code-detail">
                        <strong id="textCode" class="p-5 my-0 h1 hide-code-detail"></strong>
                    </div>
                    <div class="col-12 mt-3 text-center hide-code-detail">
                        <img id="imgqrcodesrc" src="" alt="QRCODE" width="80%">
                    </div>
                    <div class="col-12 mt-3 text-center text-white countdown "></div>
                    <div class="col-12 mt-3 text-center text-white" id="timeout"></div>
                    <div class="col-12 mt-3 text-center text-white hide-code-detail">
                        <small>กรุณาแสดงรหัสที่ร้านค้า/เจ้าหน้าที่เพื่อรับสิทธิ์</small>
                    </div>
                    <div style="display: none;" class="col-12 mt-3 text-center text-white show-code-detail">
                        <hr style="border-top: 1px dashed white; margin-bottom: 0px;">
                        <small class="detail-btn">กรุณาแสดงรหัสที่ร้านค้า/เจ้าหน้าที่เพื่อรับสิทธิ์</small>
                        <button class="btn btn-light btn-check-out col-10 mt-3">เช็คเอาท์ (Check-Out)</button>
                    </div>
                    <div style="display: none;" class="col-12 mt-3 text-center text-white show-code-detail-staff">
                        <hr style="border-top: 1px dashed white; margin-bottom: 0px;">
                        <small class="detail-btn-staff">สำหรับเจ้าหน้าที่</small>
                        <button class="btn btn-light btn-staff col-10 mt-3">ใช้สิทธิ์ (สำหรับเจ้าหน้าที่กด)</button>
                    </div>
                    <div style="display: none;" class="col-12 mt-3 text-center text-white show-code-detail-shop">
                        <hr style="border-top: 1px dashed white; margin-bottom: 0px;">
                        <small class="detail-btn-shop">สำหรับเจ้าหน้าที่</small>
                        <button class="btn btn-light btn-shop col-10 mt-3">ใช้สิทธิ์ (สำหรับเจ้าหน้าที่กด)</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer modal-block">
                <button type="button" class="modal-checkout modal-close" data-dismiss="modal">ปิด</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal Promotion -->
<div class="modal fade" id="modalPromotion" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="modalPromotionLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalPromotionLabel">Promotion</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="alertPromotion"></div>
                <div class="form-group">
                    <label for="shopCode">รหัสร้านค้า *</label>
                    <input type="text" class="form-control" id="shopCode" placeholder="Shop Code">
                </div>
                <div class="form-group">
                    <label for="balance">จำนวนเงิน (บาท)</label>
                    <input type="text" class="form-control" id="balance" placeholder="Amount">
                </div>
                <div class="form-group">
                    <label for="voucher">รหัส Voucher</label>
                    <input type="text" class="form-control" id="voucher" placeholder="Voucher code">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="confirmUsePromotion" style="background-color: #00c4b3; border: 1px solid #27bdb2; border-radius: 4px; color: #ffffff; cursor: pointer; outline: none; padding: 5px 20px;">ยืนยัน</button>
                <button type="button" class="btn btn-primary modal-close" style="background-color: #fff; border: 1px solid #27bdb2; border-radius: 4px; color: #27bdb2; cursor: pointer; outline: none; padding: 5px 20px;" data-dismiss="modal">ปิด</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal Modal Staff -->
<div class="modal fade" id="modalStaff" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="modalStaffLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalStaffLabel">สำหรับเจ้าหน้าที่</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="alertStaff"></div>
                <div class="form-group">
                    <label for="staffCode">รหัสเจ้าหน้าที่ *</label>
                    <input type="text" class="form-control" maxlength="20" id="staffCode" require>
                </div>
                <div class="form-group">
                    <label for="remark">หมายเหตุ</label>
                    <textarea class="form-control" id="remark" rows="3"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="confirmUseStaff" style="background-color: #00c4b3; border: 1px solid #27bdb2; border-radius: 4px; color: #ffffff; cursor: pointer; outline: none; padding: 5px 20px;">ยืนยัน</button>
                <button type="button" class="btn btn-primary modal-close" style="background-color: #fff; border: 1px solid #27bdb2; border-radius: 4px; color: #27bdb2; cursor: pointer; outline: none; padding: 5px 20px;" data-dismiss="modal">ปิด</button>
            </div>
        </div>
    </div>
</div>
<!-- modalShop -->
<div class="modal fade" id="modalShop" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="modalShopLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalShopLabel">สำหรับเจ้าหน้าที่</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div id="alertShop"></div>
                <div class="form-group">
                    <label for="codeShop">รหัสร้านค้า *</label>
                    <input type="text" class="form-control" id="codeShop" placeholder="Shop Code">
                </div>
                <div class="form-group">
                    <label for="balanceShop">จำนวนเงิน (บาท)</label>
                    <input type="text" class="form-control" id="balanceShop" placeholder="Amount">
                </div>
                <div class="form-group">
                    <label for="voucherShop">รหัส Voucher</label>
                    <input type="text" class="form-control" id="voucherShop" placeholder="Voucher code">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" id="confirmUseShop" style="background-color: #00c4b3; border: 1px solid #27bdb2; border-radius: 4px; color: #ffffff; cursor: pointer; outline: none; padding: 5px 20px;">ยืนยัน</button>
                <button type="button" class="btn btn-primary modal-close" style="background-color: #fff; border: 1px solid #27bdb2; border-radius: 4px; color: #27bdb2; cursor: pointer; outline: none; padding: 5px 20px;" data-dismiss="modal">ปิด</button>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="alertModalHis" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="alertModalHisLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="alertModalHisLabel">แจ้งเตือน</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary modal-close" style="background-color: #fff; border: 1px solid #27bdb2; border-radius: 4px; color: #27bdb2; cursor: pointer; outline: none; padding: 5px 20px;" data-dismiss="modal">ปิด</button>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.js'); ?>"></script>


<script src="<?php echo base_url('assets/js/moment-with-locales.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/moment-countdown.js'); ?>"></script>
<script>
    var countDown = new CustomFunction();
    var baseurl = '<?php echo base_url(); ?>';
    var thisCardOpen = null;
    var nameBtn = null;
    $(document).ready(function() {
        $('.btn-back i').css("color", "");
        $('.btn-next i').css("color", "");
    });

    $(document).on('click', '.card-data-value', function() {
        let dateTimeNow = $('.boxPage').attr('datenow');
        let codeExpired = $(this).attr('codeExpired');
        dateTimeNow = moment();
        codeExpiredCheck = moment(codeExpired, 'YYYY-MM-DD HH:mm:ss');
        let thisCard = $(this);
        thisCardOpen = $(this);
        $('.detail-btn').show();
        let pId = $(this).find('#check-out-person').attr('pId');
        let pvId = $(this).find('#check-out-person').attr('pvId');
        let tierId = $(this).find('#check-out-person').attr('tierId');
        let mpt = $(this).find('#check-out-person').attr('mpt');
        let mpCode = $(this).find('#check-out-person').attr('mpCode');
        nameBtn = $(this).find('#check-out-person').attr('nameBtn');
        let btnDetail = $(this).find('#check-out-person').attr('btnDetail');
        let btnDisabled = Boolean($(this).find('#check-out-person').attr('btnDisabled'));
        let btnDisabledcheckout = Boolean($(this).find('#check-out-person').attr('btnDisabledcheckout'));
        let nameBtnStaff = $(this).find('#check-out-person').attr('nameBtnStaff');
        let nameBtnShop = $(this).find('#check-out-person').attr('nameBtnShop');
        $('.btn-check-out').removeAttr('disabled');
        if (btnDisabled) {
            $('.btn-check-out').hide();
            $('.show-code-detail-staff').hide();
            $('.detail-btn-staff').text('');
            $('.btn-staff').text('');
        }else {
            // $('.show-code-detail-staff').show();
            if (btnDisabledcheckout) {
                $('.show-code-detail').hide();
            }else {
                $('.show-code-detail').show();
                $('.btn-check-out').show();
                if (nameBtn) {
                    $('.detail-btn').text(btnDetail);
                    $('.btn-check-out').text(nameBtn);
                } else {
                    $('.detail-btn').text('');
                    $('.btn-check-out').text('เช็คเอาท์ (Check-Out)');
                }
            }
    
            if (nameBtnStaff) {
                $('.show-code-detail-staff').show();
                $('.detail-btn-staff').text(btnDetail);
                $('.btn-staff').text(nameBtnStaff);
            } else {
                $('.show-code-detail-staff').hide();
                $('.detail-btn-staff').text('');
                $('.btn-staff').text('');
            }
        }
        
        if (nameBtnShop) {
            $('.show-code-detail-shop').show();
            $('.detail-btn-shop').text(btnDetail);
            $('.btn-shop').text(nameBtnShop);
        } else {
            $('.show-code-detail-shop').hide();
            $('.detail-btn-shop').text('');
            $('.btn-shop').text('');
        }
        if (mpCode) {
            // if (btnDisabledcheckout) {
            //     $('.show-code-detail').hide();
            // }else {
            //     $('.show-code-detail').show();
            // }
            // $('.show-code-detail').show();
            $(document).on('click', '.btn-check-out', function() {
                if (nameBtn) {
                    $('#alertPromotion').html('');
                    $('#shopCode').val('');
                    $('#balance').val('');
                    $('#voucher').val('');
                    $('#modalPromotion .modal-title').html(btnDetail);
                    $("#modalPromotion").modal('show');
                } else {
                    $('.btn-check-out').attr('disabled', true);
                    checkout(mpCode, thisCard);
                }
            });
        } else {
            $('.show-code-detail').hide();
            $("#confirmModal").modal('hide');
        }
        $('.countdown').html('');
        let title = $(this).find('.card-title').text();
        let usedDate = $(this).find('.usedDate').text();
        let newDateMoment = moment(usedDate, 'DD/MM/YYYY HH:mm').locale('th').add(543, 'year').format('DD MMM YYYY HH:mm')
        let imgr = $(this).attr('imgr');
        let codeShow = $(this).attr('codeShow');

        $("#imgqrcodesrc").attr("src", imgr);
        $('#textCode').text(codeShow);
        $('#usedDate').text('ใช้เมื่อ : ' + newDateMoment);
        $('#showCodeModal .modal-header').text(title);
        countDown.countDownTime(codeExpired, '.countdown', null, '#timeout', null, null, thisCard);
        if (dateTimeNow > codeExpiredCheck) {
            $('#textCode').text('หมดอายุแล้ว');
            $('.detail-btn').hide();
            $("#imgqrcodesrc").attr("src", '');
            $("#imgqrcodesrc").hide();
            $(this).find(".use-code-text").hide();
            $(this).removeClass('card-data-value');
            // return false;
        } else {
            $("#imgqrcodesrc").show();
        }
        $('#showCodeModal').modal('show');
    });

    $(document).on('click', '#showCodeModal .modal-close', function() {
        countDown.clearCountDownTime();
    });
    // staff
    $(document).on('click', '.btn-staff', function() {
        $('#modalStaff').modal('show');
    });
    
    $(document).on('click', '#confirmUseStaff', function() {
        confirmUseStaff();
    });
    // end staff
    // shop
    $(document).on('click', '.btn-shop', function() {
        $('#modalShop').modal('show');
    });
    
    $(document).on('click', '#confirmUseShop', function() {
        confirmUseShop();
    });
    // end shop

    $(document).on('click', '.btn-back', function() {
        var yearToDay = $('#from').attr('y');
        $('.btn-back i').css("color", "#00B8AD");
        var yaerSearch = parseInt(yearToDay) - 1;
        getData(yaerSearch);
    });

    $(document).on('click', '.btn-next', function() {
        var yearToDay = $('#from').attr('y');
        $('.btn-next i').css("color", "#00B8AD");
        var yaerSearch = parseInt(yearToDay) + 1;
        getData(yaerSearch);
    });

    function getData(yaerSearch) {
        var years = encodeURIComponent(btoa(btoa(yaerSearch)));
        window.location.replace("profile/history?y=" + years);
    }

    function checkout(mpCode, element) {
        loading('show');
        $.ajax({
            type: "post",
            url: baseurl + 'Privilege/updateCheck_out',
            data: {
                mpCode: mpCode,
            },
            dataType: "json",
            success: function(response) {
                if (response.STATUS == 'Unsuccessfully') {
                    $("#alertModalHis .modal-title").empty().append('แจ้งเตือน');
                    $("#alertModalHis .modal-body").empty().append('<div class="text-center"> ' + response.message + ' </div>');
                    $('#showCodeModal').modal('hide');
                    $("#alertModalHis").modal('show');
                    loading('hide');
                } else {
                    $('#showCodeModal').modal('hide');
                    // $("#alertModalHis .modal-title").empty().append('แจ้งเตือน');
                    // $("#alertModalHis .modal-body").empty().append('<div class="text-center"> ' + response.message + ' </div>');
                    // $("#alertModalHis").modal('show');
                    $('.show-code-detail').hide();
                    element.find('.use-code-text').hide();
                    element.removeClass('card-data-value');
                    // location.reload();
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $("#confirmModal").modal('hide');
                $(".modal-title").empty().append('แจ้งเตือน');
                $("#alertModalHis .modal-body").empty().append('<div class="text-center"> ข้อมูลไม่ถูกต้องกรุณาลองใหม่อีกครั้ง </div>');
                $("#alertModalHis").modal('show');
                loading('hide');
            },
        }).done(() => {
            loading('hide');
        });
    }

    $(document).on('click', '#confirmUsePromotion', function() {
        usePromotion();
    });

    function usePromotion() {
        loading('show');
        let codeId = thisCardOpen.find('#check-out-person').attr('codeId');
        // return false;
        let shopCode = $('#shopCode').val();
        let balance = $('#balance').val();
        let voucher = $('#voucher').val();

        $.ajax({
            type: "post",
            url: baseurl + 'profile/updateActivityPromotion',
            data: {
                codeId: codeId,
                shopCode: shopCode,
                balance: balance,
                voucher: voucher,
            },
            dataType: "json",
            success: function(response) {
                if (response.error) {
                    $('#alertPromotion').html(`<div class="alert alert-warning alert-dismissible fade show" role="alert">
                    ${response.error}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    </div>`);
                    loading('hide');
                } else {
                    $('#alertPromotion').html('');
                    $("#modalPromotion").modal('hide');
                    $('#showCodeModal').modal('hide');
                    thisCardOpen.find('.use-code-text').hide();
                    thisCardOpen.removeClass('card-data-value');
                    loading('hide');
                    // location.reload();
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $("#confirmModal").modal('hide');
                $(".modal-title").empty().append('แจ้งเตือน');
                $("#alertModalHis .modal-body").empty().append('<div class="text-center"> ข้อมูลไม่ถูกต้องกรุณาลองใหม่อีกครั้ง </div>');
                $("#alertModalHis").modal('show');
                loading('hide');
            },
        });
    }

    function confirmUseStaff() {
        loading('show');
        // $('#btnSubmitStaffSave').attr('disabled', true);
        let code = $('#textCode').text();
        let staffCode = $('#staffCode').val();
        let remark = $('#remark').val();
        var param = {
            code: code,
            staffCode: staffCode,
            remark: remark,
        };
        let errorMsg = '';
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo base_url(); ?>privilege/updateStaff',
            data: param,
            success: function(respons) {
                if (respons.status == 'Successfully') {
                    $("#modalStaff").modal('hide');
                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        title: respons.message,
                        showConfirmButton: false,
                        timer: 1500
                    })
                    setTimeout(() => {
                        // location.reload();
                        // console.log('thisCardOpen',thisCardOpen.find('.card-data-value'));
                        $('#textCode').text('หมดอายุแล้ว');
                        $('.detail-btn').hide();
                        $("#imgqrcodesrc").attr("src", '');
                        $("#imgqrcodesrc").hide();
                        thisCardOpen.find(".use-code-text").hide();
                        thisCardOpen.removeClass('card-data-value');
                        $("#showCodeModal").modal('hide');
                        loading('hide');
                    }, 2000);
                } else {
                    errorMsg = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    ${respons.message}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>`;
                    // $('#btnSubmitStaffSave').removeAttr('disabled');
                    $('#alertStaff').html(errorMsg);
                    loading('hide');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                errorMsg = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
                                ${respons.message}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>`;
                $('#alertStaff').html(errorMsg);
                // $('#btnSubmitStaffSave').removeAttr('disabled');
                loading('hide');
            },
        })
    }
    
    function confirmUseShop() {
        loading('show');
        // $('#btnSubmitStaffSave').attr('disabled', true);
        let code = $('#textCode').text();
        let shopCode = $('#codeShop').val();
        let balance = $('#balanceShop').val();
        let voucher = $('#voucherShop').val();
        var param = {
            code: code,
            shopCode: shopCode,
            balance: balance,
            voucher: voucher,
        };
        let errorMsg = '';
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo base_url(); ?>privilege/updateShopCode',
            data: param,
            success: function(respons) {
                if (respons.status == 'Successfully') {
                    $('#textCode').text('หมดอายุแล้ว');
                    $('.detail-btn').hide();
                    $("#imgqrcodesrc").attr("src", '');
                    $("#imgqrcodesrc").hide();
                    thisCardOpen.find(".use-code-text").hide();
                    thisCardOpen.removeClass('card-data-value');
                    $("#modalStaff").modal('hide');
                    $("#modalShop").modal('hide');
                    $("#showCodeModal").modal('hide');
                    loading('hide');
                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        title: respons.message,
                        showConfirmButton: false,
                        timer: 1500
                    })
                } else {
                    errorMsg = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    ${respons.message}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>`;
                    // $('#btnSubmitStaffSave').removeAttr('disabled');
                    $('#alertShop').html(errorMsg);
                    loading('hide');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                errorMsg = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
                                ${respons.message}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>`;
                $('#alertShop').html(errorMsg);
                // $('#btnSubmitStaffSave').removeAttr('disabled');
                loading('hide');
            },
        })
    }


    function loading(action) {
        if (action == "show") {
            var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg') ?>'><div class='overlay'></div></div>";
            $("body").append(loading_component);
        } else if (action == "hide") {
            $("body .loading-component").remove();
        }
    }
</script>