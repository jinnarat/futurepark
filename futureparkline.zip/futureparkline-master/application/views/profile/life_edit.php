<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>profile/lifestyle">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title" id="head_page">ไลฟ์สไตล์ (Lifestyle)</p>
        </div>
    </div>
    <div class="accordion" id="CatLifestyle">

    </div>
    <div class="row my-5">
        <div class="col-12">
            <div class="row justify-content-center">
                <a class="btn btn-submit btn-save col-8" id="btnSubmit" onclick="SaveData()" href="javascript:void(0)">บันทึก (Save)</a>
            </div>
        </div>
    </div>
</div>

<script>
    var masterLifeStyle = [];
    var myLifeStyle = [];
    $(document).ready(function() {
        loading('show');
        getMaster();
    });

    function getMaster() {
        $.ajax({
            type: "get",
            url: "profile/getMasterLifeStyle",
            dataType: "json",
            success: function(response) {
                masterLifeStyle = response.masterLifeStyle;
                myLifeStyle = response.myLifeStyle;
                showLifeStyles(response.masterLifeStyle);
            },
            error: function(e) {
                loading('hide');
            }
        }).done(function() {
            loading('hide');
            activeLifeStyle();
        });
    }

    function showLifeStyles(master = []) {
        if (master.length > 0) {
            let mainHtml = '';
            let lifeStyleCatHtml = '';
            let lifeStyleSubCatHtml = '';
            let lifeStyleHtml = '';
            let arrayCategory = [];
            let arraySubCategory = [];
            let arrayLifeStyle = [];
            let countCol = 0;
            let countRowDetail = 1;

            let catSubCat = [];

            let masterCategory = uniqObjectArray(master, (it) => it.LifestyleCategoryID);
            let masterSubCategory = uniqObjectArray(master, (it) => it.LifestyleSubCategory1ID).filter(data => data.LifestyleSubCategory1ID);
            let masterLifeStyle = uniqObjectArray(master, (it) => it.LifestyleSubCategory2ID).filter(data => data.LifestyleSubCategory2ID);

            let catDetail = '';
            masterCategory.forEach((data, index) => {
                let activeMyLifeStyle = myLifeStyle.find(mydata => mydata.category_id == data.LifestyleCategoryID);
                let textSubCat = data.LifestyleCategoryDesc ? data.LifestyleCategoryDesc.length : 0;
                let actionShowSubDetail = '';
                if (data.LifestyleSubCategory1ID) {
                    actionShowSubDetail = `<i class="fas fa-caret-down collapseBtn fa-lg" data-toggle="collapse" data-target="#catLifestyle${data.LifestyleCategoryID}" href="" role="button" aria-expanded="true" aria-controls="catLifestyle${data.LifestyleCategoryID}" countRowDetail="${countRowDetail}"></i>`;
                }

                catSubCat.push({
                    cat: data.LifestyleCategoryID,
                    countRowDetail: countRowDetail,
                })


                let sizeCheckbox = '25px';
                if ($(window).width() >= 768) {
                    sizeCheckbox = '15px';
                }

                catDetail += `
                <div class="col-12 px-0">
                    <div class="collapse" id="catLifestyle${data.LifestyleCategoryID}" data-parent="#CatLifestyle">
                        <div class="card card-body">
                            <div class="accordion" id="accordionCat${data.LifestyleCategoryID}">
                            </div>
                        </div>
                    </div>
                </div>`;
                if (countCol >= 2) {
                    lifeStyleCatHtml += ` 
                        <div class="col-6 my-2">
                             <div class="btn btn-primary btn-block d-flex justify-content-between" style="white-space: normal; word-wrap: break-word;">
                                 <div class="form-check form-check-inline">
                                     <input class="form-check-input inputCat" onchange="clickCatBtnLifeStyle(${data.LifestyleCategoryID})" type="checkbox" catname="${data.LifestyleCategoryDesc}" id="inlineCheckbox${data.LifestyleCategoryID}" value="${data.LifestyleCategoryID}" ${textSubCat > 20 ? 'style="width: '+sizeCheckbox+'; height: '+sizeCheckbox+';"' : 'style="width: 15px; height: 15px;"'} >
                                     <label class="form-check-label" for="inlineCheckbox${data.LifestyleCategoryID}">${data.LifestyleCategoryDesc}</label>
                                 </div>
                                 ${actionShowSubDetail}
                             </div>
                         </div>
                    </div>
                    ${catDetail}`;
                    countCol = 0;
                    catDetail = '';
                    countRowDetail++;
                } else {
                    lifeStyleCatHtml += ` ${countCol == 0 ? '<div class="row">':''}
                    <div class="col-6 my-2">
                        <div class="btn btn-primary btn-block d-flex justify-content-between" style="white-space: normal; word-wrap: break-word;">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input inputCat" onchange="clickCatBtnLifeStyle(${data.LifestyleCategoryID})" type="checkbox" catname="${data.LifestyleCategoryDesc}" id="inlineCheckbox${data.LifestyleCategoryID}" value="${data.LifestyleCategoryID}" ${textSubCat > 20 ? 'style="width: '+sizeCheckbox+'; height: '+sizeCheckbox+';"' : 'style="width: 15px; height: 15px;"'} >
                                <label class="form-check-label" for="inlineCheckbox${data.LifestyleCategoryID}">${data.LifestyleCategoryDesc}</label>
                            </div>
                            ${actionShowSubDetail}
                        </div>
                    </div>`;
                    countCol += countCol == 0 ? 2 : 1;
                }
            })
            $('#CatLifestyle').html(lifeStyleCatHtml);

            let countSubCat = 0;
            masterSubCategory.forEach((data, index) => {
                let actionShowSubDetail = '';
                if (data.LifestyleSubCategory2ID) {
                    actionShowSubDetail = `<i class="fas fa-caret-down collapseBtn fa-lg" data-toggle="collapse" data-target="#collapseSubCat${data.LifestyleSubCategory1ID}" aria-expanded="true" aria-controls="collapseSubCat${data.LifestyleSubCategory1ID}"></i>`;
                }
                let findSubHtmlID = catSubCat.find(findData => findData.cat == data.LifestyleCategoryID)
                lifeStyleSubCatHtml = `
                    <div class="card subcat">
                        <div class="card-header" id="subCatheading${data.LifestyleSubCategory1ID}">
                            <h2 class="my-0 d-flex justify-content-between align-items-center">
                                <span>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input subcatInput" type="checkbox" id="subcatInput${data.LifestyleSubCategory1ID}" value="${data.LifestyleSubCategory1ID}" subname="${data.LifestyleSubCategory1Desc}" onchange="clickSubCatCheckbox(this)" style="width: 15px; height: 15px;">
                                        <label class="form-check-label" for="subcatInput${data.LifestyleSubCategory1ID}">${data.LifestyleSubCategory1Desc}</label>
                                    </div>
                                </span>
                                ${actionShowSubDetail}
                            </h2>
                        </div>
                        <div id="collapseSubCat${data.LifestyleSubCategory1ID}" class="collapse" aria-labelledby="subCatheading${data.LifestyleSubCategory1ID}" data-parent="#accordionCat${data.LifestyleCategoryID}">
                            <div class="card-body">
                                <div class="row lifeStyleDtail${data.LifestyleSubCategory1ID}">
                                </div>
                            </div>
                        </div>
                    </div>`;
                $(`#accordionCat${data.LifestyleCategoryID}`).append(lifeStyleSubCatHtml);
            })

            masterLifeStyle.forEach((data, index) => {
                let lifeStyleHtml = `
                <div class="col-xs-6 col-sm-6 col-md-4 col-lg-3">
                    <button type="button" class="btn btn-success d-flex align-items-center btnLifeStyle" onclick="clickSubBtnLifeStyle(this)" style="min-width: 100px;">
                        <i class="far fa-check-circle mr-1 activeLifeStyle" id="lifeStyle${data.LifestyleSubCategory2ID}" lifeval="${data.LifestyleSubCategory2ID}" lifename="${data.LifestyleSubCategory2Desc}" style="display: none;"></i>
                        <span> ${data.LifestyleSubCategory2Desc}</span>
                    </button>
                </div>`;
                $(`#catLifestyle${data.LifestyleCategoryID} .lifeStyleDtail${data.LifestyleSubCategory1ID}`).append(lifeStyleHtml);
            })
        } else {
            alert('ไม่พบข้อมูล');
        }

    }

    function activeLifeStyle() {

        let myLifeStyleCategory = uniqObjectArray(myLifeStyle, (it) => it.category_id);
        let myLifeStyleSubCategory = uniqObjectArray(myLifeStyle, (it) => it.sub_category_id).filter(data => data.sub_category_id);
        let myLifeStyleLifeStyle = uniqObjectArray(myLifeStyle, (it) => it.plf_id).filter(data => data.plf_id);
        let checkCat = [];
        let checkSubCat = [];
        let checkLifeStyle = [];
        myLifeStyle.forEach(data => {
            if (data.category_id) {
                if (!checkCat.includes(data.category_id)) {
                    $('#inlineCheckbox' + data.category_id).prop('checked', true);
                    checkCat.push(data.category_id);
                }
            }
            if (data.sub_category_id) {
                if (!checkSubCat.includes(data.sub_category_id)) {
                    $('#subcatInput' + data.sub_category_id).prop('checked', true);
                    checkSubCat.push(data.sub_category_id);
                }
            }
            if (data.lf_id) {
                if (!checkLifeStyle.includes(data.lf_id)) {
                    $('#lifeStyle' + data.lf_id).css('display', 'block');
                    checkLifeStyle.push(data.lf_id);
                }
            }
        })
    }

    function clickSubCatCheckbox(thisEvent) {
        let parentCard = $(thisEvent).parents('.subcat');
        let valueSubCat = $(thisEvent).val();
        let findMasterData = masterLifeStyle.find(data => data.LifestyleSubCategory1ID == valueSubCat)
        if ($(thisEvent).is(":checked") == true) {
            parentCard.find('.activeLifeStyle').css('display', 'block');
        } else {
            parentCard.find('.activeLifeStyle').css('display', 'none');
        }
        subCatCheckedCat(findMasterData.LifestyleCategoryID);
    }

    function clickCatBtnLifeStyle(catID) {
        let detailCat = $(`#catLifestyle${catID}`);
        let valueCehcked = $(`#inlineCheckbox${catID}`).is(":checked");
        let subCatID = detailCat.find('.subcatInput').val();
        if (valueCehcked == true) {
            if (subCatID) {
                detailCat.find('.subcatInput').prop('checked', true);
                detailCat.find(`.subcat .activeLifeStyle`).css('display', 'block');
            }
        } else {
            if (subCatID) {
                detailCat.find('.subcatInput').prop('checked', false);
                detailCat.find(`.subcat .activeLifeStyle`).css('display', 'none');
            }
        }
    }

    function clickSubBtnLifeStyle(thisEvent) {
        let parentCard = $(thisEvent).parents('.subcat');
        let subcatInput = parentCard.find('.subcatInput');
        let displayIcon = $(thisEvent).find('.activeLifeStyle').css('display');
        if (displayIcon == 'none') {
            $(thisEvent).find('.activeLifeStyle').css('display', 'block');
        } else {
            $(thisEvent).find('.activeLifeStyle').css('display', 'none');
        }
        checkbtnLifeStyleActive(subcatInput.val())
    }

    function checkbtnLifeStyleActive(subCatID) {
        let findMasterData = masterLifeStyle.find(data => data.LifestyleSubCategory1ID == subCatID)
        countActive = 0;
        $(`.lifeStyleDtail${subCatID} .activeLifeStyle`).each(function() {
            if ($(this).css('display') == 'block') {
                countActive++;
            }
        });
        if (countActive > 0) {
            $('#subcatInput' + subCatID).prop('checked', true);
            if (findMasterData) {
                subCatCheckedCat(findMasterData.LifestyleCategoryID);
            }
        } else {
            $('#subcatInput' + subCatID).prop('checked', false);
            if (findMasterData) {
                subCatCheckedCat(findMasterData.LifestyleCategoryID);
            }
        }
    }

    function subCatCheckedCat(catID) {
        let checkedSubCat = false;
        $(`#catLifestyle${catID} .subcat`).each(function() {
            if ($(this).find('.subcatInput').is(":checked")) {
                checkedSubCat = true;
            }
        });
        if (checkedSubCat) {
            $('#inlineCheckbox' + catID).prop('checked', true);
        } else {
            $('#inlineCheckbox' + catID).prop('checked', false);
        }
    }

    function uniqObjectArray(data, key) {
        if (data.length == 0 || !key) return [];
        return [...new Map(data.map((x) => [key(x), x])).values()];
    }

    function SaveData() {
        loading('show');
        let dataCatLifeStyle = [];
        $('.inputCat').each(function(index, element) {
            let catVal = $(element).val();
            let catName = $(element).attr('catname');
            let catChecked = $(element).is(":checked");
            if (catChecked) {
                let lifeStyleSubCatData = [];
                $(`#accordionCat${catVal} .subcatInput`).each(function(index, element) {
                    let subCatVal = $(element).val();
                    let subCatName = $(element).attr('subname');
                    let subCatChecked = $(element).is(":checked");
                    if (subCatChecked) {
                        let lifeStyleData = [];
                        $(`#catLifestyle${catVal} .lifeStyleDtail${subCatVal} .activeLifeStyle`).each(function(index, element) {
                            let lifeVal = $(element).attr('lifeval');
                            let lifeName = $(element).attr('lifename');
                            if ($(element).css('display') == 'block') {
                                lifeStyleData.push({
                                    cat: catVal,
                                    catName: catName,
                                    subCat: subCatVal,
                                    subCatName: subCatName,
                                    life: lifeVal,
                                    lifeName: lifeName,
                                })
                            }
                        });
                        if (lifeStyleData.length == 0) {
                            lifeStyleSubCatData.push({
                                cat: catVal,
                                catName: catName,
                                subCat: subCatVal,
                                subCatName: subCatName,
                                life: null,
                                lifeName: null,
                            });
                        } else {
                            lifeStyleData.forEach(data => {
                                lifeStyleSubCatData.push({
                                    cat: data.cat,
                                    catName: data.catName,
                                    subCat: data.subCat,
                                    subCatName: data.subCatName,
                                    life: data.life,
                                    lifeName: data.lifeName,
                                });
                            });
                        }
                    }
                });

                if (lifeStyleSubCatData.length == 0) {
                    dataCatLifeStyle.push({
                        cat: catVal,
                        catName: catName,
                        subCat: null,
                        subCatName: null,
                        life: null,
                        lifeName: null,
                    });
                } else {
                    lifeStyleSubCatData.forEach(data => {
                        dataCatLifeStyle.push({
                            cat: data.cat,
                            catName: data.catName,
                            subCat: data.subCat,
                            subCatName: data.subCatName,
                            life: data.life,
                            lifeName: data.lifeName,
                        });
                    });
                }
            }
        });

        let baseurl = '<?php echo base_url(); ?>';
        $.ajax({
            type: "post",
            url: "profile/postLifeStyle",
            data: {
                dataLifeStyle: JSON.stringify(dataCatLifeStyle)
            },
            dataType: "json",
            success: function(response) {
                if(response.success){
                    $("#alertModal .modal-title").empty().append('แจ้งเตือน');
                    $("#alertModal .modal-body").empty().append('<div class="text-center"> ' + response.success + ' </div>');
                    $("#alertModal").modal('show');
                    setTimeout(() => {
                        window.location.href = baseurl + 'profile/lifestyle';
                    }, 1000);
                }else {
                    $("#alertModal .modal-title").empty().append('แจ้งเตือน');
                    $("#alertModal .modal-body").empty().append('<div class="text-center"> ' + response.error + ' </div>');
                    $("#alertModal").modal('show');
                }
                
            },
            error: function(e) {
                loading('hide');
            }
        }).done(function() {
            loading('hide');
        });

    }

    function loading(action) {
        if (action == "show") {
            var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg') ?>'><div class='overlay'></div></div>";
            $("body").append(loading_component);
        } else if (action == "hide") {
            $("body .loading-component").remove();
        }
    }
</script>