<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>profile">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title">ไลฟ์สไตล์ (Lifestyle)</p>
        </div>
    </div>
    <div class="card-deck" id="lifeStyleContent">
    </div>
    <form name="form1" id="form1" novalidate enctype="multipart/form-data" method="post" pid="<?php echo $person_id; ?>" action="<?php echo $uri; ?>profile/editlifestyle">
        <div class="form-group top50">
            <div class="row justify-content-center">
                <button type="submit" class="btn btn-submit btn-edit col-8" id="btn-submit">เพิ่ม Lifestyle</button>
            </div>
        </div>

    </form>

</div>

<script>
    var myLifeStyle = [];
    $(document).ready(function() {
        loading('show');
        getDataLifeStyle();
    });

    function getDataLifeStyle() {
        $.ajax({
            type: "get",
            url: "profile/getMyLifeStyle",
            dataType: "json",
            success: function(response) {
                if (response.myLifeStyle.length > 0) {
                    myLifeStyle = response.myLifeStyle;
                    $('#btn-submit').html('แก้ไข (Edit)');
                }else {
                    $('#btn-submit').html('เพิ่ม Lifestyle');
                }
            },
            error: function(e) {
                console.log('error', e);
                loading('hide');
            }
        }).done(function() {
            loading('hide');
            showLifeStyle();
        });
    }

    function showLifeStyle() {
        let lifeStyleHtml = '';
        if (myLifeStyle.length > 0) {
            let Category = uniqObjectArray(myLifeStyle, (it) => it.category_id).filter(data => data.category_id);
            let SubCategory = uniqObjectArray(myLifeStyle, (it) => it.sub_category_id).filter(data => data.sub_category_id);
            let LifeStyle = uniqObjectArray(myLifeStyle, (it) => it.lf_id).filter(data => data.lf_id);

            Category.forEach(data => {
                let lifeStyleHtml = `
                <div class="col-sm-6 my-2 px-0">
                    <div class="card  mb-3 px-0" id="lifeStyleCat${data.category_id}">
                        <div class="card-header bg-transparent ">${data.category_name}</div>
                        <div class="card-body text-success lifeStyleSubCat" style="display:none">
                        </div>
                    </div>
                </div>`;
                $('#lifeStyleContent').append(lifeStyleHtml);
            });

            SubCategory.forEach(data => {
                let lifeStyleHtml2 = `
                <p class="card-text">${data.sub_category_name}</p>
                <div id="lifeStyleDetail${data.sub_category_id}">
                </div>`;
                $(`#lifeStyleCat${data.category_id} .lifeStyleSubCat`).css('display', 'block');
                $(`#lifeStyleCat${data.category_id} .lifeStyleSubCat`).append(lifeStyleHtml2);
            });

            LifeStyle.forEach(data => {
                let lifeStyleHtml3 = `<span class="badge badge-pill badge-dark" style="background-color: #00c4b3; font-size: 15px;">${data.plf_name}</span>`;
                $(`#lifeStyleDetail${data.sub_category_id}`).append(lifeStyleHtml3);
            });
        }
    }

    function uniqObjectArray(data, key) {
        if (data.length == 0 || !key) return [];
        return [...new Map(data.map((x) => [key(x), x])).values()];
    }

    function loading(action) {
        if (action == "show") {
            var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg') ?>'><div class='overlay'></div></div>";
            $("body").append(loading_component);
        } else if (action == "hide") {
            $("body .loading-component").remove();
        }
    }
</script>