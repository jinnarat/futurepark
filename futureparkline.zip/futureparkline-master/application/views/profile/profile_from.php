
<!-- Profile Management -->
<!-- <div class="page-header breadcamp"><?php echo anchor('cmsbackend/commu/commu_list', 'Communication')." > Profile Management "?></div>	 -->

<link rel="stylesheet" href="<?php echo $uri; ?>assets/owl/owl.carousel.css?v=<?php echo date('mis'); ?>" />
<link rel="stylesheet" href="<?php echo $uri; ?>assets/owl/owl.carousel.min.css?v=<?php echo date('mis'); ?>" />
	
<script type="text/javascript" src="<?php echo $uri; ?>assets/owl/owl.carousel.min.js?v=<?php echo date("YmdHis")?>"></script>
<script type="text/javascript" src="<?php echo $uri; ?>assets/owl/owl.carousel.js?v=<?php echo date("YmdHis")?>"></script>

<div class="container boxPage">
    <div id="body-content">

        <!-- <div>
            <a href="<?php echo $uri; ?>">
                <img src="<?php echo $uri . "assets/images/icons/set_home.png?v=".date('his')."" ?>" alt=" " class="responsive top10">
            </a>
        </div> -->
        <div class="row">
            <div class="col-1">
                <a href="<?php echo $uri; ?>">
                    <i class="fa fa-chevron-left"></i>
                </a>
            </div>
            <div class="col-10">
                <p class="text-title"><b>ข้อมูลของคุณ</b></p>
            </div>
        </div>
        <div class="text-center top50">
            <!-- <a href="<?php echo $uri; ?>privilege/cardDetail">
                <img src="<?php echo $uri . "assets/images/bg/Future-card.png?v=".date('his')."" ?>" alt=" " class="responsive top10">
                <p class="top20"><?php echo $point_balance; ?> คะแนน (Point)</p>
            </a> -->
            <!-- <div class="main-content">
                <div class="nav-position">
                    <div class="owl-carousel owl-theme">
                                <?php
                                    if(count($img_slider) > 0){
                                        $dataList = $img_slider;
                                        for($i = 0; $i < count($img_slider);$i++) {
                                            echo $dataList[$i];
                                        }
                                    }
                                ?>
                    </div>
                    
                    <div class="owl-theme">
                        <div class="owl-controls">
                            <div class="custom-nav owl-nav"></div>
                        </div>
                    </div>
                </div>
            </div> -->
            <div class="text-center">
                <?php echo $memberNo; ?>
            </div>
            <div class="item">
                <?php echo $imgCard; ?>
            </div>

            <!-- <div class="owl-carousel owl-theme"> -->
                <!-- <div class="item"><img src="<?php echo $uri . "assets/images/bg/Future-card.png?v=".date('his')."" ?>" alt=" " class="responsive top10"></div> -->
                <!-- <div class="item">
                        <div class="row">
                            <?php echo $imgBadge; ?>
                        </div>
                </div>
            </div> -->

            <div class="owl-theme">
                <div class="owl-controls">
                    <!-- <div class="custom-nav owl-nav"></div> -->
                    <div class="owl-dots"></div>
                </div>
            </div>

            <p class="top20"><?php echo $point_balance; ?> คะแนน (Point)</p>

        </div>
        <div class="row top50" id="btn-basic">
            <div class="col-10">
                <a href="<?php echo $uri; ?>profile/basic/?c=<?php echo $person_id; ?>" id="btn-basic">
                    ข้อมูลส่วนตัว (Profile)
                </a>
            </div>
            <div class="col-2 text-right">
                <a href="<?php echo $uri; ?>profile/basic/?c=<?php echo $person_id; ?>">
                    <i class="fa fa-chevron-right"></i>
                </a>
            </div>
        </div>
        <div class="row top20">
            <div class="col-10">
                <a href="<?php echo $uri; ?>profile/contact">
                    ข้อมูลติดต่อ (Contact)
                </a>
            </div>
            <div class="col-2 text-right">
                <a href="<?php echo $uri; ?>profile/contact">
                    <i class="fa fa-chevron-right"></i>
                </a>
            </div>
        </div>
        <!-- <div class="row top20">
            <div class="col-10">
                <a href="<?php echo $uri; ?>profile/info">
                    ข้อมูลพื้นฐาน (Personal Details)
                </a>
            </div>
            <div class="col-2 text-right">
                <a href="<?php echo $uri; ?>profile/info">
                    <i class="fa fa-chevron-right"></i>
                </a>
            </div>
        </div> -->
        <div class="row top20">
            <div class="col-10">
                <a href="<?php echo $uri; ?>profile/lifestyle">
                    ไลฟ์สไตล์ (Lifestyle)
                </a>
            </div>
            <div class="col-2 text-right">
                <a href="<?php echo $uri; ?>profile/lifestyle">
                    <i class="fa fa-chevron-right"></i>
                </a>
            </div>
        </div>
        <div class="row top20">
            <div class="col-10">
                <a href="<?php echo $uri; ?>profile/history">
                    ประวัติ (History) 
                </a>
            </div>
            <div class="col-2 text-right">
                <a href="<?php echo $uri; ?>profile/history">
                    <i class="fa fa-chevron-right"></i>
                </a>
            </div>
        </div>
        <div class="row top20">
            <div class="col-10">
                <a href="<?php echo $uri; ?>profile/changepassword">
                    เปลี่ยนรหัสผ่าน (Change Password)
                </a>
            </div>
            <div class="col-2 text-right">
                <a href="<?php echo $uri; ?>profile/changepassword">
                    <i class="fa fa-chevron-right"></i>
                </a>
            </div>
        </div>
        <div class="row top20">
            <div class="col-10">
                <a href="<?php echo $uri; ?>profile/badge">
                สะสม Badge
                </a>
            </div>
            <div class="col-2 text-right">
                <a href="<?php echo $uri; ?>profile/badge">
                    <i class="fa fa-chevron-right"></i>
                </a>
            </div>
        </div>
        <div class="row top20">
            <div class="col-10">
                <a href="<?php echo $uri; ?>profile/logout">
                    ออกจากระบบ (Log out)
                </a>
            </div>
            <div class="col-2 text-right">
                <a href="<?php echo $uri; ?>profile/logout">
                    <i class="fa fa-chevron-right"></i>
                </a>
            </div>
        </div>

    </div>
</div>

<style>
.box{
    background: #00B8AD;
    box-shadow: 1px 1px 3px rgba(0, 0, 0, 0.15);
    border: 2px solid #00B8AD;
    width: 50%;
    box-sizing: border-box;
    height: 90px;
    padding: px;
    padding-top: 36px;
    border-radius: 10px;

}

/* .owl-dots {
    text-align: center;
    position: fixed;
    bottom: 5px;
    width: 100%;
    -webkit-backface-visibility: hidden;
    -moz-backface-visibility: hidden;
    -ms-backface-visibility: hidden;
    backface-visibility: hidden;
}

.owl-dot {
    border-radius: 50px;
    height: 10px;
    width: 10px;
    display: inline-block;
    background: rgba(127,127,127, 0.5);
    margin-left: 5px;
    margin-right: 5px;
}

.owl-dot.active {
    background: rgba(127,127,127, 1);
} */

/* .owl-dot{
    background: #31d2c6 !important;
    border: #31d2c6 !important;
    font: inherit;
    width: 13px;
    height: 13px;
    border-radius: 100%;
    margin: 5px;
} */
</style>

<script>

    $( document ).ready(function() {
        $('.owl-carousel').owlCarousel({
            loop:true,
            margin:2,
            responsiveClass:true,
            // nav:true,
            // navContainer: '.custom-nav',
            dots: true,
            responsive:{
                0:{
                    items:1,
                    // nav:true
                },
                600:{
                    items:3,
                    nav:false
                },
                1000:{
                    items:5,
                    nav:true,
                    loop:false
                }
            }
        })
    });
    // $('.main-content .owl-carousel').owlCarousel({
	// 	center: true,
	// 	loop: true,
	// 	margin: 2,
	// 	//   nav:true,
	// 		navContainer: '.main-content .custom-nav',
	// 		responsive:{
	// 			0:{
	// 				items:3,
					
	// 			},
	// 			600:{
	// 				items:3
	// 			},
	// 			1000:{
	// 				items:3
	// 			}
	// 		}
	// 	})
</script>
