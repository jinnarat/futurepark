<!-- Basic information -->
<link rel="stylesheet" href="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.css'); ?>">
<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>profile?c=<?php echo $param; ?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title"><b>ข้อมูลส่วนตัว (Profile)</b></p>
        </div>
    </div>
    <div>
        <div id="body-content">
            <form name="formBasicdata" id="formBasicdata" novalidate enctype="multipart/form-data" onsubmit="return chkForm()" method="post" action="" pid="<?php echo $person_id; ?>">
            </form>
        </div>
    </div>
    <div class="row" id="edit-profile" style="display: none;">
        <div class="col-12 my-2">
            <label>ชื่อ (First Name)</label>
            <input class="form-control form-control-sm boxInput" type="text" name="fname" id="fname" placeholder="">
        </div>
        <div class="col-12 my-2">
            <label>นามสกุล (Last Name)</label>
            <input class="form-control form-control-sm boxInput" type="text" name="lname" id="lname" placeholder="">
        </div>
    </div>
    <div class="row">
        <div class="col-12 text-center mt-5">
            <button id="btnEdit" onclick="getMember()" class="btn btn-submit" style="display: none;">แก้ไข (Edit)</button>
            <button id="btnSave" onclick="saveMember()" class="btn btn-submit" style="display: none;">บันทึก (Save)</button>
        </div>
    </div>
</div>
<script src="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.js'); ?>"></script>
<script src="<?php echo base_url("assets/js/bootstrap-birthday.js?v=" . date("YmdHis")) ?>"></script>
<script>
    var fname = '';
    var lname = '';
    var pid = '';
    var session = '';
    $(document).ready(function() {
        memberProfile();
        loading('show');
    });

    $(document).on('click', '.btn-edit', function() {
        editProfile('Edit');
        loading('show');
    });

    $(document).on('click', '.btn-save', function() {
        updateProfile();
        loading('show');
    });

    function isTypeOfUndefined(e) {
        if (typeof e === 'undefined') {
            return e = "";
        }
        return e;
    }

    function memberProfile() {
        var dataHtml = '';
        var p_id = $("#formBasicdata").attr("pid");
        var param = {
            p_id: p_id
        };
        // loadingPage('#load_page');
        $.ajax({
            url: '<?php echo $uri; ?>chkIdentity/fprofile.html?v=1.0' + Math.random()
        }).done(function(HeaderHtml) {
            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: '<?php echo $uri; ?>Fncauth/getDataMem',
                // data: DataRef,
                data: param,
                success: function(e) {
                    if (e.status.STATUS == 'Unsuccessfully') {
                        let personData = JSON.parse(JSON.stringify(<?= $personData ? json_encode($personData) : null; ?>));
                        if (personData) {
                            var ID = isTypeOfUndefined(personData.personId);
                            var tmpFirstname = isTypeOfUndefined(personData.firstname);
                            var tmpLastname = isTypeOfUndefined(personData.lastname);
                            var tmpBirthdate = isTypeOfUndefined(personData.birthdate);
                            var tmpEmail = isTypeOfUndefined(personData.email);
                            var tmpGenderM = isTypeOfUndefined(personData.gender == 'M' ? 'checked' : '');
                            var tmpGenderF = isTypeOfUndefined(personData.gender == 'F' ? 'checked' : '');
                            var tmpIdCardNo = isTypeOfUndefined(personData.idCardNo);
                            var SUB = isTypeOfUndefined(personData.preferredChannel ? true : false);
                            var tmpNationCode = isTypeOfUndefined(personData.nationCode == 'TH' ? 'Thai' : personData.nationCode);
                            var tmpPassportNo = isTypeOfUndefined(personData.passportNo ? personData.passportNo : '');
                            var tmpphone = isTypeOfUndefined(personData.mobileNo);
                            var tmpsession = isTypeOfUndefined(personData.session_id);

                            const date = new Date(tmpBirthdate)
                            const birthdate = date.toLocaleDateString('th-TH', {
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric',
                            })

                            if (isEmpty(tmpGenderM)) {
                                gender = '<p class="input-view">หญิง</p>';
                            } else {
                                gender = '<p class="input-view">ชาย</p>';
                            }

                            if (tmpIdCardNo) {
                                textShow = 'เลขบัตรประชาชน (ID Card No.)';
                                result = tmpIdCardNo;
                            } else {
                                textShow = 'เลขหนังสือเดือนทาง (Passport No.)';
                                result = tmpPassportNo;
                            }

                            var mapObj = {
                                '<%Id%>': ID,
                                '<%InputFirstname%>': tmpFirstname,
                                '<%InputLastname%>': tmpLastname,
                                '<%InputBirthdate%>': birthdate,
                                '<%InputIdCard%>': tmpIdCardNo,
                                '<%InputPassport%>': tmpPassportNo,
                                '<%InputNation%>': tmpNationCode,
                                '<%InputEmail%>': tmpEmail,
                                '<%phone%>': tmpphone,
                                '<%checkM%>': tmpGenderM,
                                '<%checkF%>': tmpGenderF,
                                '<%InputGender%>': gender,
                                '<%session%>': tmpsession,
                                '<%textShow%>': textShow,
                                '<%InputResult%>': result
                            }

                            dataHtml = HeaderHtml.replace(/<%Id%>|<%InputFirstname%>|<%InputLastname%>|<%InputBirthdate%>|<%InputIdCard%>|<%InputPassport%>|<%InputNation%>|<%InputEmail%>|<%phone%>|<%checkM%>|<%checkF%>|<%session%>|<%InputGender%>|<%textShow%>|<%InputResult%>/gi, function(matched) {
                                return mapObj[matched];
                            });
                            $("#body-content").empty().html(dataHtml);
                            $('#national').empty().html('<option value="" >' + tmpNationCode + '</option>');
                            // $('#birthdate').bootstrapBirthday();
                            // $('#birthDay').val(e.detail.birthDay);
                            // $('#birthMonth').val(e.detail.birthMonth);
                            // $('#birthYear').val(e.detail.birthYear);
                            $(".img-footer").css("position", "relative");
                            loading('hide');
                            $(".block-profile").empty();
                        }
                    } else {
                        // loadingPage('#load_page');
                        var ID = isTypeOfUndefined(e.detail.ID);
                        var tmpFirstname = isTypeOfUndefined(e.detail.FIRST);
                        var tmpLastname = isTypeOfUndefined(e.detail.LAST);
                        var tmpBirthdate = isTypeOfUndefined(e.detail.BIRTH);
                        var tmpEmail = isTypeOfUndefined(e.detail.EMAIL);
                        var tmpGenderM = isTypeOfUndefined(e.detail.GENDERM);
                        var tmpGenderF = isTypeOfUndefined(e.detail.GENDERF);
                        var tmpIdCardNo = isTypeOfUndefined(e.detail.IDCARD);
                        var SUB = isTypeOfUndefined(e.detail.SUB);
                        var tmpNationCode = isTypeOfUndefined(e.detail.NATIONAL);
                        var tmpPassportNo = isTypeOfUndefined(e.detail.PASSPORT ? e.detail.PASSPORT : '');
                        var tmpphone = isTypeOfUndefined(e.detail.PHONE);
                        var tmpsession = isTypeOfUndefined(e.detail.session_id);

                        const date = new Date(tmpBirthdate)
                        const birthdate = date.toLocaleDateString('th-TH', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                        })

                        if (isEmpty(tmpGenderM)) {
                            gender = '<p class="input-view">หญิง</p>';
                        } else {
                            gender = '<p class="input-view">ชาย</p>';
                        }

                        if (tmpIdCardNo) {
                            textShow = 'เลขบัตรประชาชน (ID Card No.)';
                            result = tmpIdCardNo;
                        } else {
                            textShow = 'เลขหนังสือเดือนทาง (Passport No.)';
                            result = tmpPassportNo;
                        }

                        var mapObj = {
                            '<%Id%>': ID,
                            '<%InputFirstname%>': tmpFirstname,
                            '<%InputLastname%>': tmpLastname,
                            '<%InputBirthdate%>': birthdate,
                            '<%InputIdCard%>': tmpIdCardNo,
                            '<%InputPassport%>': tmpPassportNo,
                            '<%InputNation%>': tmpNationCode,
                            '<%InputEmail%>': tmpEmail,
                            '<%phone%>': tmpphone,
                            '<%checkM%>': tmpGenderM,
                            '<%checkF%>': tmpGenderF,
                            '<%InputGender%>': gender,
                            '<%session%>': tmpsession,
                            '<%textShow%>': textShow,
                            '<%InputResult%>': result
                        }

                        dataHtml = HeaderHtml.replace(/<%Id%>|<%InputFirstname%>|<%InputLastname%>|<%InputBirthdate%>|<%InputIdCard%>|<%InputPassport%>|<%InputNation%>|<%InputEmail%>|<%phone%>|<%checkM%>|<%checkF%>|<%session%>|<%InputGender%>|<%textShow%>|<%InputResult%>/gi, function(matched) {
                            return mapObj[matched];
                        });

                        $("#body-content").empty().html(dataHtml);
                        $('#national').empty().html('<option value="" >' + tmpNationCode + '</option>');
                        // $('#birthdate').bootstrapBirthday();
                        // $('#birthDay').val(e.detail.birthDay);
                        // $('#birthMonth').val(e.detail.birthMonth);
                        // $('#birthYear').val(e.detail.birthYear);
                        $(".img-footer").css("position", "relative");
                        loading('hide');
                        $(".block-profile").empty();
                        // $(".card-mform").removeClass('d-none');
                        // if (typeof pid != 'undefined') {
                        // 	getPersonData(pid);
                        // }
                        // if (e.dataobj.PERSID != "") {
                        // 	getPersonData(e.dataobj.PERSID);
                        // }
                    }
                },
                error: function(error) {
                }
            }).done(() => {
                $('#btnEdit').show();
                $('#btnSave').hide();
            })
        });
    }

    function getMember() {
        loading('show');
        let p_id = $("#formUpload").attr("pid");
        $.ajax({
            type: "POST",
            url: '<?php echo $uri; ?>Fncauth/getDataMem',
            data: {
                p_id: p_id
            },
            dataType: "JSON",
            success: function(response) {
                if (response.status.STATUS == 'successfully') {
                    fname = response.detail.FIRST;
                    $('#fname').val(fname);
                    lname = response.detail.LAST;
                    $('#lname').val(lname);
                    pid = response.detail.ID;
                    session = response.detail.session_id;
                    $('#body-content').hide();
                    $('#edit-profile').show();
                } else {

                }

            },
            error: function(error) {
            }
        }).done(() => {
            $('#btnSave').show();
            $('#btnEdit').hide();
            loading('hide');
        });
    }

    function saveMember() {
        loading('show');
        $('#btnSave').attr('disabled', true);
        fname = $('#fname').val();
        lname = $('#lname').val();
        $.ajax({
            type: "post",
            url: '<?php echo $uri; ?>Fncauth/update_data',
            data: {
                pid: pid,
                session: session,
                firstname: fname,
                lastname: lname,
            },
            dataType: "json",
            success: function(response) {
                if (response.status.STATUS == 'successfully') {
                    location.reload();
                } else {
                    loading('hide');
                    $('#btnSave').removeAttr('disabled');
                    Swal.fire({
                        position: 'center',
                        icon: 'warning',
                        title: 'แจ้งเตือน',
                        text: response.status.error,
                    })
                }
            }
        });
    }

    function editProfile() {
        $('#f_name').removeAttr("disabled");
        $('#l_name').removeAttr("disabled");
        $('#Male').removeAttr("disabled");
        $('#Female').removeAttr("disabled");
        $('#idcard').removeAttr("disabled");
        $('#passport').removeAttr("disabled");
        $('#national').removeAttr("disabled");
        // $('#f_name').removeAttr("disabled")
        // $('#f_name').removeAttr("disabled");

        // $.ajax({
        //     data: '',
        //     method: "post",
        //     datatype: "json",
        //     url: '<?php echo $uri; ?>Fncauth/get_nation',
        // }).done(function (e) {
        //     $('#national').html(jQuery.parseJSON(e));
        //     loading('hide');
        // })

        // $('#head_page').empty().append('แก้ไขข้อมูลส่วนตัว');
        // $(".btn-center").empty().html('<a id="btnSubmit" class="btn btn-submit btn-save" href="javascript:void(0)">บันทึก (Save)</a>');
        var dataHtml = '';

        var p_id = $("#formUpload").attr("pid");
        var param = {
            p_id: p_id
        };
        // loadingPage('#load_page');
        $.ajax({
            url: '<?php echo $uri; ?>chkIdentity/fprofileEdit.html?v=1.0' + Math.random()
        }).done(function(HeaderHtml) {

            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: '<?php echo $uri; ?>Fncauth/getDataMem',
                // data: DataRef,
                data: param,
                success: function(e) {
                    // loadingPage('#load_page');
                    var ID = isTypeOfUndefined(e.detail.ID);
                    var tmpFirstname = isTypeOfUndefined(e.detail.FIRST);
                    fname = tmpFirstname;
                    var tmpLastname = isTypeOfUndefined(e.detail.LAST);
                    lname = tmpLastname;
                    var tmpBirthdate = isTypeOfUndefined(e.detail.BIRTH);
                    var tmpEmail = isTypeOfUndefined(e.detail.EMAIL);
                    var tmpGenderM = isTypeOfUndefined(e.detail.GENDERM);
                    var tmpGenderF = isTypeOfUndefined(e.detail.GENDERF);
                    var tmpIdCardNo = isTypeOfUndefined(e.detail.IDCARD);
                    var SUB = isTypeOfUndefined(e.detail.SUB);
                    var tmpNationCode = isTypeOfUndefined(e.detail.NATIONAL);
                    var tmpPassportNo = isTypeOfUndefined(e.detail.PASSPORT);
                    var tmpphone = isTypeOfUndefined(e.detail.PHONE);
                    var tmpsession = isTypeOfUndefined(e.detail.session_id);

                    if (isEmpty(tmpPassportNo)) {
                        textShow = 'เลขบัตรประชาชน (ID Card No.)';
                        result = tmpIdCardNo;
                    } else {
                        textShow = 'เลขหนังสือเดือนทาง (Passport No.)';
                        result = tmpPassportNo;
                    }

                    var mapObj = {
                        '<%Id%>': ID,
                        '<%InputFirstname%>': tmpFirstname,
                        '<%InputLastname%>': tmpLastname,
                        '<%InputBirthdate%>': tmpBirthdate,
                        '<%InputIdCard%>': tmpIdCardNo,
                        '<%InputPassport%>': tmpPassportNo,
                        '<%InputNation%>': tmpNationCode,
                        '<%InputEmail%>': tmpEmail,
                        '<%phone%>': tmpphone,
                        '<%checkM%>': tmpGenderM,
                        '<%checkF%>': tmpGenderF,
                        '<%session%>': tmpsession,
                        '<%textShow%>': textShow,
                        '<%InputResult%>': result
                    }

                    dataHtml = HeaderHtml.replace(/<%Id%>|<%InputFirstname%>|<%InputLastname%>|<%InputBirthdate%>|<%InputIdCard%>|<%InputPassport%>|<%InputNation%>|<%InputEmail%>|<%phone%>|<%checkM%>|<%checkF%>|<%session%>|<%textShow%>|<%InputResult%>/gi, function(matched) {
                        return mapObj[matched];
                    });

                    $("#body-content").empty().html(dataHtml);
                    $('#national').empty().html('<option value="" >' + tmpNationCode + '</option>');
                    $('#birthdate').bootstrapBirthday();
                    $('#birthDay').val(e.detail.birthDay);
                    $('#birthMonth').val(e.detail.birthMonth);
                    $('#birthYear').val(e.detail.birthYear);
                    $(".img-footer").css("position", "relative");

                    loading('hide');



                    $(".block-profile").empty();
                    // $(".card-mform").removeClass('d-none');

                    // if (typeof pid != 'undefined') {
                    // 	getPersonData(pid);
                    // }
                    // if (e.dataobj.PERSID != "") {
                    // 	getPersonData(e.dataobj.PERSID);
                    // }
                },
                error: function(error) {
                }
            })
        });

    }

    loading('hide');

    function changeGender() {
        $('input[type=radio]').removeAttr('checked');
        var data = $('input[name="gender"]:checked').val();

        if (data == 'Female') {
            $('#Female').attr('checked', true);
        } else if (data == 'Male') {
            $('#Male').attr('checked', true);
        }

    }

    function updateProfile() {
        var fname = $('#f_name').val();
        var lname = $('#l_name').val();
        var idcard = $('#idcard').val();
        var passport = $('#passport').val();
        var national = $('#national').val();
        var birth = $('#birthdate').val();
        var session = $('#formUpload').attr('session');
        var pid = $('#formUpload').attr('pid');
        var gender = $('input[name="gender"]:checked').val();

        var param = {
            pid: pid,
            session: session,
            firstname: fname,
            lastname: lname,
            idcard: idcard,
            gender: gender,
            national: national,
            passport: passport,
            birth: birth
        };

        $.ajax({
            data: param,
            method: "post",
            datatype: "json",
            url: '<?php echo $uri; ?>Fncauth/update_data',
        }).done(function(e) {
            e = JSON.parse(e);

            if (e.status.STATUS == 'successfully') {
                var arr = [pid];
                var res = arr.join(';');
                var getParam = encodeURIComponent(btoa(btoa(res)));

                window.location.replace("profile/basic?c=" + getParam);

            } else {
                $('#alert-message').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">' + e.detail + '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                loading('hide');
            }
            loading('hide');
        })

    }

    function loading(action) {
        if (action == "show") {
            var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg') ?>'><div class='overlay'></div></div>";
            $("body").append(loading_component);
        } else if (action == "hide") {
            $("body .loading-component").remove();
        }
    }
</script>