<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>profile?c=<?php echo $person_id; ?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title"><b>สะสม Badge</b></p>
        </div>
    </div>
    <?php foreach ($dataResponse as $dataRow) : ?>
        <div class="row">
            <div class="col-12 text-left">
                <h3><strong><?= $dataRow['subcampName']; ?></strong></h3>
            </div>

            <?php foreach ($dataRow['detailBage'] as $detailBageRow) : ?>
                <div class="col-3 text-center">
                    <img src="<?= $detailBageRow['badgeImg']; ?>" alt="image Badge" class="responsive size-img <?= $detailBageRow['badgeQty'] > 0 ? 'imgbadge' : 'imgbadgeGray'; ?>">
                    <span><?= $detailBageRow['badgeQty'] > 0 ? $detailBageRow['badgeQty'] : ''; ?></span>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endforeach; ?>
</div>