
<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>profile?c=<?php echo $param; ?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title"><b>ข้อมูลติดต่อ <br>(Contact information)</b></p>
        </div>
    </div>
    <div>
        <div id="body-content">
            <form name="formContactdata" id="formContactdata" novalidate enctype="multipart/form-data" onsubmit="return chkForm()" method="post" action="" pid="<?php echo $person_id; ?>">
            </form>
        </div>
    </div>

</div>

<script>
    $( document ).ready(function() {
        memberProfile();
        loading('show');
    });

    $(document).on('click', '.btn-edit', function () {
        loading('show');
        editContact('Edit');
       
    });

    $(document).on('click', '.btn-save', function () {
        checkValidate();
    });

    $(document).on('change', '#province', function() {
        $("#subdist").html('<option value="">-- เลือก --</option>');
        $('#postcode').val('');
    });

    $(document).on('change', '#district', function() {
        $('#postcode').val('');
    });

   

    function isTypeOfUndefined(e)
	{
		if(typeof e === 'undefined'){ return e = ""; }
		return e;
	}

    function memberProfile() {
        var dataHtml = '';
        var statusPerson = "<?= $personData->personStatus; ?>";
        var p_id = $("#formContactdata").attr("pid");
        var param = {p_id: p_id, status : statusPerson};	
        // loadingPage('#load_page');
        $.ajax({
            url: '<?php echo $uri; ?>chkIdentity/fcontact.html?v=1.0' + Math.random()
        }).done(function (HeaderHtml) {

            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: '<?php echo $uri; ?>Fncauth/getDataMemStatus',
                // data: DataRef,
                data: param,
                success: function (e) {
                    // loadingPage('#load_page');
                    var ID = isTypeOfUndefined(e.detail.ID);
                    var tmpFirstname = isTypeOfUndefined(e.detail.FIRST);
                    var tmpLastname = isTypeOfUndefined(e.detail.LAST);
                    var tmpBirthdate = isTypeOfUndefined(e.detail.BIRTH);
                    var tmpEmail = isTypeOfUndefined(e.detail.EMAIL);
                    var tmpGenderM = isTypeOfUndefined(e.detail.GENDERM);
                    var tmpGenderF = isTypeOfUndefined(e.detail.GENDERF);
                    var tmpIdCardNo = isTypeOfUndefined(e.detail.IDCARD);
                    var SUB = isTypeOfUndefined(e.detail.SUB);
                    var tmpNationCode = isTypeOfUndefined(e.detail.NATIONAL);
                    var tmpPassportNo = isTypeOfUndefined(e.detail.PASSPORT);
                    var tmpphone = isTypeOfUndefined(e.detail.PHONE);
                    var tmpsession = isTypeOfUndefined(e.detail.session_id);

                    var tmpAddrId = isTypeOfUndefined(e.detail.addrId);
                    var tmpAddrDetail = isTypeOfUndefined(e.detail.addrDetail);
                    var sub_district_th = isTypeOfUndefined(e.detail.sub_district_th);
                    var sub_district_en = isTypeOfUndefined(e.detail.sub_district_en);
                    var district_th = isTypeOfUndefined(e.detail.district_th);
                    var district_en = isTypeOfUndefined(e.detail.district_en);
                    var province_th = isTypeOfUndefined(e.detail.province_th);
                    var province_en = isTypeOfUndefined(e.detail.province_en);
                    var postcode = isTypeOfUndefined(e.detail.postcode);
                    var province_code = isTypeOfUndefined(e.detail.province_code);
                    var district_code = isTypeOfUndefined(e.detail.district_code);
                    var sub_district_code = isTypeOfUndefined(e.detail.sub_district_code);

                    if(isEmpty(tmpEmail)){
                        tmpEmail = '-';
                    }

                    if(tmpNationCode == 'Thai' || tmpNationCode == 'ไทย'){
                        if(isEmpty(tmpAddrDetail) && isEmpty(province)){
                            var tmpAddrDetail = '-';
                            var province = '-';
                            var district = '-';
                            var sub_district = '-';
                            var postcode = '-';
                        }else{
                            var province = province_th ? province_th : '' + province_en ? '('+province_en+')' : '';
                            var district = district_th ? district_th : '' + district_en ? '('+district_en+')' : '';
                            var sub_district = sub_district_th ? sub_district_th : '' + sub_district_en ? '('+sub_district_en+')' : '';
                        }
                    }else{
                        if(isEmpty(tmpAddrDetail)){
                            var tmpAddrDetail = '-';
                        }
                    }

                    var mapObj = {
                        '<%Id%>': ID,
                        '<%InputFirstname%>': tmpFirstname,
                        '<%InputLastname%>': tmpLastname,
                        '<%InputBirthdate%>': tmpBirthdate,
                        '<%InputIdCard%>': tmpIdCardNo,
                        '<%InputPassport%>': tmpPassportNo,
                        '<%InputNation%>': tmpNationCode,
                        '<%InputEmail%>': tmpEmail,
                        '<%InputPhone%>': tmpphone,
                        '<%phone%>': tmpphone,
                        '<%checkM%>': tmpGenderM,
                        '<%checkF%>': tmpGenderF,
                        '<%session%>':tmpsession,
                        '<%addrId%>':tmpAddrId,
                        '<%addrDetail%>':tmpAddrDetail,
                        '<%sub_districtCode%>':sub_district_code,
                        '<%districtCode%>':district_code,
                        '<%provinceCode%>':province_code,
                        '<%postcode%>':postcode,
                        '<%InputProvince%>': province,
                        '<%InputDistrict%>': district,
                        '<%InputSubdist%>': sub_district,

                    }

                    dataHtml = HeaderHtml.replace(/<%Id%>|<%InputFirstname%>|<%InputLastname%>|<%InputBirthdate%>|<%InputIdCard%>|<%InputPassport%>|<%InputNation%>|<%InputEmail%>|<%phone%>|<%checkM%>|<%checkF%>|<%session%>|<%InputPhone%>|<%addrId%>|<%addrDetail%>|<%sub_districtCode%>|<%districtCode%>|<%provinceCode%>|<%postcode%>|<%InputProvince%>|<%InputDistrict%>|<%InputSubdist%>/gi, function (matched) {
                        return mapObj[matched];
                    });

                    
                    $("#body-content").empty().html(dataHtml);
                    $(".img-footer").css("position", "relative");

                    if(tmpNationCode != 'Thai' && tmpNationCode != 'ไทย'){
                        $('.addEng').addClass('d-none');
                    }else{
                        $('.addEng').removeClass('d-none');
                    }


                    loading('hide');
                    


                    $(".block-profile").empty();
                }
                , error: function (error) {
                }
            })
        });
    }

    function editContact(){

        var dataHtml = '';

        var statusPerson = "<?= $personData->personStatus; ?>";
        var p_id = $("#formUpload").attr("pid");
        
        var param = {p_id: p_id, status : statusPerson};
        // var param = {p_id: p_id};	
        // loadingPage('#load_page');
        $.ajax({
            url: '<?php echo $uri; ?>chkIdentity/fcontactEdit.html?v=1.0' + Math.random()
        }).done(function (HeaderHtml) {

            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: '<?php echo $uri; ?>Fncauth/getDataMemStatus',
                // data: DataRef,
                data: param,
                success: function (e) {
                    // loadingPage('#load_page');
                    var ID = isTypeOfUndefined(e.detail.ID);
                    var tmpFirstname = isTypeOfUndefined(e.detail.FIRST);
                    var tmpLastname = isTypeOfUndefined(e.detail.LAST);
                    var tmpBirthdate = isTypeOfUndefined(e.detail.BIRTH);
                    var tmpEmail = isTypeOfUndefined(e.detail.EMAIL);
                    var tmpGenderM = isTypeOfUndefined(e.detail.GENDERM);
                    var tmpGenderF = isTypeOfUndefined(e.detail.GENDERF);
                    var tmpIdCardNo = isTypeOfUndefined(e.detail.IDCARD);
                    var SUB = isTypeOfUndefined(e.detail.SUB);
                    var tmpNationCode = isTypeOfUndefined(e.detail.NATIONAL);
                    var tmpPassportNo = isTypeOfUndefined(e.detail.PASSPORT);
                    var tmpphone = isTypeOfUndefined(e.detail.PHONE);
                    var tmpsession = isTypeOfUndefined(e.detail.session_id);

                    var tmpAddrId = isTypeOfUndefined(e.detail.addrId);
                    var tmpAddrDetail = isTypeOfUndefined(e.detail.addrDetail);
                    var sub_district_th = isTypeOfUndefined(e.detail.sub_district_th);
                    var sub_district_en = isTypeOfUndefined(e.detail.sub_district_en);
                    var district_th = isTypeOfUndefined(e.detail.district_th);
                    var district_en = isTypeOfUndefined(e.detail.district_en);
                    var province_th = isTypeOfUndefined(e.detail.province_th);
                    var province_en = isTypeOfUndefined(e.detail.province_en);
                    var postcode = isTypeOfUndefined(e.detail.postcode);
                    var province_code = isTypeOfUndefined(e.detail.province_code);
                    var district_code = isTypeOfUndefined(e.detail.district_code);
                    var sub_district_code = isTypeOfUndefined(e.detail.sub_district_code);

                    var mapObj = {
                        '<%Id%>': ID,
                        '<%InputFirstname%>': tmpFirstname,
                        '<%InputLastname%>': tmpLastname,
                        '<%InputBirthdate%>': tmpBirthdate,
                        '<%InputIdCard%>': tmpIdCardNo,
                        '<%InputPassport%>': tmpPassportNo,
                        '<%InputNation%>': tmpNationCode,
                        '<%InputEmail%>': tmpEmail,
                        '<%InputPhone%>': tmpphone,
                        '<%phone%>': tmpphone,
                        '<%checkM%>': tmpGenderM,
                        '<%checkF%>': tmpGenderF,
                        '<%session%>':tmpsession,

                        '<%addrId%>':tmpAddrId,
                        '<%addrDetail%>':tmpAddrDetail,
                        '<%sub_districtCode%>':sub_district_code,
                        '<%districtCode%>':district_code,
                        '<%provinceCode%>':province_code,
                        '<%postcode%>':postcode
                    }

                    dataHtml = HeaderHtml.replace(/<%Id%>|<%InputFirstname%>|<%InputLastname%>|<%InputBirthdate%>|<%InputIdCard%>|<%InputPassport%>|<%InputNation%>|<%InputEmail%>|<%phone%>|<%checkM%>|<%checkF%>|<%session%>|<%InputPhone%>|<%addrId%>|<%addrDetail%>|<%sub_districtCode%>|<%districtCode%>|<%provinceCode%>|<%postcode%>/gi, function (matched) {
                        return mapObj[matched];
                    });

                    $("#body-content").empty().html(dataHtml);
                    $(".img-footer").css("position", "relative");

                    if(tmpNationCode != 'Thai' && tmpNationCode != 'ไทย'){
                        $('.addEng').addClass('d-none');
                    }else{
                        $('.addEng').removeClass('d-none');

                        var param = {pvCode: province_code,sdCode: sub_district_code,dCode: district_code};

                        $.ajax({
                            data: "pvCode=" + province_code,
                            method: "post",
                            datatype: "json",
                        url: '<?php echo $uri; ?>Fncauth/getProvince',
                        }).done(function (e) {
                            $('#province').html(jQuery.parseJSON(e));

                            $.ajax({
                                data: param,
                                method: "post",
                                datatype: "json",
                                url: '<?php echo $uri; ?>Fncauth/getDistrict',
                            }).done(function (e) {
                                
                                $('#district').html(jQuery.parseJSON(e));
                            })  

                            if(!isEmpty(sub_district_code) && !isEmpty(district_code)){
                                $.ajax({
                                data: param,
                                    method: "post",
                                    datatype: "json",
                                    url: '<?php echo $uri; ?>Fncauth/getSubdist',
                                }).done(function (e) {
                                    
                                    $('#subdist').html(jQuery.parseJSON(e));
                                })
                            }
                        })
                    }

                    if(isEmpty(tmpEmail)){
                        $('.emailBoxData').removeClass('d-none');
                        $('.emailBox').addClass('d-none');
                    }else{
                        $('.emailBox').removeClass('d-none');
                        $('.emailBoxData').addClass('d-none');
                    }

                    loading('hide');
                

                    $(".block-profile").empty();
                }
                , error: function (error) {
                }
            })
        });
        
    }

    function selectProvince(menu)
	{	if(menu == "province"){
		 	id = document.getElementById("province").value
		}else if(menu == "district"){
			id = document.getElementById("district").value;
		}
		if(id != "") {
			$.ajax({
				data: "id=" + id +"&menu="+ menu,
				method: "post",
				datatype: "json",
				url: "<?php echo base_url('Fncauth/selectAddress') ?>",
			}).done(function(e) {
                
                data = jQuery.parseJSON(e);
                
				if(menu == "province"){
					$('#district').html(data);
				}else if(menu == "district"){
					$('#subdist').html(data);
				}
			})
		}
	}

    function selectPostcode(menu)
	{	
		var id = document.getElementById("district").value;
	
		if(id != "") {
			$.ajax({
				data: "id=" + id,
				method: "post",
				datatype: "json",
				url: "<?php echo base_url('Fncauth/selectPostcode') ?>",
			}).done(function(e) {
				$('#postcode').val(e);
			})
		}
	}

    function checkValidate(){
		var address = document.getElementById('address');
		var province = document.getElementById('province');
		var district = document.getElementById('district');
		var subdist = document.getElementById('subdist');
		var postcode = document.getElementById('postcode');
        var email = $('#email').val();
        var pid = $('#formUpload').attr('pid');

        var idCard = $('#formUpload').attr('cno');
        var passNo = $('#formUpload').attr('pno');

        
		if(address.value.trim() == ""){
			$("#address").addClass("required");
			goToByScroll('address');  return false;
        }else{
            $("#address").removeClass("required");
        }

        if(!isEmpty(idCard)){
            if(province.value.trim() == ""){
                $("#province").addClass("required");
                goToByScroll('province');  return false;
            }else{
                $("#province").removeClass("required");
            }

            if(district.value.trim() == ""){
                $("#district").addClass("required");
                goToByScroll('district');  return false;
            }else{
                $("#district").removeClass("required");
            }

            if(subdist.value.trim() == ""){
                $("#subdist").addClass("required");
                goToByScroll('subdist');  return false;
            }else{
                $("#subdist").removeClass("required");
            }

            if(postcode.value.trim() == "" || postcode.value.length != 5){
                $("#postcode").addClass("required");
                goToByScroll('postcode');  return false;
            }
        }

        if(!isEmpty(email)){
            if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email))
            {
                var param = {email: email, menu: 'email', pId: pid };
                $.ajax({
                    data: param,
                    method: "post",
                    url: '<?php echo $uri; ?>Fncauth/selectDupIdcard',
                }).done(function(e) {
                    if(e.trim() == 'fail'){
                        $("#email").addClass("required");
                        $(".textEmail").removeClass("d-none");
                        $(".textEmail").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* อีเมลนี้มีในระบบแล้ว กรุณาตรวจสอบ</p></font>");
                        goToByScroll('email');  
                        return false;
                    }else{
                        $("#email").removeClass("required");
                        $(".textEmail").addClass("d-none");
                        updateContact();
		                loading('show');
                    }
                });
            }else {
                $("#email").addClass("required");
                $(".textEmail").removeClass("d-none");
                $(".textEmail").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* อีเมลไม่ถูกต้อง กรุณาตรวจสอบ</p></font>");
                goToByScroll('email');  
            }
       }else{
            updateContact();
            loading('show');
       }
        
	}

    function updateContact(){
        var phone = $('#phone').val();
        var email = $('#email').val();
        var session = $('#formUpload').attr('session');
        var pid = $('#formUpload').attr('pid');

        var aid = $('#formUpload').attr('aid');
        var address = $('#address').val();
        var province = $('#province').val();
        var district = $('#district').val();
        var subdist = $('#subdist').val();
        var postcode = $('#postcode').val();

        var idCard = $('#formUpload').attr('cno');
        var passNo = $('#formUpload').attr('pno');
     
        var param = {pid: pid,session: session,phone: phone,email: email};
        	
        var param_address = {pid: pid,session: session,address_id: aid,address: address,province: province,district: district,subdist: subdist,postcode: postcode,idCard:idCard,passNo:passNo}
        
        $.ajax({
            data: param,
            method: "post",
            datatype: "json",
            url: '<?php echo $uri; ?>Fncauth/update_data',
        }).done(function (k) {
            k = JSON.parse(k);

            if (k.status.STATUS == 'successfully') {
                $.ajax({
                    data: param_address,
                    method: "post",
                    datatype: "json",
                    url: '<?php echo $uri; ?>Fncauth/update_address',
                }).done(function (e) {
                    
                    e = JSON.parse(e);
                    if (e.status.STATUS == 'successfully') {	
                        var arr = [pid];
                        var res = arr.join(';');
                        var getParam = encodeURIComponent(btoa(btoa(res)));
                            
                        window.location.replace("profile/contact?c=" + getParam);

                    }else{
                        $('#alert-message').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+e.detail+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                        loading('hide');
                    } 
                    loading('hide');
                })
            }else{
                $('#alert-message').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+k.detail+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                loading('hide');
            } 
        })

    }

    function loading(action)
	{
		if(action == "show")
		{
			var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg')?>'><div class='overlay'></div></div>";
			$("body").append(loading_component);
		}
		else if(action == "hide")
		{
			$("body .loading-component").remove();
		}
	}

</script>