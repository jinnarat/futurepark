
<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>profile">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title" id="head_page"> (Personal Details)</p>
        </div>
    </div>
    <div>
        <form name="form1" id="form1" novalidate enctype="multipart/form-data" onsubmit="return chkForm()" method="post" action="<?php echo $uri; ?>profile/person_edit">
            <div class="top10">
                <div>Education Level</div>
                <input class="form-control form-control-sm boxInput" type="text" name="sh_name" placeholder="">
            </div>
            <div class="top10">
                <div>Occupation</div>
                <input class="form-control form-control-sm boxInput" type="text" name="sh_name" placeholder="">
            </div>
            <div class="top10">
                <div>Career Level</div>
                <input class="form-control form-control-sm boxInput" type="text" name="sh_name" placeholder="">
            </div>

            <div class="form-group row" style="margin-top: 50px;">
                <div class="btn-center">
                    <button type="submit" class="btn btn-primary btn-submit" id="btn-submit">Edit</button>
                </div>
            </div>
        </form>
    </div>

</div>