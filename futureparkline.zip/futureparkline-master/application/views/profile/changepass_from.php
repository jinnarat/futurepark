
<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>profile?c=<?php echo $param; ?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title" id="head_page">เปลี่ยนรหัสผ่าน <br>(Change Password)</p>
        </div>
    </div>
    <div>
        <!-- <div class="container"> -->
            <form name="formUpload" id="formUpload" novalidate enctype="multipart/form-data" onsubmit="return chkForm()" method="post" action="" pid="<?php echo $person_id; ?>">
                <div id="body-content"></div>
            </form>
        <!-- </div> -->
        
    </div>

</div>

<script>
    $( document ).ready(function() {
        var pid = $
        getfrom();
        loading('show');
    });

    $(document).on('click', '.btn-save', function () {
        checkPassword();
        
    });

    // $(document).focusin('#pass', function () {
    //     $('#passinvalid').addClass('d-none');
    // });
    // $(document).focusin('#con_pass', function () {
    //     $('#passnotmach').addClass('d-none');
    // });
   

    function isTypeOfUndefined(e)
	{
		if(typeof e === 'undefined'){ return e = ""; }
		return e;
	}	

    function getfrom() {
        var dataHtml = '';
        var p_id = $("#formUpload").attr("pid");
        var param = {p_id: p_id};	
        console.log(p_id);
        // loadingPage('#load_page');
        $.ajax({
            url: '<?php echo $uri; ?>chkIdentity/fpassword.html?v=1.0' + Math.random()
        }).done(function (HeaderHtml) {
            $("#body-content").empty().html(HeaderHtml);
            loading('hide');
        });
    }

    function editContact(){
        // console.log('123');
        $('#phone').removeAttr("disabled");
        $('#email').removeAttr("disabled");
        $('#address').removeAttr("disabled");

        $(".btn-center").empty().html('<a id="btnSubmit" class="btn btn-submit btn-save" href="javascript:void(0)">บันทึก (Save)</a>');
        setTimeout(function(){ loading('hide');}, 500);
        
    }

    function checkPassword() {
        var passNow = $('#pass').val();
        var passNew = $('#new_pass').val();
        var passCon = $('#con_pass').val();

        if(isEmpty(passNow) || isEmpty(passNew) || isEmpty(passCon) || passNow.length < 6 || passNew.length < 6 || passCon.length < 6){
            if(isEmpty(passNow)){
                $('#pass').addClass("required"); 
            }else{
                $('#pass').removeClass("required");
            }

            if(isEmpty(passNew)){
                $('#new_pass').addClass("required"); 
            }else{
                $('#new_pass').removeClass("required");
            }

            if(isEmpty(passCon)){
                $('#con_pass').addClass("required"); 
            }else{
                $('#con_pass').removeClass("required");
            }

            if(passNow.length < 6){
                $('#pass').addClass("required"); 
                $('#passinvalid').removeClass('d-none');
                $('#passinvalid').empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัสผ่านอย่างน้อย 6 ตัวอักษร</p></font>");
            }else{
                $('#pass').removeClass("required");
                $('#passinvalid').addClass('d-none');
            }

            if(passNew.length < 6){
                $('#new_pass').addClass("required"); 
                $('#textPassNew').removeClass('d-none');
                $('#textPassNew').empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัสผ่านอย่างน้อย 6 ตัวอักษร</p></font>");
            }else{
                $('#new_pass').removeClass("required");
                $('#textPassNew').addClass('d-none');
            }

            if(passCon.length < 6){
                $('#con_pass').addClass("required"); 
                $('#passnotmach').removeClass('d-none');
                $('#passnotmach').empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัสผ่านอย่างน้อย 6 ตัวอักษร</p></font>");
            }else{
                $('#con_pass').removeClass("required");
                $('#passnotmach').addClass('d-none');
            }

            goToByScroll('pass');  
            return false;
             
        }else{
            $('#pass').removeClass("required");
            $('#new_pass').removeClass("required");
            $('#con_pass').removeClass("required");
            $('#passnotmach').addClass('d-none');
            $('#textPassNew').addClass('d-none');
            $('#passinvalid').addClass('d-none');

            if(passNew != passCon){
                $('#con_pass').addClass("required"); 
                $('#passnotmach').removeClass('d-none');
                $("#passnotmach").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* รหัสผ่านไม่ตรงกัน</p></font>");
                    return false;
            }else{
                $('#con_pass').removeClass("required");
                $('#passnotmach').addClass('d-none');
            }
        }
        loading('show');
        updatepassword();
		
		
	}
   
    function updatepassword(){
        var pass = $('#pass').val();
        var newpass = $('#new_pass').val();
        var conpass = $('#con_pass').val();
        var pid = $('#formUpload').attr('pid');
     
        var param = {pid: pid,pass: pass,newpass: newpass};
        console.log('param',param);

        if(newpass == conpass){
            $.ajax({
            data: param,
            method: "post",
            datatype: "json",
            url: '<?php echo $uri; ?>Fncauth/changePass',
            }).done(function (e) {
                
                e = JSON.parse(e);
                console.log('log',e); 
                
                if (e.status.STATUS == 'successfully') {	
                    // var arr = [pid];
                    // var res = arr.join(';');
                    // var getParam = encodeURIComponent(btoa(btoa(res)));
                        
                    // window.location.replace("profile/changepassword?c=" + getParam);	
                    $('#alert-message').html('<div class="alert alert-success alert-dismissible fade show" role="alert">'+e.detail.message+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                    $('#pass').val('');
                    $('#new_pass').val('');
                    $('#con_pass').val('');
                }else{
                    // $('#alert-message').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+e.status.error+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                    $('#passinvalid').removeClass('d-none');
                    $('#passinvalid').empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* "+e.status.detail+"</p></font>");
                    loading('hide');
                } 
                loading('hide');
            });
        }else{
            loading('hide');
            goToByScroll('con_pass')
            document.getElementById("passnotmach").style.display = "inline"
            document.getElementById("passnotmach").innerHTML = "<font color='red' size='4'><p style='margin-bottom: 10px;'>* รหัสผ่านไม่ตรงกัน</p></font>";
            return false;
        }
        	
        
        

    }

    function goToByScroll(id) {
        // Remove "link" from the ID
        id = id.replace("link", "");
        // Scroll
        $('html,body').animate({
            scrollTop: $("#" + id).offset().top
        }, 'slow');
    }


    function loading(action)
	{
		if(action == "show")
		{
			var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg')?>'><div class='overlay'></div></div>";
			$("body").append(loading_component);
		}
		else if(action == "hide")
		{
			$("body .loading-component").remove();
		}
	}

</script>