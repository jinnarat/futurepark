<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>privilege">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title"> สิทธิพิเศษ (Privilege)</p>
        </div>
    </div>
    <div class="row my-3">
        <div class="col-12">
            <div class="card border-0">
                <?php if ($privilegeImage) : ?>
                    <?php if (getimagesize(PATHIMGCAMPAIGN . $privilegeImage)) : ?>
                        <img src="<?= PATHIMGCAMPAIGN . $privilegeImage . '?v="' . date('his') . '"'; ?>" class="card-img-top" alt="image">
                    <?php else : ?>
                        <img src="<?= base_url('assets/images/default_image.jpg') . '?v="' . date('his') . '"'; ?>" class="card-img-top" alt="image">
                    <?php endif; ?>
                <?php else : ?>
                    <img src="<?= base_url('assets/images/default_image.jpg') . '?v="' . date('his') . '"'; ?>" class="card-img-top" alt="image">
                <?php endif; ?>
                <div class="card-body">
                    <h2 class="card-title"><?php echo $privilegeName; ?></h2>
                </div>
            </div>
            <?php if ($privilegeDetail) : ?>
                <div class="card border-0 my-3">
                    <div class="card-body">
                        <small class="card-text">รายละเอียด</small>
                        <div class="card-text"><?php echo $privilegeDetail; ?></div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php if ($quantity) : ?>
            <div class="col-12 mt-2">
                <div class="row justify-content-center">
                    <div class="col-6 text-center">
                        <div class="form-group">
                            <label for="quantity">จำนวนผู้ติดตาม</label>
                            <input type="number" min="0" class="form-control" id="quantity" value="0">
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if (isset($useTime)) : ?>
            <div class="col-12 ">
                <div class="row justify-content-center">
                    <div class="col-6 text-center">
                        <p>ใช้เมื่อ: </p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <div class="col-12 my-2 text-center">
            <?php if ($showBtn && $messageBtn) : ?>
                <button id="btnSubmit" class="btn btn-primary" style="background-color: #00c4b3; border-color:  #00c4b3; min-width: 200px"><?= $messageBtn; ?></button>
            <?php else : ?>
                <span class="text-danger"><?= $messageBtn; ?></span>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // let codeExpired = null;
        // let eventTime = moment(codeExpired, 'YYYY-MM-DD HH:mm:ss');
        // let currentTime = moment();
        // eventTime = eventTime.format('HH:mm:ss') == '00:00:00' ? eventTime.endOf('day').format('YYYY-MM-DD HH:mm:ss') : eventTime.format('YYYY-MM-DD HH:mm:ss');
        // eventTime = moment(eventTime);
        // // let countDownCal = eventTime.diff(currentTime)
        // let countDownCal = moment.duration(eventTime.diff(currentTime))
        // if (countDownCal > 0) {
        //     $('.countdown').html(`เหลือเวลา : <strong>${numeral(countDownCal.asHours()).format('00')} : ${numeral(countDownCal.minutes()).format('00')} : ${numeral(countDownCal.seconds()).format('00')}</strong>`);
        //     refreshIntervalId = setInterval(() => {
        //         currentTime = moment();
        //         countDownCal = moment.duration(eventTime.diff(currentTime))
        //         if (countDownCal > 0) {
        //             $('.countdown').html(`เหลือเวลา : <strong>${numeral(countDownCal.asHours()).format('00')} : ${numeral(countDownCal.minutes()).format('00')} : ${numeral(countDownCal.seconds()).format('00')}</strong>`);
        //         } else {
        //             $(this).find('.use-code-text').hide();
        //             $('#showCodeModal').modal('hide');
        //             checkout(pId, pvId, tierId, mpt, mpc);
        //             clearInterval(refreshIntervalId);
        //         }
        //     }, 1000);
        //     $('#showCodeModal').modal('show');
        // } else {
        //     clearInterval(refreshIntervalId);
        // }
    });
    $(document).on("click", ".modal-close", function() {
        $("#confirmModal").modal('hide');
        $("#alertModal").modal('hide');
    });

    $(document).on("click", "#btnSubmit", function() {
        var name = "<?= $privilegeName; ?>";
        var mpt = "<?= $type; ?>";
        $(".modal-title").empty().append('ยืนยัน');
        if (mpt.trim() == 'Check-inCheck-out') {
            $("#confirmModal .modal-body").empty().append('<div class="text-center"><div>คุณยืนยันที่จะเช็คอิน (Check In) เพื่อใช้สิทธิพิเศษ </div><div><b>' + name + '</b></div><div>กรุณากดเช็คเอาท์ (Check Out) เมื่อเลิกใช้งาน</div></div>');
        } else {
            $("#confirmModal .modal-body").empty().append('<div class="text-center"><div>คุณยืนยันที่จะใช้สิทธิพิเศษ</div><div><b>' + name + '</b></div>');
        }
        $("#confirmModal").modal('show');
    });

    $(document).on("click", ".submit", function() {
        $('#confirmModal .submit').attr('disabled', true);
        var pvId = "<?= $pvId; ?>";
        var pId = "<?= $pId; ?>";
        var tierId = "<?= $tid; ?>";
        var status = "<?= $status; ?>";
        var quantity = $('#quantity').val();
        var pointRedeem = <?= $point; ?>;
        var type = "<?= $type; ?>";

        var param = {
            pvId: pvId,
            pId: pId,
            tierId: tierId,
            status: status,
            quantity: quantity,
            pointRedeem: pointRedeem,
            type: type,
        };

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo base_url(); ?>privilege/updateUse',
            data: param,
            success: function(response) {
                if (response.status == 'Successfully') {
                    window.location.replace("privilege/userEvent?r=Line&pvId=" + response.PVID + "&pId=" + response.PID + "&date=" + response.DATE + "&tId=" + response.TID + "&itype=" + response.ITYPE + "&code=" + response.CODE);
                } else if (response.STATUS == 'lessPoint') {
                    $(".modal-title").etypey().append('แจ้งเตือน');
                    $("#alertModal .modal-body").etypey().append('<div class="text-center"> ' + response.messege + ' </div>');
                    $("#confirmModal").modal('hide');
                    $("#alertModal").modal('show');
                } else {
                    $("#confirmModal").modal('hide');
                    $(".modal-title").empty().append('แจ้งเตือน');
                    $("#alertModal .modal-body").empty().append('<div class="text-center"> ' + response.messege + ' </div>');
                    $("#alertModal").modal('show');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $("#confirmModal").modal('hide');
                $(".modal-title").empty().append('แจ้งเตือน');
                $("#alertModal .modal-body").empty().append('<div class="text-center"> ข้อมูลไม่ถูกต้องกรุณาลองใหม่อีกครั้ง </div>');
                $("#alertModal").modal('show');
            },
        }).done(function() {
            $('#confirmModal .submit').removeAttr('disabled');
        });
    });

    function loading(action) {
        if (action == "show") {
            var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg') ?>'><div class='overlay'></div></div>";
            $("body").append(loading_component);
        } else if (action == "hide") {
            $("body .loading-component").remove();
        }
    }
</script>