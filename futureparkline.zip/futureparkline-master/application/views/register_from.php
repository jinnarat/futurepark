	
	<!-- <div class="banner-homepage">
		<div class="banner-image" style="background: url('<?php echo base_url() . "assets/images/banner/BN-TPC20Y.jpg?v=".date('his')."" ?>') top center no-repeat;">
	</div>  -->

	<div class="banner-homepage">
		<img src="<?php echo base_url() . "assets/images/banner/BN-TPC20Y.jpg?v=".date('his') ?>" class="banner-image">
	</div> 

	<div class="screen-custom">
		<form name="form1" id="form1" novalidate enctype="multipart/form-data" onsubmit="return chkForm()" method="post" action="<?php echo $uri; ?>register/update_data">
			<div class="hidden-xs">
				<div class="text-head text-center">
					<p>ลงทะเบียนเพื่อลุ้นรับรางวัลจากกิจกรรมฉลองครบรอบ 20 ปี เดอะพิซซ่าคอมปะนี</p>
					<p>แจก Honda Scoopy I 20 คัน และของรางวัลมากมาย รวมมูลค่ามากกว่า 1,000,000 บาท</p>
				</div>
			</div>
			<div class="visible-xs">
				<div class="text-head text-center">
					<p>ลงทะเบียนเพื่อลุ้นรับรางวัลจากกิจกรรม</p>
					<p>ฉลองครบรอบ 20 ปี เดอะพิซซ่าคอมปะนี</p>
					<p>แจก Honda Scoopy I 20 คัน</p>
					<p>และของรางวัลมากมาย</p>
					<p>รวมมูลค่ามากกว่า 1,000,000 บาท</p>
				</div>
			</div>
			<div class="pc-style">
				<div class="card-box">
					<div class="card-body">	
						<lable class="star-require">ชื่อ</lable><br>
						<lable class="star-require">First Name</lable>
						<input class="form-control input-md box-input" id="inputname"  type="text" name="inputname"  value="" maxlength="50" required  >
						<div id="textname" style="display:none"></div>
					</div>
					<div class="card-body">	
						<lable class="star-require">นามสกุล</lable><br>
						<lable class="star-require">Last Name</lable>
						<input class="form-control input-md box-input" id="inputsurname"  type="text" name="inputsurname"  value="" maxlength="50" required >
						<div id="textsurname" style="display:none"></div>
					</div>
					<div class="card-body">	
						<lable class="star-require">เบอร์มือถือ</lable><br>
						<lable class="star-require">Mobile Phone No.</lable>
						<input class="form-control input-md box-input numberic" id="inputtel"  type="text" name="inputtel"  value="" maxlength="10" required >
						<div id="textPhone" style="display:none"></div>
					</div>
					<div class="card-body">	
						<lable>อีเมล</lable><br>
						<lable>Email</lable>
						<input class="form-control input-md box-input" id="inputemail"  type="email" name="inputemail"  value="" maxlength="100">
						<div id="textEmail" style="display:none"></div>
					</div>
					<div class="card-body">	
						<!-- <lable class="star-require">เลขที่ใบเสร็จ</lable><br>
						<lable class="star-require">Invoice No.</lable> -->
						<div class="row custom-font" >
							<div class="col-md-4" style="padding-right: 0;">
								<label class="star-require">เลขที่ใบเสร็จ</label>
							</div>
							<div class="col-md-8 example-img">
								<label id="ex_image" class="text-popupImg" >กดเพื่อดูภาพตัวอย่าง</label>
							</div>
						</div>
						<div class="row custom-font">
							<div class="col-md-4" style="padding-right: 0;">
								<label class="star-require">Invoice No.</label>
							</div>
							<div class="col-md-8 example-img">
								<label id="ex_image" class="text-popupImg" >Click to see an example</label>
							</div>
						</div>
						<input class="form-control input-md box-input" id="inputreceipt"  type="text" name="inputreceipt"  value="" maxlength="16"  onblur="checkLengthNo(this)" required >
						<div id="textRepeat" style="display:none"></div>
					</div>

					<div class="card-body">
						<lable class="star-require">อัพโหลดรูปภาพเลขที่ใบเสร็จ</lable><br>
						<lable class="star-require">Upload Image Invoice No.</lable>

						<div class="input-group">
							<span class="input-group-btn">
								<span class="btn btn-default btn-file font-mobile">
									อัพโหลดรูป <input type="file" name="inputImg" id="inputImg"  class="form-control input-md box-input">
								</span>
							</span>
							<input type="text" name="inputImg" class="form-control input-md box-input" readonly>
						</div>
						<div id="textImg" style="display:none"></div>
					</div>
					
					<div class="card-body">
						<input type="checkbox" class="form-check-input custom-checkbox" id="checkCondition" onclick="checkBox()">
						<label class="form-check-label span-text" id="popup">ฉันยอมรับเงื่อนไขกิจกรรมและต้องการรับข้อมูลข่าวสารและโปรโมชัน จาก เดอะพิซซ่า คอมปะนี*</label>
					</div>
					<div class="card-body">
						<input type="checkbox" class="form-check-input custom-checkbox" id="checkCongrats" onclick="checkBox()">
						<input type="hidden"  id="value_consent" name="value_consent" value="">
						<label class="form-check-label span-pc">ฉันต้องการรับข้อมูลข่าวสาร กิจกรรมส่งเสริมการขายต่างๆ จาก เดอะ พิซซ่า คอมปะนี และบริษัทในเครือ โดยเราจะเก็บข้อมูลของท่านไว้เป็นความลับ</label>
					</div>
						
					<div class="card-group" >
						<div class="card-body text-center">
							<!-- <button id="btnSubmit" class="btn btn-secondary btn-size font-mobile" disabled type="sunbmit" >ส่งข้อมูล</button> -->
							<a id="btnSubmit" class="btn btn-secondary btn-size font-mobile form1-submit" href="javascript:void(0)" >ส่งข้อมูล</a>
						</div>	
					</div>
				</div>
			</div>
		</form>	
	</div>

	<!-- Modal -->
	<div class="modal fade" id="myModal" role="dialog">
		<div class="modal-dialog">
		
			<!-- Modal content-->
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title">ภาพตัวอย่างใบเสร็จ / Receipt Example</h4>
					<button type="button" class="close" data-dismiss="modal">&times;</button>
				</div>
				<div class="modal-body-img">
					<img src="<?php echo $uri; ?>/assets/images/sample.jpg?v=<?php echo date("YmdHis")?>" alt="logo pizza" class="responsive image-size">
				</div>
				<div class="modal-footer">
					<!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
				</div>
			</div>
		
		</div>
	</div>
	
	<!-- Modal -->
		<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
			<div class="modal-dialog modal-dialog-scrollable" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalScrollableTitle">รายละเอียดและเงื่อนไขการร่วมโปรโมชันและการรับของรางวัล<br>Promotion and Prize Terms and Conditions</h5><br>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">
						<ul>
							<li>โปรโมชัน ตั้งแต่วันที่ 25 กุมภาพันธ์ 2563 ถึง 31 มีนาคม 2563</li>
							<li>ร่วมสนุกได้ทั่วประเทศเมื่อซื้อพิซซ่า 1แถม1 จากร้านเดอะ พิซซ่า คอมปะนี ในทุกช่องทาง ทั้งหน้าร้าน, www.1112.com,  แอปพลิเคชัน The Pizza Company1112, The Pizza Company 1112 Delivery  โทรสั่งเบอร์ 1112 สั่งผ่าน GRAB หรือ Food Panda หรือ Lineman หรือ Get หลังจากนั้นลงทะเบียน ด้วยการกรอกชื่อ นามสกุล ที่อยู่ หมายเลขโทรศัพท์ของตนเอง เลขที่ใบเสร็จ และใส่รูปใบเสร็จลงในระบบ ลงทะเบียนผ่านทาง The Pizza Company Line Official Account หรือสแกน QR Code ในใบเสร็จเพื่อเข้าไปลงทะเบียน</li>
							<li>1 ใบเสร็จถือว่าเป็น 1 สิทธิ์ หรือ 1 ชิ้นส่วน</li>
							<li>ของรางวัลครั้งที่ 1 ถึงครั้งที่ 4 มีดังนี้
								<ol>
									<li>รางวัลที่ 1 Honda Scoopy I รุ่น Prestige ครั้งละ 5 รางวัล ๆ ละ 48,900 บาท รวมมูลค่า 244,500 บาท จำนวน 20 รางวัล มูลค่าทั้งสิ้น 978,000 บาท</li>
									<li>รางวัลที่ 2 The Pizza Company Gift Voucher ครั้งละ 25 รางวัลๆ ละ 300 บาท รวมมูลค่า 7,500 บาท จำนวน 100 รางวัล มูลค่าทั้งสิ้น 30,000 บาท</li>
									<span>รวมของรางวัลทั้งสิ้นตลอดรายการ 120 รางวัล รวมมูลค่า 1,008,000 บาท (หนึ่งล้านแปดพันบาทถ้วน)</span>
								</ol> 
							</li>
							<li>จับรางวัลทุกอาทิตย์ ได้แก่ วันที่ 11 มีนาคม , 18 มีนาคม, 25 มีนาคม และ 1 เมษายน 2563 เวลา 14.00 น. โดยจับรางวัลที่ สำนักงานบริษัท เดอะ ไมเนอร์ ฟู้ด กรุ๊ป จำกัด (มหาชน) เลขที่ 99 อาคารเบอร์ลี่ยุคเกอร์เฮ้าส์ ชั้น15 ซอยรูเบีย ถนนสุขุมวิท 42 แขวงพระโขนง เขตคลองเตย กรุงเทพฯ 10100</li>
							<li>ประกาศรายชื่อผู้โชคดีทุกอาทิตย์ ได้แก่ วันที่ 12 มีนาคม, วันที่ 19 มีนาคม, วันที่ 26 มีนาคม, วันที่ 2 เมษายน 2563 ทาง Facebook The Pizza Company 1112 Lovers. และ The Pizza Company Line official account เวลา 14.00 น.</li>
							<li>เกณฑ์การตัดสินและรับของรางวัล 
								<ol>
									<li>ในการติดต่อขอรับรางวัล ผู้โชคดีที่ได้รับรางวัลต้องนำหลักฐาน บัตรประจำตัวประชาชน ทะเบียนบ้าน พร้อมสำเนา 1 ชุด ในกรณีที่ผู้โชคดีที่ได้รับรางวัลอายุต่ำกว่า 15 ปีบริบูรณ์จะต้องนำสูติบัตรฉบับจริงและสำเนา 1 ชุดมาแสดงโดยให้มาพร้อมกับบิดา มารดา หรือ ผู้ปกครอง (ต้องนำบัตรประชาชนและทะเบียนบ้านฉบับจริงของบิดา มารดา หรือผู้ปกครอง พร้อมสำเนามาแสดงด้วย) มาเป็นหลักฐานติดต่อเพื่อแสดงสิทธิ์รับของรางวัลภายใน 30 วันหลังวันประกาศผลผู้โชคดีในแต่ละครั้ง หากเลยเวลาที่กำหนดไว้จะถือว่าสละสิทธิ์ บริษัทฯ จะมอบรางวัลให้กับผู้โชคดีที่จับสำรองไว้ ลำดับถัดไปแทน และต้องมารับของรางวัลด้วยตนเองที่บริษัทฯ ในวันและเวลาทำการภายใน 30 วันนับแต่วันที่ประกาศผลรางวัล หากเลยกำหนด ถือว่าสละสิทธิ์ แล้วบริษัทฯ จะมอบของรางวัลดังกล่าวให้แก่องค์กรสาธารณะกุศลหรือหน่วยงานราชการเพื่อประโยชน์ของทางราชการต่อไป</li>
									<li>ส่งได้ไม่จำกัดจำนวน แต่ผู้โชคดีมีสิทธิ์ได้รับเพียงรางวัลเดียวคือรางวัลสูงสุดของการจับรางวัลเท่านั้น และชิ้นส่วนที่เหลือจากการจับรางวัลแต่ละครั้งจะถูกนำมาจับในครั้งต่อไป</li>
									<li>รางวัลที่ได้รับไม่สามารถเปลี่ยนเป็นเงินสด หรือของรางวัลอื่นได้ รวมทั้งไม่มีการจ่ายเงินเป็นส่วนประกอบแต่อย่างใดและห้ามโอนของรางวัลให้ผู้อื่น</li>
									<li>ผู้โชคดีที่ได้รับรางวัลที่ 2 The Pizza Company Gift Voucher บริษัทฯ จะจัดส่งให้ทางไปรษณีย์ ภายใน 30 วัน หลังจากประกาศรายชื่อผู้โชคดีในแต่ละครั้ง</li>
									<li>ผู้โชคดีที่ได้รับรางวัลมูลค่า 1,000 บาท ขึ้นไป จะต้องหักภาษี ณ ที่จ่าย 5 % ของมูลค่ารางวัล ตามคำสั่งกรมสรรพากร </li>
									<li>การตัดสินของคณะกรรมการและบริษัท เดอะ ไมเนอร์ ฟู้ด กรุ๊ป จำกัด (มหาชน) ถือเป็นเด็ดขาดและสิ้นสุด</li>
									<li>ขอสงวนสิทธิ์พิจารณารางวัลให้กับผู้ร่วมกิจกรรมที่มีสัญชาติไทยและมีถิ่นพำนักอาศัยอยู่ในประเทศไทยเท่านั้น โดยพนักงานของ บริษัท เดอะ ไมเนอร์ ฟู้ด กรุ๊ป จำกัด (มหาชน) บริษัทในเครือบริษัทตัวแทนโฆษณาที่เกี่ยวข้อง คณะกรรมการดำเนินรายการ ไม่มีสิทธิ์รับรางวัลในกิจกรรมครั้งนี้</li>
								</ol>
							</li>
						</ul>
						<ul>
							<li>The promotion is valid from 25 February until 31 March 2020.   </li>
							<li>You can enter the promotion by purchasing Buy 1 Get 1 Free Pizza from The Pizza Company via every channel, including The Pizza Company’s branches, www.1112.com, The Pizza Company 1112 application, The Pizza Company 1112 Delivery, GRAB, Food Panda, Lineman, and Get. Then, register for the promotion via The Pizza Company Line Official Account or by scanning the QR Code on the purchase receipt. You must provide the following information when registers: first-last name of the customer, address, phone number, receipt number, and image of the receipt.  </li>
							<li>One receipt is entitled for one entry or prize.</li>
							<li>We will conduct a random drawing four times to select winners for the following prizes:   
								<ol>
									<li>First prize: a Honda Scoopy I Prestige worth 48,900 baht for five winners in each drawing, valued in total up to 244,500 baht. A total of 20 prizes will be drawn over the four drawings, valued in total up to 978,000 baht.</li>
									<li>Second prize: The Pizza Company Gift Voucher worth 300 baht for 25 winners in each drawing, valued in total up to 7,500 baht. A total of 100 prizes will be drawn over the four drawings, valued in total up to 30,000 baht.</li>
									<span>The program will give out 120 prizes in total, valuing up to 1,008,000 baht (one million eight thousand baht).   </span>
								</ol> 
							</li>
							<li>The prize drawing will take place every week on 11 March, 18 March, 25 March, and 1 April 2020 at 14.00 at The Minor Food Group Public Company Limited, 99 Berli Jucker House, 15th Floor, Soi Rubia, Sukhumvit 42 Road, Phra Khanong, Khlong Toei, Bangkok 10100.</li>
							<li>Prize winners will be announced every week on 12 March, 19 March, 26 March, and 2 April 2020 at 14.00 on Facebook The Pizza Company 1112 Lovers and The Pizza Company Line Official Account.</li>
							<li>Drawing and Prize Claim Rules   
								<ol>
									<li>To claim a prize, the prize winner must present original and photo copies of identity card and house registration. The winner under 15 years of age must present original and photo copies of birth certificate and must be accompanied by a parent or guardian (bring original and photo copies of the parent or guardian’s identity card and house registration as well). You must submit the evidence in person to claim a prize within 30 days after each announcement of prize winners. If the prize is not claimed within the required period, it will be considered forfeited and the Company will award the prize to the next reserve winner. If the reserve winner fails to claim the prize in person within 30 days after the prize winner announcement, the prize will be considered forfeited and the Company will give the prize to a public charity or government agency.</li>
									<li>Entrants can enter multiple times with each purchase. However, the winner is eligible to receive only one prize, which will be the highest prize drawn. The remaining entries will be drawn in the next drawing.</li>
									<li>Prizes cannot be exchanged for cash or other prizes and are not offered with cash. Prizes are non-transferable.</li>
									<li>The second prize, The Pizza Company Gift Voucher, will be sent to prize winners via postal mail within 30 days after each winner announcement.</li>
									<li>Winners of prizes worth 1,000 baht or more will be liable to pay the withholding tax of five percent of the prize value as required by the Revenue Department.  </li>
									<li>The decision of the Committee and The Minor Food Group Public Company Limited shall be deemed absolute and final.</li>
									<li>The Company reserves the right to award the prizes to entrants of Thai nationality who reside in Thailand only. Employees of The Minor Food Group Public Company Limited, affiliates, and related advertising agencies, and members of the Program Committee are not eligible to receive the prizes from this promotion.</li>
								</ol>
							</li>
						</ul>
					</div>
					<div class="modal-footer text-center">
						<!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">ปิด</button> -->
					</div>
				</div>
			</div>
		</div>

<script>
	$(document).ready( function() {
		$(document).on("keyup", ".numberic", function(){
			this.value = this.value.replace(/[^0-9]/g, '');
		})

		$(document).on('click','#inputImg',function(){
			$("#textImg").css("display", "none");
		})

		// $(document).on("reload","#form1",function(){
		// 	var bill = document.getElementById("inputreceipt").value;
		// 		bill.value = null;
		// })

	
    	$(document).on('change', '.btn-file :file', function() {
		var input = $(this),
			label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
		input.trigger('fileselect', [label]);
		});

		$('.btn-file :file').on('fileselect', function(event, label) {
		    
		    var input = $(this).parents('.input-group').find(':text'),
		        log = label;
		    
		    if( input.length ) {
		        input.val(log);
		    } else {
		        if( log ) alert(log);
		    }
	    
		});
		function readURL(input) {
		    if (input.files && input.files[0]) {
		        var reader = new FileReader();
		        
		        reader.onload = function (e) {
		            $('#img-upload').attr('src', e.target.result);
		        }
		        
		        reader.readAsDataURL(input.files[0]);
		    }
		}

		$("#imgImg").change(function(){
		    readURL(this);
		}); 	
	});

	$(document).on("click", "#form1 a.form1-submit", function(){
		
		var bill = document.getElementById("inputreceipt").value;

		if(bill != "") {
			$.ajax({
				data: "bill=" + bill,
				method: "post",
				url: "<?php echo base_url('register/billRepeat') ?>",
			}).done(function(e) {
				e = JSON.parse(e)
				
				if(e.status == 500){
					$('#inputreceipt').val('');

					$("#textRepeat").css("display", "inline");
					$("#textRepeat").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* เลขที่ใบเสร็จนี้ได้ลงทะเบียนไว้แล้ว</p></font>")
					$("#inputreceipt").focus();
				}
				else
				{
					$("#textRepeat").css("display", "none");
					$("#form1").submit();
				}
			})
		}
	})


	$('#inputtel').keyup(function(e) {
		var str_regexp = /^0/;		

		if (!str_regexp.test(this.value))
		{
			this.value = this.value.replace(str_regexp,'');

			$("#textPhone").css("display", "inline");
			$("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* เบอร์โทรศัพท์ไม่ถูกต้อง</p></font>")
			
			$("#inputtel").focus();		
		}
		else
		{
			$("#textPhone").css("display", "none");
		}	
	});

	$("#inputemail").on("focusout", function(){
		var str_regexp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;		
		console.log(this.value);
		if (!str_regexp.test(this.value))
		{	console.log(this.value);
			
			if(this.value == ""){
				$("#textEmail").css("display", "none");
			}else{
				$("#textEmail").css("display", "inline");
				$("#textEmail").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกข้อมูลอีเมลให้ถูกต้อง</p></font>")
				$("#inputemail").focus(); 
			}
		 
	})

	function checkBox(){
		var Condition = $('#checkCondition').is(":checked")
		var Congrats = $('#checkCongrats').is(":checked")
		
		if(Condition == true){
			$("#btnSubmit").attr("disabled", false);
			$('#btnSubmit').removeClass('btn-secondary').addClass('btn-custom');

			if(Congrats == true){
				$("#value_consent").val("Y");
			}else{
				$("#value_consent").val("N");
			}
			
		}else{
			$("#btnSubmit").attr("disabled", true);
			$('#btnSubmit').removeClass('btn-primary').addClass('btn-secondary');
		}
	}

	function checkint(el) {
		var ex = /^[0-9]*$/;
		if (ex.test(el.value) == false) {
			el.value = el.value.substring(0, el.value.length - 1)
		}
	}

	function checkLength(el) {
		if (el.value.length != 10) {
			$("#textPhone").css("display", "inline");
			$("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกหมายเลขโทรศัพท์ให้ถูกต้อง</p></font>")
			
			$("#inputtel").focus();
		}else{
			$("#textPhone").css("display", "none");
		}
	}

	function checkLengthNo(el) {
		if(el.value.length >= 10 && el.value.length <=16) {
			$("#textRepeat").css("display", "none");
			checkReceipt();
			
		}else{
			console.log('fail');
			$("#textRepeat").css("display", "inline");
			$("#textRepeat").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกเลขที่ใบเสร็จให้ถูกต้อง</p></font>")
			
			$("#inputreceipt").focus();

			return false;
			
			
		}
	}

	$(document).on("keyup keydown", "#inputreceipt", function(){
		$(this).val(autoTab(this.value))
	})

	function autoTab(obj){
		var obj = obj.replace(/\s+/g, '').replace(/[^0-9]/gi, '');
		var parts = []

		if(obj.length <= 6)
		{
			parts.push(obj.substring(0, 6));
		}

		if(obj.length == 7)
		{
			parts.push(obj.substring(0, 6));
			parts.push(obj.substring(6, 7));
		}

		if(obj.length >= 8)
		{
			parts.push(obj.substring(0, 6));
			parts.push(obj.substring(6, 7));
			parts.push(obj.substring(7, obj.length));
		}

		if(parts.length)
		{
			return parts.join("-");
		}
		else
		{
			return obj;
		}
	}

	// $('#inputreceipt').on('focusout',function(){
	// 	checkReceipt();
	// });

	function checkReceipt() {
		
		var bill = document.getElementById("inputreceipt").value;

		if(bill != "") {
			$.ajax({
				data: "bill=" + bill,
				method: "post",
				url: "<?php echo base_url('register/billRepeat') ?>",
			}).done(function(e) {
				e = JSON.parse(e)
				
				if(e.status == 500){
					$('#inputreceipt').val('');

					$("#textRepeat").css("display", "inline");
					$("#textRepeat").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* เลขที่ใบเสร็จนี้ได้ลงทะเบียนไว้แล้ว</p></font>")
					$("#inputreceipt").focus();

					loading('hide');
				}
				else
				{
					$("#textRepeat").css("display", "none");
				}
			})
		}
	}
	$(document).on('click','#btnSubmit',function(){
		chkForm();
		
		
		
	})
	function chkForm(){
		
		var name = document.getElementById('inputname');
		var surname = document.getElementById('inputsurname');
		var tel = document.getElementById('inputtel');
		var bill = document.getElementById('inputreceipt');
		var image = document.getElementById('inputImg');
		var email = document.getElementById('inputemail');
		var checknum = tel.value.substring(0, 1);
		var extall="jpg,jpeg,png";


		// console.log(tel); return false;
		
		if(name.value.trim() == ""){
		
			
			$("#textname").css("display", "inline");
			$("#textname").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกข้อมูล</p></font>")
			name.focus(); return false;
		}

		if(surname.value.trim() == ""){
			$("#textsurname").css("display", "inline");
			$("#textsurname").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกข้อมูล</p></font>")
			surname.focus(); return false;
		}
		
		if(tel.value.trim() == ""){
			$("#textPhone").css("display", "inline");
			$("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกข้อมูล</p></font>")
			tel.focus(); return false;
		}
		
		if(tel.value.trim() != "" && checknum.trim() != '0'){

			$("#textPhone").css("display", "inline");
			$("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* เบอร์โทรศัพท์ไม่ถูกต้อง</p></font>")
			
			tel.focus(); return false;
		}

		if(bill.value.trim() == ""){
			
			$("#textRepeat").css("display", "inline");
			$("#textRepeat").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกข้อมูล</p></font>")
			bill.focus(); return false;
		}
		
		if(bill.value.trim() != ""){
			if(bill.value.length >= 10 && bill.value.length <=16) 
			{	
				$("#textRepeat").css("display", "none");
				checkReceipt();
			}else{
				
				$("#textRepeat").css("display", "inline");
				$("#textRepeat").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกเลขที่ใบเสร็จให้ถูกต้อง</p></font>")
				
				$("#inputreceipt").focus();
			
				// window.location.href = "<?php echo base_url();?>";	
				return false;
			}
			
		}

		if(image.value.trim() == ""){
			$("#textImg").css("display", "inline");
			$("#textImg").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณาอัพโหลดรูปภาพใบเสร็จ</p></font>")
			image.focus(); return false;
		}

		if(image.value.trim() != ""){
			console.log(image);
			
			var file_img = image.value;
			var ext = file_img.split('.').pop().toLowerCase();
			if(parseInt(extall.indexOf(ext)) < 0){
				$("#textImg").css("display", "inline");
				$("#textImg").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณาอัพโหลดรูปภาพ เฉพาะนามสกุล " + extall + " เท่านั้น</p></font>")
				$("#textImg").focus();
				return false;
			}
		}

		if(email.value.trim() != ""){

			if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email.value))
			{
				$("#textEmail").css("display", "none");
			}else{
				$("#textEmail").css("display", "inline");
				$("#textEmail").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกข้อมูลอีเมลให้ถูกต้อง</p></font>")
				email.focus(); return (false)
			}
		}

		loading('show');
	}

	$('#form1').keyup(function(e) {

		var name = document.getElementById('inputname');
		var surname = document.getElementById('inputsurname');
		var tel = document.getElementById('inputtel');
		var bill = document.getElementById('inputreceipt');

		if(name.value.trim() != ""){
			$("#textname").css("display", "none");
		}	
		if(surname.value.trim() != ""){
			$("#textsurname").css("display", "none");
		}
		if(tel.value.trim() != ""){
			$("#textphone").css("display", "none");
		}if(bill.value.trim() != ""){
			$("#textRepeat").css("display", "none");
		}
	});

	$(document).on("click", "#popup", function(){
		$("#exampleModalScrollable").modal("show");
	})

	$(document).on("click", "#ex_image", function(){
		$("#myModal").modal("show");
	})

	function loading(action)
	{
		if(action == "show")
		{
			var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg')?>'><div class='overlay'></div></div>";
			$("body").append(loading_component);
		}
		else if(action == "hide")
		{
			$("body .loading-component").remove();
		}
	}
	

</script>