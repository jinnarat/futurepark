<div id="myCarousel" class="carousel" data-ride="carousel">
	<div class="carousel-inner" role="listbox">
		<div class="container">
			<div class="banner-homepage">
				<div class="banner-image" style="background: url('<?php echo base_url() . "assets/images/bg/home-3.jpg?v=" . date('his') . "" ?>') top center no-repeat;">
				</div>
			</div>
		</div>
	</div><br /><br />

	<div class="lay lay-content lay-<?php echo $layout; ?>">
		<div class="container">
			<div class="row">

				<div class="col-md-8 col-sm-8 col-xs-12">
					<?php if ($head_title != "" && $head_image == "") { ?>
						<div class="warp-header mobile-box">
							<div class="head-title">
								<h2>รูปภาพกิจกรรม <?php echo $head_title; ?></h2>
								<div class="decoration">
									<div class="decoration-inline"></div>
								</div><br />
							</div>
						</div>


					<?php } else if ($head_title != "" && $head_image != "") { ?>
						<div class="warp-header image row">
							<?php if ($url_share_fb != "") { ?>
								<div class="btn-share-fb">
									<div class="fb-share-button" data-href="<?php echo $url_share_fb; ?>" data-layout="button_count" data-size="large"></div>
								</div>
							<?php } ?>

							<div class="col-md-6 col-sm-6 visible-xs">
								<div class="head-title row">
									<h2>รูปภาพกิจกรรม <?php echo $head_title; ?></h2>
									<div class="line"></div>
								</div>
							</div>
							<div class="col-md-6 col-sm-6">
								<div class="image row" align="left">
									<?php if ($head_image) {
										echo $head_image;
									} ?>
								</div>
							</div>
							<div class="col-md-6 col-sm-6 hidden-xs">
								<div class="head-title row">
									<div class="line"></div>
									<h2><?php echo $head_title; ?></h2>
								</div>
							</div>
						</div>
					<?php } ?>

					<?php if ($head_detail) { ?>
						<div class="warp-detail__data mobile-box">
							<div class="detail mobile-box">
								<?php echo $head_detail; ?>
							</div>
						</div>
					<?php } ?>

					<?php if ($gallery) { ?>
						<div class="warp-detail__data mobile-box">
							<div class="detail mobile-box">
								<?php echo $gallery; ?>
							</div>
						</div>
					<?php } ?>

					

					<?php if ($link) { ?>
						<div class="warp-download">
							<div class="file-download img-link">
								<b><?php echo $link; ?></b>
							</div>
						</div>
					<?php } ?>


				</div>


				<div class="col-md-3 col-md-offset-1">
					<div class="warp-new mobile-box">
						<h4 style="color: #0072bc!important;">PR NEWS</h4>
						<br />
						<?php
						if (count($news) > 0) {
							$dataList = $news;
							for ($i = 0; $i < count($news) &&  $i < 5; $i++) {
								echo $dataList[$i] . "<br>";
							}
						}
						?>
					</div>
				</div>

			</div>

		</div>
	</div>