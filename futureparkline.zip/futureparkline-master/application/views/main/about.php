<div id="myCarousel" class="carousel" data-ride="carousel" >
	<div class="carousel-inner" role="listbox">
		<div class="container">
			<div class="banner-homepage">
			<div class="banner-image set-bg" style="background: url('<?php echo base_url() . "assets/images/bg/home-3.jpg?v=".date('his')."" ?>') top center no-repeat;">
			</div>
		</div>
	</div>
</div>


<div class="lay lay-<?php echo $layout; ?>">
	<div class="container">
		<div class="row">
			<div class="col-md-8">
	
				<?php if($head_title != ""){ ?>
					<div class="warp-header mobile-box">
						<div class="head-title">
							<h2><?php echo $head_title; ?></h2>
							<div class="decoration">
								<div class="decoration-inline"></div>
							</div><br/>
						</div>
					</div>
				<?php } ?>
				<div class="warp-detail__data">
					<div class="box-content mobile-box">
						<?php if($head_detail){ ?>
							<div class="detail">
								<?php echo $head_detail; ?>
							</div>
						<?php } ?>
					</div>
				</div>
				<?php if($menu == "ABOUT"){ ?>
					<div class="warp-header mobile-box">
						<div class="head-title">
							<h3>ข้อบังคับ สมาคมวิทยาศาสตร์และเทคโนโลยีทางอาหารแห่งประเทศไทย</h3>
							<div class="decoration">
								<div class="decoration-inline"></div>
							</div><br/>
							<div class="box-content">
								<?php if($head_file){ ?>
									<div class="detail">
										<?php echo $head_file; ?>
									</div>
								<?php } ?>
							</div>
						</div>

						<div class="head-title mar-top">
							<h3>Historic directory</h3>
							<div class="decoration">
								<div class="decoration-inline"></div>
							</div><br/>
							<div class="box-content">
								<?php if($detail2){ ?>
									<div class="detail">
										<?php echo $detail2; ?>
									</div>
								<?php } ?>
							</div>
						</div>
					</div>
				<?php } ?>

			</div>
			<div class="col-md-3 col-md-offset-1">
				<div class="warp-new">
					<h4 style="color: #0072bc!important;">PR NEWS</h4>
					<br/>
						<?php
							if(count($news) > 0){
								$dataList = $news;
								for($i = 0; $i < count($news) &&  $i < 5;$i++) {
									echo $dataList[$i]."<br>";
								}
							}
						?>
				</div>
			</div>

		</div>
				
	</div>
</div>
