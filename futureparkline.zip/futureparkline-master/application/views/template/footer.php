<?php $uri = $this->Main_function->html_chars(base_url()); ?>

<div id="bg-lock__process" align="center" style="display:none;"></div>
<div id="box-lock__process" align="center" style="display:none;">
	<img src="<?php echo $uri; ?>assets/images/icons/bx_loader.gif" />
	<span style="color:#000;z-index:9999;">Please wait...</span>
</div>
<!-- END TRACKING -->
<script type="text/javascript" src="<?php echo $uri; ?>assets/js/menumaker.min.js?v=2.0.0"></script>
<script type="text/javascript" src="<?php echo $uri; ?>assets/js/comp.js?v=<?php echo date("mis"); ?>"></script>
<script type="text/javascript">
	var BaseUrl = '<?php echo $uri; ?>'
	var windowsize = $(window).width();
	var documentwidth = $(document).width();
	var _SCREEN_ = (window.devicePixelRatio * screen.width) / window.devicePixelRatio;
	var S = window.innerWidth;
	var media = "desktop";
	if ((_SCREEN_ <= 1200 && _SCREEN_ >= 768) || (S <= 1200 && S >= 768)) {
		media = "tablet";
	}
	if (_SCREEN_ < 768 || S < 768) {
		media = "mobile";
	}
	$(document).ready(function() {
		$("<?php echo (isset($menu) ? "#m-" . $this->Main_function->html_chars($menu) : '') ?>").addClass("active");
	});
	//window.onresize = function(){ location.reload(); }
</script>
<!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>
	(function(d, s, id) {
		var js, fjs = d.getElementsByTagName(s)[0];
		if (d.getElementById(id)) return;
		js = d.createElement(s);
		js.id = id;
		// js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
		fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));
</script>
<?php echo $javascript; ?>
<?php if(OPENTRACKING) : ?>
<!--  START TRACKING -->
<script src="<?= TRACKINGURL; ?>"></script>
<script>
	var myCookie = getCookie("fb_session_id");

	if (myCookie == null) {
		document.cookie = "fb_session_id=" + makeid(16);
	}

	var enper = "<?php echo $this->session->userdata('userfprid'); ?>";
	var person_session = "<?php echo $this->session->userdata('person_session'); ?>";

	if (!person_session) {
		person_session = generateString(36);
	}

	fpr.personId = enper ? enper : '';
	fpr.person_session = person_session ? person_session : '';

	fpr.initialize({
		appId: "FB-PRO-VEND-0002",
		personId: enper ? enper : '',
		person_session: person_session ? person_session : '',
	});

	function generateString(length) {
		const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		let result = ' ';
		const charactersLength = characters.length;
		for (let i = 0; i < length; i++) {
			result += characters.charAt(Math.floor(Math.random() * charactersLength));
		}
		return result;
	}

	function getCookie(name) {
		var dc = document.cookie;
		var prefix = name + "=";
		var begin = dc.indexOf("; " + prefix);

		if (begin == -1) {
			begin = dc.indexOf(prefix);
			if (begin != 0) return null;
		} else {
			begin += 2;
			var end = document.cookie.indexOf(";", begin);
			if (end == -1) {
				end = dc.length;
			}
		}
		return decodeURI(dc.substring(begin + prefix.length, end));
	}

	function makeid(length) {
		var result = '';
		var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		var charactersLength = characters.length;

		for (var i = 0; i < length; i++) {
			result += characters.charAt(Math.floor(Math.random() * charactersLength));
		}
		return result;
	}
</script>
<?php endif; ?>
<?php if(isset($backlist) && $backlist) : ?>
<link rel="stylesheet" href="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.css'); ?>">
<script src="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.js'); ?>"></script>
<script>
$(document).ready(function () {
    let backlist = "<?= isset($backlist) ? $backlist : false; ?>";
    if (Boolean(backlist)) {
        Swal.fire({
            position:'center',
            icon: 'error',
            allowOutsideClick: false,
            showConfirmButton: false,
            title: 'คุณไม่สามารถเข้าใช้งานได้ในขณะนี้ <br/>กรุณาติดต่อเจ้าหน้าที่เพื่อทำการตรวจสอบ',
        });
    }
});
</script>
<?php endif; ?>
</body>

</html>