<style>
    .white-home{
		float: right;
		/* margin-top: 24px; */
		width: 27px;
		margin: 24px 9px;
    }

    @media (min-width: 300px) { 
        .header-logo{
            top: 0px;
        }
        .header-logo a img{
            width: 100%;
        }
    }

    @media (min-width: 768px) { 
        .header-logo{
            top: 0px;
        }
        .header-logo a img{
            width: 50%;
        }
    }
    
	@media (min-width: 1200px){
        .header-logo{
            top: 0px;
        }
        .header-logo a img{
            width: 50%;
        }
	}
</style>

<?php
$uri = $this->Main_function->html_chars(base_url());
$baseurl = $uri; 

// $this->load->helper('url');
// $page_url=current_url();
// echo $page_url;
?>

<header>
    <nav class="navbar navbar-toggler navbar-dark navbar-fixed-top nav-url" href="<?php echo $uri; ?>">
        <div class="navbar-header row">
            <div class="col-3 col-lg-4">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarTogglerDemo02">
                    <span class="navbar-toggler-icon"></span>                       
                </button>
            
            </div>
            <div class="col-6 col-lg-4 header-logo d-flex align-items-center">
                <a href="<?php echo base_url(); ?>">
                    <img class="center" src="<?php echo base_url("assets/images/logo/template_Future_top-logo.png?v=".date('his')) ?>">
                </a>
            </div>
            <div class="col-3 col-lg-4">
                <a href="<?php echo $uri; ?>profile">
                    <img src="<?php echo $uri . "assets/images/new_icon/template_Future_icon-profile.png?v=".date('his')."" ?>" alt=" " class="responsive white-home">
                </a>
            </div>
		</div>
		
		

        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <!-- <li id="head-dropdown" class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" id="drop-menu">ข้อมูลของคุณ</a>
                    <ul class="dropdown-menu bg-light">
                        <li><a href="<?php echo $uri; ?>profile/basic">ข้อมูลส่วนตัว (Profile)</a></li>
                        <li><a href="<?php echo $uri; ?>profile/contact">ข้อมูลติดต่อ (Contact)</a></li>
                        <li><a href="<?php echo $uri; ?>profile/lifestyle">ไลฟ์สไตล์ (Lifestyle)</a></li>
                        <li><a href="<?php echo $uri; ?>profile/history">ประวัติ (History)</a></li>
                        <li><a href="<?php echo $uri; ?>profile/changepassword"> เปลี่ยนรหัสผ่าน (Change Password)</a></li>
                        <li><a href="<?php echo $uri; ?>profile/logout"> ออกจากระบบ (Log out)</a></li>
                    </ul>
				</li> -->
				<li class="nav-item">
                    <a class="nav-link" href="<?php echo $uri; ?>">หน้าหลัก (Home Page) <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $uri; ?>profile">ข้อมูลส่วนตัว (Profile) <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $uri; ?>Promotion">สิทธิพิเศษเฉพาะคุณ <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $uri; ?>Privilege">สิทธิพิเศษ (Privilege) <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $uri; ?>Campaign">กิจกรรม (Campaign/Event) <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $uri; ?>Service">บริการ (Service Request) <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo $uri; ?>Shop/cateshop">ร้านค้า (Shop Search)</a>
				</li>
				<li style="border: 0.5px solid #e4e4f2;"></li>
				<li class="nav-item">
					<a class="nav-link" href="<?php echo $uri; ?>profile/logout">ออกจากระบบ (Log out)</a>
				</li>

            </ul>
        </div>
    </nav>
</header>

<script>

	$(document).on("click","#drop-menu",function() {
        $('#head-dropdown').removeClass('open');
    });
</script>