<?php
$uri = $this->Main_function->html_chars(base_url());
$baseurl = $uri;
?>
<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title><?php echo $TITLE; ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<meta NAME="Keywords" CONTENT="<?php echo $META_KEYWORDS; ?>">
	<meta NAME="Description" CONTENT="<?php echo $META_DESC; ?>">
	<meta name="rights" content="FuturePark" />
	<meta name="author" content="">
	<link rel="shortcut icon" href="<?php echo $baseurl; ?>assets/images/logo/favicon.ico">

	<meta property="fb:app_id" content="fb_app_id" />
	<meta property="og:site_name" content="FuturePark" />
	<meta property="og:type" content="website" />
	<meta property="og:title" content="<?php echo $this->Main_function->html_chars($fb_title); ?>" />
	<meta property="og:description" content="<?php echo $this->Main_function->html_chars($fb_description); ?>" />
	<meta property="og:url" content="https://www.futurepark.co.th/th/home/" />
	<meta property="og:image" content="<?php echo $this->Main_function->html_chars($fb_image); ?>">
	<!-- <meta property="og:image" content="assets/images/logo/logo.jpg"> -->
	<base href="<?php echo $uri; ?>">
	</base>

	<meta property="og:site_name" content="<?php echo isset($fb_sitename) ? $this->Main_function->html_chars($fb_sitename) : ''; ?>" />
	<meta property="og:url" content="<?php echo isset($fb_url) ? $this->Main_function->html_chars($fb_url) : ''; ?>" />

	<?php
	$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
	$domainName = htmlspecialchars(stripslashes(trim($_SERVER['HTTP_HOST'])), ENT_QUOTES);
	$requestURI = htmlspecialchars(stripslashes(trim($_SERVER['REQUEST_URI'])), ENT_QUOTES);
	$uri = $protocol . $domainName;
	?>
	<meta property="og:url" content="<?php echo $uri . $requestURI; ?>" />
	<meta property="og:image" content="<?php echo $baseurl; ?>images/logo/tts_logo_fb.jpg">

	<!-- Bootstrap core CSS -->
	<link href="<?php echo $baseurl; ?>assets/css/bootstrap-4.0.css?v=<?php echo date("YmdHis") ?>" rel="stylesheet">
	<link href="<?php echo $baseurl; ?>assets/css/bootstrap.css?v=<?php echo date("YmdHis") ?>" rel="stylesheet">

	<link rel="stylesheet" href="<?php echo $baseurl; ?>assets/fontawesome-free-5.15.3-web/css/all.css?v=<?php echo date("mis"); ?>" />
	<!-- <link rel="stylesheet" href="<?php echo $baseurl; ?>assets/css/font-awesome.css?v=<?php echo date("mis"); ?>" /> -->
	<!-- <link rel="stylesheet" href="<?php echo base_url("css/fontawesome.css") ?>"> -->
	<link rel="stylesheet" href="<?php echo $baseurl; ?>assets/css/fonts.css?v=<?php echo date("mis"); ?>" />
	<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
	<link href="<?php echo $baseurl; ?>assets/css/ie10-viewport-bug-workaround.css?v=<?php echo date("YmdHis") ?>" rel="stylesheet">
	<?php //echo $stylesheet; 
	?>
	<!-- Custom styles for this template -->
	<link href="<?php echo $baseurl; ?>assets/css/main.style.css?v=<?php echo date("YmdHis") ?>" rel="stylesheet">
	<link href="<?php echo $baseurl; ?>assets/css/carousel.css?v=<?php echo date("YmdHis") ?>" rel="stylesheet">


	<!-- <script src="<?php echo $baseurl; ?>assets/js/jquery-3.4.1.min.js"></script> -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script>
		window.jQuery || document.write('<script src="<?php echo $baseurl; ?>assets/js/jquery.min.js?v=<?php echo date("YmdHis") ?>"><\/script>')
	</script>

	<!-- datepicker -->
	<link rel="stylesheet" media="all" type="text/css" href="<?php echo $baseurl; ?>assets/js/jquerydatepicker/jquery-ui.css?v=<?php echo date("YmdHis") ?>" />
	<link rel="stylesheet" media="all" type="text/css" href="<?php echo $baseurl; ?>assets/js/jquerydatepicker/jquery-ui-timepicker-addon.css?v=<?php echo date("YmdHis") ?>" />

	<script src="<?php echo base_url("assets/js/global.js?v=" . date("YmdHis")) ?>"></script>
	<script src="<?php echo base_url("assets/js/main_function.js?v=" . date("YmdHis")) ?>"></script>
	<script type="text/javascript" src="<?php echo $baseurl; ?>assets/js/jquery-ui.js"></script>
	<script type="text/javascript" src="<?php echo $baseurl; ?>assets/js/jquerydatepicker/jquery-ui-timepicker-addon.js?v=<?php echo date("YmdHis") ?>"></script>
	<script type="text/javascript" src="<?php echo $baseurl; ?>assets/js/jquerydatepicker/jquery-ui-sliderAccess.js?v=<?php echo date("YmdHis") ?>"></script>

	<script type="text/javascript" src="<?php echo $baseurl; ?>assets/js/bootstrap-4.0.js?v=<?php echo date("YmdHis") ?>"></script>
	<script type="text/javascript" src="<?php echo $baseurl; ?>assets/js/bootstrap.min.js?v=<?php echo date("YmdHis") ?>"></script>

	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());
		gtag('config', 'UA-121064940-1');
	</script>
</head>
<body>
	<?php
	if (isset($isHeader)) {
		$this->load->view("template/_Header");
	}
	(isset($myModal)) ? $this->load->view("template/_Modal") : "";
	?>