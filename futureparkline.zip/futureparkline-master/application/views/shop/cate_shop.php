
<div class="container boxPage">
    <!-- <div>
        <a href="<?php echo $uri; ?>">
            <img src="<?php echo $uri . "assets/images/icons/set_home.png?v=".date('his')."" ?>" alt=" " class="responsive top10">
        </a>
    </div> -->
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title"><b>SHOP SEARCH</b></p>
        </div>
    </div>

</div>
    <?php if($cate_shop){
        echo $cate_shop;
    }?>

<style>
    .box-shop{
        background-color: #FFF;
        box-shadow: 4px 5px 5px grey;
        height: 190px;
        overflow: hidden;
        position: relative;
        width: 100%;
    }
    .imgBoxcateshop{
        height: 205px;
        /* background-color: cadetblue; */
        margin: 50px 0;
    }
    .text-cat{
        font-size: 18px;
        /* color: white; */
        color: #000;
        /* padding-top: 90px; */
    }

    .inner-sub {
        margin-top: 165px;
        background-color: #fff;
        padding-top: 20px;
        padding-right: 25px;
        padding-bottom: 18px;
        width: calc(100% - 188px);
        float: right;
        border-radius: 7px 0 0 0;
    }

</style>
