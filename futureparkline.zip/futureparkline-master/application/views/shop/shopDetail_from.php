
<div class="container top30">
    <div>
        <!-- <a href="<?php echo $uri; ?>shop">
            <i class="fa fa-chevron-left"></i>
        </a> -->
        <a href="<?php echo $uri; ?>Shop">
            <i class="fa fa-chevron-left"></i>
        </a>
    </div>
    <div>
        <div class="row top20">
            <div class="col-md-5 col-xs-5 .offset-xs-1">
                <div class="imgBoxshop"></div>
            </div>
            <div class="col-md-7 col-xs-7">
                <p>name shop</p>
                <span>B Floor</span>
            </div>
        </div>
        <div>
            <div class="top50">
                <div>Category</div>
                <input class="form-control form-control-sm boxInput" type="text" name="sh_name" placeholder="" disabled>
            </div>
            <div class="top10">
                <div>Zone</div>
                <input class="form-control form-control-sm boxInput" type="text" name="sh_name" placeholder="" disabled>
            </div>
            <div class="top10">
                <div>Promotion</div>
                <input class="form-control form-control-sm boxInput" type="text" name="sh_name" placeholder="" disabled>
            </div>
            <div class="top10"> 
                <div>Mex net</div>
                <input class="form-control form-control-sm boxInput" type="text" name="sh_name" placeholder="" disabled>
            </div>
        </div>
    </div>
</div>

<style>
    .imgBoxshop{
        background-position: center;
        background-size: cover;
        height: 110px;
        background-color: cadetblue;
        width: 120px;
        /* background-color: #FFF; */
    }

    .form-control[disabled]{
        background-color: #FFF;
    }
</style>