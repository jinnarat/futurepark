<style>
    @media only screen and (max-width: 576px) {
        .boxPage {
            margin-top: 23%;
            margin-bottom: 40px;
        }
    }

    .box-shop {
        background-color: #f0f0f2;
        height: 200px;
        overflow: hidden;
        position: relative;
        width: 100%;
        border-style: solid;
        border-width: 1px;
        border-color: gray;
    }

    .box-4 {
        padding: 0 10px 15px 10px;
    }

    .imgBoxshop {
        background-position: center;
        background-size: cover;
        height: 120px;
        width: 120px;
        background-color: #f9f7fb;
        text-align: center;

    }

    .img-shop {
        max-width: 250px;
        width: auto;
        height: 100%;
        margin: 0 auto;
        vertical-align: middle;
        padding: 10px;
    }

    .imgBoxshop.boxImg {
        border: 1px solid;
        height: 122px;
    }

    .form-control[disabled] {
        background-color: #FFF;
    }

    .text-shop {
        padding: 10px;
    }

    i:focus,
    i:active {
        color: red;
        outline: none;
    }
</style>

<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <?php
            if ($menu == 'SHOP') {
                echo '<a href="' . $uri . '">
                        <i class="fa fa-chevron-left"></i>
                    </a>';
            } else {
                echo '<a href="' . $uri . 'shop/cateshop/">
                        <i class="fa fa-chevron-left"></i>
                    </a>';
            }
            ?>
        </div>
        <div class="col-10">
            <?php
            if ($menu == 'SHOP') {
                echo '<p class="text-title" id="head_page">ค้นหาร้านค้า (Shop search)</p>';
            } else {
                echo '<p class="text-title" id="head_page">ร้านค้า (Shop)</p>';
            }
            ?>
        </div>
    </div>
    
    <?php if ($menu == 'SHOP') { ?>
        <form name="form_search" id="form_search" method="post" action="<?php echo base_url() ?>shop/cateshop">
            <div class="row">
                <div class="col-11">
                    <input class="form-control form-control-sm boxInput boxSearch" type="text" name="searchData" id="searchData" placeholder="ค้นหาร้านค้า" value="<?= $searchData; ?>">
                </div>
                <div class="col-1" style="padding-left: 0px;">
                    <span>
                        <a id="search" href="javascript:void(0)">
                            <i class="fa fa-search" style="font-size:24px"></i>
                        </a>
                    </span>
                </div>
                <div class="col-xs-12 col-lg-4 my-4">
                    <select id="building" name="building" class="form-control form-control-sm boxInput" style="padding-bottom: 0px;">
                        <option value="">อาคาร (Building)</option>
                        <?php if ($buildingShopResult) : ?>
                            <?php foreach ($buildingShopResult as $buildingData) : ?>
                                <?php if ($buildingData->id) : ?>
                                    <option value="<?= $buildingData->id; ?>" <?php if ($building == $buildingData->id) echo 'selected'; ?>><?= $buildingData->name; ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-xs-12 col-lg-4 my-4">
                    <select id="floor" name="floor" class="form-control form-control-sm boxInput" style="padding-bottom: 0px;">
                        <option value="">ชั้น</option>
                        <?php if ($floorShopResult) : ?>
                            <?php foreach ($floorShopResult as $floorData) : ?>
                                <?php if ($floorData->id) : ?>
                                    <option value="<?= $floorData->id; ?>" <?php if ($floor == $floorData->id) echo 'selected'; ?>><?= $floorData->name; ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="col-xs-12 col-lg-4 my-4">
                    <select id="category" name="category" class="form-control form-control-sm boxInput" style="padding-bottom: 0px;">
                        <option value="">หมวดหมู่ทั้งหมด</option>
                        <?php if ($categoryShopResult) : ?>
                            <?php foreach ($categoryShopResult as $categoryData) : ?>
                                <?php if ($categoryData->id) : ?>
                                    <option value="<?= $categoryData->id; ?>" <?php if ($category == $categoryData->id) echo 'selected'; ?>><?= $categoryData->name; ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
            </div>
        </form>
    <?php } ?>

    <?php
    if ($menu == 'SHOP') {
        if ($shop) {
            echo '<div class="row top30">' . $shop . '</div>';
        }
    } else {
        if ($detail) {
            echo $detail;
        }
    }
    ?>
    <div>
    </div>

    <script>
        $(document).on('click', '#search', function() {
            loading('show');
            var type = $('#searchType').val();
            var nameVal = $('#searchData').val();
            $('#form_search').submit();
        });

        function loading(action) {
            if (action == "show") {
                var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg') ?>'><div class='overlay'></div></div>";
                $("body").append(loading_component);
            } else if (action == "hide") {
                $("body .loading-component").remove();
            }
        }
    </script>