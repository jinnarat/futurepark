<link rel="stylesheet" href="<?php echo $uri; ?>assets/css/element.css">

<?php echo form_open_multipart('cmsbackend/user/user_update', array('onsubmit' => 'return check_user();'));?>
<div class="page-header breadcamp"><?php echo anchor('cmsbackend/user/user_list','User Management')." > ".$text_action; ?></div>	
<p>
	<a href="<?php echo base_url()?>index.php/cmsbackend/user/user_list"><button class="btn btn-secondary btn-sm" type="button" ><span data-feather="arrow-left-circle"></span> กลับ</button></a>		
	<!-- <button type="button" class="btn btn-default" onclick="javascript:location.href='<?php echo base_url()?>index.php/cmsbackend/user/user_list'"><< กลับ</button>&nbsp; button class="btn btn-primary" type="submit">บันทึก</button -->
</p>
<div class="panel panel-default">
	<div class="panel-heading"><?php echo $action; ?></div>
	<div class="panel-body">
		<input type="hidden" name="user_id" id="user_id" value="<?php echo $user_id?>">
		<table width="60%" cellpadding="5" >
			<tr>
				<td width="170">Name : <span class="remark">*</span></td>
				<td><input type="text" id="name" name="name" class="form-control" value="<?php echo $name ?>" required /></td>
				<td></td>
			</tr>
			<tr>
				<td>Email : <span class="remark">*</span></td>
				<td>
					<input type="email" id="mail" name="mail" class="form-control" value="<?php echo $mail ?>" required />
					<font color="red" size="4">
						<p style="margin-bottom: 4px;">(Ex. mail@mail.com,mail@mail.com)</p>
					</font>
				</td>
				<td></td>
			</tr>
			<tr>
				<td>Expire Date : <span class="remark">*</span></td>
				<td><select class="form-control form-control-sm" required id="expire_date" name="expire_date" onchange="SelectSession(this)">
						<option value="">-- กรุณาเลือก --</option>
						<option value="N" <?php if($expire_date == "N") echo 'selected'; ?>> Never expire </option>
						<option value="3" <?php if($expire_date == "3") echo 'selected'; ?>> Expires 3 month </option>
					</select>
				</td>
			</tr>

			<tr>
				<td>Username : <span class="remark">*</span></td>
				<td><input type="text" id="username" name="username" class="form-control" value="<?php echo $username ?>" maxlength="10" onkeyup="text(this.value);" onkeypress="CheckTXT();" required /></td>
				<td></td>
			</tr>

			<?php if(!empty($user_id)){ ?>
				<tr>
					<td>Old Password : <span class="remark">*</span></td>
					<td>
						<input type="password" id="oldpass" name="oldpass" class="form-control" value="" maxlength="10" onkeypress="CheckPASS();" />
						<font color="red" size="4">
							<p style="margin-bottom: 4px;">ใส่เฉพาะตัวอักษรภาษาอังกฤษและตัวเลขได้ไม่เกิน 10 ตัว</p>
						</font>
					</td>
					<td></td>
				</tr>
			<?php }?>
			
			<tr>
				<td>Password : <?php if(empty($user_id)){ ?><span class="remark">*</span><?php } ?></td>
				<td>
					<input type="password" id="password" name="password" class="form-control" value="" maxlength="10" onkeypress="CheckPASS();" />
					<font color="red" size="4">
						<p style="margin-bottom: 4px;">ใส่เฉพาะตัวอักษรภาษาอังกฤษและตัวเลขได้ไม่เกิน 10 ตัว</p>
					</font>
				</td>
				<td></td>
			</tr>
			<tr>
				<td>Re - Password : <?php if(empty($user_id)){ ?><span class="remark">*</span><?php } ?></td>
				<td>
					<input type="password" id="re_password" name="re_password" class="form-control" value="" maxlength="10" onkeypress="CheckPASS();" />
					<font color="red" size="4">
						<p style="margin-bottom: 4px;">ใส่เฉพาะตัวอักษรภาษาอังกฤษและตัวเลขได้ไม่เกิน 10 ตัว</p>
					</font>
				</td>
				<td></td>
			</tr>
			<tr>
				<td>User Type : </td>
				<td>
					<input type="radio" name="user_type" onclick="accessAdmin();" id="user_type_admin"  value="Admin" <?php echo $type_admin; if($this->session->userdata('ufostatauthorsize') == "User"){ echo "disabled"; }?>  > Admin &nbsp;&nbsp;
					<input type="radio" name="user_type" onclick="accessAdmin();" id="user_type_user" value="User" <?php echo $type_user; ?>> User &nbsp;&nbsp;
				</td>
				<td></td>
			</tr>
			<?php if($this->session->userdata('ufostatauthorsize') == "Admin"){?>
				<tr id="checkbox" style="display:<?php echo $display_menu; ?>" >
					<td valign="top">User Access : </td>
					<td>
						<?php echo $menu_list; ?>
					</td>
				</tr>
			<?php  }?>
			<tr>
				<td></td>
				<td align="right"><button type="submit" class="btn btn-primary">บันทึก</button></td>
				<td></td>
			</tr>
		</table>
		
	</div>
</div>
<?php echo form_close(); ?>

<script>
	$('document').ready(function(){
       
    }); 

	function SelectSession(obj){
		if(obj.value == "ADD"){
			$("#agd_session_add").show();
		}else{
			$("#agd_session_add").val("");
			$("#agd_session_add").hide();
		}
	}
	
	function text(val){
		var s = document.getElementById("username").value;

		var re = /[\!$%^&*(){}<>:;'\"]/; 
		var re1 = /[\!$%^&*(){}<>:;'\"]/; 
		var result = s.match(re);    				
		
		if(result!=null){
			document.getElementById("username").value="";
			return false ;
		}
	}
	
	function CheckTXT(){  
		if ((event.keyCode == 32)||(event.keyCode >= 48 && event.keyCode <= 57)||(event.keyCode >= 65 && event.keyCode <= 90)||(event.keyCode >= 97 && event.keyCode <= 122)){event.returnValue = true; }
		else{event.returnValue = false;  }
	}
	
	function CheckPASS(){  
		if ((event.keyCode == 32)||(event.keyCode == 46)||(event.keyCode >= 48 && event.keyCode <= 57)||(event.keyCode == 64)||(event.keyCode >= 65 && event.keyCode <= 90)||(event.keyCode >= 97 && event.keyCode <= 122)){event.returnValue = true; }
		else{event.returnValue = false;  }
	}
	
	function check_user(){
		var user_id = document.getElementById("user_id");
		
		var password = document.getElementById("password");
		var re_password = document.getElementById("re_password");
		
		if(user_id.value.trim() != "" || user_id.value.trim() != 0){
			var old_pass = document.getElementById("oldpass");
			
			if(old_pass.value.trim() != "" || password.value.trim() != "" || re_password.value.trim() != ""){
				if(old_pass.value.trim() == ""){
					alert("กรุณากรอกรหัสผ่านเดิม"); old_pass.focus(); return false; 
				}
				if(password.value.trim() == ""){
					alert("กรุณากรอกรหัสผ่านใหม่"); password.focus(); return false; 
				}
				if(re_password.value.trim() == ""){
					alert("กรุณากรอกรหัสผ่านใหม่ อีกครั้ง"); re_password.focus(); return false; 
				}
			}
			if(old_pass.value.trim() != "" && password.value.trim() != "" && re_password.value.trim() != ""){
				if(password.value.trim() != re_password.value.trim()){
					alert("กรุณาตรวจสอบรหัสผ่านใหม่ อีกครั้ง !"); password.value=""; re_password.value=""; password.focus(); return false; 
				}
			}
		}else{
			if(password.value.trim() == ""){
				alert("กรุณากรอกรหัสผ่านใหม่"); password.focus(); return false; 
			}
			if(re_password.value.trim() == ""){
				alert("กรุณากรอกรหัสผ่านใหม่ อีกครั้ง"); re_password.focus(); return false; 
			}
			
			if(password.value.trim() != "" && re_password.value.trim() != ""){
				if(password.value.trim() != re_password.value.trim()){
					alert("กรุณาตรวจสอบรหัสผ่านใหม่ อีกครั้ง !"); password.value=""; re_password.value=""; password.focus(); return false; 
				}
			}
		}
	}
	
	function accessAdmin(){
		if(document.getElementById('user_type_admin').checked == true){
			// alert('a');
			$('#checkbox').hide();
			// document.getElementById('checkbox').hidden =true;	
			//console.log(1);
			document.getElementById('menu[1]').checked = true;	
			document.getElementById('menu[2]').checked =true;		
			document.getElementById('menu[3]').checked =true;			
			document.getElementById('menu[4]').checked =true;		
			document.getElementById('menu[5]').checked =true;			
			document.getElementById('menu[6]').checked =true;	
		
			//var menu = $("#menu[1]").val("1"); 	
		}else if(document.getElementById('user_type_user').checked == true){
			// alert('u');
			$('#checkbox').show();
		}
	}
	
	(function() {
		'use strict';

		window.addEventListener('load', function() { 
			var forms = document.getElementsByClassName('needs-validation');
			var validation = Array.prototype.filter.call(forms, function(form) {
				form.addEventListener('submit', function(event) {
					if (form.checkValidity() === false) {
						event.preventDefault();
						event.stopPropagation();
					}
				form.classList.add('was-validated');
				}, false);
			});
		}, false);
	})();
</script>     
