<!-- <script src="<?php echo $uri; ?>assets/js/jquery.bootgrid.js"></script>
<script src="<?php echo $uri; ?>assets/js/jquery.bootgrid.fa.js"></script>
<link href="<?php echo $uri; ?>assets/css/jquery.bootgrid.css" rel="stylesheet" /> -->

<table width="100%" style="margin-top: 50px;">
	<tr>
		<td width="50%"><div class="page-header breadcamp">User Management</div></td>
	</tr>
</table>
<div>
	<?php if($this->session->userdata('ufostatauthorsize') == "Admin"){ ?>
		<a class="btn btn-info btn-sm" href="<?php echo $uri;?>index.php/cmsbackend/user/user_manage" role="button">+ เพิ่ม User</a>
	<?php } ?>
</div>
<div class="table-responsive"> <br>
	<table class="table table-striped table-sm">
		<thead>
			<tr>
				<th width="7%" style="text-align: center;" >ลำดับ</th>
				<th width="20%" style="text-align: left">Username</th>
				<th width="15%" style="text-align: left">Roles</th>
				<th width="15%" style="text-align: left;" >สถานะ</th>
				<th width="15%" style="text-align: left;">แก้ไขล่าสุด</th>
				<th width="1%" style="text-align: left;">แก้ไข</th>
				<th width="1%" style="text-align: left;">ลบ</th>
			</tr>
		</thead>
		<tbody id="tbody_activity">
			<?php echo $tablelist ?>
		</tbody>
	</table>
</div>	

<script>
	// $('document').ready(function(){

    // }); 
	
	// function deleteForm(id, name)
	// {
	// 	var conf = confirm("Do you want to delete this form?");
	// 	if(conf == true)
	// 	{
	// 		location.href='<?php echo base_url()?>index.php/cmsbackend/user/user_status/'+id+'/D/'+name;
	// 	}else
	// 	{
	// 		return false;
	// 	}
	// }
	
	// function DelAction(id){		
	// 	if (confirm("Are you sure you want to delete?")) {
	// 		$.ajax({
	// 			data: "user_id=" + id,
	// 			method: "post",
	// 			url: "<?php echo base_url('index.php/cmsbackend/user/user_delete') ?>"
	// 		}).done(function(e) {
	// 			if(e == 'pass'){
	// 				alert('Delete data already.'); location.href='<?php echo base_url('index.php/cmsbackend/user/user_list') ?>';
	// 			}
	// 		})
	// 	}
	// }
</script>     
