				</div>
			</div>	
		</div>
		<!-- <div class="loading"><img class="loading-img" src="<?php echo base_url() . "images/loading/wait.gif" ?>" /></div> -->
		
		<div class="modal fade" id="confirmModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
			<div class="modal-dialog modal-sm" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">ข้อความ</h5>
						<button type="button" class="close modal-close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<div class="modal-body">

					</div>
					<div class="modal-footer modal-block">
						<button type="button" class="btn btn-default modal-close" data-dismiss="modal">ยกเลิก</button>
						<button type="button" class="btn btn-primary submit">ยืนยัน</button>
					</div>
				</div>
			</div>
		</div>
		
    </body>
</html>