<?php
$urlin = $this->Main_function->html_chars(base_url());
$uri = substr($urlin,0,-10);
$baseurl = $uri;

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Line Application : Content Management System (CMS)</title>
        <meta http-equiv="X-UA-Compatible" content="IE=Edge">
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<link rel="shortcut icon" href="<?php echo $baseurl; ?>assets/images/logo/favicon.ico">
        
        <!-- Jquery Version.1.9 -->
        <script src="<?php echo $uri;?>assets/js/jquery-3.3.1.min.js"></script>
        
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="<?php echo $uri;?>assets/css/bootstrap.css">

        <!-- Optional theme -->
        <link rel="stylesheet" href="<?php echo $uri;?>assets/css/bootstrap-theme.min.css">
        <!-- <link rel="stylesheet" href="<?php echo $uri;?>assets/css/datepicker.css"> -->
        <link rel="stylesheet" href="<?php echo $uri.'assets/css/style.css?v='.date('His')?>">
		
		<!-- Custom styles for this template -->
		<!-- <link href="<?php echo $uri;?>css/dashboard.css" rel="stylesheet"> -->
        

        <!-- Latest compiled and minified JavaScript -->
        <script src="<?php echo $uri;?>assets/js/bootstrap.min.js"></script>
      
        <!-- For Support IE 6-8 -->
        <script src="<?php echo $uri;?>assets/js/respond.js"></script>    
        
        <!-- auto complete-->
        <link href="<?php echo $uri;?>assets/css/jquery.ui.css" rel="stylesheet">
        <script src="<?php echo $uri;?>assets/js/jquery-ui.min.js"></script>    
		
		<!-- <script src="<?php echo $uri;?>assets/js/global.js"></script>   -->
    </head>
    <body>
    <!--Nav bar TOP-->
	<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="<?php echo $uri."index.php/main"?>"><img src="<?php echo $uri;?>assets/images/logo/logo.futurepark.png" height="30px;"> 
		  	<!-- Content Management System (CMS) -->
		 </a>
        </div>
        <div class="navbar-collapse collapse"> 			
			<ul class="navbar-form navbar-right">				
				<li><span style='color: white;padding-right:7px;' class="fontMenu">Welcome <?php echo $this->session->userdata('uname');?></span></li>
				<li><a href="<?php echo $uri;?>index.php/login/logout" class="fontMenu">Logout</a></li>
			</ul>
        </div>
      </div>
    </div>	
    <!--End Nav bar TOP-->
	
	<div class="container-fluid">
		<div class="row none_margin">
		<!-- Start Menu -->
		<div class="col-sm-3 col-md-2 sidebar">
			<ul class="nav nav-pills nav-stacked">
				<li id="m_user"><a href="#">User Management</a>
				  <ul class="sub-nav">
					<li id="s_user_list" class="first"><a href="<?php echo $uri;?>index.php/cmsbackend/user/user_manage">User List</a></li> 
				  </ul>
				</li>
				<li id="m_service_log"><a href="#">title</a>
				  <ul class="sub-nav">
					<li id="s_log_web_consent" class="first"><a href="#">submenu1</a></li> 
					<li id="s_log_web_service"><a href="#">submenu2</a></li> 
				  </ul>
				</li>
			</ul>
		</div>
		<!-- End Menu -->
		
<style>
.navbar-fixed-top {
	border: 0;
}
.none_margin {
    margin: 0px;
}
.nav li a {
    background-image: url(../images/icon/down-arrow.svg);
    background-position: right 6px center;
    background-repeat: no-repeat;
    background-size: 12px;
    position: relative;
}
.nav ul.sub-nav {
    display: none;
}
.nav ul.sub-nav {
    padding-left: 20px;
}
.nav ul.sub-nav > li.first {
    padding: 5px 0;
}
.nav ul.sub-nav > li {
    list-style: none;
    padding: 10px 0 5px;
}
.nav li ul.sub-nav li a {
    background-image: none;
}
.nav ul.sub-nav > li a {
    text-decoration: none;
}

.nav-stacked > li + li {
    margin-top: 2px;
    margin-left: 0;
}
.nav li a {
    /* background-image: url(../images/icon/down-arrow.svg); */
    background-position: right 6px center;
    background-repeat: no-repeat;
    background-size: 12px;
    position: relative;
}
@media (min-width: 768px){
.sidebar {
    position: fixed;
    top: 51px;
    bottom: 0;
    left: 0;
    z-index: 1000;
    display: block;
    padding: 20px;
    overflow-x: hidden;
    overflow-y: auto;
    background-color: #f5f5f5;
    border-right: 1px solid #eee;
}
}
</style>
		<script>
			$(document).ready(function(){
				$("ul.nav li a").click(function(){
					$(this).parent("li").find("ul.sub-nav").slideToggle();
					$(this).parent("li").toggleClass("toggle");
				})
			})
		</script>
		
		<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">