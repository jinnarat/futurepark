<style>
    /* body{
        background-image: linear-gradient(119.85deg, #57EE6A -35.6%, #2AE1A1 -2.26%, #00B8AD 47.78%);
        color: #F9F9F9 !important;
        height: 100vh;
    } */
    .landing-slider-frame-popup .landing-item-cover-short {
        bottom: 47px;
    }

    .landing-item-cover-img {
        object-fit: cover;
        display: block;
        height: 100%;
        width: 100%;
    }

    .hero-image {
        /* background-image: url(<?php echo $uri . "assets/images/bg/home.png?v=" . date('his') . "" ?>); */
        height: 200px;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        position: relative;
        background-size: 100% !important;
    }

    .hero-text {
        text-align: center;
        position: absolute;
        top: 30%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: white;
    }

    .hero-text button {
        border: none;
        outline: 0;
        display: inline-block;
        padding: 10px;
        background-color: #00A694;
        text-align: center;
        cursor: pointer;
        margin-top: 150px;
        width: 250px;
    }

    .modal-dialog {
        margin: 0;
    }

    .modal-content {
        height: 100vh;
        /* display: flex; */
        /* height: -webkit-fill-available; */
        /* min-height: 100vh; */
        /* min-height: -webkit-fill-available; */
        /* min-height: -webkit-fill-available; */
        /*       height: 100vh;
        height: -webkit-fill-available; */
    }

    /* .hero-text button:hover {
        background-color: white;
        color: #00A694;
    } */

    .personal-pro {
        /* position: relative;
        margin: -25px 15px 0 -20px; */
        width: 17%;
        margin-right: 7px;
    }

    .text-eng {
        font-size: 17px;
    }

    .col-3 {
        padding: 0;
    }
</style>
<link rel="stylesheet" href="<?php echo $uri; ?>assets/owl/owl.carousel.css?v=<?php echo date('mis'); ?>" />
<link rel="stylesheet" href="<?php echo $uri; ?>assets/owl/owl.carousel.min.css?v=<?php echo date('mis'); ?>" />

<script type="text/javascript" src="<?php echo $uri; ?>assets/owl/owl.carousel.min.js?v=<?php echo date("YmdHis") ?>"></script>
<script type="text/javascript" src="<?php echo $uri; ?>assets/owl/owl.carousel.js?v=<?php echo date("YmdHis") ?>"></script>

<!-- <div class="hero-image" style="background: url('<?php echo $uri . "assets/images/bg/home.png?v=" . date('his') . "" ?>') top center no-repeat;"> -->
<div class="hero-image">
    <div class="hero-text">
        <button>
            <a href="<?php echo $uri; ?>Promotion">
                <img src="<?php echo $uri . "assets/images/new_icon/template_Future_icon-your-privilege.png?v=" . date('his') . "" ?>" alt=" " class="responsive personal-pro">
                <spen style="color: white;">สิทธิพิเศษเฉพาะคุณ</spen>
                <!-- <span class="text-eng">(Personalized Promotion)</span> -->
            </a>
        </button>

    </div>
</div>

<div class="container bottom40">
    <div class="row text-center">
        <div class="col-3">
            <a href="<?php echo $uri; ?>Privilege">
                <img src="<?php echo $uri . "assets/images/new_icon/template_Future_icon-privilege.png?v=" . date('his') . "" ?>" alt=" " class="responsive top10 center">
                <div class="top10">สิทธิพิเศษ</div>
                <div class="text-eng">(Privilege)</div>
            </a>
        </div>
        <div class="col-3">
            <a href="<?php echo $uri; ?>Campaign">
                <img src="<?php echo $uri . "assets/images/new_icon/template_Future_icon-activity.png?v=" . date('his') . "" ?>" alt=" " class="responsive top10 center">
                <div class="top10">กิจกรรม</div>
                <div class="text-eng">(Campaign/Event)</div>
            </a>
        </div>
        <div class="col-3">
            <a href="<?php echo $uri; ?>Service">
                <img src="<?php echo $uri . "assets/images/new_icon/template_Future_icon-service.png?v=" . date('his') . "" ?>" alt=" " class="responsive top10 center">
                <div class="top10">บริการ</div>
                <div class="text-eng">(Service Request)</div>
            </a>
        </div>
        <div class="col-3">
            <a href="<?php echo $uri; ?>Shop/cateshop">
                <img src="<?php echo $uri . "assets/images/new_icon/template_Future_icon-shop.png?v=" . date('his') . "" ?>" alt=" " class="responsive top10 center">
                <div class="top10">ร้านค้า</div>
                <div class="text-eng">(Shop Search)</div>
            </a>
        </div>
    </div>

    <?php if ($privilege_slider) { ?>
        <div class="top30">
            <p class="text-highlight">สิทธิพิเศษ</p>
            <div class="owl-carousel owl-theme">
                <?php
                if (count($privilege_slider) > 0) {
                    foreach ($privilege_slider as $privilegeHtml) {
                        echo $privilegeHtml;
                    }
                }
                ?>
            </div>
        </div>
    <?php } ?>

    <?php if ($act_slider) { ?>
        <div class="top30">
            <p class="text-highlight">กิจกรรม</p>
            <div class="owl-carousel owl-theme">
                <?php
                if (count($act_slider) > 0) {
                    $dataList = $act_slider;
                    for ($i = 0; $i < count($act_slider); $i++) {
                        echo $dataList[$i];
                    }
                }
                ?>
            </div>
        </div>
    <?php } ?>

    <?php if ($highlight_slider) { ?>
        <div class="top30">
            <p class="text-highlight">โปรโมชั่นไฮไลท์ และ กิจกรรมไฮไลท์</p>
            <div class="owl-carousel owl-theme">
                <?php
                if (count($highlight_slider) > 0) {
                    $dataList = $highlight_slider;
                    for ($i = 0; $i < count($highlight_slider); $i++) {
                        echo $dataList[$i];
                    }
                }
                ?>
            </div>
        </div>
    <?php } ?>
</div>

<script>
    $('.owl-carousel').owlCarousel({
        stagePadding: 60,
        // loop:true,
        loop: false,
        margin: 10,
        nav: false,
        // stagePadding: Number,
        // items:2
        responsive: {
            0: {
                items: 1
            }
        }
    })
</script>

<style>
    .item {
        /* border: 1px solid; */
        box-shadow: 5px 10px 8px #888888;
        border-radius: 7px;
        background: #fff;
    }

    .owl-stage {
        padding-left: 0 !important;
    }

    .promo-detail {
        margin: 5px 0;
        /* height: 16vh; */
    }

    /* .owl-carousel .owl-item img {
        height: 40vh;
    } */

    .promo-img .default-img {
        padding: 10px 0;
    }

    .iframe-container iframe {
        border: 0;
        height: 100%;
        left: 0;
        position: absolute;
        top: 0;
        width: 100%;
    }
</style>

<script>
    $('.item-ifram').click(function(e) {
        e.preventDefault();

        let type = $(this).attr('type');
        let linkPromo = $(this).find('.promo-img a').attr('href');
        let namePromo = $(this).find('.activityName').text();
        if (type) {
            window.location.href = linkPromo;
        } else {
            let iframHtml = `<iframe class="ifram iframe-container iframe-model" src="${linkPromo}" frameborder="0"></iframe>`;
            $("#myModalTitle .modal-title").empty().html(namePromo);
            $("#myModalTitle .modal-body").empty().append(`${iframHtml}`);
            $("#myModalTitle").modal('show');
        }
    });
</script>