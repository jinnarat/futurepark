<!-- Campaign/Event -->
<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title"> กิจกรรม (Event)</p>
        </div>
    </div>
</div>
<div>
    <?php echo $list_camp; ?>
</div>