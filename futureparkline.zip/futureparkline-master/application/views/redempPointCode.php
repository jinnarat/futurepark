<link rel="stylesheet" href="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.css'); ?>">
<style>
    .modal-dialog {
        margin-top: 70%;
    }
</style>
<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo base_url('Campaign'); ?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title"> </p>
        </div>
    </div>
    <div class="top30">

    </div>

    <div class="row my-3">
        <div class="col-12">
            <div class="card border-0">
                <?php if (isset($imgBanner)) : ?>
                    <?php if (getimagesize(PATHIMGCAMPAIGN . $imgBanner)) : ?>
                        <img src="<?= PATHIMGCAMPAIGN . $imgBanner . '?v="' . date('his') . '"'; ?>" class="card-img-top" alt="image">
                    <?php else : ?>
                        <img src="<?= base_url('assets/images/default_image.jpg') . '?v="' . date('his') . '"'; ?>" class="card-img-top" alt="image">
                    <?php endif; ?>
                <?php else : ?>
                    <img src="<?= base_url('assets/images/default_image.jpg') . '?v="' . date('his') . '"'; ?>" class="card-img-top" alt="image">
                <?php endif; ?>
                <div class="modal-header">
                    <h2 class="card-title text-center"><?php echo isset($activityName) ? $activityName: ''; ?></h2>
                </div>
                <?php if ($status) : ?>
                    <div class="card-body" style="background-color: #00c4b3;">
                        <div class="row">
                            <div class="col-12 text-center text-white" id="usedDate">ใช้เมื่อ : <?= date('d-m-Y H:i:s', strtotime($useTime)); ?></div>
                            <div style="background-color: white;" class="col-12 text-center d-flex justify-content-center align-items-center hide-code-detail">
                                <?php if ($status == true) : ?>
                                    <strong id="textCode" class="p-5 my-0 h1 hide-code-detail"><?= $code; ?></strong>
                                <?php endif; ?>
                            </div>
                            <div class="col-12 mt-3 text-center hide-code-detail">
                                <?php if ($status == true) : ?>
                                    <?php if (isset($qrcodeImage) && $status) : ?>
                                        <?php if (getimagesize(PATHIMGCAMPAIGN . $qrcodeImage)) : ?>
                                            <img src="<?= PATHIMGCAMPAIGN . $qrcodeImage . '?v="' . date('his') . '"'; ?>" alt="..." style="width:80%" class="img-thumbnail">
                                        <?php else : ?>
                                            <img src="<?= base_url('assets/images/default_image.jpg') . '?v="' . date('his') . '"'; ?>" alt="..." class="img-thumbnail">
                                        <?php endif; ?>
                                    <?php else : ?>
                                        <?php if ($code) : ?>
                                            <img src="<?= base_url('assets/images/default_image.jpg') . '?v="' . date('his') . '"'; ?>" alt="..." class="img-thumbnail">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <?php if ($status == true) : ?>
                                <div class="col-12 mt-3 text-center text-white countdown "></div>
                            <?php endif; ?>
                            <div class="col-12 mt-3 text-center text-white" id="timeout"></div>
                            <?php if (isset($detail)) : ?>
                                <div class="col-12 mt-3 text-center text-white hide-code-detail">
                                    <small><?= $detail; ?></small>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php else : ?>
                    <h3 class="text-center"><?= $message; ?></h3>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.js'); ?>"></script>

<script src="<?php echo base_url('assets/js/moment-with-locales.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/moment-countdown.js'); ?>"></script>
<script>
    $(document).ready(function() {
        let status = "<?= $status; ?>";
        if (status) {
            let codeExpired = "<?= isset($codeExpired) ? $codeExpired : null; ?>";
            let usedDate = "<?= isset($useTime) ? $useTime : null; ?>";
            if (usedDate) {
                let newDateMoment = moment(usedDate, 'YYYY/MM/DD HH:mm').locale('th').add(543, 'year').format('DD MMM YYYY HH:mm')
                $('#usedDate').text('ใช้เมื่อ : ' + newDateMoment);
                let countDown = new CustomFunction();
                if (codeExpired) {
                    countDown.countDownTime(codeExpired, '.countdown', '', '#timeout');
                }
            }
        }
    })
</script>