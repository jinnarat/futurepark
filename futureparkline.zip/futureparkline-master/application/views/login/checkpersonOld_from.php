<link rel="stylesheet" href="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.css'); ?>">

<style>
    .requiredRadio{
        background-color: rgba(237, 35, 36, .1);
        border-color: #ed2324;
    }
</style>
<?php
	$arrayRef 	= '{}'; 
	$tmpDataSet = ''; 
	if(isset($DataRef)){ $arrayRef	= $DataRef;}
?>
<div class="template"> 
	<div class="body-content card-form" cname="<?php if(isset($detail[0]['urlfriendly'])) echo $detail[0]['urlfriendly'];?>" uid="<?php if(isset($uid)) echo $uid;?>">
		<div class="container"> 
			<div class="block-profile mt-3">
				<?php if(isset($DataPerson) && $DataPerson != "") { ?>
				<p class="text-title top30" id="head_page">สมัครสมาชิก</p>
				<div class="mt-3">
					<div class="text-center top30">
                        <div>หากคุณเป็นเจ้าของเบอร์มือถือ <?php echo $newphone ?> โปรดเลือกรายชื่อที่ตรงกับคุณ (ถ้าไม่มีให้เลือก ไม่ใช่คุณ)</div>
					</div>
					<div class="card-profile mb-3">
						<div class="card-columns  top30">						
							<?php echo $DataPerson; ?>				
						</div>					
					</div>
				</div>
				<div class="mt-5 text-center">
					<button class="btn btn-submit btn-confirm">ยืนยัน (Submit)</button>
				</div>
				<?php } ?>
			</div>
			<div class="card mb-3 card-mform d-none">
				<div class="card-body">					
					<div class="card-form"></div>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- <div class="img-footer">
    <img src="<?php echo $uri . "assets/images/bg/bottom_bg.jpg?v=".date('his')."" ?>" alt=" " style="width: 111%;"class="responsive top10">  
</div> -->
<script src="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.js'); ?>"></script>

<script src="<?php echo base_url("assets/js/moment-with-locales.js?v=" . date("YmdHis")) ?>"></script>
<script src="<?php echo base_url("assets/js/bootstrap-birthday.js?v=" . date("YmdHis")) ?>"></script>
<script type="text/javascript">
	//loadingPage('#load_page');
	var DataRef = <?php echo json_encode($arrayRef) ?>; 	
	var tmpDataSet = "<?php echo $tmpDataSet ?>"; 
	var DataPerson = <?php echo $countPerson ?>;
	//  console.log('DataPerson : ',DataPerson);

    //  console.log('tmpDataSet : ',tmpDataSet);

	$(document).ready(function() {
		if(DataPerson == 0){
			InitTemplate();	
        }else{
            InitTemplate(<?php echo $pid; ?>);
        }

        Swal.fire({
            position: 'top',
            icon: 'success',
            title: 'รอสักครู่ กำลังเตรียมข้อมูล',
            showConfirmButton: false,
            timer: 5000
        });

    });

    $(document).on('change', '#national', function () {
        var nation = $("#national option:selected").val();

        if(nation == 'TH'){
            $('.idcardBox').removeClass('d-none');
            $('.passportBox').addClass('d-none');
        }else{
            $('.idcardBox').addClass('d-none');
            $('.passportBox').removeClass('d-none');
        }
    });
  
    $(document).on('change', 'input:radio', function () {
        var value= $("input:radio[name=gender]:checked").val();
        // console.log('value : ',value);
    });

    $(document).on('click', '.card.cs-pointer', function () {
        $(".card-columns .my-checkfield").removeClass("my-checkfield-selected");
        $(this).find(".my-checkfield").addClass("my-checkfield-selected");
        $(".btn-confirm").attr("pid", $(this).attr('pid'));
    });

$(document).on('click', '.btn-confirm', function () {
    InitTemplate($(this).attr('pid'));
    //getPersonData();
});

$(document).on('click', '.btn-save', function () {
    loading('show');
    checkValidate();
});

$(document).on('click', '.modal-close', function () {
    $('#confirmModal').modal('hide');
    $('#confirmModal .modal-dialog').css("margin-top", "");
    $('#checkCondition').prop('checked', false);
    $("#btnSubmit").addClass("disabled");
    $('#btnSubmit').removeClass('btn-submit').addClass('btn-secondary');
});

$(document).on('click', '.submit', function () {
    $('#confirmModal').modal('hide');
    $('#confirmModal .modal-dialog').css("margin-top", "");
    $('#checkCondition').prop('checked', true);
    var Condition = $('#checkCondition').is(":checked")
    if (Condition == true) {
        $('#btnSubmit').removeClass('disabled')
        $('#btnSubmit').removeClass('disabled').addClass('btn-submit');
        var Congrats = $('#checkCongrats').is(":checked")
        if (Congrats == true) {
            $("#value_consent").val("Y");
        } else {
            $("#value_consent").val("N");
        }
    } else {
        $("#btnSubmit").addClass("disabled");
        $('#btnSubmit').removeClass('btn-submit').addClass('btn-secondary');
    }
});

function checkBox() {
$('#confirmModal .modal-dialog').css("margin-top", "0%");
$('#confirmModal .modal-title').html('ยินยอมให้เปิดเผยข้อมูล');
$('#confirmModal .modal-body').html(`
    <div class="row">
        <div class="col-12 text-center">
            <img width="100%" height="154" src="https://crm.futurepark.co.th/mkt/wp-content/uploads/2020/05/Photos-Library-300x154.png" class="attachment-medium size-medium" alt="" loading="lazy" srcset="https://crm.futurepark.co.th/mkt/wp-content/uploads/2020/05/Photos-Library-300x154.png 300w, https://crm.futurepark.co.th/mkt/wp-content/uploads/2020/05/Photos-Library.png 592w" sizes="100vw">
        </div>
    </div>
    <div class="row">
        <div class="col-12">
        <h4 class="text-center">หนังสือขอความยินยอมในการนำข้อมูลไปใช้ภายใต้โครงการ CDP</h4>
            &nbsp;&nbsp;
            บริษัท รังสิตพลาซ่า จำกัด (“บริษัท”) ในนามของศูนย์การค้าฟิวเจอร์พาร์ค รังสิต และ สเปลล์ (“ศูนย์การค้า”) ได้ดำเนินการตามพระราชบัญญัติคุ้มครองข้อมูลส่วนบุคคล พ.ศ. 2562 สำหรับการเก็บรวบรวม ใช้ ประมวลผลและเปิดเผยข้อมูลส่วนบุคคล เพื่อวัตถุประสงค์ต่างๆ ตามที่ได้ระบุไว้ด้านล่างนี้ 
            ทั้งนี้ หากท่านมีข้อสงสัยเกี่ยวกับการเก็บรวบรวม ใช้ หรือเปิดเผยข้อมูลส่วนบุคคลของท่าน ระยะเวลาที่บริษัทจะเก็บข้อมูลส่วนบุคคลของท่านไว้ วิธีการในการเก็บรักษาและมาตรฐานในการรักษาความปลอดภัยของข้อมูลส่วนบุคคลของท่าน หรือเกี่ยวกับสิทธิในข้อมูลส่วนบุคคล ช่องทางและวิธีในการใช้สิทธิของท่านในฐานะเจ้าของข้อมูลส่วนบุคคล รวมถึงสิทธิในการขอถอนความยินยอมของท่านได้ที่นโยบายความเป็นส่วนตัว ติดต่อเจ้าหน้าที่คุ้มครองข้อมูลส่วนบุคคลของบริษัทได้ที่ หมายเลขโทรศัพท์ 02-958-0011
            สำหรับเจ้าของข้อมูลส่วนบุคคล - กรุณาทำเครื่องหมาย  ในช่อง  เพื่อให้ความยินยอมตามที่ท่านประสงค์จะให้ไว้ 
            ข้าพเจ้ายินยอม  ข้าพเจ้าไม่ยินยอม ให้บริษัท เก็บรวบรวม ใช้และเปิดเผยข้อมูลส่วนบุคคลของข้าพเจ้าให้แก่ .... ได้แก่ ชื่อ นามสกุล หมายเลขโทรศัพท์มือถือ อีเมล์ วันเดือนปีเกิด และที่อยู่ปัจจุบันของข้าพเจ้าเพื่อนำใปใช้ในการแจ้งข่าวสาร โปรโมชั่น และกิจกรรมต่าง ๆ ของศูนย์การค้า และพันธมิตรของบริษัท
            ข้าพเจ้ายินยอม  ข้าพเจ้าไม่ยินยอม ให้บริษัท เก็บรวบรวม ใช้และเปิดเผยข้อมูลส่วนบุคคลของข้าพเจ้าให้แก่ .... ได้แก่ ชื่อ นามสกุล หมายเลขโทรศัพท์มือถือ อีเมล์ เพศ วันเดือนปีเกิด หมายเลขบัตรประชาชนและที่อยู่ปัจจุบันของข้าพเจ้าเพื่อนำใปใช้ในการวิเคราะห์และวิจัยเพื่อปรับปรุงการให้บริการของศูนย์การค้า ซึ่งรวมถึงการวิเคราะห์และวางแผนทางธุรกิจเท่าที่จำเป็นเพื่อประโยชน์ในการปรับปรุงการให้บริการ
            </br></br>
            &nbsp;&nbsp;ท่านสามารถเลือกที่จะให้ความยินยอมหรือไม่ให้ความยินยอมก็ได้ โดยที่ไม่ส่งผลต่อการเข้าใช้บริการหรือสมัครสมาชิก แต่บริษัทอาจไม่สามารถแจ้งข่าวสาร โปรโมชั่น และกิจกรรมต่าง ๆ ที่เหมาะสมแก่ท่าน และ/หรือบริษัทฯ จะไม่สามารถนำข้อมูลท่านไปวิเคราะห์และวิจัยได้หากท่านไม่ให้ความยินยอมหรือถอนความยินยอม ทั้งนี้ ท่านสามารถถอนความยินยอมได้ที่ หมายเลขโทรศัพท์ 02-958-0011
        </div>
    </div>
    `);
$('#confirmModal .modal-close').html('ไม่ยินยอม');
$('#confirmModal .submit').html('ยินยอม');
$('#confirmModal').modal('show');
$('#checkCondition').prop('checked', false);
return;
var Condition = $('#checkCondition').is(":checked")
var Congrats = $('#checkCongrats').is(":checked")

if (Condition == true) {
    // $("#btnSubmit").attr("disabled", false);
    $('#btnSubmit').removeClass('disabled')
    $('#btnSubmit').removeClass('disabled').addClass('btn-submit');
} else {
    $("#btnSubmit").addClass("disabled");
    $('#btnSubmit').removeClass('btn-submit').addClass('btn-secondary');
}
}



function checkPassword() {
    var passNow = $('#pass').val();
    var passCon = $('#con_pass').val();
    if(passNow != passCon){
        $('#con_pass').addClass("required"); 
        $('#passnotmach').removeClass('d-none');
        $("#passnotmach").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* รหัสผ่านไม่ตรงกัน</p></font>");
            return false;
            result= false;
    }else{
        $('#con_pass').removeClass("required");
        $('#passnotmach').addClass('d-none');
        result = true;
    }

}

function isTypeOfUndefined(e) {
    if (typeof e === 'undefined') { return e = ""; }
    return e;
}

    // var TMP = tmpDataSet;
    var TMP = 'fregisterOld';
    var baseURL = window.location.href;

    function InitTemplate(pid) {
        var dataHtml = '';
        // console.log(DataRef.REFPH, pid,DataRef.UID);

        var param = { phone: DataRef.REFPH, pid: pid ,reigs:true};

        // console.log('param : ',param);
        // loadingPage('#load_page');
        $.ajax({
            url: '<?php echo $uri; ?>chkIdentity/' + TMP + '.html?v=1.0' + Math.random()
        }).done(function (HeaderHtml) {

            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: '<?php echo $uri; ?>Fncauth/get_member',
                // data: DataRef,
                data: param,
                success: function (e) {
                    // console.log('log >>>> ', e);
                    $.ajax({
                        data: '',
                        method: "post",
                        datatype: "json",
                        url: '<?php echo $uri; ?>Fncauth/get_nation',
                    }).done(function (n) {
                        $('#national').html(jQuery.parseJSON(n));

                    })

                    // console.log('log >>>> ', e.detail);

                    // loadingPage('#load_page');
                    var ID = isTypeOfUndefined(e.detail.ID);
                    var tmpFirstname = isTypeOfUndefined(e.detail.FIRST);
                    var tmpLastname = isTypeOfUndefined(e.detail.LAST);
                    var tmpBirthdate = isTypeOfUndefined(e.detail.BIRTH);
                    var tmpEmail = isTypeOfUndefined(e.detail.EMAIL);
                    var tmpGender = isTypeOfUndefined(e.detail.GENDER);
                    var tmpIdCardNo = isTypeOfUndefined(e.detail.IDCARD);
                    var tmpConsent = isTypeOfUndefined(e.detail.CONSENT);
                    var SUB = isTypeOfUndefined(e.detail.SUB);
                    var tmpNationCode = isTypeOfUndefined(e.detail.NATIONAL);
                    var tmpPassportNo = isTypeOfUndefined(e.detail.PASSPORT);
                    var tmpStatus = isTypeOfUndefined(e.status.STATUS);
                    var tmpMemNoRef = isTypeOfUndefined(e.detail.MEMNOCRM);
                    var tmpphone = DataRef.REFPH;

                    var tmpAddrDetail = isTypeOfUndefined(e.detail.addrDetail);
                    var province_code = isTypeOfUndefined(e.detail.province_code);
                    var district_code = isTypeOfUndefined(e.detail.district_code);
                    var sub_district_code = isTypeOfUndefined(e.detail.sub_district_code);
                    var postcode = isTypeOfUndefined(e.detail.postcode);
                    
                    var mapObj = {
                        '<%Id%>': ID,
                        '<%InputFirstname%>': tmpFirstname,
                        '<%InputLastname%>': tmpLastname,
                        '<%InputBirthdate%>': tmpBirthdate,
                        '<%InputGender%>': tmpGender,
                        '<%InputIdCard%>': tmpIdCardNo,
                        '<%InputPassport%>': tmpPassportNo,
                        '<%InputNation%>': tmpNationCode,
                        '<%InputEmail%>': tmpEmail,
                        '<%InputConsent%>': tmpConsent,
                        '<%phone%>': tmpphone,
                        '<%uri%>': '<?php echo $uri; ?>',
                        '<%uid%>': DataRef.UID,
                        '<%status%>': tmpStatus,
                        '<%memNoRef%>': tmpMemNoRef,

                        '<%addrDetail%>':tmpAddrDetail,
                        '<%sub_districtCode%>':sub_district_code,
                        '<%districtCode%>':district_code,
                        '<%provinceCode%>':province_code,
                        '<%postcode%>':postcode
                    }

                    dataHtml = HeaderHtml.replace(/<%Id%>|<%InputFirstname%>|<%InputLastname%>|<%InputBirthdate%>|<%InputGender%>|<%InputIdCard%>|<%InputPassport%>|<%InputNation%>|<%InputEmail%>|<%InputConsent%>|<%phone%>|<%uri%>|<%uid%>|<%status%>|<%memNoRef%>|<%addrDetail%>|<%sub_districtCode%>|<%districtCode%>|<%provinceCode%>|<%postcode%>/gi, function (matched) {
                        return mapObj[matched];
                    });

                    $(".card-form").empty().html(dataHtml);
                    $('#birthdate').bootstrapBirthday();
                    $('#birthDay').val(e.detail.birthDay);
                    $('#birthMonth').val(e.detail.birthMonth);
                    $('#birthYear').val(e.detail.birthYear);
                    $(".img-footer").css("position", "relative");

                    $.ajax({
                        data: "pvCode=" + province_code,
                        method: "post",
                        datatype: "json",
                        url: '<?php echo $uri; ?>Fncauth/getProvince',
                    }).done(function (e) {
                        $('#province').html(jQuery.parseJSON(e));
                        $.ajax({
                            data: param,
                            method: "post",
                            datatype: "json",
                            url: '<?php echo $uri; ?>Fncauth/getDistrict',
                        }).done(function (e) {
                            $('#district').html(jQuery.parseJSON(e));
                        })  

                        // if(!isEmpty(sub_district_code) && !isEmpty(district_code)){
                            $.ajax({
                            data: param,
                                method: "post",
                                datatype: "json",
                                url: '<?php echo $uri; ?>Fncauth/getSubdist',
                            }).done(function (e) {
                                
                                $('#subdist').html(jQuery.parseJSON(e));
                            })
                        // }
                    })

                    $(".block-profile").empty();
                    // $(".card-mform").removeClass('d-none');

                    // if (typeof pid != 'undefined') {
                    // 	getPersonData(pid);
                    // }
                    // if (e.dataobj.PERSID != "") {
                    // 	getPersonData(e.dataobj.PERSID);
                    // }
                }
                , error: function (error) {
                    // console.log('error; ', error);
                }
            }).done( function () {
                let nowDate = new Date();
                let nowYear = nowDate.getFullYear();
                let checkYear = nowYear - 15;
                for (let index = nowYear; index >= checkYear; index--) {
                    $("#birthYear option[value=" + index + "]").hide();
                }
            })
        });
    }

    function selectProvince(menu)
	{	if(menu == "province"){
		 	id = document.getElementById("province").value
		}else if(menu == "district"){
			id = document.getElementById("district").value;
		}
		if(id != "") {
			$.ajax({
				data: "id=" + id +"&menu="+ menu,
				method: "post",
				datatype: "json",
				url: "<?php echo base_url('Fncauth/selectAddress') ?>",
			}).done(function(e) {
                
                data = jQuery.parseJSON(e);
                
				if(menu == "province"){
					$('#district').html(data);
				}else if(menu == "district"){
					$('#subdist').html(data);
				}
			})
		}
	}

    function selectPostcode(menu)
	{	
		var id = document.getElementById("district").value;
	
		if(id != "") {
			$.ajax({
				data: "id=" + id,
				method: "post",
				datatype: "json",
				url: "<?php echo base_url('Fncauth/selectPostcode') ?>",
			}).done(function(e) {
				$('#postcode').val(e);
			})
		}
	}

    $(document).on("focusout", "#f_name", function(){
        $("#f_name").removeClass("required");
    });

    $(document).on('click', 'input:radio[name=gender]', function () {
        $(".radio-tile").removeClass("requiredRadio");
    });

    $(document).on("focusout", "#idcard", function(){
        checkIdcard();
    });

    $(document).on("focusout", "#passport", function(){
        chackPassport();
    });

    function checkIdcard(){
        var idCard = $('#idcard').val();
        var type = 'idcard';
        var pid = $('#formUpload').attr('pid');


        if(!isEmpty(idCard)){
            if(!checkID(idCard)){
                $("#idcard").addClass("required");
                $(".texterror").removeClass("d-none");
                $(".texterror").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* เลขบัตรประชาชนไม่ถูกต้อง กรุณาตรวจสอบ</p></font>");

                goToByScroll('idcard'); 
                return false;
            }else{
                var param = { idCard: idCard, menu: type, pId: pid };
                $.ajax({
                    data: param,
                    method: "post",
                    url: '<?php echo $uri; ?>Fncauth/selectDupIdcard',
                }).done(function(e) {
                    if(e.trim() == 'fail'){
                        $("#idcard").addClass("required");
                        $(".texterror").removeClass("d-none");
                        $(".texterror").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* เลขบัตรประชาชนนี้มีในระบบแล้ว กรุณาตรวจสอบ</p></font>");
                        return false;
                        
                    }else{
                        $("#idcard").removeClass("required");
                        $(".texterror").addClass("d-none");
                    }
                })
            }
        }
    }

    function chackPassport(){
        var passport = $('#passport').val();
        var type = 'passport';
        var pid = $('#formUpload').attr('pid');

        if(!isEmpty(passport)){
            $.ajax({
                data: "passport=" + passport + "&menu=" + type + "&pId=" +pid,
                method: "post",
                url: '<?php echo $uri; ?>Fncauth/selectDupIdcard',
            }).done(function(e) {
                if(e.trim() == 'fail'){
                    $("#passport").addClass("required");
                    $(".texterror").removeClass("d-none");
                    $(".texterror").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* เลขหนังสือเดือนทางนี้มีในระบบแล้ว กรุณาตรวจสอบ</p></font>");
                    return false;
                    result = false;
                    
                }else{
                    $("#passport").removeClass("required");
                    $(".texterror").addClass("d-none");
                    result = true;
                }
            })
        }
    }

    function seletData(){
        var result = $('#numberCard').val();
        // console.log(result);

        if(result == 'passport'){
            $('#idcardBox').addClass('d-none');
            $('#passportBox').removeClass('d-none');
        }else{
            $('#idcardBox').removeClass('d-none');
            $('#passportBox').addClass('d-none');
        }
    }

    function checkValidate(){
        loading('show');
        var pid = $('#formUpload').attr('pid');
        var idcard = $('#idcard').val();
        var passport = $('#passport').val();
        var fname = $('#f_name').val();
        var lname = $('#l_name').val();
        var birthdate = $('#birthdate').val();
        var email = $('#email').val();
        var passNow = $('#pass').val();
        var passCon = $('#con_pass').val();
        var national = $('#national').val();
        var gender = $("input[name='gender']:checked").val();
        var birthDay = $("#birthDay").val();
        var birthMonth = $("#birthMonth").val();
        var birthYear = $("#birthYear").val();
        var result = false;

        var address = $("#address").val();
        var province = $("#province").val();
        var district = $("#district").val();
        var subdist = $("#subdist").val();
        var postcode = $("#postcode").val();

        var tel = $("#formUpload").attr('phone');

        if(isEmpty(fname) || isEmpty(lname) || isEmpty(passNow) || isEmpty(passCon) || isEmpty(gender) || isEmpty(birthDay) || isEmpty(birthMonth) || isEmpty(birthYear) ){

            if(isEmpty(fname)){
                $("#f_name").addClass("required");
            }else{
                $("#f_name").removeClass("required");
            }

            if(isEmpty(lname)){
                $("#l_name").addClass("required");
            }else{
                $("#l_name").removeClass("required");
            }

            if(isEmpty(birthDay)){
                $("#birthDay").addClass("required");
            }else{
                $("#birthDay").removeClass("required");
            }

            if(isEmpty(birthMonth)){
                $("#birthMonth").addClass("required");
            }else{
                $("#birthMonth").removeClass("required");
            }
            if(isEmpty(birthYear)){
                $("#birthYear").addClass("required");
            }else{
                $("#birthYear").removeClass("required");
            }

            if(isEmpty(gender)){
                $(".radio-tile").addClass("requiredRadio");
            }else{
                $(".radio-tile").removeClass("requiredRadio");
            }

            if(national == 'TH'){
                if(isEmpty(idcard)){
                    $("#idcard").addClass("required");
                }else{
                     $("#idcard").removeClass("required");
                } 

                // address 
                if(province.trim() == ""){
                    $("#province").addClass("required");
                    result = false;
                    // goToByScroll('province');  return false;
                }else{
                    $("#province").removeClass("required");
                }

                if(district.trim() == ""){
                    $("#district").addClass("required");
                    result = false;
                    // goToByScroll('district');  return false;
                }else{
                    $("#district").removeClass("required");
                }

                if(subdist.trim() == ""){
                    $("#subdist").addClass("required");
                    result = false;
                    // goToByScroll('subdist');  return false;
                }else{
                    $("#subdist").removeClass("required");
                }

                if(postcode.trim() == "" || postcode.length != 5){
                    $("#postcode").addClass("required");
                    result = false;
                    // goToByScroll('postcode');  return false;
                }
                // address 
                    
            }else {
                if(isEmpty(passport)){
                    $("#passport").addClass("required");
                    
                }else{
                    $("#passport").removeClass("required");
                    chackPassport();
                }

                // address
                if(address.trim() == ""){
                    $("#address").addClass("required");
                    result = false;
                    // goToByScroll('address');  return false;
                }else{
                    $("#address").removeClass("required");
                }
                // address
                
            }

            if(isEmpty(passNow) || passNow.length < 6){
                $('#pass').addClass("required"); 
                $('#passinvalid').removeClass('d-none');
                $('#passinvalid').empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัสผ่านอย่างน้อย 6 ตัวอักษร</p></font>");
            }else{
                $('#pass').removeClass("required");
                $('#passinvalid').addClass('d-none');
            }

            if(isEmpty(passCon) || passCon.length < 6){
                $('#con_pass').addClass("required"); 
                $('#passnotmach').removeClass('d-none');
                $('#passnotmach').empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัสผ่านอย่างน้อย 6 ตัวอักษร</p></font>");
            }else{
                $('#con_pass').removeClass("required");
                $('#passnotmach').addClass('d-none');
            }

            result = false;
            goToByScroll('l_name');  
            loading('hide');
            return false;

        }else{
            
            $("#f_name").removeClass("required");
            $("#l_name").removeClass("required");
            $(".radio-tile").removeClass("requiredRadio");
            $("#birthDay").removeClass("required");
            $("#birthMonth").removeClass("required");
            $("#birthYear").removeClass("required");
            $('#pass').removeClass("required");
            $('#passinvalid').addClass('d-none');

            if(birthDay && birthMonth && birthYear){
                if(moment().diff(moment(`${birthDay}/${birthMonth}/${birthYear}`, "DD/MM/YYYY"), 'years') < 15){
                    $('#alertModal').modal('show');
                    $('#alertModal .modal-body').html('ต้องมีอายุ 15 ปีขึ้นไป');
                    goToByScroll('f_name');
                    loading('hide');
                    return false;
                }
            }

            if(passNow.length < 6){
                $('#pass').addClass("required"); 
                $('#passinvalid').removeClass('d-none');
                $('#passinvalid').empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัสผ่านอย่างน้อย 6 ตัวอักษร</p></font>");
                goToByScroll('pass');  
                loading('hide');
                return false;
            }else{
                $('#pass').removeClass("required");
                $('#passinvalid').addClass('d-none');
            }

            if(passCon.length < 6){
                $('#con_pass').addClass("required"); 
                $('#passnotmach').removeClass('d-none');
                $('#passnotmach').empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัสผ่านอย่างน้อย 6 ตัวอักษร</p></font>");
                goToByScroll('con_pass'); 
                loading('hide'); 
                return false;
            }else{
                $('#con_pass').removeClass("required");
                $('#passnotmach').addClass('d-none');
            }

            if(!isEmpty(passCon)){
                if(passNow != passCon){
                    $('#con_pass').addClass("required"); 
                    $('#passnotmach').removeClass('d-none');
                    $("#passnotmach").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* รหัสผ่านไม่ตรงกัน</p></font>");
                    goToByScroll('con_pass'); 
                    loading('hide');
                        return false;
                }else{
                    $('#con_pass').removeClass("required");
                    $('#passnotmach').addClass('d-none');
                }
            }

            let chceckAddress = true;
            if(national == 'TH'){
                if(province.trim() == ""){
                    $("#province").addClass("required");
                    chceckAddress = false;
                    // goToByScroll('province');  return false;
                }else{
                    $("#province").removeClass("required");
                }

                if(district.trim() == ""){
                    $("#district").addClass("required");
                    chceckAddress = false;
                    // goToByScroll('district');  return false;
                }else{
                    $("#district").removeClass("required");
                }

                if(subdist.trim() == ""){
                    $("#subdist").addClass("required");
                    chceckAddress = false;
                    // goToByScroll('subdist');  return false;
                }else{
                    $("#subdist").removeClass("required");
                }

                if(postcode.trim() == "" || postcode.length != 5){
                    $("#postcode").addClass("required");
                    chceckAddress = false;
                    // goToByScroll('postcode');  return false;
                }
            }else {
                if(address.trim() == ""){
                    $("#address").addClass("required");
                    chceckAddress = false;
                    // goToByScroll('address');  return false;
                }else{
                    $("#address").removeClass("required");
                }
            }

            if (!chceckAddress) {
                loading('hide');
                goToByScroll('address');  return false;
            }

            if(!isEmpty(email)){
                if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email))
                {
                    var param = {email: email, menu: 'email', pId: pid };
                    $.ajax({
                        data: param,
                        method: "post",
                        url: '<?php echo $uri; ?>Fncauth/selectDupIdcard',
                    }).done(function(e) {
                        if(e.trim() == 'fail'){
                            $("#email").addClass("required");
                            $(".textEmail").removeClass("d-none");
                            $(".textEmail").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* อีเมลนี้มีในระบบแล้ว กรุณาตรวจสอบ</p></font>");
                            goToByScroll('email');  
                            loading('hide');
                            return false;
                            
                        }else{
                            $("#email").removeClass("required");
                            $(".textEmail").addClass("d-none");

                            if(national == 'TH'){
                                if(!isEmpty(idcard)){
                                    if(!checkID(idcard)){
                                        $("#idcard").addClass("required");
                                        $(".texterror").removeClass("d-none");
                                        $(".texterror").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* เลขบัตรประชาชนไม่ถูกต้อง กรุณาตรวจสอบ</p></font>");

                                        goToByScroll('idcard'); 
                                        loading('hide');
                                        return false;
                                    }else{
                                        var param = { idCard: idcard, menu: 'idcard', pId: pid };
                                        $.ajax({
                                            data: param,
                                            method: "post",
                                            url: '<?php echo $uri; ?>Fncauth/selectDupIdcard',
                                        }).done(function(e) {
                                            if(e.trim() == 'fail'){
                                                $("#idcard").addClass("required");
                                                $(".texterror").removeClass("d-none");
                                                $(".texterror").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* เลขบัตรประชาชนนี้มีในระบบแล้ว กรุณาตรวจสอบ</p></font>");
                                                loading('hide');
                                                return false;
                                                
                                            }else{
                                                $("#idcard").removeClass("required");
                                                $(".texterror").addClass("d-none");

                                                loading('show');
                                                updatePersonData();
                                            }
                                        });
                                    }
                                }
                                    
                            }else {
                                if(!isEmpty(passport)){
                                    var param = { passport: passport, menu: 'passport', pId: pid };
                                    $.ajax({
                                        data: param,
                                        method: "post",
                                        url: '<?php echo $uri; ?>Fncauth/selectDupIdcard',
                                    }).done(function(e) {
                                        if(e.trim() == 'fail'){
                                            $("#passport").addClass("required");
                                            $(".texterror").removeClass("d-none");
                                            $(".texterror").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* เลขหนังสือเดือนทางนี้มีในระบบแล้ว กรุณาตรวจสอบ</p></font>");
                                            loading('hide');
                                            return false;
                                            
                                        }else{
                                            $("#passport").removeClass("required");
                                            $(".texterror").addClass("d-none");
                                            updatePersonData();
                                        }
                                    })
                                }
                            }
 
                        }
                    });
                    
                }else{
                    $("#email").addClass("required");
                    $(".textEmail").removeClass("d-none");
                    $(".textEmail").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* รูปแบบอีเมลไม่ถูกต้อง กรุณาตรวจสอบ</p></font>");
                    loading('hide');
                    goToByScroll('email');  
                    return false;

                }
            }else{
                if(national == 'TH'){
                    if(!isEmpty(idcard)){
                        if(!checkID(idcard)){
                            $("#idcard").addClass("required");
                            $(".texterror").removeClass("d-none");
                            $(".texterror").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* เลขบัตรประชาชนไม่ถูกต้อง กรุณาตรวจสอบ</p></font>");

                            goToByScroll('idcard'); 
                            loading('hide');
                            return false;
                        }else{
                            var param = { idCard: idcard, menu: 'idcard', pId: pid };
                            $.ajax({
                                data: param,
                                method: "post",
                                url: '<?php echo $uri; ?>Fncauth/selectDupIdcard',
                            }).done(function(e) {
                                if(e.trim() == 'fail'){
                                    $("#idcard").addClass("required");
                                    $(".texterror").removeClass("d-none");
                                    $(".texterror").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* เลขบัตรประชาชนนี้มีในระบบแล้ว กรุณาตรวจสอบ</p></font>");
                                    loading('hide');
                                    return false;
                                    
                                }else{
                                    $("#idcard").removeClass("required");
                                    $(".texterror").addClass("d-none");
                                    updatePersonData();
                                }
                            });
                        }
                    }
                        
                }else {
                    if(!isEmpty(passport)){
                        var param = { passport: passport, menu: 'passport', pId: pid };
                        $.ajax({
                            data: param,
                            method: "post",
                            url: '<?php echo $uri; ?>Fncauth/selectDupIdcard',
                        }).done(function(e) {
                            if(e.trim() == 'fail'){
                                $("#passport").addClass("required");
                                $(".texterror").removeClass("d-none");
                                $(".texterror").empty().append("<font color='red' size='4'><p style='margin-bottom: 10px;'>* เลขหนังสือเดือนทางนี้มีในระบบแล้ว กรุณาตรวจสอบ</p></font>");
                                loading('hide');
                                return false;
                                
                            }else{
                                $("#passport").removeClass("required");
                                $(".texterror").addClass("d-none");
                                updatePersonData();
                            }
                        })
                    }
                }
            }
            // result = true;
        }
        
        if(result){
            updatePersonData();
        }
        
	}

    function goToByScroll(id) {
		// Remove "link" from the ID
		id = id.replace("link", "");
		// Scroll
		$('html,body').animate({
			scrollTop: $("#" + id).offset().top-100
		}, 'slow');
	}


    function updatePersonData() {
        var firstname = document.getElementById("f_name").value;
        var lastname = document.getElementById("l_name").value;
        var birth = document.getElementById("birthdate").value;
        var gender = $('input[name=gender]:checked', '.radio-tile-group').val()
        var idcard = document.getElementById("idcard").value;
        var passport = document.getElementById("passport").value;
        var national = document.getElementById("national").value;
        // var national = $('#national').val();
        var email = document.getElementById("email").value;
        var pass = document.getElementById("con_pass").value;
        var phone = $("#formUpload").attr("phone");
        var pid = $("#formUpload").attr("pid");
        var uid = $("#formUpload").attr("uid");
        var status = $("#formUpload").attr("status");

        var consent = $('#checkCondition').is(":checked")
        var subscribe = $('#checkCongrats').is(":checked")

        var address = $("#address").val();
        var province = $("#province").val();
        var district = $("#district").val();
        var subdist = $("#subdist").val();
        var postcode = $("#postcode").val();

        // console.log('birth ', birth,national,phone,gender);
        // console.log('uid : ',uid);

        // return false;

        var param = {pid: pid, firstname: firstname, lastname: lastname, birth: birth, gender: gender, idcard: idcard, passport: passport, national: national, email: email, pass: pass, phone: phone, consent: consent, subscribe: subscribe,uid: uid, address:address, province:province, district:district, subdist:subdist, postcode:postcode};

        if(status == 'Success_member'){
            var urlPath = 'update_data';
        }else{
            var urlPath = 'insert_data';
        }

        $.ajax({
            // beforeSend: function(){
            //     loading('show');
            // }
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/insert_data',
            data: param,
            success: function (e) {
                // console.log('log >>>> ', e); 
                // loadingPage('#load_page');
                if (e.status.STATUS == 'successfully') {
                    if(isEmpty(email)){
                        window.location.href = '<?php echo base_url() ?>login/thankPageMail?u=' + encodeURIComponent(btoa(btoa(uid)));
                    }else{
                        confirmEmail(email,pid,uid);
                    }
                }else{
                    $('#alert-message').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+e.detail+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                    loading('hide');
                }
            }
            , error: function (error) {
                // console.log('error; ', error);
            }
            
        });

       
    }

    function confirmEmail(email, pid,uid) {
        var getCurrentUrl 	= window.location.href;

        var dataHtml = '';
        $.ajax({
            url:  '<?php echo $uri; ?>chkIdentity/fsendotp_mail.html?v=1.0' + Math.random()
        }).done(function (HeaderHtml) {
            loading('hide');
			var arr = [email, pid,uid];
			var res = arr.join(';');
			var getParam = encodeURIComponent(btoa(btoa(res)));
			
			var mapObj = {
				'<%email%>': email,
				'<%pid%>': pid,
                '<%uid%>': uid,
				'<%next%>': '<?php echo $uri; ?>login/nextpage?u='+encodeURIComponent(btoa(btoa(uid))),
			}
			dataHtml = HeaderHtml.replace(/<%email%>|<%pid%>|<%uid%>|<%next%>/gi, function (matched) { return mapObj[matched]; });
			
			$('#formUpload').empty().append(dataHtml);
            $('.text-title').empty().append('ขั้นตอนสุดท้าย');
			$(".img-footer").removeAttr("style");

            $(".con_email").click(function () {
                setValGetEmail()
            })
        });
    }

    $(document).on('click', '.resent_mail', function (){
        setValGetEmail()
    });

    function setValGetEmail(){
        var email = $(".row-otp").attr('e');
        var uid = $(".row-otp").attr('uid');
        var pid = $(".row-otp").attr('p');
        getFormEmail(email,pid,uid);
        loading('show');
    }

    function getFormEmail(email,pid,uid) {

        var param = { email: email};
            // console.log(email);
            loading('hide');
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/genOTPandSMS',
            data: param,
            success: function(e) {
                    // console.log('data : ',e);
                    // console.log(e.detail.otp);
                    
                    // loadingPage('#load_page');
                    if (e.status.STATUS == 'Successfully') { 
                        getEmailOTP(email,e.detail.REF,pid,uid);	
                        // window.location.replace("index.php/login/?id=" + phone);			
                    }
                    else{
                        alert('Send email status : ',e.status.STATUS);
                        getEmailOTP();
                        // $(".error").text(e.status.ERRDESC);
                        // $(".error").removeClass('d-none');
                        // $("#validationCustomPhone").addClass("required");						
                    }
                }
            , error: function (error) {
                // console.log('error; ', error);
            }
        })
    }

    $(document).on('focusin', '#validationCustomOTP', function (){
        $('.texterror_otp').addClass('d-none');
        $("#validationCustomOTP").removeClass("required");
    });

    function getEmailOTP(email, ref,pid,uid) {
        var getCurrentUrl 	= window.location.href;

        var dataHtml = '';
        $.ajax({
            url:  '<?php echo $uri; ?>chkIdentity/fmailotp.html?v=1.0' + Math.random()
        }).done(function (HeaderHtml) {
            loading('hide');
			var arr = [email, pid,uid];
			var res = arr.join(';');
			var getParam = encodeURIComponent(btoa(btoa(res)));
			// var link =  getCurrentUrl + '?c=' + getParam;
			// console.log('arr', arr);
			
			var mapObj = {
				'<%email%>': email,
				'<%pid%>': pid,
                '<%uid%>':uid,
				'<%reference%>': btoa(ref),
				'<%next%>': '<?php echo $uri; ?>login/nextpage',
			}
			dataHtml = HeaderHtml.replace(/<%email%>|<%pid%>|<%uid%>|<%next%>|<%reference%>/gi, function (matched) { return mapObj[matched]; });
			
			$('#formUpload').empty().append(dataHtml);
            $('.text-title').empty().append('ขั้นตอนสุดท้าย');
			$(".img-footer").removeAttr("style");

            $(".submit_otp").click(function () {
                loading('show');
                var otp = $.trim($("#validationCustomOTP").val());
                // var otp = parseInt(a)
                if (otp == "") {
                    $("#validationCustomOTP").addClass("required");
                    $('.texterror_otp').removeClass('d-none');
                    $(".texterror_otp").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัส OTP</p></font>");
                    return false;
                }else{
                    $("#validationCustomOTP").removeClass("required");
                    $('.texterror_otp').addClass('d-none');
                }

				var new_ref = atob($(".row-otp").attr('r'));
				
                var param = {email: email, otp: otp, ref: new_ref};

                // console.log('param :',param);

                $.ajax({
                    type: 'POST',
                    dataType: 'json',
                    url: '<?php echo $uri; ?>Fncauth/checkOTP',
                    data: param,
                    success: function (e) {
                       
                        if (e.status.STATUS == 'Successfully') {

                            var arr = [pid];
                            var res = arr.join(';');
                            var getParam = encodeURIComponent(btoa(btoa(res)));

                            if(!isEmpty(uid)){
                                // loginUID(uid);
                                // window.location.href = '<?php echo base_url() ?> ?c=' +getParam;
                                window.location.replace("login/thankpage?c=" + getParam);	
                            }else{
                                window.location.replace("login/thankpage?c=" + getParam);	
                            }   
                            
                        } else {
                            loading('hide');
                            $("#validationCustomOTP").addClass("required");
                            $(".texterror_otp").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* รหัส OTP ไม่ถูกต้อง กรุณารวจสอบ</p></font>");
                            $(".texterror_otp").removeClass('d-none');
                        }
                    }
                })
            })
        });
    }

    function loginUID(uid){
        var param = {uid: uid}
        $.ajax({
            data: param,
            method: "post",
            datatype: "json",
            url: '<?php echo $uri; ?>Fncauth/login',
        }).done(function(e) {
            e = JSON.parse(e);

            if (e.status.STATUS == 'successfully') {
                var arr = [e.detail.ID];
                var getParam = encodeURIComponent(btoa(btoa(arr)));
                // var link =  getCurrentUrl + '?c=' + getParam;
                
                window.location.href = '<?php echo base_url() ?> ?c=' +getParam;
            }else{
                $('#alert-message').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">กรุณาตรวจสอบ อีเมล/เบอร์โทรศัพท์ และ รหัสผ่าน<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            }
            // $('#national').html(jQuery.parseJSON(e));
            
        })
    }

    function loading(action)
	{
		if(action == "show")
		{
			var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg')?>'><div class='overlay'></div></div>";
			$("body").append(loading_component);
		}
		else if(action == "hide")
		{
			$("body .loading-component").remove();
		}
	}
	
</script>
<!-- <script src="<?php echo base_url("assets/js_api/loginAndregister.js?v=" . date("YmdHis")) ?>"></script>
<script src="<?php echo base_url("assets/js/bootstrap-birthday.js?v=" . date("YmdHis")) ?>"></script> -->