

<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>login">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
        <p class="text-title" id="head_page">ช่องทางรับรหัสยืนยันตัวตน</p>
        </div>
    </div>
    <div>
        <div id="body_page">
            <div class="top30" id="alert-message"></div>
            <div class="top50 row">
                <div class="col-5 offset-2" style="padding: 0;">
                    <input type="radio" id="tel" name="forget" value="tel">
                    <span>เบอร์โทรศัพท์มือถือ</span><br>
                </div>
                <div class="col-4">
                    <input type="radio" id="email" name="forget" value="email">
                    <span>อีเมล</span><br>
                </div>
            </div>
            
            <div id="tap-tel" class="top30 d-none">
                <div>เบอร์โทรศัพท์มือถือ</div>
                <input class="form-control form-control-sm boxInput numberic" type="text" name="inputphone" id="inputphone" placeholder="" maxlength="10" required>
                
            </div>
            <div id="tap-email" class="top50 d-none">
                <div>อีเมล</div>
                <input class="form-control form-control-sm boxInput" type="text" name="inputemail" id="inputemail" placeholder="" maxlength="50" required>
                
            </div>
            <div class="textPhone d-none"></div>
            <div class="form-group top50">
                <div class="row justify-content-center">
                    <a class="btn btn-submit form1-submit col-8 d-none" id="btnSubmit" href="javascript:void(0)">ยืนยัน (Submit)</a>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- <div class="img-footer">
    <img src="<?php echo $uri . "assets/images/bg/bottom_bg.png?v=".date('his')."" ?>" alt=" " style="width: 111%;"class="responsive top10">  
</div> -->

<script>

    $(document).ready(function() {
        $('input:radio').change(function(){
            
            if(this.value.trim() == 'tel'){
                $("#tap-tel").removeClass('d-none');
                $("#tap-email").addClass('d-none');
            }else{
                $("#tap-email").removeClass('d-none');
                $("#tap-tel").addClass('d-none');
            }

            $(".btn").removeClass('d-none');
        });

        $(document).on("keyup", ".numberic", function(){
			this.value = this.value.replace(/[^0-9]/g, '');
		})

	});

    $(document).on('click', '.form1-submit', function (){
        checkMember();
    }); 

    $(document).on('click', '.resent', function (){
        resentOtp();
        loading('show');
    }); 

    function resentOtp()
    {	
        var type = atob($(".row-otp").attr('t'));
        console.log('type :',type);
        if(type == 'sms'){
            var phone = $(".row-otp").attr('d');
        }else{
            var email = $("#verifyEmail").attr('d');
        }
        
        var param = {phone: phone, email: email};	
        console.log(param);

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/genOTPforget',
            data: param,
            success: function(e) {
                console.log('data : ',e);
                console.log(e.detail.otp);
                
                // loadingPage('#load_page');
                PARAM_PHONE = phone;
                if(e.status.STATUS == "Successfully") 
                {
                    if(e.detail.TYPE == 'sms'){
                        getOtpFormrepass(e.detail.mobile,e.detail.REF,e.detail.TYPE);	          
                    }else{
                        getOtpFormrepass(e.detail.email,e.detail.REF,e.detail.TYPE);	
                    }	
                }
                else if(e.status.STATUS == "DATANOTVERIFLY" ){

                    console.log(e.detail.message);

                    if(e.detail.message == 'Email is not verify.'){
                        $('#alert-message').empty().append('<div class="alert alert-danger alert-dismissible fade show" role="alert">อีเมลนี้ยังไม่ผ่านการยืนยันตัวตน ('+e.detail.message+')<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                    }else{
                        $('#alert-message').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+e.detail.message+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                    }
                   
                    loading('hide');
                }
                else{
                    $(".error").text(e.ERRDESC);
                    $(".error").removeClass('d-none');
                    $("#validationCustomPhone").addClass("required");						
                }
            }
            ,error: function (error) {
                console.log('error; ',error);
            }
        })
    }


    function checkMember(){
        var phone = $('#inputphone').val();  
        var email = $('#inputemail').val();
        var param = {phone: phone, email: email};	
        console.log(phone,email);

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/check_member',
            data: param,
            success: function (e) {

                if(e.status.STATUS == 'Success_memberLine'){
                    loading('show');
                    getFormPhone_pass();
                }else if(e.status.STATUS == 'Success_member'){
                    $(".textPhone").removeClass("d-none");

                    if(!isEmpty(phone)){
                        $(".textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;margin-top: 15px;'>*เบอร์โทรศัพท์นี้ยังไม่ได้เป็นสมาชิกในระบบ กรุณาสมัครสมาชิก</p></font>")
                    }else{
                        $(".textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;margin-top: 15px;'>*อีเมลนี้ยังไม่ได้เป็นสมาชิกในระบบ กรุณาสมัครสมาชิก </p></font>")
                    }
                    
                     return false;

                }else{
                    $(".textPhone").removeClass("d-none");

                    if(!isEmpty(phone)){
                        $(".textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;margin-top: 15px;'>*เบอร์โทรศัพท์นี้ไม่มีในระบบ กรุณาตรวจสอบเบอร์โทรศัพท์</p></font>")
                    }else{
                        $(".textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;margin-top: 15px;'>*อีเมลนี้ไม่มีในระบบ กรุณาตรวจสอบอีเมล </p></font>")
                    }
                    
                     return false;
                }
            }
            ,error: function (error) {
                console.log('error; ',error);
            }
        })
    }

    function getFormPhone_pass()
    {	     
        var phone = $('#inputphone').val();  
        var email = $('#inputemail').val();
        var param = {phone: phone, email: email};	
        console.log(phone,email);

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/genOTPforget',
            data: param,
            success: function(e) {
                console.log('data : ',e);
                console.log(e.detail.otp);
                
                // loadingPage('#load_page');
                PARAM_PHONE = phone;
                if(e.status.STATUS == "Successfully") 
                {
                    if(e.detail.TYPE == 'sms'){
                        getOtpFormrepass(e.detail.mobile,e.detail.REF,e.detail.TYPE);	          
                    }else{
                        getOtpFormrepass(e.detail.email,e.detail.REF,e.detail.TYPE);	
                    }	
                }
                else if(e.status.STATUS == 'DATANOTVERIFLY' ){
                    if(e.detail.message == 'Email is not verify.'){
                        $('#alert-message').empty().append('<div class="alert alert-danger alert-dismissible fade show" role="alert">อีเมลนี้ยังไม่ผ่านการยืนยันตัวตน ('+e.detail.message+')<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                    }else{
                        $('#alert-message').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">'+e.detail.message+'<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                    }
                    loading('hide');
                }
                else{
                    $(".error").text(e.ERRDESC);
                    $(".error").removeClass('d-none');
                    $("#validationCustomPhone").addClass("required");						
                }
            }
            ,error: function (error) {
                console.log('error; ',error);
            }
        })
    }

    function getOtpFormrepass(data, ref,type) {
        var getCurrentUrl 	= window.location.href;
        var token = $('#token').val();
        var html_header = '<p><b>VERIFICATION OTP</b></p>';

        var dataHtml = '';
        $.ajax({
            url:  '<?php echo $uri; ?>chkIdentity/fotp.html?v=1.0' + Math.random()
        }).done(function (HeaderHtml) {
            console.log(type,data);
            var refShow = ref;
            
            if(type.trim() == 'sms'){
                var newphone = data.substring(0, 2) + 'x-xxx-' + data.substring(6, 10);

                var mapObj = {
                    '<%phone%>': data,
                    '<%ref%>': refShow,
                    '<%reference%>': btoa(ref),
                    '<%newphone%>': newphone,
                    '<%chanel%>': btoa(type)
                }
                dataHtml = HeaderHtml.replace(/<%phone%>|<%reference%>|<%newphone%>|<%chanel%>|<%ref%>/gi, function (matched) { return mapObj[matched]; });

            }else{
                var mapObj = {
                    '<%email%>': data,
                    '<%ref%>': refShow,
                    '<%reference%>': btoa(ref),
                    '<%chanel%>': btoa(type)
                }
                dataHtml = HeaderHtml.replace(/<%email%>|<%reference%>|<%chanel%>|<%ref%>/gi, function (matched) { return mapObj[matched]; })
            }
           
            $('#head_page').empty().append(html_header);
            $('#body_page').empty().append(dataHtml);
            
            if(type.trim() == 'email'){
                $("#verifyPhone").addClass('d-none');
                $("#verifyEmail").removeClass('d-none');
            }
            loading('hide');

            $(".submit_otp").click(function () {
                getFormrepass(data);
            });
           
        })
    } 

    $(document).on('focusin', '#validationCustomOTP', function (){
        $('.texterror_otp').addClass('d-none');
        $("#validationCustomOTP").removeClass("required");
    });

    function getFormrepass(data){
        var otp = $.trim($("#validationCustomOTP").val());
        // var otp = parseInt(a)
        if (otp == "") {
            $("#validationCustomOTP").addClass("required");
            $('.texterror_otp').removeClass('d-none');
            $(".texterror_otp").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัส OTP</p></font>");
            return false;
        }else{
            $("#validationCustomOTP").removeClass("required");
            $('.texterror_otp').addClass('d-none');
            loading('show');
        }

        var new_ref = atob($(".row-otp").attr('r'));
        // var data = $(".row-otp").attr('d');
        var type = atob($(".row-otp").attr('t'));
        // console.log('new_ref',new_ref,data,otp,type)
        if(type == 'sms'){
            var param = {phone: data, otp: otp, ref: new_ref};
        }else{
            var param = {email: data, otp: otp, ref: new_ref};
        }
        
        var html_header = '<p><b>รหัสผ่านใหม่</b></p>';

        var dataHtml = '';
        $.ajax({
            url:  '<?php echo $uri; ?>chkIdentity/frepassword.html?v=1.0' + Math.random()
        }).done(function (HeaderHtml) {

            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: '<?php echo $uri; ?>Fncauth/checkOTPFoget',
                data: param,
                success: function (e) {
                    console.log(e);
                    loading('hide');

                    if (e.status.STATUS == 'Successfully') {
                        var mapObj = {
                            '<%Id%>': btoa(e.detail.pid),
                            '<%phone%>': btoa(e.detail.phone),
                            '<%email%>': btoa(e.detail.email),
                            '<%session%>': btoa(e.detail.pid_session),
                            '<%card%>': btoa(e.detail.idCardNo)
                        }
                        dataHtml = HeaderHtml.replace(/<%Id%>|<%phone%>|<%email%>|<%session%>|<%card%>/gi, function (matched) { return mapObj[matched]; });

                        $('#head_page').empty().append(html_header);
                        $('#body_page').empty().append(dataHtml);

                        $(".btn-repass").click(function () {
                            checkPassword();
                        })


                    } else {
                        $("#validationCustomOTP").addClass("required");
                        $(".texterror_otp").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* รหัส OTP ไม่ถูกต้อง กรุณารวจสอบ</p></font>");
                        $(".texterror_otp").removeClass('d-none');
                    }
                }
                ,error: function (error) {
                   console.log('error :',error);
                   
                }
            })
            

        });
    }

    // $(document).on('click', '.btn-repass', function (){
    //     console.log('.btn-repass');
    // }); 

    function checkPassword() {
        var passNow = $('#pass').val();
        var passCon = $('#con_pass').val();

        if(isEmpty(passNow) ||  isEmpty(passCon) || passNow.length < 6 || passCon.length < 6){
            if(isEmpty(passNow)){
                $('#pass').addClass("required"); 
            }else{
                $('#pass').removeClass("required");
            }

            if(isEmpty(passCon)){
                $('#con_pass').addClass("required"); 
            }else{
                $('#con_pass').removeClass("required");
            }

            if(passNow.length < 6){
                $('#pass').addClass("required"); 
                $('#passinvalid').removeClass('d-none');
                $('#passinvalid').empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัสผ่านอย่างน้อย 6 ตัวอักษร</p></font>");
            }else{
                $('#pass').removeClass("required");
                $('#passinvalid').addClass('d-none');
            }

            if(passCon.length < 6){
                $('#con_pass').addClass("required"); 
                $('#passnotmach').removeClass('d-none');
                $('#passnotmach').empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัสผ่านอย่างน้อย 6 ตัวอักษร</p></font>");
            }else{
                $('#con_pass').removeClass("required");
                $('#passnotmach').addClass('d-none');
            }

            goToByScroll('pass');  
            return false;
             
        }else{
            $('#pass').removeClass("required");
            $('#con_pass').removeClass("required");
            $('#passnotmach').addClass('d-none');
            $('#passinvalid').addClass('d-none');

            if(passNow != passCon){
                $('#con_pass').addClass("required"); 
                $('#passnotmach').removeClass('d-none');
                $("#passnotmach").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* รหัสผ่านไม่ตรงกัน</p></font>");
                    return false;
            }else{
                $('#con_pass').removeClass("required");
                $('#passnotmach').addClass('d-none');
            }
        }

        loading('show');
        updateData();
		
		
	}


    function updateData(){
        var password = document.getElementById("pass").value;
		var pass = document.getElementById("con_pass").value;
		var phone = atob($("#formUpdatePass").attr("phone"));
        var idcard = atob($("#formUpdatePass").attr("card"));
		var pid = atob($("#formUpdatePass").attr("pid"));
        var email = atob($("#formUpdatePass").attr("email"));
        var session = atob($("#formUpdatePass").attr("s"));

        if(password == '' || pass == ''){
            return false;
        }
		
		var html_header = '<p><b>รหัสผ่านใหม่</b></p>';
		var param = {pid: pid,pass: pass,phone: phone,email: email,session: session,idcard:idcard};

        console.log(param); 

		$.ajax({
			url: '<?php echo $uri; ?>chkIdentity/fthankForget.html?v=1.0' + Math.random()
		}).done(function (HeaderHtml) {
            
			$.ajax({
				type: 'POST',
				dataType: 'json',
				url: '<?php echo $uri; ?>Fncauth/update_data',
				data: param,
				success: function (e) {
					console.log('log >>>> ',e);
                   
                    loading('hide');
					// loadingPage('#load_page');
					if (e.status.STATUS == 'successfully') {
						
						var mapObj = {
							'<%link%>': '<?php echo $uri; ?>login',
						}
						dataHtml = HeaderHtml.replace(/<%link%>/gi, function (matched) { return mapObj[matched]; });

                        $('#head_page').empty().append(html_header);
                        $('#body_page').empty().append(dataHtml);
					} 
				}
					,error: function (error) {
					console.log('error; ',error);
				}
			})

		});
		
	}

    function loading(action)
	{
		if(action == "show")
		{
			var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg')?>'><div class='overlay'></div></div>";
			$("body").append(loading_component);
		}
		else if(action == "hide")
		{
			$("body .loading-component").remove();
		}
	}

</script>