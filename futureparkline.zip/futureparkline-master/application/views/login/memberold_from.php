
<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>login">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title" id="head_page">ยืนยันหมายเลขโทรศัพท์</p>
        </div>
    </div>
    <div>
        <div id="body_page">
            <!-- <form name="form1" id="form1" novalidate enctype="multipart/form-data" onsubmit="return chkForm()" method="post" action="<?php echo $uri; ?>fncsms/genOTPandSMS"> -->
                <div class="top50">
                    <label class="star-require">เบอร์โทรศัพท์มือถือ (Phone Number)</label>
                    <input class="form-control form-control-sm boxInput" type="text" name="phone" id="phone" placeholder="" maxlength="10" onkeyup="checkint(this);">
                    <div id="textPhone" style="display:none;"></div>
                </div>
                <div class="top30">
                    <label class="star-require">หมายเลขสมาชิก (Member No.)</label>
                    <input class="form-control form-control-sm boxInput" type="text" name="memNo" id="memNo" placeholder="" maxlength="20" onkeyup="checkint(this);">
                    <div id="textMem" style="display:none;"></div>
                </div>

                <div class="form-group top50">
                    <div class="row justify-content-center">
                        <a class="btn btn-submit form1-submit col-8" id="btnSubmit" href="javascript:void(0)">ยืนยัน (Submit)</a>
                    </div>
                </div>
            <!-- </form> -->
        </div>
    </div>

</div>
<!-- <div class="img-footer img-position-fixed">
    <img src="<?php echo $uri . "assets/images/bg/bottom_bg.png?v=".date('his')."" ?>" alt=" " style="width: 111%;"class="responsive top10">  
</div> -->

<style>
    .span-text {
        padding-left: 25px;
        /* text-decoration-line: underline; */
        /* cursor: pointer; */
    }
    .custom-checkbox {
        width: 20px;
        height: 20px;
        margin: 0px !important;
    }
</style>

<script>
    $(document).ready( function() {
		$(document).on("keyup", ".numberic", function(){
			this.value = this.value.replace(/[^0-9]/g, '');
		})

        $(document).on('click', '.form1-submit', function () {
            chkForm();
        }); 
    });


    $('#phone').keyup(function(e) {
		var str_regexp = /^0/;		

		if (!str_regexp.test(this.value))
		{
			this.value = this.value.replace(str_regexp,'');

			$("#textPhone").css("display", "inline");
			$("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* เบอร์โทรศัพท์ไม่ถูกต้อง</p></font>")
			
			$("#phone").focus();	
            return false;	
		}
		else
		{
			$("#textPhone").css("display", "none");
		}	
	});	

    function chkForm(){
		var tel = $('#phone').val();
        var memNo = $('#memNo').val();
		var checknum = tel.substring(0, 1);
        var str_regexp = /^0/;	
        var result = false;

        if(isEmpty(tel) || isEmpty(memNo)){
            if(isEmpty(tel)){
                $("#phone").addClass("required");
                $("#textPhone").css("display", "inline");
                $("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกเบอร์โทรศัพท์</p></font>");
                return false;
            }else if(checknum != '0' || tel.length != 10){
                $("#phone").addClass("required");
                $("#textPhone").css("display", "inline");
                $("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* เบอร์โทรศัพท์ไม่ถูกต้อง</p></font>")
                
                $("#phone").focus();	
                return false;	
            }else{
                $("#phone").removeClass("required");
                $("#textPhone").css("display", "none");
            }

            if(isEmpty(memNo)){
                $("#memNo").addClass("required");
                $("#textMem").css("display", "inline");
                $("#textMem").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกหมายเลขสมาชิก</p></font>");
            }
        }else{
            $("#phone").removeClass("required");
            $("#textPhone").css("display", "none");
            $("#memNo").removeClass("required");
            $("#textMem").css("display", "none");
            result = true;
        }

        if(result){
            check_status();
        }
    }

    function check_status(phone, ref) {
        var phone = $('#phone').val(); 
        var memNo = $('#memNo').val();
        var param = {phone: phone,memNo:memNo};

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/select_memberOld',
            data: param,
            success: function (e) {
                PARAM_PHONE = phone;
                if (e.status.STATUS == 'NEW_MEMBER') {
                    $("#textMem").css("display", "inline");
                    $("#textMem").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;margin-top: 15px;'>*ข้อมูลไม่ถูกต้องกรุณาติดต่อประชาสัมพันธ์ หรือ สมัครสมาชิกใหม่ (กรณีสมัครสมาชิกใหม่ คะแนนของท่านจะถูกปรับเป็น 0)</p></font>")
                     return false;
                }else if(e.status.STATUS == 'Successfully' || e.status.STATUS == 'Success_member' || e.status.STATUS == 'Select_Person'){
                    getFormPhone(phone,e.status.PID);    
                }
                else if(e.status.STATUS == 'Success_memberLine'){
                    $("#textMem").css("display", "inline");
                    $("#textMem").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;margin-top: 15px;'>*เบอร์นี้ใช้สมัครสมาชิกแล้ว กรุณาเข้าสู่ระบบหรือขอรหัสผ่านใหม่</p></font>")
                     return false;
                }else {
                    $("#validationCustomOTP").addClass("required");
                    $(".error").empty().text('รหัส OTP ไม่ถูกต้อง');
                    $(".error").removeClass('d-none');
                }
            }
            ,error: function (error) {
                console.log('error; ',error);
            }
        })
    }

    $(document).on('click', '.resent', function (){
        resentOtp();
        loading('show');
    });

    function resentOtp() {
        var phone = atob($("#verifyPhone").attr('d'));
        var param = { phone: phone};
        console.log(param);

        $.ajax({
            type: 'POST',
            dataType: 'json',
            // url: baseURL + 'function/Fncsms/genOTPandSMS',
            url: '<?php echo $uri; ?>Fncauth/genOTPandSMS',
            data: param,
            success: function (e) {
                console.log(e.detail.otp);
                //PARAM_PHONE = phone;
                if (e.status.STATUS == 'Successfully') {
                    getFormOTP(phone,e.detail.REF);	
                } else {
                    $(".error").text(e.status.ERRDESC);
                    $(".error").removeClass('d-none');
                    $("#validationCustomPhone").addClass("required");	
                }
            }
        })
    }
    

    function getFormPhone(phone,pid)
    {	     
        var phone = $('#phone').val();  
        var param = {phone: phone};	
        console.log(phone);

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/genOTPandSMS',
            data: param,
            success: function(e) {
                console.log('data : ',e);
                console.log(e.detail.otp);
                
                // loadingPage('#load_page');
                PARAM_PHONE = phone;
				if (e.status.STATUS == 'Successfully') { 
                    getFormOTP(phone,e.detail.REF,pid);	
                    // window.location.replace("index.php/login/chack_otp?id=" + phone);			
                }
                else{
                    $(".error").text(e.status.ERRDESC);
                    $(".error").removeClass('d-none');
                    $("#validationCustomPhone").addClass("required");	
                    loading('hide');					
                }
            }
            ,error: function (error) {
                console.log('error; ',error);
            }
        })
    }

    $(document).on('focusin', '#validationCustomOTP', function (){
        $('.texterror_otp').addClass('d-none');
        $("#validationCustomOTP").removeClass("required");
    });

    function getFormOTP(phone, ref,pId) {
        var getCurrentUrl 	= window.location.href;
        var html_header = '<div>ยืนยันหมายเลขโทรศัพท์</div><div>(verification your number)</div>';
        
        var newphone = phone.substring(0, 2) + 'x-xxx-' + phone.substring(6, 10);

        var dataHtml = '';
        $.ajax({
            url:  '<?php echo $uri; ?>chkIdentity/fotp.html?v=1.0' + Math.random()
        }).done(function (HeaderHtml) {
            var refShow = ref;
            
            var mapObj = {
                '<%phone%>': btoa(phone),
                '<%reference%>': btoa(ref),
                '<%ref%>': refShow,
                '<%newphone%>': newphone,
            }
            dataHtml = HeaderHtml.replace(/<%phone%>|<%reference%>|<%newphone%>|<%ref%>/gi, function (matched) { return mapObj[matched]; });

            $(".error").addClass('d-none');

            $('#head_page').empty().append(html_header);
            $('#body_page').empty().append(dataHtml);
            loading('hide');

            // $("#myModal .submit").off();
            $(".submit_otp").click(function () {
                // var refId = ref;
                var otp = $.trim($("#validationCustomOTP").val());
                // var otp = parseInt(a)
                if (otp == "") {
                    $("#validationCustomOTP").addClass("required");
                    $('.texterror_otp').removeClass('d-none');
                    $(".texterror_otp").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัส OTP</p></font>");
                    return false;
                }else{
                    $("#validationCustomOTP").removeClass("required");
                    $('.texterror_otp').addClass('d-none');
                }
                var new_ref = atob($(".row-otp").attr('r'));
                console.log('new_ref',ref,phone,otp)
                
                // var param = { refId: refId, refCode: refCode, campId: campId, campCode: campCode, phone: phone, otp: otp, ref: new_ref };
                var param = {phone: phone, otp: otp, ref: new_ref };

                $.ajax({
                    type: 'POST',
                    dataType: 'json',
                    url: '<?php echo $uri; ?>Fncauth/checkOTP',
                    data: param,
                    success: function (e) {
                        console.log(e);

                        console.log('pId : ',pId);
                        
                        PARAM_PHONE = phone;
                        if (e.status.STATUS == 'Successfully') {
                            var arr = [phone, ref,null,pId];
                            var res = arr.join(';');
                            var getParam = encodeURIComponent(btoa(btoa(res)));
                            // var link =  getCurrentUrl + '?c=' + getParam;
                            console.log(getParam);
                        
                            window.location.replace("login/person_memberOld?c=" + getParam);	
                            
                            // window.location.href = getCurrentUrl + '?c=' + getParam;
                        } else {    
                            $("#validationCustomOTP").addClass("required");
                            $(".texterror_otp").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* รหัส OTP ไม่ถูกต้อง กรุณารวจสอบ</p></font>");
                            $(".texterror_otp").removeClass('d-none');
                        }
                    }
                })
            })
        });
    }
 

    //main_function->start
    function isNumbers(data, type, AllowNagative, AllowZero){
        var rgx;
        var status = false;
        
        if(typeof AllowNagative === 'undefined') 
        AllowNagative = false;

        if(typeof AllowZero == 'undefined')
        AllowZero = false;

        if(typeof type  === 'undefined')
        type = 'int'

        switch (type){
            case 'int': rgx = /^[0-9]+$/; break;
            case 'float': rgx = /^[0-9.]+$/; break;
            case 'number': rgx = /^[0-9.,]+$/; break;
            case 'phone': rgx = /[\d -]+/g; break;// /[\d -]+/g; break;   [0]{1}\d{2}
            default: rgx = /^[0-9]+$/;
        }

        if(rgx.test(data) == true){
            status = true;
            if(type == 'int' || type == 'float' || type == 'number'){
                var convData = parseFloat(data);
                if(AllowNagative == false && convData >= 0){
                    status = true;

                    if(AllowZero != true && convData <= 0){
                        status = false;
                    }

                }else{
                    status = false;
                }
            }
            
            // status = (AllowNagative == false && convData > 0) ? true : false;
        }
        return status;
    }

    function loading(action)
	{
		if(action == "show")
		{
			var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg')?>'><div class='overlay'></div></div>";
			$("body").append(loading_component);
		}
		else if(action == "hide")
		{
			$("body .loading-component").remove();
		}
	}


    

</script>