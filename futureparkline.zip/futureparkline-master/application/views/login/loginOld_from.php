
<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>login">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title" id="head_page">Login with Line</p>
        </div>
    </div>

    <div class="form-group  top50">
        <div class="row justify-content-center">
            <a href="https://liff.line.me/1654089965-n9ejqQq2" class="btn btn-submit col-8" >สมาชิกใหม่</a>
        </div>
        <div class="row justify-content-center top30">
            <a href="https://liff.line.me/1654089965-Xjop1Z1P" class="btn btn-submit col-8" >สมาชิกเก่า</a>
            <!-- <a href="<?php echo $uri; ?>login/socialOld" class="btn btn-submit btn-line col-8" >สมาชิกเก่า</a> -->
        </div>
    </div>
</div>
<!-- <div class="img-footer">
    <img src="<?php echo $uri . "assets/images/bg/bottom_bg.png?v=".date('his')."" ?>" alt=" " style="width: 111%;"class="responsive top10">  
</div> -->

<script src="https://static.line-scdn.net/liff/edge/2.1/sdk.js"></script>
