<div class="my-3 text-center" id="gobalAlert" style="font-size: 18px; color: red; margin-left: 15px;"></div>
<div class="boxsocail d-none">
    <div class="container boxPage">
        <!-- <div>
            <a href="<?php echo $uri; ?>login">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div> -->
        <div>
            <form id="formDataSoial" name="formDataSoial" method="post" action="#" enctype="multipart/form-data" img="" uid="" nameline="" email="">
                <p class="text-title" id="head_page">กรอกข้อมูลเพื่อเข้าสู่ระบบ</p>

                <div class="my-3 text-center" id="checkMemberAlert" style="font-size: 18px; color: red; margin-left: 15px;"></div>
                <div id="body_page">
                    <div class="top50">
                        <label class="star-require">เบอร์โทรศัพท์มือถือ (Phone Number)</label>
                        <input class="form-control form-control-sm boxInput" type="text" name="phone" id="phone" placeholder="" value="<?= $this->session->userdata('dataPhoneNumber') ? $this->session->userdata('dataPhoneNumber') : '' ?>" maxlength="10" onkeyup="checkint(this);">
                        <div id="textPhone" style="display:none;"></div>
                    </div>
                    <div class="top30">
                        <label class="star-require">หมายเลขสมาชิก (Member No.)</label>
                        <input class="form-control form-control-sm boxInput" type="text" name="memNo" id="memNo" placeholder="" maxlength="20" onkeyup="checkint(this);">
                        <div id="textMem" style="display:none;"></div>
                    </div>

                    <div class="form-group top50">
                        <div class="row justify-content-center">
                            <a class="btn btn-submit form1-submit col-8" id="btnSubmit" href="javascript:void(0)">ยืนยัน (Submit)</a>
                        </div>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>


<script src="https://static.line-scdn.net/liff/edge/2.1/sdk.js"></script>
<script>
    var refPID = null;
    $(document).ready(function() {
        function runApp() {
            liff.getProfile().then(profile => {
                $("#formDataSoial").attr("img", profile.pictureUrl);
                $("#formDataSoial").attr("uid", profile.userId);
                $("#formDataSoial").attr("nameline", profile.displayName);
                $("#formDataSoial").attr("email", liff.getDecodedIDToken().email);
                $("#formDataSoial").attr("StatusMessage", profile.statusMessage);
                check_uid();
            }).catch(err => {
                $('#gobalAlert').text('ไม่สามารถใช้งาน Line ได้ กรุณาเข้าใหม่อีกครั้ง');
                $('#gobalAlert').show();
                // $('#body_page').hide();
            });

        }
        liff.init({
            liffId: "<?= LIFFSOCIALOLDCODE; ?>"
        }, () => {
            if (liff.isLoggedIn()) {
                runApp()
            } else {
                liff.login();
            }
            $('#gobalAlert').hide();
        }, err => {
            $('#gobalAlert').text('ไม่สามารถใช้งาน Line ได้ กรุณาเข้าใหม่อีกครั้ง');
            $('#gobalAlert').show();
        });

        function check_uid() {
            var uid = $("#formDataSoial").attr("uid");
            if (uid) {
                loading('show');
                $('#gobalAlert').hide();
                login_line(uid)
            } else {
                $('#gobalAlert').text('ไม่สามารถใช้งาน Login Line ได้ กรุณาเข้าใหม่อีกครั้ง');
                $('#gobalAlert').show();
                return false;
                // $(".boxsocail").removeClass("d-none");
            }
        }
    });

    $(document).on("keyup", ".numberic", function() {
        this.value = this.value.replace(/[^0-9]/g, '');
    })

    $(document).on('click', '.form1-submit', function() {
        chkForm();
    });

    function chkForm() {
        loading('show');
        var tel = $('#phone').val();
        var memNo = $('#memNo').val();
        var checknum = tel.substring(0, 1);
        var str_regexp = /^0/;
        var result = false;

        if (isEmpty(tel) || isEmpty(memNo)) {
            if (isEmpty(tel)) {
                $("#phone").addClass("required");
                $("#textPhone").css("display", "inline");
                $("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกเบอร์โทรศัพท์</p></font>");
                loading('hide');
                return false;
            } else if (checknum != '0' || tel.length != 10) {
                $("#phone").addClass("required");
                $("#textPhone").css("display", "inline");
                $("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* เบอร์โทรศัพท์ไม่ถูกต้อง</p></font>")
                $("#phone").focus();
                loading('hide');
                return false;
            } else {
                $("#phone").removeClass("required");
                $("#textPhone").css("display", "none");
            }

            if (isEmpty(memNo)) {
                $("#memNo").addClass("required");
                $("#textMem").css("display", "inline");
                $("#textMem").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกหมายเลขสมาชิก</p></font>");
                loading('hide');
            }
        } else {
            $("#phone").removeClass("required");
            $("#textPhone").css("display", "none");
            $("#memNo").removeClass("required");
            $("#textMem").css("display", "none");
            result = true;
        }

        if (result) {
            check_status();
        }
    }

    function check_status() {
        var phone = $('#phone').val();
        var memNo = $('#memNo').val();
        var param = {
            phone: phone,
            memNo: memNo
        };
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/select_memberOld',
            data: param,
            success: function(e) {
                if (e.status.STATUS == 'NEW_MEMBER') {
                    $("#textMem").css("display", "inline");
                    $("#textMem").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;margin-top: 15px;'>*ข้อมูลไม่ถูกต้องกรุณาติดต่อประชาสัมพันธ์ หรือ สมัครสมาชิกใหม่ (กรณีสมัครสมาชิกใหม่ คะแนนของท่านจะถูกปรับเป็น 0)</p></font>")
                    loading('hide');
                    return false;
                } else if (e.status.STATUS == 'Successfully' || e.status.STATUS == 'Success_member' || e.status.STATUS == 'Select_Person') {
                    getFormPhone();
                } else if (e.status.STATUS == 'Success_memberLine') {
                    if (e.status.is_member == 'Y') {
                        // updateUserID(e.detail.ID,phone,e.detail.session_id);
                        getFormPhone();
                    }
                } else {
                    $("#validationCustomOTP").addClass("required");
                    $(".error").empty().text('รหัส OTP ไม่ถูกต้อง');
                    $(".error").removeClass('d-none');
                    loading('hide');
                }
            },
            error: function(error) {}
        })
    }

    function updateUserID(id, phone, session) {
        var uid = $("#formDataSoial").attr("uid");
        var img = $("#formDataSoial").attr("img");
        var email = $("#formDataSoial").attr("email");


        var param = {
            pid: id,
            uid: uid,
            phone: phone,
            email: email,
            session: session
        };

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/update_data',
            data: param,
            success: function(e) {

                // loadingPage('#load_page');
                if (e.status.STATUS == 'successfully') {
                    loginUID(uid)
                    loading('hide');
                } else {
                    login_line(uid);
                    loading('show');
                }
            },
            error: function(error) {}
        })
    }

    function login_line(uid) {
        if (uid) {
            $('#gobalAlert').hide();
            $('#boxsocail').show();
        } else {
            $('#boxsocail').hide();
            $('#gobalAlert').text('ไม่สามารถใช้งาน Login Line ได้ กรุณาเข้าใหม่อีกครั้ง');
            $('#gobalAlert').show();
            loading('hide');
            return false;
        }
        
        var param = {
            // uid: uid
            uid: $("#formDataSoial").attr("uid"),
            socialPictureUrl: $("#formDataSoial").attr("img"),
            socialDisplayName: $("#formDataSoial").attr("nameline"),
            socialStatusMessage: $("#formDataSoial").attr("StatusMessage"),
            socialEmail: $("#formDataSoial").attr("email"),
        };

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/login',
            data: param,
            success: function(e) {
                if (e.status.STATUS == 'successfully') {
                    var arr = [e.detail.ID];
                    var getParam = encodeURIComponent(btoa(btoa(arr)));
                    window.location.href = '<?php echo base_url() ?> ?c=' + getParam;
                } else {
                    if (e.status.message == 'Member not found.') {
                        $(".boxsocail").removeClass("d-none");
                        loading('hide');
                    }
                }
            },
            error: function(error) {}
        })
    }

    function getTofromRegister(phone, status_mem) {
        var uid = $("#formDataSoial").attr("uid");

        if (status_mem == 'N') {
            getFormPhone()
        }
    }

    $(document).on('focusin', '#validationCustomOTP', function() {
        $('.texterror_otp').addClass('d-none');
        $("#validationCustomOTP").removeClass("required");
    });

    $(document).on('click', '.resent', function() {
        loading('show');
        resentOtp();

    });

    function resentOtp() {
        var uid = $("#formDataSoial").attr("uid");
        var phone = atob($("#verifyPhone").attr('d'));
        var param = {
            phone: phone
        };

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/check_member',
            data: param,
            success: function(e) {
                PARAM_PHONE = phone;

                loading('hide');
                if (e.status.STATUS == 'NEW_MEMBER' || e.status.STATUS == 'Select_Person') {
                    getTofromRegister(phone, e.detail.is_member);
                } else if (e.status.STATUS == 'Successfully' || e.status.STATUS == 'Success_member') {
                    getTofromRegister(phone, e.status.is_member);
                } else if (e.status.STATUS == 'Success_memberLine') {
                    if (e.detail.is_member == 'Y') {
                        getFormPhone();
                    }
                } else {
                    $("#validationCustomOTP").addClass("required");
                    $(".error").empty().text('รหัส OTP ไม่ถูกต้อง');
                    $(".error").removeClass('d-none');
                }
            },
            error: function(error) {}
        })
    }

    function getFormPhone() {
        var phone = $('#phone').val();
        $('#validationCustomOTP').val('');
        var param = {
            phone: phone
        };
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/genOTPandSMS',
            data: param,
            success: function(e) {
                PARAM_PHONE = phone;
                if (!phone) {
                    phone = e.detail.phone;
                }
                if (e.status.STATUS == 'Successfully') {
                    getOTPFormsocial(phone, e.detail.REF);
                    setTimeout(() => {
                        $('#validationCustomOTP').val(e.detail.otp);
                    }, 1000);
                } else {
                    $(".error").text(e.status.ERRDESC);
                    $(".error").removeClass('d-none');
                    $("#validationCustomPhone").addClass("required");
                    loading('hide');
                }
            },
            error: function(error) {}
        })
    }

    function getOTPFormsocial(phone, ref) {
        var getCurrentUrl = window.location.href;
        var html_header = '<p><b>VERIFICATION OTP</b></p>';
        var newphone = phone.substring(0, 2) + 'x-xxx-' + phone.substring(6, 10);
        var dataHtml = '';
        $.ajax({
            url: '<?php echo $uri; ?>chkIdentity/fotp.html?v=1.0' + Math.random()
        }).done(function(HeaderHtml) {
            var refShow = ref;
            var mapObj = {
                '<%phone%>': btoa(phone),
                '<%ref%>': refShow,
                '<%reference%>': btoa(ref),
                '<%newphone%>': newphone,
            }
            dataHtml = HeaderHtml.replace(/<%phone%>|<%reference%>|<%newphone%>|<%ref%>/gi, function(matched) {
                return mapObj[matched];
            });
            $(".error").addClass('d-none');
            $('#head_page').empty().append(html_header);
            $('#body_page').empty().append(dataHtml);
            $(".submit_otp").click(function() {
                loading('show');
                var otp = $.trim($("#validationCustomOTP").val());
                if (otp == "") {
                    $("#validationCustomOTP").addClass("required");
                    $('.texterror_otp').removeClass('d-none');
                    $(".texterror_otp").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัส OTP</p></font>");
                    return false;
                } else {
                    $("#validationCustomOTP").removeClass("required");
                    $('.texterror_otp').addClass('d-none');
                }
                // var new_ref = atob($(".row-otp").attr('r'));
                var param = {
                    phone: phone,
                    otp: otp,
                    ref: ref,
                };

                $.ajax({
                    type: 'POST',
                    dataType: 'json',
                    url: '<?php echo $uri; ?>Fncauth/checkOTP',
                    data: param,
                    success: function(e) {
                        PARAM_PHONE = phone;
                        if (e.status.STATUS == 'Successfully') {
                            let pId = e.status.dataID;
                            if (!phone) {
                                phone = e.status.phone;
                            }
                            var uid = $("#formDataSoial").attr("uid");
                            var arr = [phone, ref, uid, pId];
                            var res = arr.join(';');
                            var getParam = encodeURIComponent(btoa(btoa(res)));
                            // if(status_mem == 'N'){
                            window.location.replace("login/person_memberOld?c=" + getParam);
                            loading('hide');
                            // }else{
                            // updateUserID(pId,phone,pId,session);
                            // window.location.href = '<?php echo base_url() ?> ?c=' +getParam;
                            // loginUID(uid)
                            // }

                        } else {
                            $("#validationCustomOTP").val('');
                            $("#validationCustomOTP").addClass("required");
                            $(".texterror_otp").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* รหัส OTP ไม่ถูกต้อง กรุณารวจสอบ</p></font>");
                            $(".texterror_otp").removeClass('d-none');
                            loading('hide');
                        }
                    }
                })
            })
            $('#validationCustomOTP').keydown(function(e) {
                if (e.keyCode == 13) {
                    e.preventDefault();
                }
            })
            loading('hide');
        });
    }

    function loginUID(uid) {
        var param = {
            uid: uid
        }
        $.ajax({
            data: param,
            method: "post",
            datatype: "json",
            url: '<?php echo $uri; ?>Fncauth/login',
        }).done(function(e) {
            e = JSON.parse(e);

            if (e.status.STATUS == 'successfully') {
                var arr = [e.detail.ID];
                var getParam = encodeURIComponent(btoa(btoa(arr)));
                window.location.href = '<?php echo base_url() ?> ?c=' + getParam;
            } else {
                $('#alert-message').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">กรุณาตรวจสอบ อีเมล/เบอร์โทรศัพท์ และ รหัสผ่าน<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            }

        })
    }

    function loading(action) {
        if (action == "show") {
            var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg') ?>'><div class='overlay'></div></div>";
            $("body").append(loading_component);
        } else if (action == "hide") {
            $("body .loading-component").remove();
        }
    }
</script>