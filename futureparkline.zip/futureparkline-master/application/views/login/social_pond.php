
<div class="container top20 d-none" >
    <div>
        <a href="<?php echo $uri; ?>login">
            <i class="fa fa-chevron-left"></i>
        </a>
    </div>
    <div>
        <!-- <form id="formDataSoial" name="formDataSoial" method="post" action="#" enctype="multipart/form-data" img=""
        uid="U89daff62503f3fd15f9998" nameline="" email="jinnarat_yo@hotmail.com"> -->
        <form id="formDataSoial" name="formDataSoial" method="post" action="#" enctype="multipart/form-data" img=""
        uid="" nameline="" email="">

            <p class="text-title top30" id="head_page">กรอกเบอร์โทรศัพท์มือถือเพื่อเข้าสู่ระบบ</p>

            <div id="body_page">
                <div class="top50">
                    <div>เบอร์โทรศัพท์มือถือ</div>
                    <input class="form-control form-control-sm boxInput numberic" type="text" name="phone" id="phone" placeholder="" maxlength="10" required>
                    <div id="textPhone" style="display:none;"></div>
                </div>

                <div class="form-group top50">
                    <div class="row justify-content-center">
                        <a class="btn btn-submit form1-submit col-8 d-none" id="btnSubmit" href="javascript:void(0)">ยืนยัน (Submit)</a>
                    </div>
                </div>
            </div>
        </form>
    </div>

</div>
<div class="img-footer">
    <img src="<?php echo $uri . "assets/images/bg/bottom_bg.png?v=".date('his')."" ?>" alt=" " style="width: 111%;"class="responsive top10">  
</div>

<script src="https://static.line-scdn.net/liff/edge/2.1/sdk.js"></script>
<script>

    $(document).ready(function() {
        check_uid();
        function runApp() {
            liff.getProfile().then(profile => {
                // document.getElementById("pictureUrl").src = profile.pictureUrl;
                // document.getElementById("userId").innerHTML = '<b>UserId:</b> ' + profile.userId;
                // document.getElementById("displayName").innerHTML = '<b>DisplayName:</b> ' + profile.displayName;
                // document.getElementById("statusMessage").innerHTML = '<b>StatusMessage:</b> ' + profile.statusMessage;
                // document.getElementById("getDecodedIDToken").innerHTML = '<b>Email:</b> ' + liff.getDecodedIDToken().email;

                console.log("uid",profile.userId);
                
                $("#formDataSoial").attr("img",profile.pictureUrl);
                $("#formDataSoial").attr("uid",profile.userId);
                $("#formDataSoial").attr("nameline",profile.displayName);
                $("#formDataSoial").attr("email",liff.getDecodedIDToken().email);
                check_uid();
                
            }).catch(err => console.error(err));
        }
        liff.init({ liffId: "1654447737-M6YPy1kD" }, () => {
            if (liff.isLoggedIn()) {
                runApp()
            } else {
                liff.login();
            }
        }, err => console.error(err.code, error.message));

        function check_uid(){
            var uid =  $("#formDataSoial").attr("uid");
            console.log(uid);
            if(uid != ''){
                login_line(uid)
                loading('show');
            }else{
                $(".container").removeClass("d-none");
            }
        }

        

    });

    $(document).on("keyup", ".numberic", function(){
        this.value = this.value.replace(/[^0-9]/g, '');
    })

    $(document).on('click', '.form1-submit', function () {
        chkForm();
        check_status();
    }); 


    $('#phone').keyup(function(e) {
		var str_regexp = /^0/;		

		if (!str_regexp.test(this.value))
		{
			this.value = this.value.replace(str_regexp,'');

			$("#textPhone").css("display", "inline");
			$("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* เบอร์โทรศัพท์ไม่ถูกต้อง</p></font>")
			
			$("#phone").focus();		
		}
		else
		{
			$("#textPhone").css("display", "none");
		}	
	});

    function chkForm(){
		
		var tel = document.getElementById('phone');
		var checknum = tel.value.substring(0, 1);
		// console.log(tel); return false;
		
		if(tel.value.trim() == ""){
			$("#textPhone").css("display", "inline");
			$("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกเบอร์โทรศัพท์</p></font>")
			tel.focus(); return false;
		}
    }

    function check_status() {
        var phone = $('#phone').val();  
        var param = {phone: phone};
        console.log(phone);
        
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/check_member',
            data: param,
            success: function (e) {
                console.log('e',e);
                PARAM_PHONE = phone;
                if (e.status.STATUS == 'NEW_MEMBER' ||e.status.STATUS == 'Select_Person') {
                    getTofromRegister(phone,e.detail.is_member);	
                }else if(e.status.STATUS == 'Successfully'){
                    console.log('verifly_phoneแล้ว');
                    getTofromRegister(phone,e.status.is_member);    
                }
                else if(e.status.STATUS == 'Success_member'){
                    // var arr = [e.detail.ID ,e.detail.FIRST,e.detail.LAST,e.detail.BIRTH,e.detail.EMAIL,e.detail.GENDER,e.detail.IDCARD,e.detail.CONSENT,e.detail.SUB,e.detail.NATIONAL,e.detail.PASSPORT,e.detail];	
                        if(e.detail.is_member == 'Y'){
                            updateUserID(e.detail.ID,phone,e.detail.session_id);
                        }
                }else {
                    console.log(4);
                    
                    $("#validationCustomOTP").addClass("required");
                    $(".error").empty().text('รหัส OTP ไม่ถูกต้อง');
                    $(".error").removeClass('d-none');
                }
            }
            ,error: function (error) {
                console.log('error; ',error);
            }
        })
    }

    function updateUserID(id,phone,session){
        var uid = $("#formDataSoial").attr("uid");
        var img = $("#formDataSoial").attr("img");
        var email = $("#formDataSoial").attr("email");

		console.log('phone > ', phone,'uid > ', uid,'pid > ', id,'email > ', email);

		var param = {pid: id,uid: uid,phone: phone,email: email,session:session};

			$.ajax({
				type: 'POST',
				dataType: 'json',
				url: '<?php echo $uri; ?>Fncauth/update_data',
				data: param,
				success: function (e) {
                    console.log('log >>>> ',e);
                    
					// loadingPage('#load_page');
					if (e.status.STATUS == 'successfully') {
                        getFormPhone(phone);
					}else{
                        console.log(e.status.error);
                        login_line(uid);
                        loading('show');
                        // var uid = $("#formDataSoial").attr("uid");
                        // var arr = [phone, uid];
                        // var res = arr.join(';');
                        // var getParam = encodeURIComponent(btoa(btoa(res)));
                        //     console.log(getParam);
                            
                        // window.location.href = '<?php echo base_url() ?> ?c=' +getParam;	
                    }
				}
					,error: function (error) {
					console.log('error; ',error);
				}
			})
    }

    function login_line(uid){
        var param = {uid: uid};	
        console.log('>>> ',uid);

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/login',
            data: param,
            success: function(e) {
                console.log('data : ',e);
                // e = JSON.parse(e);

                if (e.status.STATUS == 'successfully') {
                    var arr = [e.detail.ID];
                    var getParam = encodeURIComponent(btoa(btoa(arr)));
                    // var link =  getCurrentUrl + '?c=' + getParam;
                    
                    window.location.href = '<?php echo base_url() ?> ?c=' +getParam;
                }else{
                    // console.log(e.status.error);
                    if(e.status.message == 'Member not found.'){
                        $(".container").removeClass("d-none");
                        loading('hide');
                    }
                } 
            }
            ,error: function (error) {
                console.log('error; ',error);
            }
        })
    }

    function getTofromRegister(phone,status_mem)
    {	     
    
        if(status_mem == 'N'){
            var dataHtml = '';
            var html_header = 'โปรดสมัครสมาชิก';

            var dataHtml = '';
            $.ajax({
                url:  '<?php echo $uri; ?>chkIdentity/fwarningRegis.html?v=1.0' + Math.random()
            }).done(function (HeaderHtml) {
                
                var mapObj = {
                    '<%link%>': '<?php echo $uri; ?>login/chack_phone',
                }
                dataHtml = HeaderHtml.replace(/<%link%>/gi, function (matched) { return mapObj[matched]; });

                $('#head_page').empty().append(html_header);
                $('#body_page').empty().append(dataHtml);
            });
        
        }
    }

    function getFormPhone(phone)
    {	     
        var param = {phone: phone};	
        console.log(phone);

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/genOTPandSMS',
            data: param,
            success: function(e) {
                console.log('data : ',e);
                console.log(e.detail.otp);
                
                // loadingPage('#load_page');
                PARAM_PHONE = phone;
                if (e.status.STATUS == 'Successfully')
                {
                    getOTPFormsocial(phone,e.detail.REF);	
                    // window.location.replace("index.php/login/chack_otp?id=" + phone);			
                }
                else{
                    $(".error").text(e.status.ERRDESC);
                    $(".error").removeClass('d-none');
                    $("#validationCustomPhone").addClass("required");						
                }
            }
            ,error: function (error) {
                console.log('error; ',error);
            }
        })
    }

    $(document).on('focusin', '#validationCustomOTP', function (){
        $('.texterror_otp').addClass('d-none');
        $("#validationCustomOTP").removeClass("required");
    });

    function getOTPFormsocial(phone, ref) {
        var getCurrentUrl 	= window.location.href;
        var html_header = '<p><b>VERIFICATION OTP</b></p>';

        var newphone = phone.substring(0, 2) + 'x-xxx-' + phone.substring(6, 10);

        var dataHtml = '';
        $.ajax({
            url:  '<?php echo $uri; ?>chkIdentity/fotp.html?v=1.0' + Math.random()
        }).done(function (HeaderHtml) {
            var refShow = ref;
            var mapObj = {
                '<%phone%>': btoa(phone),
                '<%reference%>': btoa(ref),
                '<%ref%>': refShow,
                '<%newphone%>': newphone,
            }
            dataHtml = HeaderHtml.replace(/<%phone%>|<%reference%>|<%newphone%>|<%ref%>/gi, function (matched) { return mapObj[matched]; });

            $(".error").addClass('d-none');

            $('#head_page').empty().append(html_header);
            $('#body_page').empty().append(dataHtml);

            $(".submit_otp").click(function () {
                // var refId = ref;
                var otp = $.trim($("#validationCustomOTP").val());
                // var otp = parseInt(a)
                if (otp == "") {
                    $("#validationCustomOTP").addClass("required");
                    $('.texterror_otp').removeClass('d-none');
                    $(".texterror_otp").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัส OTP</p></font>");
                    return false;
                }else{
                    $("#validationCustomOTP").removeClass("required");
                    $('.texterror_otp').addClass('d-none');
                }

                var new_ref = atob($(".row-otp").attr('r'));
                console.log('new_ref',ref,phone,otp)
                
                var param = {phone: phone, otp: otp, ref: ref };

                $.ajax({
                    type: 'POST',
                    dataType: 'json',
                    url: '<?php echo $uri; ?>Fncauth/checkOTP',
                    data: param,
                    success: function (e) {
                        console.log(e);
                        
                        PARAM_PHONE = phone;
                        if (e.status.STATUS == 'Successfully') {
                            var uid = $("#formDataSoial").attr("uid");
                            var arr = [phone, uid];
                            var res = arr.join(';');
                            var getParam = encodeURIComponent(btoa(btoa(res)));
                                console.log(getParam);
                                
                            window.location.href = '<?php echo base_url() ?> ?c=' +getParam;	

                            // window.location.href = getCurrentUrl + '?c=' + getParam;
                        } else {
                            $("#validationCustomOTP").addClass("required");
                            $(".texterror_otp").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* รหัส OTP ไม่ถูกต้อง กรุณารวจสอบ</p></font>");
                            $(".texterror_otp").removeClass('d-none');
                        }
                    }
                })
            })
        });
    }

    function loading(action)
	{
		if(action == "show")
		{
			var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg')?>'><div class='overlay'></div></div>";
			$("body").append(loading_component);
		}
		else if(action == "hide")
		{
			$("body .loading-component").remove();
		}
	}
    
</script>

