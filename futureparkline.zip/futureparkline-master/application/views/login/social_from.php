<link rel="stylesheet" href="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.css'); ?>">
<div class="my-3 text-center" id="gobalAlert" style="font-size: 18px; color: red; margin-left: 15px;"></div>
<div class="boxData d-none">
    <div class="container boxPage member d-none">
        <div class="row">
            <!-- <div class="col-1">
                <a href="<?php echo $uri; ?>login">
                    <i class="fa fa-chevron-left"></i>
                </a>
            </div> -->
            <div class="col-12">
                <form id="formDataSoial" name="formDataSoial" method="post" action="#" enctype="multipart/form-data" img="" uid="" nameline="" email="" StatusMessage="">
                    <p class="text-title inputPhoneOtp" id="head_page">ยื่นยันเบอร์โทรศัพท์มือถือ</p>
                    <div id="body_page">
                        <div class="top50 inputPhoneOtp">
                            <div>เบอร์โทรศัพท์มือถือ</div>
                            <input class="form-control form-control-sm boxInput numberic" type="text" name="phone" id="phone" placeholder="" maxlength="10" required>
                            <div id="textPhone" style="display:none;"></div>
                        </div>
    
                        <div class="form-group top50 inputPhoneOtp">
                            <div class="row justify-content-center">
                                <button class="btn btn-submit col-8" id="btnSubmit" onclick="form1Submit()">ยืนยัน (Submit)</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="container boxPage checkMember d-none">
        <div class="checkLineFrom">
            <div class="row">
                <!-- <div class="col-1">
                    <a href="<?php echo $uri; ?>login">
                        <i class="fa fa-chevron-left"></i>
                    </a>
                </div> -->
                <div class="col-12">
                    <p class="text-title" id="head_page">กรอกข้อมูลเพื่อเข้าสู่ระบบ</p>
                </div>
            </div>
            <div class="my-3 text-center checkMemberAlert" style="display:none;font-size: 18px; color: red; margin-left: 15px;"></div>
            <div id="isLineLogin">
                <div class="top50">
                    <div>เบอร์โทรศัพท์มือถือ</div>
                    <input class="form-control form-control-sm boxInput numberic" type="text" name="checkPhone" id="checkPhone" placeholder="" maxlength="10" required>
                    <div id="textCheckPhone" style="display:none;font-size: 18px; color: red; margin-left: 15px;"></div>
                </div>
                <div class="my-3">
                    <div class="form-check d-flex align-items-center">
                        <input class="form-check-input" style="margin: 0px !important;" type="radio" name="cardType" id="cardTypeThai" value="Thai" checked>
                        <label class="form-check-label ml-5 labelCardTypeThai" for="cardTypeThai" style="font-size: 18px; font-weight: unset;">
                            เลขบัตรประชาชน (ID Card No.)
                        </label>
                    </div>
                    <div class="form-check d-flex align-items-center">
                        <input class="form-check-input" type="radio" name="cardType" id="cardTypePassport" value="Passport">
                        <label class="form-check-label ml-5 labelCardTypePassport" for="cardTypePassport" style="font-size: 18px; font-weight: unset;">
                            เลขหนังสือเดินทาง (Passport No.)
                        </label>
                    </div>
                    <div class="my-3">
                        <div id="cardTypeText">เลขบัตรประชาชน (ID Card No.)</div>
                        <input class="form-control form-control-sm boxInput" type="text" name="checkIdcard" id="checkIdcard" placeholder="" maxlength="13">
                        <div id="textCheckIdcard" style="display:none;font-size: 18px; color: red; margin-left: 15px;"></div>
                    </div>
                    <div class="form-group top50">
                        <div class="row justify-content-center">
                            <button class="btn btn-submit btn-checkMember col-8" onclick="checkLineID()">ยืนยัน (Submit)</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="container boxPage selectMem d-none">
            <div class="row">
                <div class="col-12">
                    <p class="text-title" id="head_page">Login with Line</p>
                </div>
            </div>
            <div class="my-3 text-center checkMemberAlert" style="display:none;font-size: 18px; color: red; margin-left: 15px;"></div>
            <div class="form-group isLineLogin top50">
                <div class="row justify-content-center">
                    <a href="javascript:void(0)" class="btn btn-submit col-8 btn-memberNew">สมาชิกใหม่</a>
                </div>
                <div class="row justify-content-center top30">
                    <a href="<?= LIFFSOCIALOLDLink; ?>" class="btn btn-submit col-8">สมาชิกเก่า</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.js'); ?>"></script>

<script src="https://static.line-scdn.net/liff/edge/2.1/sdk.js"></script>
<script>
    var newUidFlow = Boolean(<?= NEWUIDFLOW; ?>);
    $(document).ready(function() {
        function runApp() {
            liff.getProfile().then(profile => {
                $("#formDataSoial").attr("img", profile.pictureUrl);
                $("#formDataSoial").attr("uid", profile.userId);
                $("#formDataSoial").attr("nameline", profile.displayName);
                $("#formDataSoial").attr("StatusMessage", profile.statusMessage);
                $("#formDataSoial").attr("email", liff.getDecodedIDToken().email);
                check_uid();
            }).catch(err => {
                $('#gobalAlert').text('ไม่สามารถใช้งาน Line ได้ กรุณาเข้าใหม่อีกครั้ง');
                $('#gobalAlert').show();
                // $('#body_page').hide();
            });
        }
        liff.init({
            liffId: "<?= LIFFSOCIALCODE; ?>"
        }, () => {
            if (liff.isLoggedIn()) {
                runApp()
            } else {
                liff.login();
            }
            $('#gobalAlert').hide();
        }, err => {
            $('#gobalAlert').text('ไม่สามารถใช้งาน Line ได้ กรุณาเข้าใหม่อีกครั้ง');
            $('#gobalAlert').show();
        });

        function check_uid() {
            var uid = $("#formDataSoial").attr("uid");
            if (uid) {
                $('#gobalAlert').hide();
                login_line(uid)
                loading('show');
            } else {
                $('.boxData').hide();
                $('#gobalAlert').text('ไม่สามารถใช้งาน Login Line ได้ กรุณาเข้าใหม่อีกครั้ง');
                $('#gobalAlert').show();
                Swal.fire({
                    position: 'center',
                    icon: 'error',
                    title: 'Oops...',
                    text: 'ไม่สามารถใช้งาน Login Line ได้ กรุณาเข้าใหม่อีกครั้ง',
                })
                // $(".boxsocail").removeClass("d-none");
                return false;
            }
        }

        $('[name=cardType]').change(function(e) {
            e.preventDefault();
            let valueInput = $(this).val();
            let textString = $('.labelCardType' + valueInput).text();
            $('#cardTypeText').text(textString);
        });
    });

    $(document).on("keyup", ".numberic", function() {
        this.value = this.value.replace(/[^0-9]/g, '');
    })

    function form1Submit() {
        $('#btnSubmit').prop("disabled", true);
        loading('show');
        chkForm();
    }

    $(document).on('click', '.btn-memberNew', function() {
        if (newUidFlow) {
            loading('show');
            getFormPhone();
            $('.inputPhoneOtp').hide();
        }else {
            $('.inputPhoneOtp').show();
        }
        $(".selectMem").addClass("d-none");
        $(".member").removeClass("d-none");
        $('.member').show();
    });

    $('#phone').keydown(function(e) {
        if (e.keyCode == 13) {
            e.preventDefault();
            loading('show');
            chkForm();
        }
    });

    function checkLineID() {
        loading('show');
        let uid = $("#formDataSoial").attr("uid");
        let dataFrom = {
            phone: $('#checkPhone').val(),
            idcard: $('#checkIdcard').val(),
            type: $('[name=cardType]:checked').val(),
            uid: uid,
        };

        $('#phone').val($('#checkPhone').val());
        $.ajax({
            type: "post",
            url: "<?= $uri; ?>Fncauth/checkLineID",
            data: dataFrom,
            dataType: "json",
            success: function(response) {
                if (response.status) {
                    // login_line(uid)
                    if (response.login) {
                        login_line(uid);
                    }
                    // loading('hide');
                } else {
                    if (response.newUser) {
                        $('.selectMem').removeClass('d-none');
                        $('.selectMem').show();
                        $(".member").addClass("d-none");
                        $('.member').hide();
                        $('.checkLineFrom').show();
                        $(".checkLineFrom").addClass("d-none");
                    } else {
                        if (response.error) {
                            if (response.error.phone) {
                                $('#textCheckPhone').show();
                                $('#textCheckPhone').text(response.error.phone);
                            } else {
                                $('#textCheckPhone').hide();
                            }
                            if (response.error.idcard) {
                                $('#textCheckIdcard').show();
                                $('#textCheckIdcard').text(response.error.idcard);
                            } else {
                                $('#textCheckIdcard').hide();
                            }
                            if (response.error.uid) {
                                $('.checkMemberAlert').show();
                                $('.checkMemberAlert').text(response.error.uid);
                            } else {
                                $('.checkMemberAlert').hide();
                            }
                        }

                        // Notifications together
                        if (response.fail) {
                            $('.checkMemberAlert').show();
                            $('.checkMemberAlert').html(response.message);
                        } else {
                            $('.checkMemberAlert').hide();
                        }
                    }
                    loading('hide');
                }
            },
            error: function(error) {
                loading('hide');
            }
        }).done(() => {

        });
    }

    function chkForm() {
        var tel = document.getElementById('phone');
        if (tel.value.trim() == "") {
            $("#textPhone").css("display", "inline");
            $("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกเบอร์โทรศัพท์</p></font>")
            tel.focus();
            $('#btnSubmit').prop("disabled", false);
            loading('hide');
            return false;
        } else {
            check_status();
        }
    }

    function check_status() {
        var phone = $('#phone').val();
        var uid = $("#formDataSoial").attr("uid");
        var param = {
            phone: phone
        };

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/check_member',
            data: param,
            success: function(e) {
                PARAM_PHONE = phone;
                if (e.status.STATUS == 'NEW_MEMBER' || e.status.STATUS == 'Select_Person') {
                    // getTofromRegister(phone, e.status.is_member);
                    getFormPhone();
                } else if (e.status.STATUS == 'Successfully' || e.status.STATUS == 'Success_member') {
                    // getTofromRegister(phone, e.status.is_member);
                    getFormPhone();
                } else if (e.status.STATUS == 'Success_memberLine') {
                    if (e.detail.is_member == 'Y') {
                        getFormPhone();
                        // getFormPhone(phone, uid, 'Y', e.detail.ID, e.detail.session_id);
                    }
                } else {
                    $("#validationCustomOTP").addClass("required");
                    $(".error").empty().text('รหัส OTP ไม่ถูกต้อง');
                    $(".error").removeClass('d-none');
                    loading('hide');
                }
            },
            error: function(error) {
                loading('hide');
            }
        })

    }

    function updateUserID(id, phone, session) {
        var uid = $("#formDataSoial").attr("uid");
        var img = $("#formDataSoial").attr("img");
        var email = $("#formDataSoial").attr("email");


        var param = {
            pid: id,
            uid: uid,
            phone: phone,
            email: email,
            session: session
        };

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/update_data',
            data: param,
            success: function(e) {

                // loadingPage('#load_page');
                if (e.status.STATUS == 'successfully') {
                    loginUID(uid)
                } else {
                    login_line(uid);
                    loading('show');
                }
            },
            error: function(error) {}
        })
    }

    function login_line(uid) {
        var param = {
            uid: $("#formDataSoial").attr("uid"),
            socialPictureUrl: $("#formDataSoial").attr("img"),
            socialDisplayName: $("#formDataSoial").attr("nameline"),
            socialStatusMessage: $("#formDataSoial").attr("StatusMessage"),
            socialEmail: $("#formDataSoial").attr("email"),
        };
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/login',
            data: param,
            success: function(e) {
                if (e.status.STATUS == 'successfully') {
                    Swal.fire({
                        position: 'top',
                        icon: 'success',
                        title: 'รอสักครู่ กำลังเข้าสู่ระบบ',
                        showConfirmButton: false,
                        timer: 5000
                    })
                    var arr = [e.detail.ID];
                    var getParam = encodeURIComponent(btoa(btoa(arr)));
                    window.location.href = '<?php echo base_url() ?> ?c=' + getParam;
                } else {
                    if (e.status.message == 'Member not found.') {
                        $(".boxData").removeClass("d-none");
                        $('.boxData').show();
                        $(".member").addClass("d-none");
                        $(".checkMember").removeClass("d-none");
                        if (newUidFlow) {
                            $(".checkLineFrom").removeClass("d-none");
                            $(".selectMem").addClass("d-none");
                        }else {
                            $(".checkLineFrom").addClass("d-none");
                            $(".selectMem").removeClass("d-none");
                        }
                        loading('hide');
                    }else if (e.status.STATUS == "Unsuccessfully") {
                        let originalString = e.status.message;
                        let strippedString = originalString.replace(/(<([^>]+)>)/gi, "");
                        Swal.fire({
                            position: 'top',
                            icon: 'error',
                            title: 'ผิดพลาด',
                            showConfirmButton: false,
                            allowOutsideClick: false,
                            text: strippedString,
                        })
                    }
                }
            },
            error: function(error) {}
        })
    }

    function getTofromRegister(phone, status_mem) {
        var uid = $("#formDataSoial").attr("uid");
        if (status_mem == 'N') {
            // var dataHtml = '';
            // var html_header = 'โปรดสมัครสมาชิก';

            // var dataHtml = '';
            // $.ajax({
            //     url:  '<?php echo $uri; ?>chkIdentity/fwarningRegis.html?v=1.0' + Math.random()
            // }).done(function (HeaderHtml) {

            //     var mapObj = {
            //         '<%link%>': '<?php echo $uri; ?>login/chack_phone?uid='+uid,
            //     }
            //     dataHtml = HeaderHtml.replace(/<%link%>/gi, function (matched) { return mapObj[matched]; });

            //     $('#head_page').empty().append(html_header);
            //     $('#body_page').empty().append(dataHtml);
            // });

            getFormPhone()

        }
    }

    $(document).on('focusin', '#validationCustomOTP', function() {
        $('.texterror_otp').addClass('d-none');
        $("#validationCustomOTP").removeClass("required");
    });

    $(document).on('click', '.resent', function() {
        // loading('show');
        // check_status();
        loading('show');
        resentOtp();

    });

    function resentOtp() {
        var uid = $("#formDataSoial").attr("uid");
        // var phone = atob($("#verifyPhone").attr('d'));
        var phone = $('#checkPhone').val();
        var param = {
            phone: phone
        };

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo $uri; ?>Fncauth/check_member',
            data: param,
            success: function(e) {
                PARAM_PHONE = phone;
                loading('hide');
                if (e.status.STATUS == 'NEW_MEMBER' || e.status.STATUS == 'Select_Person') {
                    getTofromRegister(phone, e.status.is_member);
                } else if (e.status.STATUS == 'Successfully' || e.status.STATUS == 'Success_member') {
                    getTofromRegister(phone, e.status.is_member);
                } else if (e.status.STATUS == 'Success_memberLine') {
                    if (e.detail.is_member == 'Y') {
                        getFormPhone();
                    }
                } else {
                    $("#validationCustomOTP").addClass("required");
                    $(".error").empty().text('รหัส OTP ไม่ถูกต้อง');
                    $(".error").removeClass('d-none');
                }
            },
            error: function(error) {}
        })
    }

    // function getFormPhone(phone, uid, status_mem, pId, session) {
    function getFormPhone() {
        var uid = $("#formDataSoial").attr("uid");
        $('#validationCustomOTP').val('');
        var phone = null;
        if (newUidFlow) {
            phone = $('#checkPhone').val(); // new uid flow
        }else {
            phone = $('#phone').val(); // normal uid flow
        }
        var param = {
            phone: phone
        };
        if (phone) {
            // $(".selectMem").addClass("d-none");
            $.ajax({
                type: 'POST',
                dataType: 'json',
                url: '<?php echo $uri; ?>Fncauth/genOTPandSMS',
                data: param,
                success: function(e) {
                    PARAM_PHONE = phone;
                    if (e.status.STATUS == 'Successfully') {
                        getOTPFormsocial(phone, e.detail.REF);
                        setTimeout(() => {
                            $('#validationCustomOTP').val(e.detail.otp);
                        }, 1000);
                    } else {
                        $(".error").text(e.status.ERRDESC);
                        $(".error").removeClass('d-none');
                        $("#validationCustomPhone").addClass("required");
                        loading('hide');
                    }
                },
                error: function(error) {}
            }).done(() => {
                loading('hide');
            });
        }else {
            $("#textPhone").css("display", "inline");
            $("#textPhone").empty().append("<font color='#FF6666' ><p style='margin-bottom: 10px;'>* กรุณากรอกเบอร์โทรศัพท์</p></font>")
            tel.focus();
            loading('hide'); 
        }
    }

    function getOTPFormsocial(phone, ref) {
        var getCurrentUrl = window.location.href;
        var html_header = '<p><b>VERIFICATION OTP</b></p>';
        var newphone = phone.substring(0, 2) + 'x-xxx-' + phone.substring(6, 10);
        var dataHtml = '';
        $.ajax({
            url: '<?php echo $uri; ?>chkIdentity/fotp.html?v=1.0' + Math.random()
        }).done(function(HeaderHtml) {
            var refShow = ref;
            var mapObj = {
                '<%phone%>': btoa(phone),
                '<%ref%>': refShow,
                '<%reference%>': btoa(ref),
                '<%newphone%>': newphone,
            }
            dataHtml = HeaderHtml.replace(/<%phone%>|<%reference%>|<%newphone%>|<%ref%>/gi, function(matched) {
                return mapObj[matched];
            });
            $(".error").addClass('d-none');
            $('#head_page').empty().append(html_header);
            $('#head_page').show();
            $('#body_page').empty().append(dataHtml);
            $(".submit_otp").click(function() {
                loading('show');
                var otp = $.trim($("#validationCustomOTP").val());
                if (otp == "") {
                    $("#validationCustomOTP").addClass("required");
                    $('.texterror_otp').removeClass('d-none');
                    $(".texterror_otp").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* กรุณากรอกรหัส OTP</p></font>");
                    return false;
                } else {
                    $("#validationCustomOTP").removeClass("required");
                    $('.texterror_otp').addClass('d-none');
                }
                // var new_ref = atob($(".row-otp").attr('r'));
                var param = {
                    phone: phone,
                    otp: otp,
                    ref: ref
                };
                $.ajax({
                    type: 'POST',
                    dataType: 'json',
                    url: '<?php echo $uri; ?>Fncauth/checkOTP',
                    data: param,
                    success: function(e) {
                        PARAM_PHONE = phone;
                        if (e.status.STATUS == 'Successfully') {
                            var uid = $("#formDataSoial").attr("uid");
                            var arr = [phone, ref, uid, 'new'];
                            var res = arr.join(';');
                            var getParam = encodeURIComponent(btoa(btoa(res)));
                            window.location.replace("login/person_member?c=" + getParam);
                        } else {
                            $("#validationCustomOTP").val('');
                            loading('hide');
                            $("#validationCustomOTP").addClass("required");
                            $(".texterror_otp").empty().html("<font color='red' size='4'><p style='margin-bottom: 10px;'>* รหัส OTP ไม่ถูกต้อง กรุณารวจสอบ</p></font>");
                            $(".texterror_otp").removeClass('d-none');
                        }
                    }
                })
            })
            $('#validationCustomOTP').keydown(function(e) {
                if (e.keyCode == 13) {
                    e.preventDefault();
                }
            })
            loading('hide');
        });
    }

    function loginUID(uid) {
        var param = {
            uid: uid
        }
        $.ajax({
            data: param,
            method: "post",
            datatype: "json",
            url: '<?php echo $uri; ?>Fncauth/login',
        }).done(function(e) {
            e = JSON.parse(e);

            if (e.status.STATUS == 'successfully') {
                var arr = [e.detail.ID];
                var getParam = encodeURIComponent(btoa(btoa(arr)));
                // var link =  getCurrentUrl + '?c=' + getParam;

                window.location.href = '<?php echo base_url() ?> ?c=' + getParam;
            } else {
                $('#alert-message').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">กรุณาตรวจสอบ อีเมล/เบอร์โทรศัพท์ และ รหัสผ่าน<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            }
            // $('#national').html(jQuery.parseJSON(e));

        })
    }

    function loading(action) {
        if (action == "show") {
            var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg') ?>'><div class='overlay'></div></div>";
            $("body").append(loading_component);
        } else if (action == "hide") {
            $("body .loading-component").remove();
        }
    }
</script>