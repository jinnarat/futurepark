
<div class="template"> 
	<!-- <div class="body-content card-form" cname="<?php if(isset($detail[0]['urlfriendly'])) echo $detail[0]['urlfriendly'];?>"> -->
		<div class="container"> 
			<div class="block-profile mt-3">
				<?php if(isset($DataPerson) && $DataPerson != "") { ?>
				<div class="mt-3">
					<div class="card-profile mb-3">
						<div class="card-columns">						
							<?php echo $DataPerson; ?>				
						</div>					
					</div>
				</div>
				<div class="mt-3 text-center">
					<button class="btn btn-green btn-confirm">ยืนยัน (Submit)</button>
				</div>
				<?php } ?>
			</div>
			<div class="card mb-3 card-mform d-none">
				<div class="card-body">					
					<div class="card-form"></div>
				</div>
			</div>
		</div>
	<!-- </div> -->
</div>

<script>

    $(document).ready(function() {
        InitTemplate();	
    });
   
    function checkBox(){
		var Condition = $('#checkCondition').is(":checked")
		var Congrats = $('#checkCongrats').is(":checked")
		
		if(Condition == true){
			$("#btnSubmit").attr("disabled", false);
			$('#btnSubmit').removeClass('btn-secondary').addClass('btn-submit');

			if(Congrats == true){
				$("#value_consent").val("Y");
			}else{
				$("#value_consent").val("N");
			}
			
		}else{
			$("#btnSubmit").attr("disabled", true);
			$('#btnSubmit').removeClass('btn-submit').addClass('btn-secondary');
		}
	}

    function isTypeOfUndefined(e)
	{
		if(typeof e === 'undefined'){ return e = ""; }
		return e;
	}		

	// var TMP = tmpDataSet;
	var TMP = 'fregister';
	var baseURL 	= window.location.href;
	
	function InitTemplate(pid) {
		var dataHtml = '';
		
		var param = {phone: DataRef.REFPH,pid: pid};	
		// loadingPage('#load_page');
		$.ajax({
			url: '<?php echo $uri; ?>chkIdentity/' + TMP + '.html?v=1.0' + Math.random()
		}).done(function (HeaderHtml) {
			
			$.ajax({
				type: 'POST',
				dataType: 'json',
				url: '<?php echo $uri; ?>Fncauth/get_member',
				// data: DataRef,
				data: param,
				success: function (e) {
					
					// loadingPage('#load_page');
					var REFID = isTypeOfUndefined(e.status.STATUS);

					var mapObj = {
						'<%InputFirstname%>': REFID,
						'<%InputLastname%>': REFID,
						// '<%phone%>': btoa(phone),
						// '<%reference%>': btoa(ref),
						// '<%newphone%>': newphone,
					}
					dataHtml = HeaderHtml.replace(/<%InputFirstname%>|<%InputLastname%>/gi, function (matched) { return mapObj[matched]; });
					// dataHtml = HeaderHtml.replace(/<%campaignId%>|<%campaignCode%>|<%activityId%>|<%activityCode%>|<%LabelCurrentAddress%>|<%InputFirstname%>|<%InputLastname%>|<%InputBirthdate%>|<%InputGender%>|<%InputIdCard%>|<%InputIdCard%>|<%InputPassport%>|<%InputNation%>|<%InputMobile%>|<%InputEmail%>|<%InputCurrentDetail%>|<%InputCurrentLocation%>|<%LabelRegisteredAddress%>|<%InputRegisteredDetail%>|<%InputRegisteredLocation%>|<%InputConsent%>/gi, function (matched) {
					// 	return mapObj[matched];
					// });

					// var REFID = isTypeOfUndefined(e.dataobj.REFID);
					// var REFCODE = isTypeOfUndefined(e.dataobj.REFCODE);
					// var REFCAMPID = isTypeOfUndefined(e.dataobj.REFCAMPID);
					// var REFCAMPCODE = isTypeOfUndefined(e.dataobj.REFCAMPCODE);
					// var tmpFirstname = isTypeOfUndefined(e.datafield.firstname);
					// var tmpLastname = isTypeOfUndefined(e.datafield.lastname);
					// var tmpIdCardNo = isTypeOfUndefined(e.datafield.idCardNo);
					// var tmpPassportNo = isTypeOfUndefined(e.datafield.passportNo);
					// var tmpMobileNo = isTypeOfUndefined(e.datafield.mobileNo);
					// var tmpBirthdate = isTypeOfUndefined(e.datafield.birthdate);
					// var tmpEmail = isTypeOfUndefined(e.datafield.email);
					// var tmpGender = isTypeOfUndefined(e.datafield.gender);
					// var tmpNationCode = isTypeOfUndefined(e.datafield.nationCode);

					// var tmpLabelCurAddr = isTypeOfUndefined(e.datafield.LabelCurrentAddr);
					// var tmpCurrentDetail = isTypeOfUndefined(e.datafield.Current_detail);
					// var tmpCurrentProvince = isTypeOfUndefined(e.datafield.Current_provinceCode);
					// var tmpCurrentDistrict = isTypeOfUndefined(e.datafield.Current_districtCode);
					// var tmpCurrentSubDistrict = isTypeOfUndefined(e.datafield.Current_subDistrictCode);
					// var tmpCurrentPoscode = isTypeOfUndefined(e.datafield.Current_postcode);
					// var tmpCurrentLocation = tmpCurrentProvince + tmpCurrentDistrict + tmpCurrentSubDistrict + tmpCurrentPoscode;

					// var tmpLabelRegAddr = isTypeOfUndefined(e.datafield.LabelRegisteredAddr);
					// var tmpRegisteredDetail = isTypeOfUndefined(e.datafield.Registered_detail);
					// var tmpRegisteredProvince = isTypeOfUndefined(e.datafield.Registered_provinceCode);
					// var tmpRegisteredDistrict = isTypeOfUndefined(e.datafield.Registered_districtCode);
					// var tmpRegisteredSubDistrict = isTypeOfUndefined(e.datafield.Registered_subDistrictCode);
					// var tmpRegisteredPoscode = isTypeOfUndefined(e.datafield.Registered_postcode);
					// var tmpRegisteredLocation = tmpRegisteredProvince + tmpRegisteredDistrict + tmpRegisteredSubDistrict + tmpRegisteredPoscode;

					// var tmpTechAdoption = isTypeOfUndefined(e.datafield.technologyAdoption);
					// var tmpPreferChannel = isTypeOfUndefined(e.datafield.preferredChannel);
					// var tmpConsent = isTypeOfUndefined(e.datafield.consent);

					// var mapObj = {
					// 	'<%campaignId%>': REFCAMPID,
					// 	'<%campaignCode%>': REFCAMPCODE,
					// 	'<%activityId%>': REFID,
					// 	'<%activityCode%>': REFCODE,
					// 	'<%InputFirstname%>': tmpFirstname,
					// 	'<%InputLastname%>': tmpLastname,
					// 	'<%InputBirthdate%>': tmpBirthdate,
					// 	'<%InputGender%>': tmpGender,
					// 	'<%InputIdCard%>': tmpIdCardNo,
					// 	'<%InputPassport%>': tmpPassportNo,
					// 	'<%InputNation%>': tmpNationCode,
					// 	'<%InputMobile%>': tmpMobileNo,
					// 	'<%InputEmail%>': tmpEmail,
					// 	'<%LabelCurrentAddress%>': tmpLabelCurAddr,
					// 	'<%InputCurrentDetail%>': tmpCurrentDetail,
					// 	'<%InputCurrentLocation%>': tmpCurrentLocation,
					// 	'<%LabelRegisteredAddress%>': tmpLabelRegAddr,
					// 	'<%InputRegisteredDetail%>': tmpRegisteredDetail,
					// 	'<%InputRegisteredLocation%>': tmpRegisteredLocation,
					// 	'<%InputConsent%>': tmpConsent,
					// }

					// dataHtml = HeaderHtml.replace(/<%campaignId%>|<%campaignCode%>|<%activityId%>|<%activityCode%>|<%LabelCurrentAddress%>|<%InputFirstname%>|<%InputLastname%>|<%InputBirthdate%>|<%InputGender%>|<%InputIdCard%>|<%InputIdCard%>|<%InputPassport%>|<%InputNation%>|<%InputMobile%>|<%InputEmail%>|<%InputCurrentDetail%>|<%InputCurrentLocation%>|<%LabelRegisteredAddress%>|<%InputRegisteredDetail%>|<%InputRegisteredLocation%>|<%InputConsent%>/gi, function (matched) {
					// 	return mapObj[matched];
					// });


					// $('#body_page').empty().append(dataHtml);
					$(".card-form").empty().html(dataHtml);
					// $('#birthdate').bootstrapBirthday();
					$(".card-mform").removeClass('d-none');
                    $(".block-profile").empty();

					// if (typeof pid != 'undefined') {
					// 	getPersonData(pid);
					// }
					// if (e.dataobj.PERSID != "") {
					// 	getPersonData(e.dataobj.PERSID);
					// }
				}
					,error: function (error) {
					console.log('error; ',error);
				}
			})
		});
	}

</script>