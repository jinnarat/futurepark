
<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>login">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title" id="head_page" u="<?php echo $uid; ?>">เสร็จสิ้น (Success)</p>
        </div>
    </div>
    <div>
        <div id="body_page">
            <div class="top50 text-center">
                <?php if($menu == 'next'){
                    echo '<div>คุณได้ทำการสมัครเรียบร้อยแล้ว แต่ยังไม่ได้ยืนยันอีเมลของคุณ</div>';
                }else if($menu == 'mail')
                {
                    echo '<div>คุณได้ทำการสมัครเรียบร้อยแล้ว</div>';
                }else{
                    echo '<div>คุณได้ทำการสมัครและยืนยันตัวตนผ่านอีเมลเรียบร้อยแล้ว </div>';
                }
                ?>
                
                <!-- <a class="text-next" href="<?php echo $uri; ?>login">กรุณาเข้าสู่ระบบ</a> -->
            </div>
            <div class="form-group top50">
                <div class="row justify-content-center">
                    <a class="btn btn-submit" href="<?= LIFFSOCIALLink; ?>">กรุณาเข้าสู่ระบบ (Login)</a>
                </div>
            </div>
        </div>
    </div>

    <!-- <div class="row">
        <div class="col-12 my-5 text-center">
            <a href="<?php echo $uri.'assets/images/thankimg.jpeg'; ?>" target="_blank">
                <img src="<?php echo $uri.'assets/images/thankimg.jpeg'; ?>" style="width: 100%;" alt="">
            </a>
        </div>
    </div> -->

</div>
<!-- <div class="img-footer">
    <img src="<?php echo $uri . "assets/images/bg/bottom_bg.png?v=".date('his')."" ?>" alt=" " style="width: 111%;"class="responsive top10">  
</div> -->

<script>
    $( document ).ready(function() {
        var uid = $("#head_page").attr('u');

        if(!isEmpty(uid)){
            loginUID(uid);
            loading('show');
        }
    });

    function loginUID(uid){
        var param = {uid: uid}
        $.ajax({
            data: param,
            method: "post",
            datatype: "json",
            url: '<?php echo $uri; ?>Fncauth/login',
        }).done(function(e) {
            e = JSON.parse(e);

            if (e.status.STATUS == 'successfully') {
                var arr = [e.detail.ID];
                var getParam = encodeURIComponent(btoa(btoa(arr)));
                // var link =  getCurrentUrl + '?c=' + getParam;
                
                window.location.href = '<?php echo base_url() ?> ?c=' +getParam;
            }else{
                $('#alert-message').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">กรุณาตรวจสอบ อีเมล/เบอร์โทรศัพท์ และ รหัสผ่าน<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            }
            // $('#national').html(jQuery.parseJSON(e));
            
        })
    }
</script>