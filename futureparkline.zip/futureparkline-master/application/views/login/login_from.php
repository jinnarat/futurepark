
<style>
    .line{
        /* border: 0.5px solid #000; */
        border-bottom: 1px solid #000;
        margin-bottom: 60px;
        margin-top: 40px;
    }
    .btn-line ,.btn-line:focus{
        background: #fff;
        color: #00A69C;
    }
</style>

<div class="container top50">
    <div>
        <p class="text-title">เข้าสู่ระบบ (Login) </p>
        <div class="top30" id="alert-message"></div>
        <form name="form1" id="form1" novalidate enctype="multipart/form-data" onsubmit="return chkForm()" method="post" action="<?php echo $uri; ?>profile/profile_edit">
            <!-- <input type="text" name="token" id="token" value=""> -->
            <div class="top30">
                <div class="textBold">อีเมล/เบอร์โทรศัพท์มือถือ (Email/Tel.)</div>
                <input class="form-control form-control-sm boxInput" type="text" name="username" id="username" placeholder="">
            </div>
            <div class="top10">
                <div class="textBold">รหัสผ่าน (Password)</div>
                <input class="form-control form-control-sm boxInput" type="password" name="password" id="password" placeholder="">
            </div>
            <div class="forget top20">
                <a href="<?php echo $uri; ?>login/forget" class="forget-pos col-12"> ลืมรหัสผ่าน (Forget Password)</a>
            </div>

            <div class="form-group top70">
                <div class="row justify-content-center" style="margin-top: 40px;">
                    <a class="btn btn-submit btn-line col-8" id="btn-login" href="javascript:void(0)" >เข้าสู่ระบบ (Login)</a>
                </div>
            </div>
            <div class="form-group">
                <div class="row justify-content-center">
                    <!-- production -->
                    <a href="<?= LIFFSOCIALLink; ?>" class="btn btn-submit btn-line col-8">Login with Line</a> 
                </div>
            </div>
        </form>
        <p class="line"></p>
    </div>
</div>
<div class="img-login">
    <!-- <img src="<?php echo $uri . "assets/images/bg/login_page.png?v=".date('his')?>" alt=" " class="responsive top10">   -->
</div>
<script src="https://static.line-scdn.net/liff/edge/2.1/sdk.js"></script>
<!-- <script type="text/javascript" src="<?php echo $uri;?>assets/js_api/api.js?v=<?php echo date("YmdHis") ?>"></script> -->

<script>
    $(document).on('click', '#btn-login', function () {
		loginprogeam();
    });
    
    function loginprogeam(){
        loading('show');
        var username = document.getElementById("username").value;
        var password = document.getElementById("password").value;

        // console.log(username,password);
        
        var param = {username: username,password: password}
        $.ajax({
            data: param,
            method: "post",
            datatype: "json",
            url: '<?php echo $uri; ?>Fncauth/login',
        }).done(function(e) {
            e = JSON.parse(e);
            // console.log('e.status.STATUS.message',e.status.STATUS.message);
            if (e.status.STATUS == 'successfully') {
                var arr = [e.detail.ID];
                var getParam = encodeURIComponent(btoa(btoa(arr)));
                // var link =  getCurrentUrl + '?c=' + getParam;
                
                window.location.href = '<?php echo base_url() ?> ?c=' +getParam;
            }else{
                loading('hide');
                document.getElementById("username").value = '';
                document.getElementById("password").value = '';
                if (e.status.message) {
                    $('#alert-message').html(`<div class="alert alert-danger alert-dismissible fade show" role="alert">${e.status.message}<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>`);
                }else {
                    $('#alert-message').html('<div class="alert alert-danger alert-dismissible fade show" role="alert">กรุณาตรวจสอบ อีเมล/เบอร์โทรศัพท์ และ รหัสผ่าน<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
                }
            }
            // $('#national').html(jQuery.parseJSON(e));
            
        })
    }

    function loading(action)
	{
		if(action == "show")
		{
			var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg')?>'><div class='overlay'></div></div>";
			$("body").append(loading_component);
		}
		else if(action == "hide")
		{
			$("body .loading-component").remove();
		}
	}
</script>