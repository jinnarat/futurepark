<!-- Personalized Promotion -->

<style>
    .promo-img {
        background-position: center;
        background-size: cover;
    }

    .promo-img .size-img {
        width: 100%
    }
    .modal-dialog{
        margin: 0;
    }

    .promo-detail {
        margin: 5px 0;
        /* height: 16vh; */
    }

    .promo-img .default-img {
        padding: 10px 0;
    }
    
    .modal-content{
        height: 100vh;
        /* display: flex; */
        /* height: -webkit-fill-available; */
        /* min-height: 100vh; */
        /* min-height: -webkit-fill-available; */
        /* min-height: -webkit-fill-available; */
/*       height: 100vh;
        height: -webkit-fill-available; */
    }

    .iframe-container iframe {
        border: 0;
        height: 100%;
        left: 0;
        position: absolute;
        top: 0;
        width: 100%;
    }

</style>

<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title"> สิทธิพิเศษเฉพาะคุณ</p>
        </div>
    </div>
</div>
<div>
    <?php echo $list_promotion; ?>
</div>

<script>
    var dataPormo = <?php echo json_encode($list_promotion); ?>;
    $('.borderBox').click(function (e) { 
        e.preventDefault();
        
        let linkPromo = $(this).find('.promo-img a').attr('href');
        let namePromo = $(this).find('.activityName').text();
        let iframHtml = `<iframe class="ifram iframe-container iframe-model" src="${linkPromo}" frameborder="0" style="width: 100%;"></iframe>`;
        $("#myModalTitle .modal-title").empty().html(namePromo);
        $("#myModalTitle .modal-body").empty().append(`${iframHtml}`);
        $("#myModalTitle").modal('show');
    });
</script>