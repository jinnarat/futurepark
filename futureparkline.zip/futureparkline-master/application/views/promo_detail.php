
<div class="container boxPage">
    <div>
        <a href="<?php echo $uri; ?>promotion">
            <i class="fa fa-chevron-left"></i>
        </a>
    </div>
    <div class="top30">
        <?php   if($list_camp){
                echo $list_camp;
                }

                if($detail_promotion){
                    echo $detail_promotion;
                }
        ?>
    </div>
</div>

<script>

$(document).on("click",".modal-close",function() {
    $("#confirmModal").modal('hide');
});

$(document).on("click",".btn-use",function() {
    var name = $("#formUpdate").attr("name");
    var time = $("#formUpdate").attr("time");

    $(".modal-title").empty().append('ยืนยัน');
    $("#confirmModal .modal-body").empty().append('<div class="text-center"><div>คุณยืนยันที่จะใช้โปรโมชั่น <b>'+name+'</b> </div><div>คุณมีเวลา '+time+' นาทีในการรับสิทธิ์</div></div>');
    $("#confirmModal").modal('show');
});

$(document).on("click",".submit",function() {
    var cId = $("#formUpdate").attr("cId");
    var scId = $("#formUpdate").attr("sId");
    var aId = $("#formUpdate").attr("aId");
    var pId = $("#formUpdate").attr("pId");
    var code = $("#formUpdate").attr("code");

    var param = {cId: cId, scId: scId, aId: aId, pId: pId,code:code}; 

    // console.log(param); return false;

    $.ajax({
        type: 'POST',
        dataType: 'json',
        url: '<?php echo base_url(); ?>promotion/updateUse',
        data: param,
        success: function (e) {
            console.log(e);
            
            if (e.status.STATUS == 'Successfully') {

                window.location.replace("promotion/userEvent?r=Line&cId=" + e.status.CID + "&sId=" + e.status.SID + "&aId=" + e.status.AID + "&pId=" + e.status.PID + "&code=" + e.status.CODE);
            }else{
                console.log('errer update usedby');
            }
        }
    })
});
</script>