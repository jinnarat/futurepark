<!-- Service request -->

<style>
    .nav-size{
        width: 50%;
    }
    .fade h4{
        text-align:center;
        margin-top:20px;
    }
    textarea{
        border: 2px solid #dcdcdc;
    }

    .tab {
        overflow: hidden;
        /* background-color: #f1f1f1; */
        border: 1px solid #929293;
        width: fit-content;
        border-radius: 13px;
        /* margin-top: 30px; */
        background-color: #ccc;
        color: #929293;
    }


    /* Style the buttons inside the tab */
    .tab button {
        background-color: inherit;
        float: left;
        border: none;
        outline: none;
        cursor: pointer;
        padding: 8px 7px;
        transition: 0.3s;
        font-size: 22px;
        width: 140px;
    }

    /* Change background color of buttons on hover */
    .tab button:hover {
        background-color: #ddd;
    }

    /* Create an active/current tablink class */
    .tab button.active {
        background-color: #fff;
        color: #333;
    }

    /* Style the tab content */
    .tabcontent {
        display: none;
        padding: 6px 12px;
        -webkit-animation: fadeEffect 1s;
        animation: fadeEffect 1s;
    }

    /* Fade in tabs */
    @-webkit-keyframes fadeEffect {
        from {opacity: 0;}
        to {opacity: 1;}
    }

    @keyframes fadeEffect {
        from {opacity: 0;}
        to {opacity: 1;}
    }
</style>

<div class="container boxPage top70">
    <!-- <div>
        <a href="<?php echo $uri; ?>">
            <img src="<?php echo $uri . "assets/images/icons/set_home.png?v=".date('his')."" ?>" alt=" " class="responsive top10">
        </a>
    </div> -->
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <!-- <p class="text-title">บริการ (Service Request)</p> -->
            <div class="tab center text-center">
                <button class="tablinks active" id="defaultOpen"  style="border-right:1px solid #929293;" onclick="openCity(event, 'service')">บริการของเรา</button>
                <button class="tablinks" onclick="openCity(event, 'request')">ขอใช้บริการ</button>
            </div>
        </div>
    </div>
    <!-- <div class="top10">
        <p>name</p>
        <p>type member | Point</p>
    </div> -->


    <div id="container" style="padding-bottom: 40px;">

        <div id="service" class="tabcontent text-center">
            <div class="top20 text-color"><b>บริการของเรา (Our Services) </b></div>
            <?php foreach ($serviceContents as  $contentRow) { ?>
                <div class="promo-img">
                <?php if($contentRow->service_show_img && $contentRow->service_img){ ?>
                    <img src="<?php echo PATHIMGCAMPAIGN.$contentRow->service_img.'?v='.date('his'); ?>" alt=" " class="responsive size-img">
                <?php } ?>
                </div>
                <div class="container promo-detail">
                    <p class="textBold"><?php echo $contentRow->service_title; ?></p>
                    <p><?php echo $contentRow->service_details; ?> </p>
                </div>
            <?php } ?>

            <!-- <div class="promo-img">
                    <img src="<?php echo $uri; ?>assets/images/information.jpg?v= <?php echo date('his') ?>" alt=" " class="responsive size-img">
            </div>
            <div class="container promo-detail">
                <p class="textBold">ข้อมูลและความสัมพันธ์กับลูกค้า</p>
                <p>เคาน์เตอร์ลูกค้าสัมพันธ์บนชั้น G ที่โซน ZPELL</p>
            </div> -->
        </div>

        <div id="request" class="tabcontent">
            <div class="top20 text-color"><b>ขอใช้บริการ (Service Request)</b></div>
            <form name="formUpdate" id="formUpdate" novalidate enctype="multipart/form-data" onsubmit="return chkForm()" method="post" action="<?php echo $uri; ?>profile/profile_edit" pId="<?php echo $person_id; ?>"  caseType = "" e = "<?php echo $email; ?>">
                <div class="top10">
                    <div class="star-require">ชื่อ (First Name)</div>
                    <input class="form-control form-control-sm boxInput" type="text" id="f_name" name="f_name" placeholder="" value = "<?php echo $firstname; ?>">
                </div>
                <div class="top10">
                    <div class="star-require">นามสกุล (Last Name)</div>
                    <input class="form-control form-control-sm boxInput" type="text" id="l_name" name="l_name" placeholder="" value = "<?php echo $lastname; ?>">
                </div>
                <div class="top10">
                    <div class="star-require">เบอร์มือถือ (Tel.)</div>
                    <input class="form-control form-control-sm boxInput" type="text" name="phone" id="phone" placeholder="" value = "<?php echo $mobileNo; ?>">
                </div>
                <div class="top10">
                    <div class="star-require">เลขบัตรประชาชน (ID Card No.) / <br>เลขหนังสือเดือนทาง (Passport No.)</div>
                    <input class="form-control form-control-sm boxInput" type="text" name="idCard" id="idCard" placeholder="" value = "<?php echo $idCardNo; ?>">
                </div>

                <div class="top20">
                    <div>เลือกบริการที่ต้องการ</div>
                    <div class="row text-center">
                          <div class="col-3">
                            <div id="wheelchair" class="responsive top10 center icon-size wheelchair" onclick="selectItem('wheelchair')"></div>
                            <p id="text-iconSer" class="top10">รถเข็นคน (Wheelchair)</p>
                          </div>
                          <div class="col-3 icon-ser" id="kidscart">
                            <div id="kidscart" class="responsive top10 center icon-size kidscart" onclick="selectItem('kid')"></div>
                            <p id="text-iconSer" class="top10">รถเข็นเด็ก <br> (Kids cart)</p>
                          </div>
                          <div class="col-3 icon-ser" id="shopcart">
                            <div id="shopcart" class="responsive top10 center icon-size shopcart" onclick="selectItem('shop')"></div>
                            <p id="text-iconSer" class="top10">รถเข็นช้อปปิ้ง (Shopping cart)</p>
                          </div>
                          <div class="col-3 icon-ser" id="supportcart">
                            <div id="supportcart" class="responsive top10 center icon-size supportcart" onclick="selectItem('support')"></div>
                            <p id="text-iconSer" class="top10">รถเข็นช่วยพยุง (Support cart)</p>
                          </div>
                    </div>
                </div>

                <div class="row top10">
                    <div class="col-6" style="padding-right: 0px;">
                        <br>
                        <input class="form-control form-control-sm boxInput" type="text" name="sl_case" id="sl_case" value= "" placeholder="กรุณาเลือกไอคอนบริการ" readonly>
                    </div>
                    <div class="col-6">
                        <lable class="star-require">จำนวน (Amount)</lable>
                        <select id="amount" name="amount" class="form-control form-control-sm boxInput" required>
                            <!-- <option value="">...เลือก...</option> -->
                            <option selected value="1">1</option>
                            <!-- <option value="2">2</option>
                            <option value="3">3</option> -->
                        </select>
                    </div>
                </div>
                <div class="top10">
                    <div class="star-require">จุดรับของ (Pick up point)</div>
                    <select id="sl_pickup" name="sl_pickup" class="form-control form-control-sm boxInput" required>
                        <?php echo $sl_pickuppoint; ?>
                    </select>
                </div>
                <div class="top10">
                    <div>เพิ่มเติม (Note)</div>
                    <textarea id="inputDetail" name="inputDetail" rows="4" cols="50" placeholder="หมายเหตุเพิ่มเติมระบุ..."></textarea>
                </div>
                <div class="text-placeholder"> * กรุณานำบัตรประชาชนไปยังจุดรับที่ระบุ ภายใน 30 นาที</div>

                <div class="form-group top50">
                    <div class="row justify-content-center">
                        <a class="btn btn-submit btn-sendCase col-8" href="javascript:void(0)">ยืนยัน (Submit)</a>
                    </div>
                </div>
            </form>
        </div>
    </div>

</div>

<script>
    $(document).ready(function() {
        document.getElementById("defaultOpen").click();
    });
    function openCity(evt, cityName) {
        if(evt){
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(cityName).style.display = "block";
        evt.currentTarget.className += " active";
        }
    }

    // $(document).on('click', '.wheelchair', function() {
    //     // $('#wheelchair img').attr('src', '<?php echo $uri ."assets/images/icons/wheelchair-green.png?v=".date('his')?>');
    //     $('.wheelchair').addClass('wc_active');
    //     $('.kidscart').removeClass('kc_active');
    //     $('.shopcart').removeClass('sc_active');
    //     $('.supportcart').removeClass('spc_active');
        
    // });

    function selectItem(text){
        $('.wheelchair').removeClass('wc_active');
        $('.kidscart').removeClass('kc_active');
        $('.shopcart').removeClass('sc_active');
        $('.supportcart').removeClass('spc_active');

        if(text == 'kid'){
            $('.kidscart').addClass('kc_active');
            $('#sl_case').val('รถเข็นเด็ก (Kids cart)');
            $("#formUpdate").attr("caseType","CC050601")
        }else if(text == 'shop'){
            $('.shopcart').addClass('sc_active');
            $('#sl_case').val('รถเข็นช้อปปิ้ง (Shopping cart)');
            $("#formUpdate").attr("caseType","CC050604")
        }else if(text == 'support'){
            $('.supportcart').addClass('spc_active');
            $('#sl_case').val('รถเข็นช่วยพยุง (Support cart)');
            $("#formUpdate").attr("caseType","CC050606")
        }else{
            $('.wheelchair').addClass('wc_active');
            $('#sl_case').val('รถเข็นคน (Wheelchair)');
            $("#formUpdate").attr("caseType","CC050602")
        }
    }

    $(document).on("click",".modal-close",function() {
        // $("#alertModal").modal('hide');
        window.location.replace("Service");
    });

    $(document).on("click","#alertModal",function() {
        // $("#alertModal").modal('hide');
        window.location.replace("Service");
    });

    $(document).on("click",".btn-sendCase",function() {
        checkValidate();
    });

    function checkValidate(){
        var pId = $("#formUpdate").attr("pId");   
        var caseType = $("#formUpdate").attr("caseType");
        var email = $("#formUpdate").attr("e")
        var f_name = $("#f_name").val();
        var l_name = $("#l_name").val();
        var phone = $("#phone").val();
        var idCard = $("#idCard").val();
        var amount = $("#amount").val();
        var pickup = $("#sl_pickup").val();
        var inputDetail = $("#inputDetail").val();

        var sl_case = $("#sl_case").val();

        console.log('pickup>>> ',pickup);

        if(isEmpty(f_name) || isEmpty(l_name) || isEmpty(phone) || isEmpty(idCard) || isEmpty(sl_case) || isEmpty(amount) || isEmpty(pickup)){
            if(isEmpty(f_name)){
                $("#f_name").addClass("required");  
            }

            if(isEmpty(l_name)){
                $("#l_name").addClass("required");
            }

            if(isEmpty(phone)){
                $("#phone").addClass("required");
            }

            if(isEmpty(idCard)){
                $("#idCard").addClass("required");
            }

            if(isEmpty(sl_case)){
                $("#sl_case").addClass("required");
            }

            if(isEmpty(amount)){
                $("#amount").addClass("required");
            }

            if(isEmpty(pickup)){
                $("#sl_pickup").addClass("required");
            }

            goToByScroll('formUpdate');  
            return false;
        }else{
            $("#f_name").removeClass("required");  
            $("#l_name").removeClass("required");
            $("#phone").removeClass("required");
            $("#idCard").removeClass("required");
            $("#sl_case").removeClass("required");
            $("#amount").removeClass("required");
            $("#sl_pickup").removeClass("required");

        }

        updateData();
		loading('show');
	}

    function updateData(){
        var pId = $("#formUpdate").attr("pId");   
        var caseType = $("#formUpdate").attr("caseType");
        var email = $("#formUpdate").attr("e")
        var f_name = $("#f_name").val();
        var l_name = $("#l_name").val();
        var phone = $("#phone").val();
        var idCard = $("#idCard").val();
        var amount = $("#amount").val();
        var pickup = $("#sl_pickup").val();
        var inputDetail = $("#inputDetail").val();

        var param = {pId: pId, caseType: caseType, f_name:f_name ,l_name:l_name, phone:phone, idCard:idCard, amount:amount, pickup:pickup, inputDetail:inputDetail, email:email}; 

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo base_url(); ?>Service/updateCase',
            data: param,
            success: function (e) {
                loading('hide');
                if (e.status.STATUS == 'successfully') {
                    console.log('Successfully');
                        // window.location.replace("privilege/userEvent?r=Line&pvId=" + e.status.PVID + "&pId=" + e.status.PID + "&date=" + e.status.DATE+ "&tid=" + e.status.TID + "&itype=" + e.status.ITYPE);
                    $(".modal-title").empty().append('แจ้งเตือน');
                    $("#alertModal .modal-body").empty().append('<div class="text-center"> การขอใช้บริการสำเร็จแล้ว <br>กรุณานำบัตรประชาชนไปยังจุดรับที่ระบุ ภายใน 30 นาที </div>');
                    $("#alertModal").modal('show');
                }else{
                    $(".modal-title").empty().append('แจ้งเตือน');
                    $("#alertModal .modal-body").empty().append('<div class="text-center"> การขอใช้บริการไม่สำเร็จ กรุณาทำรายการใหม่อีกครั้ง </div>');
                    $("#alertModal").modal('show');
                }
            }
        })
    }

    function loading(action)
	{
		if(action == "show")
		{
			var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg')?>'><div class='overlay'></div></div>";
			$("body").append(loading_component);
		}
		else if(action == "hide")
		{
			$("body .loading-component").remove();
		}
	}

</script>