
<style>
    .modal-dialog{
        margin-top: 70%;
    }
</style>
<div class="container boxPage">
    <!-- <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?>promotion/event/<?php echo $actId;?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title"><?php echo $actName;?></p>
        </div>
    </div> -->

    <p class="text-title"><?php echo $actName;?></p>
    <div class="top30">
        <?php   
                if($result){
                    echo $result;
                }
        ?>

    </div>
    <div class='text-error'>
        <lable>หากคุณปิดหน้าจอ จะไม่สามารถกลับมาหน้านี้ได้อีก</lable>
    </div>
    <div class="countdown-box">
        <div class="icon-clock" id="time"></div>
    </div>
</div>

<script>
    
    $( document ).ready(function() {
        countdown(5, 60, "start");
    });

    $(document).on("click",".close",function() {
        // window.location.href = getOriginUrl + cutPath + '?aId=' + data.status.AID;
        // window.location.href = "<?php echo base_url();?>";	
        // window.location.replace("login/thankpage?c=" + getParam);
        window.location.replace("promotion");
    });

    var rewardintervalid;

    function countdown(minutes, seconds, status) {
        var sec=seconds;
        var mins=minutes;

        if(mins == 0 && sec == 0)
        {
            endtime();
        }
        else
        {
            counttime();
        }

        if(status=="start")
        {
            mins--;
        }
        
        clearInterval(rewardintervalid);

        rewardintervalid = setInterval(function() {
            tick();
        }, 1000);

        function tick()
        {
            if(sec > 0)
            {
                sec--;
            }

            if(mins==0 && sec==0)
            {
                clearInterval(rewardintervalid);

                endtime();
            }
            else
            {
                counttime();
            }

            if(sec==0)
            {
                mins--;
                sec=60;
            }
        }

        function counttime()
        {
            var c = "00:" + String("0" + mins).slice(-2) + ":" + (sec=="60" ? "00": String("0" + sec).slice(-2));

            $('#time').empty().append(c);
        }

        function endtime()
        {
            $('#time').removeClass('icon-clock');
            $('img').addClass('disabled');
            // $('#time').empty().append("<div class='text-clock'><span>โค้ดนี้หมดอายุแล้วไม่สามารถใช้งานได้</span></div>");
            $(".countdown-box").addClass('d-none');
            $(".text-error").addClass('d-none');
            // $("#alertModal .modal-body").empty().append('<div class="text-clock"><span>โค้ดนี้หมดอายุแล้วไม่สามารถใช้งานได้</span></div>');
            $("#myModal .modal-body").empty().append('<div class="text-clock">โค้ดนี้หมดอายุแล้วไม่สามารถใช้งานได้</div>');
            $("#myModal").modal('show');

        
        }
    }
</script>