<link rel="stylesheet" href="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.css'); ?>">
<style>
    .modal-dialog {
        margin-top: 70%;
    }
</style>
<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?php echo $uri; ?><?php echo $linkBack; ?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title"> สิทธิพิเศษ (Privilege)</p>
        </div>
    </div>
    <div class="top30">

    </div>

    <div class="row my-3">
        <div class="col-12">
            <div class="card border-0">
                <?php if ($privilegeData->mps_image) : ?>
                    <?php if (getimagesize(PATHIMGCAMPAIGN . $privilegeData->mps_image)) : ?>
                        <img src="<?= PATHIMGCAMPAIGN . $privilegeData->mps_image . '?v="' . date('his') . '"'; ?>" class="card-img-top" alt="image">
                    <?php else : ?>
                        <img src="<?= base_url('assets/images/default_image.jpg') . '?v="' . date('his') . '"'; ?>" class="card-img-top" alt="image">
                    <?php endif; ?>
                <?php else : ?>
                    <img src="<?= base_url('assets/images/default_image.jpg') . '?v="' . date('his') . '"'; ?>" class="card-img-top" alt="image">
                <?php endif; ?>
                <div class="modal-header">
                    <h2 class="card-title text-center"><?php echo $privilegeData->mps_name; ?></h2>
                </div>
                <?php if ($code) : ?>
                    <div class="card-body" style="background-color: #00c4b3;">
                        <div class="row">
                            <div class="col-12 text-center text-white" id="usedDate">ใช้เมื่อ : <?= $useTime; ?></div>
                            <div style="background-color: white;" class="col-12 text-center d-flex justify-content-center align-items-center hide-code-detail">
                                <?php if ($hideData == false) : ?>
                                    <strong id="textCode" class="p-5 my-0 h1 hide-code-detail"><?= $code; ?></strong>
                                <?php endif; ?>
                            </div>
                            <div class="col-12 mt-3 text-center hide-code-detail">
                                <?php if ($hideData == false) : ?>
                                    <?php if ($qrcodeImage && $code) : ?>
                                        <?php if (getimagesize(PATHIMGCAMPAIGN . $qrcodeImage)) : ?>
                                            <img src="<?= PATHIMGCAMPAIGN . $qrcodeImage . '?v="' . date('his') . '"'; ?>" alt="..." style="width:80%" class="img-thumbnail">
                                        <?php else : ?>
                                            <img src="<?= base_url('assets/images/default_image.jpg') . '?v="' . date('his') . '"'; ?>" alt="..." class="img-thumbnail">
                                        <?php endif; ?>
                                    <?php else : ?>
                                        <?php if ($code) : ?>
                                            <img src="<?= base_url('assets/images/default_image.jpg') . '?v="' . date('his') . '"'; ?>" alt="..." class="img-thumbnail">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                            <?php if ($hideData == false) : ?>
                                <div class="col-12 mt-3 text-center text-white countdown "></div>
                            <?php endif; ?>
                            <div class="col-12 mt-3 text-center text-white" id="timeout"></div>
                            <?php if ($detail) : ?>
                                <div class="col-12 mt-3 text-center text-white hide-code-detail">
                                    <small><?= $detail; ?></small>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php else : ?>
                    <h3 class="text-center">ข้อมูลไม่ถูกต้อง</h3>
                <?php endif; ?>
                <div class="card-footer bg-transparent text-center">
                    <div class="row">
                        <div class="col-12">
                            <?php if ($showBtn && $code) : ?>
                                <a href="javascript:void(0)" id="btnSubmit" class="btn btn-primary" style="background-color: #00c4b3; border-color:  #00c4b3; min-width: 200px"><?= $message; ?></a>
                            <?php else : ?>
                                <span class="text-danger"><?= $message; ?></span>
                            <?php endif; ?>
                        </div>
                        <?php if ($showBtnStaff && $code) : ?>
                            <div class="col-12 mt-3">
                                <hr style="border-top: 1px dashed black; margin-bottom: 0px;">
                                <h4>สำหรับเจ้าหน้าที่</h4>
                                <a href="javascript:void(0)" id="btnSubmitStaff" class="btn btn-info" data-toggle="modal" data-target="#modalStaff" style="min-width: 200px"><?= $showBtnStaffMessage; ?></a>
                                <!-- Modal -->
                                <div class="modal fade" id="modalStaff" tabindex="-1" aria-labelledby="modalStaffLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="modalStaffLabel">สำหรับเจ้าหน้าที่</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="alert alert-primary" role="alert">
                                                    กรุณาตรวจสอบข้อมูลก่อนกดปุ่ม <strong>ยืนยัน</strong>
                                                </div>
                                                <div id="alertErrorStaff"></div>
                                                <form>
                                                    <div class="form-group">
                                                        <label for="staffCode">รหัสเจ้าหน้าที่ *</label>
                                                        <input type="text" class="form-control" maxlength="20" id="staffCode" require>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="remark">หมายเหตุ</label>
                                                        <textarea class="form-control" id="remark" rows="3"></textarea>
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-primary" style="background-color: #fff; border: 1px solid #27bdb2; border-radius: 4px; color: #27bdb2; cursor: pointer; outline: none; padding: 5px 20px;" data-dismiss="modal">ปิด</button>
                                                <button type="button" class="btn btn-primary" id="btnSubmitStaffSave" style="background-color: #00c4b3; border: 1px solid #27bdb2; border-radius: 4px; color: #ffffff; cursor: pointer; outline: none; padding: 5px 20px;">ยืนยัน</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if ($showBtnShop && $code) : ?>
                            <div class="col-12 mt-3">
                                <hr style="border-top: 1px dashed black; margin-bottom: 0px;">
                                <h4>สำหรับเจ้าหน้าที่</h4>
                                <a href="javascript:void(0)" id="btnSubmitShop" class="btn btn-info" data-toggle="modal" data-target="#modalShop" style="min-width: 200px"><?= $showBtnStaffMessage; ?></a>
                                <!-- Modal -->
                                <div class="modal fade" id="modalShop" tabindex="-1" aria-labelledby="modalShopLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="modalShopLabel">สำหรับเจ้าหน้าที่</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="alert alert-primary" role="alert">
                                                    กรุณาตรวจสอบข้อมูลก่อนกดปุ่ม <strong>ยืนยัน</strong>
                                                </div>
                                                <div id="alertErrorShop"></div>
                                                <form>
                                                    <div class="form-group">
                                                        <label for="shopCode">รหัสร้านค้า *</label>
                                                        <input type="text" class="form-control" id="shopCode" placeholder="Shop Code">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="balance">จำนวนเงิน (บาท)</label>
                                                        <input type="text" class="form-control" id="balance" placeholder="Amount">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="voucher">รหัส Voucher</label>
                                                        <input type="text" class="form-control" id="voucher" placeholder="Voucher code">
                                                    </div>
                                                </form>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-primary" id="btnSubmitShopClose" style="background-color: #fff; border: 1px solid #27bdb2; border-radius: 4px; color: #27bdb2; cursor: pointer; outline: none; padding: 5px 20px;" data-dismiss="modal">ปิด</button>
                                                <button type="button" class="btn btn-primary" id="btnSubmitShopSave" style="background-color: #00c4b3; border: 1px solid #27bdb2; border-radius: 4px; color: #ffffff; cursor: pointer; outline: none; padding: 5px 20px;">ยืนยัน</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <?php if (isset($reloadPage)) {
        echo $reloadPage;
    } ?>
    <?php if (isset($tiemout)) {
        echo $tiemout;
    } ?>

</div>

<script src="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.js'); ?>"></script>


<script src="<?php echo base_url('assets/js/moment-with-locales.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/moment-countdown.js'); ?>"></script>
<script>
    var showBtnClick = true;
    $(document).ready(function() {
        let refreshIntervalId = null;
        let codeExpired = "<?= $codeExpired; ?>";
        let usedDate = "<?= $useTime; ?>";
        let newDateMoment = moment(usedDate, 'DD/MM/YYYY HH:mm').locale('th').add(543, 'year').format('DD MMM YYYY HH:mm')
        $('#usedDate').text('ใช้เมื่อ : ' + newDateMoment);

        let countDown = new CustomFunction();
        countDown.countDownTime(codeExpired, '.countdown', '', '#timeout');

        // $('#modalStaff').on('hidden.bs.modal', function(e) {
        //     console.log('hidden modalStaff');
        // })
        $('#modalShop').on('hidden.bs.modal', function() {
            if (showBtnClick) {
                $('#btnSubmitShop').show();
            }
        })
    });

    // $(document).on("click", "", function() {
    //     window.location.replace("privilege");
    // });

    var rewardintervalid;

    $(document).on("click", "#btnSubmit", function() {
        $('#btnSubmit').attr('disabled', true);
        $('#btnSubmit').hide();
        var pvId = "<?= $pvId; ?>";
        var pId = "<?= $pId; ?>";
        var tierId = "<?= $tId; ?>";
        var status = "<?= $status; ?>";

        var param = {
            pvId: pvId,
            pId: pId,
            tierId: tierId,
            status: status,
        };

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo base_url(); ?>privilege/updateUse',
            data: param,
            success: function(respons) {
                if (respons.status == 'Successfully') {
                    $("#confirmModal").modal('hide');
                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        title: respons.message,
                        showConfirmButton: false,
                        timer: 1500
                    })
                    if (respons.type == "checkout") {
                        setTimeout(() => {
                            window.location = "privilege";
                        }, 2000);
                    }

                } else {
                    $('#btnSubmit').removeAttr('disabled');
                    $('#btnSubmit').show();
                    $(".modal-title").empty().append('แจ้งเตือน');
                    $("#alertModal .modal-body").empty().append('<div class="text-center"> ' + respons.message + ' </div>');
                    $("#confirmModal").modal('hide');
                    $("#alertModal").modal('show');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $('#btnSubmit').removeAttr('disabled');
                $('#btnSubmit').show();
                $(".modal-title").empty().append('แจ้งเตือน');
                $("#alertModal .modal-body").empty().append('<div class="text-center"> ข้อมูลไม่ถูกต้องกรุณาลองใหม่อีกครั้ง </div>');
                $("#alertModal").modal('show');
            },
        })
    });

    $(document).on("click", "#btnSubmitStaffSave", function() {
        loading('show');
        $('#btnSubmitStaffSave').attr('disabled', true);
        // $('#btnSubmitStaffSave').hide();
        var pvId = "<?= $pvId; ?>";
        var pId = "<?= $pId; ?>";
        var tierId = "<?= $tId; ?>";
        var status = "<?= $status; ?>";
        let code = "<?= $code; ?>";
        let staffCode = $('#staffCode').val();
        let remark = $('#remark').val();

        var param = {
            pvId: pvId,
            pId: pId,
            tierId: tierId,
            status: status,
            code: code,
            staffCode: staffCode,
            remark: remark,
        };

        let errorMsg = '';

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo base_url(); ?>privilege/updateStaff',
            data: param,
            success: function(respons) {
                if (respons.status == 'Successfully') {
                    $("#modalStaff").modal('hide');
                    showBtnClick = false;
                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        title: respons.message,
                        showConfirmButton: false,
                        timer: 1500
                    })
                    setTimeout(() => {
                        location.reload();
                    }, 2000);
                } else {
                    errorMsg = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    ${respons.message}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>`;
                    $('#btnSubmitStaffSave').removeAttr('disabled');
                    $('#btnSubmitShop').show();
                    $('#alertErrorStaff').html(errorMsg);
                    loading('hide');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                errorMsg = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
                                ${respons.message}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>`;
                $('#alertErrorStaff').html(errorMsg);
                $('#btnSubmitStaffSave').removeAttr('disabled');
                loading('hide');
            },
        })
    });

    $(document).on("click", "#btnSubmitShopSave", function() {
        loading('show');
        $('#btnSubmitShop').attr('disabled', true);
        $('#btnSubmitShop').hide();
        var pvId = "<?= $pvId; ?>";
        var pId = "<?= $pId; ?>";
        var tierId = "<?= $tId; ?>";
        var status = "<?= $status; ?>";
        let code = "<?= $code; ?>";
        let shopCode = $('#shopCode').val();
        let balance = $('#balance').val();
        let voucher = $('#voucher').val();

        var param = {
            pvId: pvId,
            pId: pId,
            tierId: tierId,
            status: status,
            code: code,
            shopCode: shopCode,
            balance: balance,
            voucher: voucher,
        };

        let errorMsg = '';

        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: '<?php echo base_url(); ?>privilege/updateShopCode',
            data: param,
            success: function(respons) {
                if (respons.status == 'Successfully') {
                    showBtnClick = false;
                    loading('hide');
                    $("#modalShop").modal('hide');
                    Swal.fire({
                        position: 'center',
                        icon: 'success',
                        title: respons.message,
                        showConfirmButton: false,
                        timer: 1500
                    })
                    setTimeout(() => {
                        window.location = "privilege";
                    }, 2000);
                } else {
                    errorMsg = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    ${respons.message}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>`;
                    $('#btnSubmitShop').removeAttr('disabled');
                    $('#alertErrorShop').html(errorMsg);
                    loading('hide');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                errorMsg = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
                                ${respons.message}
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>`;
                $('#alertErrorShop').html(errorMsg);
                $('#btnSubmitShop').removeAttr('disabled');
                $('#btnSubmitShop').show();
                loading('hide');
            },
        })
    });

    function loading(action) {
        if (action == "show") {
            var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg') ?>'><div class='overlay'></div></div>";
            $("body").append(loading_component);
        } else if (action == "hide") {
            $("body .loading-component").remove();
        }
    }
</script>