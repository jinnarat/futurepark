<link rel="stylesheet" href="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.css'); ?>">
<style>
    .modal-dialog {
        margin: 0;
    }

    .landing-slider-frame-popup .landing-item-cover-short {
        bottom: 47px;
    }

    .landing-item-cover-img {
        object-fit: cover;
        display: block;
        height: 100%;
        width: 100%;
    }

    .modal-content {
        height: 100vh;
    }
    
    .iframe-container iframe {
        border: 0;
        height: 100%;
        left: 0;
        position: absolute;
        top: 0;
        width: 100%;
    }
</style>
<div class="container boxPage">
    <div class="row">
        <div class="col-1">
            <a href="<?= $uri . 'campaign'; ?>">
                <i class="fa fa-chevron-left"></i>
            </a>
        </div>
        <div class="col-10">
            <p class="text-title"> <?= $activityName; ?></p>
        </div>
    </div>
    <div class="row my-3">
        <div class="col-12">
            <div class="card border-0">
                <?php if ($imgBanner) : ?>
                    <?php if (getimagesize(PATHIMGCAMPAIGN . $imgBanner)) : ?>
                        <img src="<?= PATHIMGCAMPAIGN . $imgBanner . '?v="' . date('his') . '"'; ?>" class="card-img-top" alt="image">
                    <?php else : ?>
                        <img src="<?= base_url('assets/images/default_image.jpg') . '?v="' . date('his') . '"'; ?>" class="card-img-top" alt="image">
                    <?php endif; ?>
                <?php else : ?>
                    <img src="<?= base_url('assets/images/default_image.jpg') . '?v="' . date('his') . '"'; ?>" class="card-img-top" alt="image">
                <?php endif; ?>
                <div class="card-body">
                    <h2 class="card-title"><?= $activityName; ?></h2>
                </div>
            </div>
            <div class="card border-0 my-3">
                <div class="card-body">
                    <?php if ($detail) : ?>
                        <small class="card-text">รายละเอียด</small>
                        <div class="card-text"><?= $detail; ?></div>
                    <?php endif; ?>
                    <div class="text-center">
                        <?php if ($activityType == 'Information' || $activityType == 'Redemption') : ?>
                            <?php if ($activityType == 'Redemption') : ?>
                                <?php if ($showBtn) : ?>
                                    <button class="btn btn-submit col-8" id="redemptionBtn"><?= $btn_name; ?></button>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php else : ?>
                            <?php if ($showBtn) : ?>
                                <button class="btn btn-submit col-8" id="promotionBtn"><?= $btn_name; ?></button>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo base_url('assets/sweetalert2/dist/sweetalert2.min.js'); ?>"></script>
<script>
    var mapLink = "<?= $mapLink; ?>";
    var nameActivity = "<?= $activityName; ?>";
    $(document).ready(function() {
        $('#promotionBtn').click(function(e) {
            e.preventDefault();
            let iframHtml = `<iframe class="ifram iframe-container iframe-model" src="${mapLink}" frameborder="0" style="width: 100%;"></iframe>`;
            $("#myModalTitle .modal-title").empty().html(nameActivity);
            $("#myModalTitle .modal-body").empty().append(`${iframHtml}`);
            $("#myModalTitle").modal('show');
        });

        $('#redemptionBtn').click(function(e) {
            e.preventDefault();
            $(".modal-title").empty().append('ยืนยัน');
            $("#confirmModal .modal-body").empty().append('<div class="text-center"><div>คุณยืนยันที่จะใช้สิทธิพิเศษ</div><div><b>' + nameActivity + '</b></div>');
            $("#confirmModal").modal('show');
        });

        $(document).on("click", ".submit", function() {
            loading('show');
            $("#confirmModal").modal('hide');
            let dataPost = {
                acid: "<?= $enAid; ?>"
            }
            $.ajax({
                type: "post",
                url: "<?= base_url('campaign/useRedemptionPoint'); ?>",
                data: dataPost,
                dataType: "json",
                success: function(response) {
                    if (response.status) {
                        // loading('hide');
                        // Swal.fire({
                        //     position: 'top',
                        //     icon: 'success',
                        //     title: 'Success',
                        //     text: response.message,
                        //     showConfirmButton: false,
                        //     timer: 2000
                        // });
                        window.location = "<?= base_url('campaign/detailCode'); ?>?ref=" + response.refID;
                    } else {
                        loading('hide');
                        Swal.fire({
                            position: 'center',
                            icon: 'info',
                            title: 'Oops...',
                            text: response.message,
                        })
                    }
                }
            });
        });
    });

    function loading(action) {
        if (action == "show") {
            var loading_component = "<div class='loading-component'><img src='<?php echo base_url('assets/images/loading/loading.svg') ?>'><div class='overlay'></div></div>";
            $("body").append(loading_component);
        } else if (action == "hide") {
            $("body .loading-component").remove();
        }
    }
</script>