
<div class="container top30">
    <div>
        <a href="<?php echo $uri; ?>history">
            <i class="fa fa-chevron-left"></i>
        </a>
    </div>
    <div class="top20">
        <p><b>title</b></p>
        <p>The LAROM standard launch pod containers hold 13 LAR Mk IV rockets or 20 GRAD rockets, with two pods on a launcher.
The LAROM can operate with the standard 122 mm rockets, as well as with the more advanced 160 mm rocket, with a strike range between 20 and 45 km. The GRAD 122 mm rocket is utilised to suppress and annihilate concentrated targets. It has an 18 kg high-explosive warhead, a range of approximately 20 km and can be fired in salvos of up to 2 rounds per second.</p>
        <div>
            <img src="<?php echo $uri . "assets/images/pic_test.jpg?v=".date('his')."" ?>" alt=" "  width="100%" class="responsive">
        </div>
    </div>
</div>