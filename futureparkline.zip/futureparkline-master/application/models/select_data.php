<?php

class Select_data extends CI_Model{
	
    function __construct(){
        parent::__construct();
    }	
	
	function select_data($field=null,$table=null,$cond=null,$orderby=null,$sortby='asc'){
	
		$sql = "SELECT $field FROM $table WHERE 1 ";
		// $sql = "SELECT $field FROM $table WHERE ";
		
		if($cond != null || $cond != ''){
			$sql .= $cond;
		}
		
		if($orderby != null || $orderby != ''){
			$sql.= " ORDER BY $orderby $sortby ";
		}
	
		return $rs=$this->db->query($sql);		
	}
}
?>