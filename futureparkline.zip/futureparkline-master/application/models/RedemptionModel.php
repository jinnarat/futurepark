<?php
class RedemptionModel extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    public function getActivityRedemptionBurnPoint()
    {
        $this->db->from("activity");
        $this->db->join("activity_redemption_mechanic", "activity.activityId = activity_redemption_mechanic.act_id AND activity_redemption_mechanic.mec_status = 'A'");
        $this->db->join("master_mechanic", "activity_redemption_mechanic.mmc_id = master_mechanic.mmc_id AND activity_redemption_mechanic.mec_status = 'A' AND master_mechanic.mmc_status = 'A' AND master_mechanic.rwt_id = 5");
        $this->db->where("activity.activityStatus", "A");
        $this->db->where("activity.activityType", "Redemption");
        $this->db->where("activity.approveStatus", "A");
        $this->db->where("activity.is_lineonly", "Y");
        $this->db->where("activity.startDisplay <= GETDATE( )");
        $this->db->where("activity.endDisplay >= GETDATE( )");
        $this->db->order_by("activity.activityId", 'DESC');
        $query = $this->db->get();
        return $query->result();
    }
    
    public function getActivityRedemptionBurnPointByActitivityID($activityId)
    {
        $this->db->select('
        activity.activityId as activityId,
        activity.activityType as activityType,
        activity.activityName as activityName,
        activity.urlfriendly as urlfriendly,
        activity.imgBanner as imgBanner,
        activity.detail as detail,
        activity.btn_name as btn_name,
        activity_redemption_mechanic.mec_id as mec_id,
        ');
        $this->db->from("activity");
        $this->db->join("activity_redemption_mechanic", "activity.activityId = activity_redemption_mechanic.act_id AND activity_redemption_mechanic.mec_status = 'A'");
        $this->db->join("master_mechanic", "activity_redemption_mechanic.mmc_id = master_mechanic.mmc_id AND activity_redemption_mechanic.mec_status = 'A' AND master_mechanic.mmc_status = 'A' AND master_mechanic.rwt_id = 5");
        $this->db->where("activity.activityStatus", "A");
        $this->db->where("activity.activityType", "Redemption");
        $this->db->where("activity.approveStatus", "A");
        $this->db->where("activity.is_lineonly", "Y");
        $this->db->where("activity.activityId", $activityId);
        $this->db->where("activity.startDisplay <= GETDATE( )");
        $this->db->where("activity.endDisplay >= GETDATE( )");
        $this->db->order_by("activity.activityId", 'DESC');
        $query = $this->db->get();
        return $query->row();
    }

    public function getItemRedemption($mec_id)
    {
        $this->db->where('mec_id', $mec_id);
        $this->db->where('mitm_status', $this->config->item('status_active'));
        $query = $this->db->get('activity_redemption_mechanic_item');
        return $query->row();
    }
    public function getConditionItemRedemption($mec_id)
    {
        $this->db->select('
        item.mec_id as mec_id,
        item.mitm_id as mitm_id,
        item.mec_id as mcnd_id,
        item.item_quantity as item_quantity,
        item.item_id as item_id,
        condition.mcnd_redeem_point as mcnd_redeem_point,
        condition.mcnd_id as mcnd_id,
        ');
        $this->db->from("activity_redemption_mechanic_item item");
        $this->db->join("activity_redemption_mechanic_item_condition condition", "item.mitm_id = condition.mitm_id AND condition.mcnd_status = 'A' AND condition.mcnd_redeem_method = '001'");
        $this->db->where("item.mec_id", $mec_id);
        $this->db->where("item.mitm_status", $this->config->item('status_active'));
        $query = $this->db->get();
        return $query->row();
    }

    public function insertRedemptionPoint($data)
    {
        // $this->db->set('rtp_id', $data['aa']);
        $this->db->set('ti_id', $data['ti_id']);
        $this->db->set('pers_id', $data['person_id']);
        $this->db->set('mec_id', $data['mec_id']);
        $this->db->set('mitm_id', $data['mitm_id']);
        $this->db->set('mcnd_id', $data['mcnd_id']);
        $this->db->set('item_id', $data['item_id']);
        $this->db->set('pntt_code', $data['textCode']);
        $this->db->set('pntt_code_expire', $data['expireCode']);
        // $this->db->set('pntt_spending', $data['aa']);
        $this->db->set('pntt_redeem_point', $data['redeem_point']);
        $this->db->set('pntt_item_quantity', $data['item_quantity']);
        $this->db->set('pntt_redeem_datetime', $data['datetime_now']);
        // $this->db->set('pntt_admin_redeem_datetime', $data['aa']);
        // $this->db->set('pntt_admin_redeem_by', $data['aa']);
        $this->db->set('pntt_qr_image', $data['qrcode']);
        // $this->db->set('pntt_remark', $data['aa']);
        $this->db->set('pntt_status', $data['status']);
        $this->db->set('pntt_createdatetime', $data['datetime_now']);
        $this->db->set('pntt_createby', $data['person_id']);
        $this->db->set('pntt_updatedatetime', $data['datetime_now']);
        $this->db->set('pntt_updateby', $data['person_id']);
        $this->db->insert('redemption_point_transaction');
        return $this->db->insert_id();
    }

    public function checkDuplicateCode($code)
	{
		$this->db->where('pntt_code', $code);
		$query = $this->db->get('redemption_point_transaction');
		return $query->row();
	}
    
    public function getPointTransactionByID($pntt_id , $person_id)
	{
		$this->db->where('pntt_id', $pntt_id);
		$this->db->where('pers_id', $person_id);
		$this->db->where('pntt_status', $this->config->item('status_active'));
		$query = $this->db->get('redemption_point_transaction');
		return $query->row();
	}

    public function getActivityByMachanicID($mec_id)
    {
        $this->db->select('
        activity.activityName as activityName,
        activity.imgBanner as imgBanner,
        ');
        $this->db->from("activity_redemption_mechanic mechanic");
        $this->db->join("activity activity", "mechanic.act_id = activity.activityId AND activity.activityStatus = 'A'");
        $this->db->where("mechanic.mec_id", $mec_id);
        $this->db->where("mechanic.mec_status", $this->config->item('status_active'));
        $query = $this->db->get();
        return $query->row();
    }

    public function getActivityByMachanicID_NO_Status($mec_id)
    {
        $this->db->select('
        activity.activityName as activityName,
        activity.imgBanner as imgBanner,
        ');
        $this->db->from("activity_redemption_mechanic mechanic");
        $this->db->join("activity activity", "mechanic.act_id = activity.activityId");
        $this->db->where("mechanic.mec_id", $mec_id);
        $query = $this->db->get();
        return $query->row();
    }

    public function getRedemptionPointTransactionByID($pntt_id)
    {
        $this->db->where('pntt_id',$pntt_id);
        $this->db->where('pntt_status', $this->config->item('status_active'));
        $query = $this->db->get('redemption_point_transaction');
        return $query->row();
    }

    public function getMasterItemRedemptionPoint($item_id)
    {
        $this->db->where('item_id',$item_id);
        $this->db->where('item_status', $this->config->item('status_active'));
        $query = $this->db->get('master_item');
        return $query->row();
    }
}
