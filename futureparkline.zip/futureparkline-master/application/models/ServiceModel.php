<?php
class ServiceModel extends CI_Model 
{
    function __construct()
    {
        parent::__construct();
	}

	public function getServiceContents()
	{
		$this->db->where('service_status', $this->config->item('status_active'));
		$query = $this->db->get('service_content_line');
		return $query->result();
	}
	
	


}