<?php
class ActivityModel extends CI_Model 
{
    function __construct()
    {
        parent::__construct();
	}
	
	public function getActivityLists($camp_id=null,$id=null,$url=null,$status=null,$startdate=null,$enddate=null){
		
		$condition_field = '';
		$condition_value = array();
		$condition_value[] = "D";
		
		if($camp_id != "" || $camp_id != null)
		{
			$condition_field .= ' AND campId = ?';
			$condition_value[] = $camp_id;
		}
		
		if($id != "" || $id != null)
		{
			$condition_field .= ' AND activityId = ?';
			$condition_value[] = $id;
		}
		
		if($url != "" || $url != null)
		{
			$condition_field .= ' AND urlfriendly = ?';
			$condition_value[] = $url;
		}
		
		if($status != "" || $status != null)
		{
			$condition_field .= ' AND activityStatus = ?';
			$condition_value[] = $status;
		}
		
		if($startdate != "" || $startdate != null)
		{
			$condition_field .= ' AND startDisplay <= ?';
			$condition_value[] = $startdate;
		}
		
		if($enddate != "" || $enddate != null)
		{
			$condition_field .= ' AND endDisplay >= ?';
			$condition_value[] = $enddate;
		}
				
		$sql = $this->MainModel->getDataBind("SELECT campId, campCode, activityId, activityCode, activityType, activityName, urlfriendly, limit, 
												tmpDataSet, imgBanner, detail, startDisplay, endDisplay, createby, createtime, lastupdateby, lastupdatetime, unique_register, consent_show, consent_detail, thankyou
											 FROM activity WITH (NOLOCK) "
											,"WHERE activityStatus != ? ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = NULL);
		return $sql;
	}
	
	public function getActivityForm($camp_id=null ,$activity_id=null, $show=null, $ORDERBY=null)
	{		
		$condition_field = '';
		$condition_value = array();
		
		if($camp_id != "" || $camp_id != null)
		{
			$condition_field .= ' AND campId = ?';
			$condition_value[] = $camp_id;
		}
		if($activity_id != "" || $activity_id != null)
		{
			$condition_field .= ' AND activityId = ?';
			$condition_value[] = $activity_id;
		}
		if($show != "" || $show != null)
		{
			$condition_field .= ' AND is_show = ?';
			$condition_value[] = $show;
		}
		
		if($ORDERBY == "" || $ORDERBY == null){ $ORDERBY = "sort";}		
		
		$sql = $this->MainModel->getDataBind("SELECT formId, campId, activityId, quesNo, elementType, elementLabel, choiceLabel, choiceValue,
												is_show, required, fieldType, sort, mappingtable, mappingfield, objType, objValue, createby, colWidth, maxlength, createtime, lastupdateby, lastupdatetime
											 FROM activity_form WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,"ORDER BY ".$ORDERBY);
		return $sql;
	}
	
	public function getActivityData($camp_id=null ,$activity_id=null, $personId=null, $privId=null, $privCode=null, $GROUPBY=null, $ORDERBY= null, $mobile=null, $startdate=null, $enddate=null)
	{		
		$condition_field = '';
		$condition_value = array();
		
		if($camp_id != "" || $camp_id != null)
		{
			$condition_field .= ' AND campId = ?';
			$condition_value[] = $camp_id;
		}
		if($activity_id != "" || $activity_id != null)
		{
			$condition_field .= ' AND activityId = ?';
			$condition_value[] = $activity_id;
		}
		if($personId != "" || $personId != null)
		{
			$condition_field .= ' AND personId = ?';
			$condition_value[] = $personId;
		}
		if($privId != "" || $privId != null)
		{
			$condition_field .= ' AND privId = ?';
			$condition_value[] = $privId;
		}
		if($privCode != "" || $privCode != null)
		{
			$condition_field .= ' AND privCode = ?';
			$condition_value[] = $privCode;
		}
		
		if($mobile != "" || $mobile != null)
		{
			$condition_field .= ' AND question = ? AND answer = ? ';
			$condition_value[] = 'mobileNo';
			$condition_value[] = $mobile;
		}
		
		if($startdate != "" || $startdate != null)
		{
			$condition_field .= ' AND lastupdatetime >= ?';
			$condition_value[] = $startdate;
		}
		
		if($enddate != "" || $enddate != null)
		{
			$condition_field .= ' AND lastupdatetime <= ?';
			$condition_value[] = $enddate;
		}
		
		
		$FIELD	= " dataId, campId, activityId, formId, personId, privId, privCode, quesNo, question, answer, lastupdatetime ";
		if($ORDERBY == "" || $ORDERBY == null){ $ORDERBY = "formId";}		
		if($GROUPBY != "" || $GROUPBY != null){ 
			$FIELD		= $GROUPBY;
			$ORDERBY	= $FIELD;
			$GROUPBY	= " GROUP BY ".$GROUPBY;			
		}
		
		$sql = $this->MainModel->getDataBind("SELECT $FIELD FROM activity_data WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY
											," ORDER BY ".$ORDERBY);
		return $sql;
	}


}