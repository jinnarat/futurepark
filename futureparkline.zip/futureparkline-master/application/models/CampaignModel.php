<?php
class CampaignModel extends CI_Model 
{
    function __construct()
    {
        parent::__construct();
	}
	
	public function getCampaignLists($id=null,$status=null,$startdate=null,$enddate=null){
		
		$condition_field = '';
		$condition_value = array();
		$condition_value[] = "D";
		
		if($id != "" || $id != null)
		{
			$condition_field .= ' AND campId = ?';
			$condition_value[] = $id;
		}
		
		if($status != "" || $status != null)
		{
			$condition_field .= ' AND campStatus = ?';
			$condition_value[] = $status;
		}
		
		if($startdate != "" || $startdate != null)
		{
			$condition_field .= ' AND startDisplay <= ?';
			$condition_value[] = $startdate;
		}
		
		if($enddate != "" || $enddate != null)
		{
			$condition_field .= ' AND endDisplay >= ?';
			$condition_value[] = $enddate;
		}
		
		$sql = $this->MainModel->getDataBind("SELECT campId, cateId, campCode, campType, campName, imgBanner, detail, 
												startDisplay, endDisplay, campStatus, createby, createtime, lastupdateby, lastupdatetime
											 FROM campaign WITH (NOLOCK) "
											,"WHERE campStatus != ? ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = NULL);
		return $sql;
	}
}