<?php
class LogModel extends CI_Model
{
    function __construct(){
        parent::__construct();
		
    }
	
	public function CheckOTP($ref_id=null, $ref_code=null, $status=null, $mobilephone=null, $otp=null, $reference=null, $startdate=null, $enddate=null)
	{
		$condition_field = '';
		$condition_value = array();
		
		if($status != "" || $status != null)
		{
			$condition_field .= ' AND status = ?';
			$condition_value[] = $status;
		}
		
		if($mobilephone != "" || $mobilephone != null)
		{
			$condition_field .= ' AND mobileNo = ?';
			$condition_value[] = $mobilephone;
		}
		
		if($otp != "" || $otp != null)
		{
			$condition_field .= ' AND otp = ?';
			$condition_value[] = $otp;
		}
		
		if($reference != "" || $reference != null)
		{
			$condition_field .= ' AND reference = ?';
			$condition_value[] = $reference;
		}
		
		if($startdate != "" || $startdate != null)
		{
			$condition_field .= ' AND starttime <= ?';
			$condition_value[] = $startdate;
		}
		
		if($enddate != "" || $enddate != null)
		{
			$condition_field .= ' AND endtime >= ?';
			$condition_value[] = $enddate;
		}
		
		$sql = $this->MainModel->getDataBind("SELECT logId, refId, refCode, mobileNo, mobileFullNo, otp, reference, message, 
												reponse, description, status, usedby, usedtime, starttime, endtime
											 FROM log_sms WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = NULL);
		return $sql;		
	}
   
	public function UpdateLogSMS($ref_id=null, $ref_code=null, $mobilephone=null, $otp=null, $reference=null, $message=null, $response_code=null, $response_desc=null, $log_id=null){
		$ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
		
		try{
			$this->db->trans_start();				
			
			if($log_id != "" || $log_id != null)
			{
				if(strpos($response_desc,'successful') === false) { $textstatus = 'Error'; }else{ $textstatus = 'Send';}
					
				$dataUpdate = array(
					'reponse' 		=> $response_code,
					'description' 	=> $response_desc,
					'status' 		=> $textstatus,
				);
				
				$this->db->where(array('logId' => $log_id));
				$this->db->update('log_sms',$dataUpdate);	
				
				if(!$this->db->affected_rows()){
					$this->db->trans_rollback();
					$this->db->trans_complete();
					$ERR_STATUS = 400; throw new exception('err update data into database');
				}	
				$db_id	= $log_id;
			}else{
				$textstatus = 'Save';
				$mobile		= '0'.substr($mobilephone,2,strlen($mobilephone));
				$dataInsert = array(
					'refId' 		=> $ref_id,
					'refCode' 		=> $ref_code,
					'mobileNo' 		=> $mobile,
					'mobileFullNo' 	=> $mobilephone,					
					'otp' 			=> $otp,
					'reference' 	=> $reference,
					'message' 		=> $message,				
					'status' 		=> $textstatus,				
					'starttime' 	=> date("Y-m-d H:i:s"),
					'endtime' 		=> date('Y-m-d H:i:s', strtotime("+5 min"))
				);
				$this->db->insert('log_sms',$dataInsert);	
				
				if(!$this->db->affected_rows()){
					$this->db->trans_rollback();
					$this->db->trans_complete();
					$ERR_STATUS = 400; throw new exception('err write data into database');
				}	
				
				$db_id	= $this->db->insert_id();
			}					
		
			$this->db->trans_complete();		
			if ($this->db->trans_status() === FALSE) {
				$this->db->trans_rollback();				
			} 
			else {
				$this->db->trans_commit();
			} 
			
			$dataRes	= array('STATUS' => 'Successfully', 'ID' => $db_id, 'OTP' => $otp, 'REF' => $reference, 'STATUSSMS' => $textstatus);
			
			return json_encode($dataRes);            
			
		}catch(exception $e){
            if($ERR_STATUS == 400)
            {
                log_message('error', $e->getMessage());
            }
            $Err = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
			return json_encode($Err);            
        }
	}
}
?>