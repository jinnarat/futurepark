<?php
class SelectModel extends CI_Model 
{
    function __construct()
    {
        parent::__construct();
	}
	
	public function SelectNationality($id=null,$code=null,$status=null){
		
		$condition_field = '';
		$condition_value = array();
		
		if($id != "" || $id != null)
		{
			$condition_field .= ' AND nationId = ?';
			$condition_value[] = $id;
		}
		
		if($code != "" || $code != null)
		{
			$condition_field .= " AND nationCode = ? ";
			$condition_value[] = $code;
		}

		if($status != "" || $status != null)
		{
			$condition_field .= ' AND nationStatus = ?';
			$condition_value[] = $status;
		}
				
		$sql = $this->MainModel->getDataBind("SELECT nationId, nationCode, countryCode, nationNameThai, nationNameEng, countryNameThai, 
												countryNameEng, nationStatus, nationCode as displayCode, nationNameThai as displayNameLC
											 FROM master_nation WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = NULL);
		return $sql;
	}
	
	public function SelectProvince($id=null,$code=null,$status=null){
		
		$condition_field = '';
		$condition_value = array();
		
		if($id != "" || $id != null)
		{
			$condition_field .= ' AND provinceId = ?';
			$condition_value[] = $id;
		}
		
		if($code != "" || $code != null)
		{
			$condition_field .= " AND provinceCode = ? ";
			$condition_value[] = $code;
		}

		if($status != "" || $status != null)
		{
			$condition_field .= ' AND provinceStatus = ?';
			$condition_value[] = $status;
		}
				
		$sql = $this->MainModel->getDataBind("SELECT provinceId, regionId, provinceCode, provinceNameThai, provinceNameEng, provinceType, 
												provinceStatus, provinceCode as displayCode, provinceNameThai as displayNameLC
											 FROM master_province WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = " ORDER BY provinceNameThai");
		return $sql;
	}
	
	public function SelectDistrict($id=null,$code=null,$status=null,$province=null){
		
		$condition_field = '';
		$condition_value = array();
		
		if($id != "" || $id != null)
		{
			$condition_field .= ' AND districtId = ?';
			$condition_value[] = $id;
		}
		
		if($code != "" || $code != null)
		{
			$condition_field .= " AND districtCode = ? ";
			$condition_value[] = $code;
		}
		
		if($province != "" || $province != null)
		{
			$condition_field .= " AND provinceCode = ? ";
			$condition_value[] = $province;
		}

		if($status != "" || $status != null)
		{
			$condition_field .= ' AND districtStatus = ?';
			$condition_value[] = $status;
		}
				
		$sql = $this->MainModel->getDataBind("SELECT districtId, districtCode, districtNameThai, districtNameEng, districtNameThaiShort, 
												districtNameEngShort, districtStatus, provinceCode, 
												districtCode as displayCode, districtNameThai as displayNameLC
											 FROM master_district WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = " ORDER BY districtNameThai");
		return $sql;
	}
	
	public function SelectSubDistrict($id=null,$code=null,$status=null,$district=null,$province=null){
		
		$condition_field = '';
		$condition_value = array();
		
		if($id != "" || $id != null)
		{
			$condition_field .= ' AND subDistrictId = ?';
			$condition_value[] = $id;
		}
		
		if($code != "" || $code != null)
		{
			$condition_field .= " AND subDistrictCode = ? ";
			$condition_value[] = $code;
		}
		
		if($district != "" || $district != null)
		{
			$condition_field .= " AND districtCode = ? ";
			$condition_value[] = $district;
		}
		
		if($province != "" || $province != null)
		{
			$condition_field .= " AND provinceCode = ? ";
			$condition_value[] = $province;
		}

		if($status != "" || $status != null)
		{
			$condition_field .= ' AND subDistrictStatus = ?';
			$condition_value[] = $status;
		}
				
		$sql = $this->MainModel->getDataBind("SELECT  subDistrictId, subDistrictCode, subDistrictNameThai, subDistrictNameEng, 
												subDistrictNameThaiShort, subDistrictNameEngShort, postcode, subDistrictStatus, districtCode, provinceCode, subDistrictCode as displayCode, subDistrictNameThai as displayNameLC
											 FROM master_subdistrict WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = " ORDER BY subDistrictNameThai");
		return $sql;
	}
}