<?php
class PrivilegeModel extends CI_Model 
{
    function __construct()
    {
        parent::__construct();
	}
	
	public function getPrivilegeLists($camp_id=null,$activityId=null,$id=null,$code=null,$status=null){
		
		$condition_field = '';
		$condition_value = array();
		$condition_value[] = "A";
		
		if($camp_id != "" || $camp_id != null)
		{
			$condition_field .= ' AND campId = ?';
			$condition_value[] = $camp_id;
		}
		
		if($activityId != "" || $activityId != null)
		{
			$condition_field .= ' AND activityId = ?';
			$condition_value[] = $activityId;
		}
		
		if($id != "" || $id != null)
		{
			$condition_field .= ' AND privId = ?';
			$condition_value[] = $id;
		}	

		if($code != "" || $code != null)
		{
			$condition_field .= ' AND privCode = ?';
			$condition_value[] = $code;
		}
				
		$sql = $this->MainModel->getDataBind("SELECT privId, campId, activityId, privCode, limit, privStatus, 
												createby, createtime, lastupdateby, lastupdatetime
											 FROM activity_privilege WITH (NOLOCK) "
											,"WHERE privStatus = ? ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = NULL);
		return $sql;
	}


	// new privilege 
	public function SelectPrivilegeALL($ti_id)
	{
		$active = $this->config->item('status_active');
		$this->db->from('member_privilege_setting ps');
		$this->db->join("member_privilege_condition pc", "ps.mps_id = pc.mps_id AND pc.mpc_status = '".$active."'", "left");
		$this->db->where('ps.mps_status', $active);
		$this->db->where('ps.mps_show_on_line', $active);
		$this->db->where('ps.mps_start_display <=', date("Y-m-d H:i:s"));
		$this->db->where('ps.mps_end_display >=', date("Y-m-d H:i:s"));
		$this->db->where('pc.ti_id', $ti_id);
		$this->db->order_by('ps.mps_id', 'DESC');
		$query = $this->db->get();
		return $query;
	}
	public function getPersonByID($personId)
	{
		$this->db->where('personStatus !=', $this->config->item('status_delete'));
		// $this->db->where('personStatus', $this->config->item('status_active'));
		$this->db->where('personId', $personId);
		$this->db->where("(verify_email = 'Y' OR verify_phone = 'Y')");
		$query = $this->db->get('person');
		return $query->row();
	}

	public function updatePointPerson($data)
	{
		$this->db->set('person_point_balance', $data['poinBalance']);
		$this->db->set('person_point_spending', $data['poinSpending']);
		$this->db->set('lastupdatetime', $data['dateTimeNow']);
		$this->db->set('lastupdateby', $data['personId']);
		$this->db->where('personId', $data['personId']);
		$query = $this->db->update('person');
		return $query;
	}

	public function insertPersonHistory($data)
	{
		$this->db->set('pers_id', $data['personId']);
		$this->db->set('ref_type_id', $data['ref_type_id']);
		$this->db->set('ref_id', $data['ref_id']);
		$this->db->set('perh_createby', $data['personId']);
		$this->db->set('perh_createdatetime', $data['dateTimeNow']);
		$this->db->set('perh_status', $this->config->item('status_active'));
		$this->db->set('pers_status', $data['pers_status']);
		$this->db->insert('person_history');
		return $this->db->insert_id();
	}
	
	public function insertPersonPoint($data)
	{
		$this->db->set('ref_type_id', $data['ref_type_id']);
		$this->db->set('ref_id', $data['ref_id']);
		$this->db->set('historyId', $data['personHistoryID']);
		$this->db->set('ti_id', $data['tierId']);
		$this->db->set('pers_id', $data['personId']);
		$this->db->set('perp_type', $data['perp_type']);
		$this->db->set('perp_point', $data['perp_point']);
		$this->db->set('perp_status', $data['perp_status']);
		$this->db->set('perp_createdatetime', $data['dateTimeNow']);
		$this->db->set('perp_createby', $data['personId']);
		$this->db->set('perp_updatedatetime', $data['dateTimeNow']);
		$this->db->set('perp_updateby', $data['personId']);
		$this->db->insert('person_point');
		return $this->db->insert_id();
	}

	public function getProveCheckout($mps_id, $mpc_id, $mp_used_by, $dateTimeNow){
		$active = $this->config->item('status_active');
		$this->db->select('pc.mp_code, pc.mp_qr_image, pc.mp_used_datetime, pc.mp_code_expired, pc.mp_balance, pc.mp_shop_code, pc.mp_voucher, pc.mp_staff_code, pc.refChannel, pc.mp_remark');
		$this->db->from('member_privilege_code pc');
		$this->db->join("member_privilege_type pt", "pc.mpt_id = pt.mpt_id AND pt.mpt_status = '".$active."'");
		$this->db->join("member_privilege_condition cn", "pc.mpc_id = cn.mpc_id AND cn.mpc_status = '".$active."'");
		$this->db->where('pt.mpt_type', 'Check-inCheck-out');
		$this->db->where('pc.mp_status', $active);
		$this->db->where('pc.mp_used_by', $mp_used_by);
		$this->db->where('pc.mp_code_expired >=', $dateTimeNow);
		$this->db->where('pc.mp_used_check_out_datetime', NULL);
		$this->db->where('pc.mp_admin_check_out_datetime', NULL);
		$this->db->where('pc.mp_admin_check_out_by', NULL);
		$this->db->where('cn.mps_id', $mps_id);
		$this->db->where('pc.mpc_id', $mpc_id);
		$query = $this->db->get();
		return $query->last_row();
	}
	
	public function getProveCheckoutByID($mp_id, $mp_used_by, $dateTimeNow){
		$active = $this->config->item('status_active');
		$this->db->select('pc.mp_code, pc.mp_qr_image, pc.mp_used_datetime, pc.mp_code_expired');
		$this->db->from('member_privilege_code pc');
		$this->db->join("member_privilege_type pt", "pc.mpt_id = pt.mpt_id AND pt.mpt_status = '".$active."'");
		$this->db->join("member_privilege_condition cn", "pc.mpc_id = cn.mpc_id AND cn.mpc_status = '".$active."'");
		$this->db->where('pt.mpt_type', 'Check-inCheck-out');
		$this->db->where('pc.mp_status', $active);
		$this->db->where('pc.mp_used_by', $mp_used_by);
		$this->db->where('pc.mp_code_expired >=', $dateTimeNow);
		$this->db->where('pc.mp_used_check_out_datetime', NULL);
		$this->db->where('pc.mp_admin_check_out_datetime', NULL);
		$this->db->where('pc.mp_admin_check_out_by', NULL);
		$this->db->where('pc.mp_id', $mp_id);
		$query = $this->db->get();
		return $query->last_row();
	}
	
	public function getProveAdminUse($mps_id, $mp_used_by, $dateTimeNow){
		$active = $this->config->item('status_active');
		$this->db->select('pc.mp_code, pc.mp_qr_image, pc.mp_used_datetime, pc.mp_code_expired, pc.mp_shop_code, pc.mp_balance, pc.mp_voucher');
		$this->db->from('member_privilege_code pc');
		$this->db->join("member_privilege_type pt", "pc.mpt_id = pt.mpt_id AND pt.mpt_status = '".$active."'");
		$this->db->join("member_privilege_condition cn", "pc.mpc_id = cn.mpc_id AND cn.mpc_status = '".$active."'");
		$this->db->where('pc.mp_status', $active);
		$this->db->where('pc.mp_used_by', $mp_used_by);
		$this->db->where('pc.mp_code_expired >=', $dateTimeNow);
		$this->db->where('pc.mp_admin_check_in_datetime', NULL);
		$this->db->where('pc.mp_admin_check_in_by', NULL);
		$this->db->where('cn.mps_id', $mps_id);
		$query = $this->db->get();
		return $query->last_row();
	}

	public function updateCheckOut($data)
	{
		$this->db->set('mp_used_by', $data['personId']);
		$this->db->set('mp_updateby', $data['personId']);
		$this->db->set('mp_updatedatetime', $data['dateTimeNow']);
		$this->db->set('mp_used_check_out_datetime', $data['dateTimeNow']);
		$this->db->where('mp_code', $data['mp_code']);
		$this->db->where('mp_used_by', $data['personId']);
		$query = $this->db->update('member_privilege_code');
		return $query;
	}

	public function checkDuplicateCode($code)
	{
		$this->db->where('mp_code', $code);
		$query = $this->db->get('member_privilege_code');
		return $query->row();
	}
	
	public function getPrivilegeCodeByID($mp_id)
	{
		$this->db->where('mp_id', $mp_id);
		$query = $this->db->get('member_privilege_code');
		return $query->row();
	}
	
	public function getMasterSchedule($scd_name)
	{
		$this->db->where('scd_name', $scd_name);
		$this->db->where('scd_status', $this->config->item('status_active'));
		$query = $this->db->get('master_schedule');
		return $query->row();
	}
	
	public function insertPrivilegeCode($data)
	{
		$this->db->set('mp_code', $data['mp_code']);
		if($data['privilegeType'] != 'Platinum Lounge'){
			$this->db->set('mp_used_quantity', $data['mp_used_quantity']);
		}
		$this->db->set('mp_point_redeem', $data['mp_point_redeem']);
		$this->db->set('mp_used_by', $data['mp_used_by']);
		$this->db->set('mp_used_datetime', $data['now']);
		$this->db->set('mp_code_expired', $data['mp_code_expired']);
		$this->db->set('mp_used_type', $data['mp_used_type']);
		$this->db->set('mp_used_by_free', $data['mp_used_by_free']);
		$this->db->set('mp_used_follower', $data['mp_used_follower']);
		$this->db->set('mp_point_reddem_person', $data['mp_point_reddem_person']);
		$this->db->set('mp_point_redeem_follower', $data['mp_point_redeem_follower']);
		$this->db->set('mp_status', $data['mp_status']);
		$this->db->set('mp_createdatetime', $data['now']);
		$this->db->set('mp_used_datetime', $data['now']);
		$this->db->set('mp_createby', $data['mp_used_by']);
		$this->db->set('mp_updatedatetime', $data['now']);
		$this->db->set('mp_updateby', $data['mp_used_by']);
		if(isset($data['checkinTime'])){
			$this->db->set('mp_used_check_in_datetime', $data['checkinTime']);
		}
		$this->db->set('mp_qr_image', $data['mp_qr_image']);
		$this->db->set('mpc_id', $data['mpc_id']);
		$this->db->set('mpt_id', $data['mpt_id']);
		$this->db->set('ti_id', $data['ti_id']);
		$this->db->insert('member_privilege_code');
		return $this->db->insert_id();
	}
	
	public function getPrivilegeConditionSettingNoStatus($mpc_id = null){
		$this->db->from('member_privilege_condition pc');
		$this->db->join("member_privilege_setting ps", "pc.mps_id = ps.mps_id");
		$this->db->where('pc.mpc_id', $mpc_id);
		$query = $this->db->get();
		return $query->row();
	}
	
	public function getPrivilegeConditionSetting($mpc_id = null){
		$active = $this->config->item('status_active');
		// $this->db->select('ps.mps_id, ps.mps_name, ps.mps_image, ps.mps_detail, ps.mps_end_action_used, ps.mpt_id, pt.mpt_type ');
		$this->db->from('member_privilege_condition pc');
		$this->db->join("member_privilege_setting ps", "pc.mps_id = ps.mps_id AND ps.mps_status = '".$active."'");
		$this->db->where('pc.mpc_id', $mpc_id);
		$this->db->where('pc.mpc_status', $active);
		$query = $this->db->get();
		return $query->row();
	}
	
	public function getPrivilegeSettingType($pvrivId = null){
		$active = $this->config->item('status_active');
		// $this->db->select('ps.mps_id, ps.mps_name, ps.mps_image, ps.mps_detail, ps.mps_end_action_used, ps.mpt_id, pt.mpt_type ');
		$this->db->from('member_privilege_setting ps');
		$this->db->join("member_privilege_type pt", "ps.mpt_id = pt.mpt_id AND pt.mpt_status = '".$active."'", "left");
		$this->db->where('ps.mps_id', $pvrivId);
		// $this->db->where('ps.mps_status', $active);
		// $this->db->where('ps.mps_show_on_line', $active);
		$query = $this->db->get();
		return $query->row();
	}
	
	public function getPrivilegeType($mpt_id = null)
	{
		$this->db->where('mpt_id', $mpt_id);
		$this->db->where('mpt_status', $this->config->item('status_active'));
		$query = $this->db->get('member_privilege_type');
		return $query->row();
	}

	public function getPrivilegeList()
	{
		$this->db->where('mps_show_on_line', $this->config->item('status_active'));
		$this->db->where('mps_status', $this->config->item('status_active'));
		$query = $this->db->get('member_privilege_setting');
		return $query->result();
	}
	
	public function getPrivilegeListByID($mps_id, $checkStatus)
	{
		$active = $this->config->item('status_active');
		$this->db->from('member_privilege_setting ps');
		$this->db->join("member_privilege_type pt", "ps.mpt_id = pt.mpt_id AND pt.mpt_status = '".$active."'", "left");
		$this->db->where('ps.mps_id', $mps_id);
		if($checkStatus){
			$this->db->where('ps.mps_status', $active);
		}
		$this->db->where('ps.mps_show_on_line', $active);
		$query = $this->db->get();
		return $query->row();
	}

	public function getPrivilegeListCondition($mps_id, $ti_id, $checkStatus)
	{
		$this->db->where('mps_id', $mps_id);
		$this->db->where('ti_id', $ti_id);
		if ($checkStatus) {
			$this->db->where('mpc_status', $this->config->item('status_active'));
		}
		$query = $this->db->get('member_privilege_condition');
		return $query->row();
	}

	public function getMasterExpire($mpe_id)
	{
		$this->db->where('mpe_id', $mpe_id);
		$this->db->where('mpe_status', $this->config->item('status_active'));
		$query = $this->db->get('master_expire');
		return $query->row();
	}


	public function _get($parameter)
    {
        return $this->db->query('EXEC _Privilege @type = ?, @privilege_id = ?, @privilege_condition_id = ?', $parameter);
    }

    public function _check_privilege_code($parameter)
    {
        return $this->db->query('EXEC _Privilege @type = ?, @privilege_condition_id = ?, @privilege_code = ?, @condition_status = ?', $parameter);
    }

    public function _get_privilege_limit($parameter)
    {
        return $this->db->query('EXEC _Redemption_Point @type = ?, @privilege_condition_id = ?, @condition_status = ?', $parameter);
    }

    public function _get_member_privilege_limit($parameter)
    {
        return $this->db->query('EXEC _Privilege @type = ?, @person_id = ?, @privilege_condition_id = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @condition_status = ?', $parameter);
    }

    public function _insert_privilege_follower($parameter)
    {
        return $this->db->query('EXEC _Redemption_Point @type = ?, @privilege_code_id = ?, @person_id = ?, @point_status = ?, @point_createdatetime = ?, @point_createby = ?, @point_updatedatetime = ?, @point_updateby = ?', $parameter);
    }

	public function checkCodePrivilege($code, $personId)
	{
		$this->db->where('mp_used_by', $personId);
		$this->db->where('mp_status', $this->config->item('status_active'));
		$this->db->where('mp_code', $code);
		$query = $this->db->get('member_privilege_code');
		return $query->row();
	}
	
	public function updateStaffPrivilegeCode($data)
	{
		$this->db->set('mp_code', $data['code']);
		$this->db->set('mp_staff_code', $data['staffCode']);
		$this->db->set('mp_remark', $data['remark']);
		$this->db->set('mp_updateby', $data['personId']);
		$this->db->set('mp_updatedatetime', $data['dateTimeNow']);
		$this->db->set('mp_admin_check_in_datetime', $data['dateTimeNow']);
		$this->db->set('mp_admin_check_in_by', 1128); //shopStaff 1128
		$this->db->where('mp_id', $data['mp_id']);
		$query = $this->db->update('member_privilege_code');
		return $query;
	}
	
	public function updateShopPrivilegeCode($data)
	{
		$this->db->set('mp_code', $data['code']);
		$this->db->set('mp_shop_code', $data['shopCode']);
		$this->db->set('mp_balance', $data['balance']);
		$this->db->set('mp_voucher', $data['voucher']);
		$this->db->set('mp_updateby', $data['personId']);
		$this->db->set('mp_updatedatetime', $data['dateTimeNow']);
		$this->db->set('mp_admin_check_in_datetime', $data['dateTimeNow']);
		$this->db->set('mp_admin_check_in_by', 1128); //shopStaff 1128
		$this->db->where('mp_id', $data['mp_id']);
		$query = $this->db->update('member_privilege_code');
		return $query;
	}
	public function getMaster_shop($shopCode)
	{
		$this->db->where('shop_customer_number', $shopCode);
		$this->db->where('shop_status', $this->config->item('status_active'));
		$query = $this->db->get('master_shop');
		return $query->row();
	}
	// new privilege 
}