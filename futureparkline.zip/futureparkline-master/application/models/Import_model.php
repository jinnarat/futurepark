<?php
/**
 * Description of Import Model
 *
 * @author TechArise Team
 *
 * @email  info@techarise.com
 */
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Import_model extends CI_Model {

    private $_batchImport;

    public function setBatchImport($batchImport) {
        $this->_batchImport = $batchImport;
    }

    // save data
    public function importData() {
        $data = $this->_batchImport;
        $this->db->insert_batch('sms_no', $data);
    }
    // get employee list
    public function employeeList() {
        $this->db->select(array('e.id', 'e.tel_no'));
        $this->db->from('sms_no as e');
        $query = $this->db->get();
        return $query->result_array();
    }

}

?>