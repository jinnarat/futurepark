<?php

class Lists_model extends CI_Model{
	
    function __construct(){
		parent::__construct();
		$this->load->model('MainModel');  
    }

    function upcomingssss($menu=null){
		$field_select = ",file_name";
		
		$sql = "SELECT id".$field_select." FROM upload_file WHERE status = 'A'";
		if($menu != null | $menu != ""){
			$sql .= " AND menu = '".$menu."' ";
		}
		$sql .= " ORDER BY update_date desc";
		// echo $sql.'<br />';
		return $this->db->query($sql);
	}

	function select_token($token = null){
		$sql = "SELECT logId,access_token, app_id,refresh_token,token_type,status,starttime,endtime  FROM log_token WITH (NOLOCK)";

		if($token != null | $token != ""){
			$sql .= "WHERE access_token = '".$token."' ";
		}
		// echo $sql.'<br />';
		return $this->db->query($sql);
	}

	function CheckOTP($status = null,$mobilephone=null,$otp=null,$reference=null,$startdate=null,$enddate=null,$chanel=null,$email=null){
		$sql = "SELECT logId, refId, email, chanel, refCode, mobileNo, mobileFullNo, otp, reference, message, reponse, description, status, usedby, usedtime, starttime, endtime
		 FROM log_sms WITH (NOLOCK) WHERE status = '".$status."'";
		
		if($mobilephone != "" || $mobilephone != null)
		{
			$sql .= " AND mobileNo = '".$mobilephone."' ";
		}

		if($email != "" || $email != null)
		{
			$sql .= " AND email = '".$email."' ";
		}

		if($chanel != "" || $chanel != null)
		{
			$sql .= " AND chanel = '".$chanel."' ";
		}
		
		if($otp != "" || $otp != null)
		{
			$sql .= " AND otp = '".$otp."' ";
		}
		
		if($reference != "" || $reference != null)
		{	
			$sql .= " AND reference = '".$reference."' ";
		}
		
		// if($startdate != "" || $startdate != null)
		// {
		// 	$sql .= " AND starttime >= '".$startdate."' ";
		// }
		
		if($enddate != "" || $enddate != null)
		{
			$sql .= " AND endtime <= '".$enddate."' ";
		}

		// echo $sql;
		return $this->db->query($sql);
	}

	function SelectNation($id=null,$code=null,$status=null){
		$condition_field = '';
		$condition_value = array();
		
		if($id != "" || $id != null)
		{
			$condition_field .= ' AND nationId = ?';
			$condition_value[] = $id;
		}
		
		if($code != "" || $code != null)
		{
			$condition_field .= " AND nationCode = ? ";
			$condition_value[] = $code;
		}

		if($status != "" || $status != null)
		{
			$condition_field .= ' AND nationStatus = ?';
			$condition_value[] = $status;
		}
				
		$sql = $this->MainModel->getDataBind("SELECT nationId, nationCode, countryCode, nationNameThai, nationNameEng, countryNameThai, 
												countryNameEng, nationStatus, nationCode as displayCode, nationNameThai as displayNameLC
											 FROM master_nation WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = NULL);
		return $sql;
	}

	function SelectProvice111(){
		$condition_field = '';
		$condition_value = array();
		
		if($id != "" || $id != null)
		{
			$condition_field .= ' AND nationId = ?';
			$condition_value[] = $id;
		}
		
		if($code != "" || $code != null)
		{
			$condition_field .= " AND nationCode = ? ";
			$condition_value[] = $code;
		}

		if($status != "" || $status != null)
		{
			$condition_field .= ' AND nationStatus = ?';
			$condition_value[] = $status;
		}
				
		$sql = $this->MainModel->getDataBind("SELECT provinceId, regionId, provinceCode, provinceNameThai, provinceNameEng, provinceType
											 FROM master_province WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = NULL);
		return $sql;
	}

	function SelectProvice($pvId = null){
		$sql = "SELECT provinceId, regionId, provinceCode,provinceNameThai, provinceNameEng, provinceType FROM master_province WITH (NOLOCK) WHERE provinceStatus = 'A'";

		if($pvId != "" || $pvId != null)
		{
			$sql .= " AND provinceId = '".$pvId."' ";
		}

		$sql .= " ORDER BY provinceNameThai asc";

		return $this->db->query($sql);
	}

	function Selectdistrict($pvId = null){
		$sql = "SELECT districtId, districtCode, districtNameThai,districtNameEng, districtNameThaiShort, districtNameEngShort,districtStatus,provinceCode FROM master_district WITH (NOLOCK) WHERE districtStatus = 'A'";

		if($pvId != "" || $pvId != null)
		{
			$sql .= " AND provinceCode = '".$pvId."' ";
		}

		$sql .= " ORDER BY districtNameThai asc";

		return $this->db->query($sql);
	}

	function Selectsubdis($dId = null, $sdId = null){
		$sql = "SELECT subDistrictId, subDistrictCode, subDistrictNameThai,subDistrictNameEng, subDistrictNameThaiShort, subDistrictNameEngShort,postcode,districtCode,provinceCode FROM master_subdistrict WITH (NOLOCK) WHERE subDistrictStatus = 'A' ";

		if($dId != "" || $dId != null)
		{
			$sql .= " AND districtCode = '".$dId."' ";
		}

		$sql .= " ORDER BY subDistrictNameThai asc";

		return $this->db->query($sql);
	}

	function SelectMastercate($cateId = null){
		$sql = "SELECT cat_id, cat_name_th,cat_name_en, cat_status ,cat_image, cat_image_gen,cat_alt
		FROM master_shop_categoryLine WITH (NOLOCK) WHERE cat_status = 'A'";

		if($cateId != "" || $cateId != null)
		{
			$sql .= " AND cat_id = '".$cateId."' ";
		}

		return $this->db->query($sql);

	}

	function SelectMastershop($cateId = null,$shopId = null,$condition = null){
		$sql = "SELECT s.cat_id as cat_id, shop_id, scat_id, shop_name_en, shop_name_th,shop_createdatetime,shop_updatedatetime,shop_image,shop_image_alt,shop_room,shop_floor,shop_zone,floor_name_en,floor_name_th,cat_name_th,cat_name_en
		FROM master_shopLine s WITH (NOLOCK) 
		LEFT JOIN master_floor f ON s.shop_floor = f.floor_ref_id
		LEFT JOIN master_shop_categoryLine c ON s.cat_id = c.cat_id
		WHERE shop_status = 'A' ";

		if($cateId != "" || $cateId != null)
		{
			$sql .= " AND s.cat_id = '".$cateId."' ";
		}

		if($shopId != "" || $shopId != null)
		{
			$sql .= " AND shop_id = '".$shopId."' ";
		}

		if($condition != "" || $condition != null)
		{
			$sql .= $condition;
		}

		// $sql .= " ORDER BY shop_name_th asc";

		// echo '<br>'.$sql.'<br>';

		return $this->db->query($sql);

	}


	function SelectCamp($highlight = null){
		$sql = "SELECT campId, cateId, campCode,campName, imgBanner, detail, is_highlight,startDisplay,endDisplay, FORMAT(startDisplay, 'dd/MM/yy')as startDate,FORMAT(endDisplay, 'dd/MM/yy') as endDate, campStatus
		 FROM campaign WITH (NOLOCK) WHERE campStatus = 'A'";

		if($highlight != "" || $highlight != null)
		{
			$sql .= " AND is_highlight = '".$highlight."' ";
		}

		$sql .= " ORDER BY createtime asc";

		return $this->db->query($sql);
	}

	function SelectActAll($campId=null,$actId=null,$dateNow=null,$highlight = null,$actType=null){
		$sql = "SELECT activityId, campId, campCode,activityCode, activityType, activityName, urlfriendly, imgBanner, detail, limit, startDisplay,endDisplay,FORMAT(startDisplay, 'dd/MM/yy')as startDate,FORMAT(endDisplay, 'dd/MM/yy') as endDate, activityStatus, is_only_member,is_highlight
		 FROM activity WITH (NOLOCK) WHERE activityStatus = 'A' 
		--  AND activityType != 'Promotion' 
		 AND is_lineonly != 'N' AND approveStatus = 'A'";

		if($campId != "" || $campId != null)
		{
			$sql .= " AND campId = '".$campId."' ";
		}

		if($actId != "" || $actId != null)
		{
			$sql .= " AND activityId = '".$actId."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			$sql .= " AND endDisplay >= '".$dateNow."' ";
		}

		if($highlight != "" || $highlight != null)
		{
			$sql .= " AND is_highlight = '".$highlight."' ";
		}

		if($actType != "" || $actType != null)
		{
			$sql .= " AND activityType = '".$actType."' ";
		}

		$sql .= " ORDER BY createtime asc";

		return $this->db->query($sql);
	}

	function SelectAct($campId=null,$actId=null,$dateNow=null,$highlight = null){
		$sql = "SELECT activityId, campId, campCode,activityCode, activityType, activityName, urlfriendly, imgBanner, detail, limit, startDisplay,endDisplay,FORMAT(startDisplay, 'dd/MM/yy')as startDate,FORMAT(endDisplay, 'dd/MM/yy') as endDate, activityStatus, is_only_member,is_highlight,btn_name
		 FROM activity WITH (NOLOCK) WHERE activityStatus = 'A' AND activityType != 'Promotion' AND is_lineonly != 'N' AND approveStatus = 'A'";

		if($campId != "" || $campId != null)
		{
			$sql .= " AND campId = '".$campId."' ";
		}

		if($actId != "" || $actId != null)
		{
			$sql .= " AND activityId = '".$actId."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			$sql .= " AND endDisplay >= '".$dateNow."' ";
		}

		if($highlight != "" || $highlight != null)
		{
			$sql .= " AND is_highlight = '".$highlight."' ";
		}

		$sql .= " ORDER BY createtime DESC";

		return $this->db->query($sql);
	}

	function SelectActPath($campId=null,$actId=null,$dateNow=null){
		$sql = "SELECT a.activityType, urlfriendly,mapLink,slCode
			FROM activity a WITH (NOLOCK) 
			LEFT JOIN master_activity_link l ON a.activityType = l.activityType
			LEFT JOIN master_selection s ON s.slCode = l.activityTypeCode
			WHERE activityStatus = 'A' AND a.activityType != 'Promotion' AND is_lineonly != 'N' AND approveStatus = 'A'";

			if($campId != "" || $campId != null)
			{
				$sql .= " AND a.campId = '".$campId."' ";
			}

			if($actId != "" || $actId != null)
			{
				$sql .= " AND a.activityId = '".$actId."' ";
			}

			if($dateNow != "" || $dateNow != null)
			{
				$sql .= " AND a.endDisplay >= '".$dateNow."' ";
			}

		return $this->db->query($sql);
	}

	function master_lifestyle(){
		$sql = "SELECT lf_id,lf_name
		 FROM master_lifestyle WITH (NOLOCK) WHERE lf_status = 'A'";

		$sql .= " ORDER BY lf_id asc";

		return $this->db->query($sql);
	}

	function person_lifestyle($userId=null,$lf_id=null){
		$sql = "SELECT plf_id,personId,lf_id,plf_name,plf_status,plf_usable
		 FROM person_lifestyle WITH (NOLOCK) WHERE plf_status = 'A' AND plf_usable = 'Y'";

		if($userId != "" || $userId != null)
		{
			$sql .= " AND personId = '".$userId."' ";
		}

		if($lf_id != "" || $lf_id != null)
		{
			$sql .= " AND lf_id = '".$lf_id."' ";
		}

		$sql .= " ORDER BY plf_id asc";

		return $this->db->query($sql);
	}

	function person_lifestyleAll($userId=null){
		$sql = "SELECT plf_id,personId,lf_id,plf_name,plf_status,plf_usable
		 FROM person_lifestyle WHERE personId = '".$userId."'";

		return $this->db->query($sql);
	}

	function SelectMember($userId = null){
		$sql = "SELECT t.ti_id,ti_name,ti_img
		 FROM person p WITH (NOLOCK) 
		 LEFT JOIN master_tier t ON t.ti_id = p.ti_id
		  WHERE personStatus = 'A' AND is_member = 'Y'";

		if($userId != "" || $userId != null)
		{
			$sql .= " AND personId = '".$userId."' ";
		}

		return $this->db->query($sql);
	}

	function SelectPromotion($campId=null,$actId=null,$dateNow=null){
		$sql = "SELECT activityId, campId,subcampId, campCode,activityCode, activityType, activityName, urlfriendly, imgBanner, detail, limit, startDisplay,endDisplay,FORMAT(startDisplay, 'dd/MM/yy')as startDate,FORMAT(endDisplay, 'dd/MM/yy') as endDate, activityStatus, is_only_member
		 FROM activity WITH (NOLOCK) WHERE activityStatus = 'A' AND activityType = 'Promotion' AND is_lineonly != 'N'";

		if($campId != "" || $campId != null)
		{
			$sql .= " AND campId = '".$campId."' ";
		}

		if($actId != "" || $actId != null)
		{
			$sql .= " AND activityId = '".$actId."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			$sql .= " AND endDisplay >= '".$dateNow."' ";
		}

		$sql .= " ORDER BY createtime DESC";

		return $this->db->query($sql);
	}

	function SelectPromotionCode($campId=null,$subId=null,$actId=null,$pId=null,$dateNow=null){
		$sql = "SELECT ac.activityId, ac.campId,ac.subcampId,code,codeStatus,codeType,codeExpired,is_used,usedby,usedtime,activityCode,activityName
		 FROM activity_code ac WITH (NOLOCK) 
		 LEFT JOIN activity a ON ac.activityId = a.activityId WHERE codeStatus = 'A' AND (is_used != 'Y' OR is_used is null OR is_used != '')";

		if($campId != "" || $campId != null)
		{
			$sql .= " AND ac.campId = '".$campId."' ";
		}

		if($subId != "" || $subId != null)
		{
			$sql .= " AND ac.subcampId = '".$subId."' ";
		}

		if($actId != "" || $actId != null)
		{
			$sql .= " AND ac.activityId = '".$actId."' ";
		}
		if($pId != "" || $pId != null)
		{
			$sql .= " AND usedby >= '".$pId."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			$sql .= " AND codeExpired >= '".$dateNow."' ";
		}

		$sql .= " ORDER BY ac.createtime DESC";

		return $this->db->query($sql);
	}

	function SelectItem($item_id=null){
		$sql = "SELECT item_id,item_code,item_type,item_name,item_status
				FROM master_item  WITH (NOLOCK) 
				WHERE item_status = 'A'";

		if($item_id != "" || $item_id != null)
		{
			$sql .= " AND item_id = '".$item_id."' ";
		}

		return $this->db->query($sql);
	}


	function SelectPrivilege($tier=null,$pvrivId=null,$dateNow=null){
		$sql = "SELECT pc.mprivId,pc.ti_id,ps.mprivType,mprivName,imgBanner,detail,pc.limit,startDisplay,endDisplay,FORMAT(startDisplay, 'dd/MM/yy')as startDate,FORMAT(endDisplay, 'dd/MM/yy') as endDate,mprivTypeCode,expire_minutes,mptcName,pc.pointRedeem,pc.getReward,mptcType,pc.itemId,pc.limitTotal,startActionUsed,endActionUsed
				FROM member_privilege_setting ps WITH (NOLOCK) 
				LEFT JOIN member_privilege_type pt ON ps.mprivType = pt.mptcId
				LEFT JOIN member_privilege_condition pc ON ps.mprivId = pc.mprivId
				WHERE mprivStatus = 'A' AND mptcStatus = 'A'";

		if($tier != "" || $tier != null)
		{
			$sql .= " AND pc.ti_id = '".$tier."' ";
		}

		if($pvrivId != "" || $pvrivId != null)
		{
			$sql .= " AND pc.mprivId = '".$pvrivId."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			// $sql .= " AND startDisplay <= '".$dateNow."' AND endDisplay >= '".$dateNow."' ";
			$sql .= " AND endDisplay >= '".$dateNow."' ";
		}

		$sql .= " ORDER BY ps.createtime DESC";

		return $this->db->query($sql);
	}

	

	function SelectUsdPriv($ti_id=null,$mprivId=null,$pId=null,$dateNow=null,$usedtime=null){
		$sql = "SELECT mpcId,ti_id,mprivId,mprivCode,is_used,usedby,usedtime,codeExpired,createtime,lastupdatetime,action_createdatetime_1,imgQr,action_createdatetime_2,is_checkout
		 FROM member_privilege_code WITH (NOLOCK) 
		 WHERE mprivStatus = 'A'";

		if($ti_id != "" || $ti_id != null)
		{
			$sql .= " AND ti_id = '".$ti_id."' ";
		}

		if($mprivId != "" || $mprivId != null)
		{
			$sql .= " AND mprivId = '".$mprivId."' ";
		}

		if($pId != "" || $pId != null)
		{
			$sql .= " AND usedby = '".$pId."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			$sql .= " AND codeExpired >= '".$dateNow."' ";
		}

		if($usedtime != "" || $usedtime != null)
		{
			$sql .= " AND usedtime = '".$usedtime."' ";
		}

		$sql .= " ORDER BY createtime asc";

		return $this->db->query($sql);
	}


	function selectBadgeSubcamp(){
		$sql = "SELECT b.subcampId,subcampName
				FROM activity_badge b WITH (NOLOCK) 
				LEFT JOIN subcampaign s ON b.subcampId = s.subcampId
				WHERE badgeId is not null AND b.abStatus = 'A' GROUP BY b.subcampId,subcampName";

		return $this->db->query($sql);
	}


	function selectBadgeActivity($subId=null){
		$sql = "SELECT abId,b.campId,b.subcampId,b.activityId,b.badgeId,abStatus,b.createby,b.createtime,b.lastupdateby,b.lastupdatetime,badgeName,file_path,badgeStatus,subcampName,activityName

		FROM activity_badge b WITH (NOLOCK) 
		LEFT JOIN subcampaign s ON b.subcampId = s.subcampId
		LEFT JOIN activity a ON b.activityId = a.activityId
		LEFT JOIN master_badge m ON b.badgeId = m.badgeId 
		WHERE b.badgeId is not null AND b.abStatus = 'A'";
		
		if($subId != "" || $subId != null)
		{
			$sql .= " AND b.subcampId = '".$subId."' ";
		}

		$sql .= " ORDER BY b.createtime ASC";

		return $this->db->query($sql);
	}

	function selectLogBadgeActivity($pid=null,$subId=null,$actId=null){
		$sql = "SELECT logId,abId,l.campId,l.subcampId,activityId,personId,l.lastupdatetime,l.badgeId,badgeName,file_path,badgeStatus,l.lastupdatetime
		FROM log_activity_badge l WITH (NOLOCK) 
		LEFT JOIN master_badge m ON l.badgeId = m.badgeId 
		WHERE 1=1";

		if($pid != "" || $pid != null)
		{
			$sql .= " AND personId = '".$pid."' ";
		}

		if($subId != "" || $subId != null)
		{
			$sql .= " AND l.subcampId = '".$subId."' ";
		}

		if($actId != "" || $actId != null)
		{
			$sql .= " AND l.activityId = '".$actId."' ";
		}

		$sql .= " ORDER BY createtime ASC";

		return $this->db->query($sql);
	}

	public function getDistinctCodeLists($codeId=null, $privId=null, $code=null, $codeStatus=null, $is_used=null, $personId=null, $order=null)
	{	
		$condition_field 	= '';
		$condition_value 	= array();
		$condition_value[] = $this->config->item('status_delete');

		$ORDERBY 			= NULL;
		$OTHER 				= NULL;

		if($codeId != "" || $codeId != null)
		{
			$condition_field .= ' AND codeId = ?';
			$condition_value[] = $codeId;
		}
		
		if($privId != "" || $privId != null)
		{
			$condition_field .= ' AND mprivId = ?';
			$condition_value[] = $privId;
		}
		
		if($code != "" || $code != null)
		{
			$condition_field .= ' AND code = ?';
			$condition_value[] = $code;
		}
		
		if($codeStatus != "" || $codeStatus != null)
		{
			$condition_field .= ' AND mprivStatus = ?';
			$condition_value[] = $codeStatus;
		}
		
		if($is_used != "" || $is_used != null)
		{
			$condition_field .= ' AND is_used = ?';
			$condition_value[] = $is_used;
		}

		if($personId != "" || $personId != null)
		{
			$condition_field .= ' AND usedby = ?';
			$condition_value[] = $personId;
		}
		
		if($order != "" || $order != null)
		{
			$ORDERBY = "ORDER BY ".$order;
		} 

		// WHERE 1=1
		$sql = $this->MainModel->getDataBind("SELECT DISTINCT mprivCode as code
											FROM member_privilege_code  WITH (NOLOCK) "
											,"WHERE mprivStatus != ? ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY
											,$OTHER);
		return $sql;
	}

	public function SelectMasterPickupPoint($id=null,$value=null){
		
		$condition_field = '';
		$condition_value = array();
		$condition_value[] 	= $this->config->item('status_delete');
		$ORDERBY = 'ORDER BY slSort ASC';
		if($id != "" || $id != null)
		{
			$condition_field .= ' AND puId = ?';
			$condition_value[] = $id;
		}

		if($value != "" || $value != null)
		{
			$condition_field .= ' AND puVale = ?';
			$condition_value[] = $value;
		}
				
		$sql = $this->MainModel->getDataBind("SELECT  puId, puVale, puDisplay, puStatus								 
											FROM master_pickUpPoint WITH (NOLOCK) "
											,"WHERE puStatus != ? ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = NULL);
		return $sql;
	}

	function SelectMasterTier($ti_id = null){
		$sql = "SELECT ti_id,ti_name,ti_img
		 FROM master_tier  WITH (NOLOCK) 
		  WHERE ti_status = 'A'";

		if($ti_id != "" || $ti_id != null)
		{
			$sql .= " AND ti_id = '".$ti_id."' ";
		}

		return $this->db->query($sql);
	}

	

	
    
}
?>

<?php
