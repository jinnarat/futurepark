<?php

class Lists_model extends CI_Model{
	
    function __construct(){
		parent::__construct();
		$this->load->model('MainModel');  
		$this->dbcdp = $this->load->database('cdp', TRUE);
    }

    function upcomingssss($menu=null){
		$field_select = ",file_name";
		
		$sql = "SELECT id".$field_select." FROM upload_file WHERE status = 'A'";
		if($menu != null | $menu != ""){
			$sql .= " AND menu = '".$menu."' ";
		}
		$sql .= " ORDER BY update_date desc";
		// echo $sql.'<br />';
		return $this->db->query($sql);
	}

	function select_token($token = null){
		$sql = "SELECT logId,access_token, app_id,refresh_token,token_type,status,starttime,endtime  FROM log_token WITH (NOLOCK) WHERE app_id = ".APPID;

		if($token != null | $token != ""){
			$sql .= "WHERE access_token = '".$token."' ";
		}
		// echo $sql.'<br />';
		return $this->db->query($sql);
	}

	function CheckOTP($status = null,$mobilephone=null,$otp=null,$reference=null,$startdate=null,$enddate=null,$chanel=null,$email=null){
		$sql = "SELECT logId, refId, email, chanel, refCode, mobileNo, mobileFullNo, otp, reference, message, reponse, description, status, usedby, usedtime, starttime, endtime
		 FROM log_sms WITH (NOLOCK) WHERE status = '".$status."'";
		
		if($mobilephone != "" || $mobilephone != null)
		{
			$sql .= " AND mobileNo = '".$mobilephone."' ";
		}

		if($email != "" || $email != null)
		{
			$sql .= " AND email = '".$email."' ";
		}

		if($chanel != "" || $chanel != null)
		{
			$sql .= " AND chanel = '".$chanel."' ";
		}
		
		if($otp != "" || $otp != null)
		{
			$sql .= " AND otp = '".$otp."' ";
		}
		
		if($reference != "" || $reference != null)
		{	
			$sql .= " AND reference = '".$reference."' ";
		}
		
		// if($startdate != "" || $startdate != null)
		// {
		// 	$sql .= " AND starttime >= '".$startdate."' ";
		// }
		
		if($enddate != "" || $enddate != null)
		{
			$sql .= " AND endtime <= '".$enddate."' ";
		}

		// echo $sql;
		return $this->db->query($sql);
	}

	function SelectNation($id=null,$code=null,$status=null){
		$condition_field = '';
		$condition_value = array();
		
		if($id != "" || $id != null)
		{
			$condition_field .= ' AND nationId = ?';
			$condition_value[] = $id;
		}
		
		if($code != "" || $code != null)
		{
			$condition_field .= " AND nationCode = ? ";
			$condition_value[] = $code;
		}

		if($status != "" || $status != null)
		{
			$condition_field .= ' AND nationStatus = ?';
			$condition_value[] = $status;
		}
				
		$sql = $this->MainModel->getDataBind("SELECT nationId, nationCode, countryCode, nationNameThai, nationNameEng, countryNameThai, 
												countryNameEng, nationStatus, nationCode as displayCode, nationNameThai as displayNameLC
											 FROM master_nation WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = NULL);
		return $sql;
	}

	// function SelectProvice111(){
	// 	$condition_field = '';
	// 	$condition_value = array();
		
	// 	if($id != "" || $id != null)
	// 	{
	// 		$condition_field .= ' AND nationId = ?';
	// 		$condition_value[] = $id;
	// 	}
		
	// 	if($code != "" || $code != null)
	// 	{
	// 		$condition_field .= " AND nationCode = ? ";
	// 		$condition_value[] = $code;
	// 	}

	// 	if($status != "" || $status != null)
	// 	{
	// 		$condition_field .= ' AND nationStatus = ?';
	// 		$condition_value[] = $status;
	// 	}
				
	// 	$sql = $this->MainModel->getDataBind("SELECT provinceId, regionId, provinceCode, provinceNameThai, provinceNameEng, provinceType
	// 										 FROM master_province WITH (NOLOCK) "
	// 										,"WHERE 1=1 ".$condition_field
	// 										,$VALUE = $condition_value
	// 										,$GROUPBY = NULL
	// 										,$ORDERBY = NULL);
	// 	return $sql;
	// }

	function SelectProvice($pvId = null){
		$sql = "SELECT provinceId, regionId, provinceCode,provinceNameThai, provinceNameEng, provinceType FROM master_province WITH (NOLOCK) WHERE provinceStatus = 'A'";

		if($pvId != "" || $pvId != null)
		{
			$sql .= " AND provinceId = '".$pvId."' ";
		}

		$sql .= " ORDER BY provinceNameThai asc";

		return $this->db->query($sql);
	}

	function Selectdistrict($pvId = null){
		$sql = "SELECT districtId, districtCode, districtNameThai,districtNameEng, districtNameThaiShort, districtNameEngShort,districtStatus,provinceCode FROM master_district WITH (NOLOCK) WHERE districtStatus = 'A'";

		if($pvId != "" || $pvId != null)
		{
			$sql .= " AND provinceCode = '".$pvId."' ";
		}

		$sql .= " ORDER BY districtNameThai asc";

		return $this->db->query($sql);
	}

	function Selectsubdis($dId = null, $sdId = null){
		$sql = "SELECT subDistrictId, subDistrictCode, subDistrictNameThai,subDistrictNameEng, subDistrictNameThaiShort, subDistrictNameEngShort,postcode,districtCode,provinceCode FROM master_subdistrict WITH (NOLOCK) WHERE subDistrictStatus = 'A' ";

		if($dId != "" || $dId != null)
		{
			$sql .= " AND districtCode = '".$dId."' ";
		}

		$sql .= " ORDER BY subDistrictNameThai asc";

		return $this->db->query($sql);
	}

	function SelectMastercate($cateId = null){
		$sql = "SELECT cat_id, cat_name_th,cat_name_en, cat_status ,cat_image, cat_image_gen,cat_alt
		FROM master_shop_categoryLine WITH (NOLOCK) WHERE cat_status = 'A'";

		if($cateId != "" || $cateId != null)
		{
			$sql .= " AND cat_id = '".$cateId."' ";
		}

		return $this->db->query($sql);

	}

	function SelectMastershop($cateId = null,$shopId = null,$condition = null){
		$sql = "SELECT s.cat_id as cat_id, shop_id, scat_id, shop_name_en, shop_name_th,shop_createdatetime,shop_updatedatetime,shop_image,shop_image_alt,shop_room,shop_floor,shop_zone,floor_name_en,floor_name_th,cat_name_th,cat_name_en, shop_plaza_name, shop_description
		FROM master_shopLine s WITH (NOLOCK) 
		LEFT JOIN master_floor f ON s.shop_floor = f.floor_ref_id
		LEFT JOIN master_shop_categoryLine c ON s.cat_id = c.cat_id
		WHERE shop_status = 'A' ";

		if($cateId != "" || $cateId != null)
		{
			$sql .= " AND s.cat_id = '".$cateId."' ";
		}

		if($shopId != "" || $shopId != null)
		{
			$sql .= " AND shop_id = '".$shopId."' ";
		}

		if($condition != "" || $condition != null)
		{
			$sql .= $condition;
		}

		// $sql .= " ORDER BY shop_name_th asc";

		// echo '<br>'.$sql.'<br>';

		return $this->db->query($sql);

	}


	function SelectCamp($highlight = null){
		$sql = "SELECT campId, cateId, campCode,campName, imgBanner, detail, is_highlight,startDisplay,endDisplay, FORMAT(startDisplay, 'dd/MM/yy')as startDate,FORMAT(endDisplay, 'dd/MM/yy') as endDate, campStatus
		 FROM campaign WITH (NOLOCK) WHERE campStatus = 'A'";

		if($highlight != "" || $highlight != null)
		{
			$sql .= " AND is_highlight = '".$highlight."' ";
		}

		$sql .= " ORDER BY lastupdatetime desc";

		return $this->db->query($sql);
	}

	function SelectActAll($campId=null,$actId=null,$dateNow=null,$highlight = null,$actType=null){
		$sql = "SELECT aty.activityId, aty.campId, aty.campCode, aty.activityCode, aty.activityType, aty.activityName, aty.urlfriendly, aty.imgBanner, aty.detail, aty.limit, aty.startDisplay, aty.endDisplay, FORMAT(aty.startDisplay, 'dd/MM/yy')as startDate, FORMAT(aty.endDisplay, 'dd/MM/yy') as endDate, aty.activityStatus, aty.is_only_member, aty.is_highlight, cp.campStatus, sp.subcampStatus, aty.usedTargetCDP, aty.regis_new_system, aty.insertData, aty.subDetail
		FROM activity aty WITH (NOLOCK)
		LEFT JOIN subcampaign sp ON aty.subcampId = sp.subcampId
		LEFT JOIN campaign cp ON aty.campId = cp.campId
		WHERE aty.activityStatus = 'A' 
		AND aty.is_lineonly = 'Y' AND aty.approveStatus = 'A'";
		// --  AND activityType != 'Promotion' 

		if($campId != "" || $campId != null)
		{
			$sql .= " AND aty.campId = '".$campId."' ";
		}

		if($actId != "" || $actId != null)
		{
			$sql .= " AND aty.activityId = '".$actId."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			$sql .= " AND aty.endDisplay >= '".$dateNow."' ";
		}

		if($highlight != "" || $highlight != null)
		{
			$sql .= " AND aty.is_highlight = '".$highlight."' ";
		}

		if($actType != "" || $actType != null)
		{
			$sql .= " AND aty.activityType = '".$actType."' ";
		}

		$sql .= " ORDER BY aty.lastupdatetime desc";

		return $this->db->query($sql);
	}

	function SelectAct($campId=null,$actId=null,$dateNow=null,$highlight = null){
		$sql = "SELECT aty.activityId, aty.campId, aty.campCode, aty.activityCode, aty.activityType, aty.activityName, aty.urlfriendly, aty.imgBanner, aty.detail, aty.limit, aty.startDisplay,aty.endDisplay, FORMAT(aty.startDisplay, 'dd/MM/yy')as startDate, FORMAT(aty.endDisplay, 'dd/MM/yy') as endDate, aty.activityStatus, aty.is_only_member, aty.is_highlight, aty.btn_name, cp.campStatus, sp.subcampStatus, aty.usedTargetCDP, aty.regis_new_system, aty.insertData, aty.subDetail
		FROM activity aty WITH (NOLOCK)
		LEFT JOIN subcampaign sp ON aty.subcampId = sp.subcampId
		LEFT JOIN campaign cp ON aty.campId = cp.campId
		WHERE aty.activityStatus = 'A' AND aty.activityType != 'Promotion' AND aty.is_lineonly = 'Y' AND aty.approveStatus = 'A'";

		if($campId != "" || $campId != null)
		{
			$sql .= " AND aty.campId = '".$campId."' ";
		}

		if($actId != "" || $actId != null)
		{
			$sql .= " AND aty.activityId = '".$actId."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			$sql .= " AND aty.endDisplay >= '".$dateNow."' ";
		}

		if($highlight != "" || $highlight != null)
		{
			$sql .= " AND aty.is_highlight = '".$highlight."' ";
		}

		$sql .= " ORDER BY aty.createtime DESC";

		return $this->db->query($sql);
	}

	function SelectActPath($campId=null,$actId=null,$dateNow=null){
		$sql = "SELECT a.activityType, urlfriendly,mapLink,slCode
			FROM activity a WITH (NOLOCK) 
			LEFT JOIN master_activity_link l ON a.activityType = l.activityType
			LEFT JOIN master_selection s ON s.slCode = l.activityTypeCode
			WHERE activityStatus = 'A' AND a.activityType != 'Promotion' AND is_lineonly = 'Y' AND approveStatus = 'A'";

			if($campId != "" || $campId != null)
			{
				$sql .= " AND a.campId = '".$campId."' ";
			}

			if($actId != "" || $actId != null)
			{
				$sql .= " AND a.activityId = '".$actId."' ";
			}

			if($dateNow != "" || $dateNow != null)
			{
				$sql .= " AND a.endDisplay >= '".$dateNow."' ";
			}

		return $this->db->query($sql);
	}

	function master_lifestyle(){
		$sql = "SELECT lf_id,lf_name
		 FROM master_lifestyle WITH (NOLOCK) WHERE lf_status = 'A'";

		$sql .= " ORDER BY lf_id asc";

		return $this->db->query($sql);
	}

	function person_lifestyle($userId=null,$lf_id=null){
		$sql = "SELECT plf_id,personId,lf_id,plf_name,plf_status,plf_usable
		 FROM person_lifestyle WITH (NOLOCK) WHERE plf_status = 'A' AND plf_usable = 'Y'";

		if($userId != "" || $userId != null)
		{
			$sql .= " AND personId = '".$userId."' ";
		}

		if($lf_id != "" || $lf_id != null)
		{
			$sql .= " AND lf_id = '".$lf_id."' ";
		}

		$sql .= " ORDER BY category_id asc, sub_category_id asc, lf_id asc";

		return $this->db->query($sql);
	}

	function person_lifestyleAll($userId=null){
		$sql = "SELECT plf_id,personId,lf_id,plf_name,plf_status,plf_usable
		 FROM person_lifestyle WHERE personId = '".$userId."'";

		return $this->db->query($sql);
	}

	function SelectMember($userId = null){
		$sql = "SELECT t.ti_id,ti_name,ti_img
		 FROM person p WITH (NOLOCK) 
		 LEFT JOIN master_tier t ON t.ti_id = p.ti_id
		  WHERE personStatus != 'D' AND is_member = 'Y'";

		if($userId != "" || $userId != null)
		{
			$sql .= " AND personId = '".$userId."' ";
		}

		return $this->db->query($sql);
	}

	function SelectPromotion($campId=null,$actId=null,$dateNow=null){
		$sql = "SELECT aty.activityId, aty.campId, aty.subcampId, aty.campCode, aty.activityCode, aty.activityType, aty.activityName, aty.urlfriendly, aty.imgBanner, aty.detail, aty.limit, aty.startDisplay, aty.endDisplay, FORMAT(aty.startDisplay, 'dd/MM/yy')as startDate, FORMAT(aty.endDisplay, 'dd/MM/yy') as endDate, aty.activityStatus, aty.is_only_member, cp.campStatus, sp.subcampStatus, aty.usedTargetCDP, aty.regis_new_system, aty.insertData
		FROM activity aty WITH (NOLOCK)
		LEFT JOIN subcampaign sp ON aty.subcampId = sp.subcampId
		LEFT JOIN campaign cp ON aty.campId = cp.campId
		WHERE aty.activityStatus = 'A' AND aty.is_lineonly = 'Y'";

		if($campId != "" || $campId != null)
		{
			$sql .= " AND aty.campId = '".$campId."' ";
		}

		if($actId != "" || $actId != null)
		{
			$sql .= " AND aty.activityId = '".$actId."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			$sql .= " AND aty.endDisplay >= '".$dateNow."' ";
		}

		$sql .= " ORDER BY aty.createtime DESC";

		return $this->db->query($sql);
	}

	function SelectPromotionCode($campId=null,$subId=null,$actId=null,$pId=null,$dateNow=null){
		$sql = "SELECT ac.activityId, ac.campId,ac.subcampId,code,codeStatus,codeType,codeExpired,is_used,usedby,usedtime,activityCode,activityName
		 FROM activity_code ac WITH (NOLOCK) 
		 LEFT JOIN activity a ON ac.activityId = a.activityId WHERE codeStatus = 'A' AND (is_used != 'Y' OR is_used is null OR is_used != '')";

		if($campId != "" || $campId != null)
		{
			$sql .= " AND ac.campId = '".$campId."' ";
		}

		if($subId != "" || $subId != null)
		{
			$sql .= " AND ac.subcampId = '".$subId."' ";
		}

		if($actId != "" || $actId != null)
		{
			$sql .= " AND ac.activityId = '".$actId."' ";
		}
		if($pId != "" || $pId != null)
		{
			$sql .= " AND usedby >= '".$pId."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			$sql .= " AND codeExpired >= '".$dateNow."' ";
		}

		$sql .= " ORDER BY ac.createtime DESC";

		return $this->db->query($sql);
	}

	function SelectItem($item_id=null){
		$sql = "SELECT item_id,item_code,item_type,item_name,item_status
				FROM master_item  WITH (NOLOCK) 
				WHERE item_status = 'A'";

		if($item_id != "" || $item_id != null)
		{
			$sql .= " AND item_id = '".$item_id."' ";
		}

		return $this->db->query($sql);
	}

	function SelectPrivilegeOld($tier=null,$pvrivId=null,$dateNow=null){
		$sql = "SELECT pc.mps_id,pc.ti_id,ps.mpt_id,mps_name,mps_image,mps_detail,mps_start_display,mps_end_display,FORMAT(mps_start_display, 'dd/MM/yy')as startDate,FORMAT(mps_end_display, 'dd/MM/yy') as endDate,mps_expire_in,pc.pointRedeem,pc.getReward,mptcType,pc.itemId,startActionUsed,endActionUsed
				FROM member_privilege_setting ps WITH (NOLOCK) 
				LEFT JOIN member_privilege_type pt ON ps.mpt_id = pt.mpt_id
				LEFT JOIN member_privilege_condition pc ON ps.mps_id = pc.mps_id
				WHERE mps_status = 'A' AND mpt_status = 'A' AND (ps.mps_show_on_line = 'Y' OR ps.mps_show_on_line IS NULL)";

		if($tier != "" || $tier != null)
		{
			$sql .= " AND pc.ti_id = '".$tier."' ";
		}

		if($pvrivId != "" || $pvrivId != null)
		{
			$sql .= " AND pc.mprivId = '".$pvrivId."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			// $sql .= " AND startDisplay <= '".$dateNow."' AND endDisplay >= '".$dateNow."' ";
			$sql .= " AND endDisplay >= '".$dateNow."' ";
		}

		$sql .= " ORDER BY ps.createtime DESC";

		return $this->db->query($sql);
	}

	function SelectUsdPriv($ti_id=null,$mprivId=null,$pId=null,$dateNow=null,$usedtime=null){
		$sql = "SELECT mpcId,ti_id,mprivId,mprivCode,is_used,usedby,usedtime,codeExpired,createtime,lastupdatetime,action_createdatetime_1,imgQr,action_createdatetime_2,is_checkout
		 FROM member_privilege_code WITH (NOLOCK) 
		 WHERE mprivStatus = 'A'";

		if($ti_id != "" || $ti_id != null)
		{
			$sql .= " AND ti_id = '".$ti_id."' ";
		}

		if($mprivId != "" || $mprivId != null)
		{
			$sql .= " AND mprivId = '".$mprivId."' ";
		}

		if($pId != "" || $pId != null)
		{
			$sql .= " AND usedby = '".$pId."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			$sql .= " AND codeExpired >= '".$dateNow."' ";
		}

		if($usedtime != "" || $usedtime != null)
		{
			$sql .= " AND usedtime = '".$usedtime."' ";
		}

		$sql .= " ORDER BY createtime asc";

		return $this->db->query($sql);
	}


	function selectBadgeSubcamp(){
		$sql = "SELECT b.subcampId,subcampName
				FROM activity_badge b WITH (NOLOCK) 
				JOIN subcampaign s ON b.subcampId = s.subcampId AND s.subcampStatus = 'A' AND GETDATE() < s.endDisplay
				JOIN campaign c ON b.campId = c .campId AND c.campStatus = 'A' AND GETDATE() < c.endDisplay
				WHERE badgeId is not null AND b.abStatus = 'A' GROUP BY b.subcampId,subcampName";

		return $this->db->query($sql);
	}


	function selectBadgeActivity($subId=null){
		$sql = "SELECT abId,b.campId,b.subcampId,b.activityId,b.badgeId,abStatus,b.createby,b.createtime,b.lastupdateby,b.lastupdatetime,badgeName,file_path,badgeStatus,subcampName,activityName

		FROM activity_badge b WITH (NOLOCK) 
		LEFT JOIN subcampaign s ON b.subcampId = s.subcampId
		LEFT JOIN activity a ON b.activityId = a.activityId
		LEFT JOIN master_badge m ON b.badgeId = m.badgeId 
		WHERE b.badgeId is not null AND b.abStatus = 'A'";
		
		if($subId != "" || $subId != null)
		{
			$sql .= " AND b.subcampId = '".$subId."' ";
		}

		$sql .= " ORDER BY b.createtime ASC";

		return $this->db->query($sql);
	}

	public function selectLogBadgeActivityNew($pid=null,$subId=null,$actId=null,$badgeId=null)
	{
		$this->db->select('logId,abId,l.campId,l.subcampId,activityId,personId,l.lastupdatetime,l.badgeId,badgeName,file_path,badgeStatus,l.lastupdatetime');
		$this->db->from('log_activity_badge l');
		$this->db->join('master_badge m', 'l.badgeId = m.badgeId', 'left');
		if($pid != "" || $pid != null)
		{
			$this->db->where('l.personId', $pid);
		}

		if($subId != "" || $subId != null)
		{
			$this->db->where('l.subcampId', $subId);
		}

		if($actId != "" || $actId != null)
		{
			$this->db->where('l.activityId', $actId);
		}
		
		if($badgeId != "" || $badgeId != null)
		{
			$this->db->where('l.badgeId', $badgeId);
		}
		$query = $this->db->get();
		return $query->num_rows();
	}

	function selectLogBadgeActivity($pid=null,$subId=null,$actId=null,$badgeId=null){
		$sql = "SELECT logId,abId,l.campId,l.subcampId,activityId,personId,l.lastupdatetime,l.badgeId,badgeName,file_path,badgeStatus,l.lastupdatetime
		FROM log_activity_badge l WITH (NOLOCK) 
		LEFT JOIN master_badge m ON l.badgeId = m.badgeId 
		WHERE 1=1";

		if($pid != "" || $pid != null)
		{
			$sql .= " AND personId = '".$pid."' ";
		}

		if($subId != "" || $subId != null)
		{
			$sql .= " AND l.subcampId = '".$subId."' ";
		}

		if($actId != "" || $actId != null)
		{
			$sql .= " AND l.activityId = '".$actId."' ";
		}

		if($badgeId != "" || $badgeId != null)
		{
			$this->db->where('l.badgeId', $badgeId);
		}

		$sql .= " ORDER BY createtime ASC";

		return $this->db->query($sql);
	}

	public function getDistinctCodeLists($codeId=null, $privId=null, $code=null, $codeStatus=null, $is_used=null, $personId=null, $order=null)
	{	
		$condition_field 	= '';
		$condition_value 	= array();
		$condition_value[] = $this->config->item('status_delete');

		$ORDERBY 			= NULL;
		$OTHER 				= NULL;

		if($codeId != "" || $codeId != null)
		{
			$condition_field .= ' AND codeId = ?';
			$condition_value[] = $codeId;
		}
		
		if($privId != "" || $privId != null)
		{
			$condition_field .= ' AND mprivId = ?';
			$condition_value[] = $privId;
		}
		
		if($code != "" || $code != null)
		{
			$condition_field .= ' AND code = ?';
			$condition_value[] = $code;
		}
		
		if($codeStatus != "" || $codeStatus != null)
		{
			$condition_field .= ' AND mprivStatus = ?';
			$condition_value[] = $codeStatus;
		}
		
		if($is_used != "" || $is_used != null)
		{
			$condition_field .= ' AND is_used = ?';
			$condition_value[] = $is_used;
		}

		if($personId != "" || $personId != null)
		{
			$condition_field .= ' AND usedby = ?';
			$condition_value[] = $personId;
		}
		
		if($order != "" || $order != null)
		{
			$ORDERBY = "ORDER BY ".$order;
		} 

		// WHERE 1=1
		$sql = $this->MainModel->getDataBind("SELECT DISTINCT mprivCode as code
											FROM member_privilege_code  WITH (NOLOCK) "
											,"WHERE mprivStatus != ? ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY
											,$OTHER);
		return $sql;
	}

	public function SelectMasterPickupPoint($id=null,$value=null){
		
		$condition_field = '';
		$condition_value = array();
		$condition_value[] 	= $this->config->item('status_delete');
		$ORDERBY = 'ORDER BY slSort ASC';
		if($id != "" || $id != null)
		{
			$condition_field .= ' AND puId = ?';
			$condition_value[] = $id;
		}

		if($value != "" || $value != null)
		{
			$condition_field .= ' AND puVale = ?';
			$condition_value[] = $value;
		}
				
		$sql = $this->MainModel->getDataBind("SELECT  puId, puVale, puDisplay, puStatus								 
											FROM master_pickUpPoint WITH (NOLOCK) "
											,"WHERE puStatus != ? ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = NULL);
		return $sql;
	}

	function SelectMasterTier($ti_id = null){
		$sql = "SELECT ti_id,ti_name,ti_img
		 FROM master_tier  WITH (NOLOCK) 
		  WHERE ti_status = 'A'";

		if($ti_id != "" || $ti_id != null)
		{
			$sql .= " AND ti_id = '".$ti_id."' ";
		}

		return $this->db->query($sql);
	}

	public function getActivityMember($codeId)
	{
		$this->db->where('mbStatus', $this->config->item('status_active'));
		$this->db->where('mb_usable', 'Y');
		$this->db->where('activityId', $codeId);
		$query = $this->db->get('activity_member');
		return $query->result();
	}
	
	public function getPerson($personId)
	{
		$this->db->where('personId', $personId);
		$query = $this->db->get('person');
		return $query->row();
	}
	
	public function getPrivilegeCode($mpcId)
	{
		$this->db->where('mpcId', $mpcId);
		$query = $this->db->get('member_privilege_code');
		return $query->row();
	}

	public function SelectPrivilegeALL()
	{
		$this->db->where('mps_status', $this->config->item('status_active'));
		$this->db->where('mps_show_on_line', $this->config->item('status_active'));
		$this->db->where('mps_end_display >=', date("Y-m-d H:i:s"));
		$query = $this->db->get('member_privilege_setting');
		return $query;
	}
	
	public function SelectPrivilegeHighlight()
	{
		$this->db->where('mps_status', $this->config->item('status_active'));
		$this->db->where('mps_show_on_line', $this->config->item('status_active'));
		$this->db->where('mps_end_display >=', date("Y-m-d H:i:s"));
		$this->db->where('mps_is_highlight', $this->config->item('status_active'));
		$query = $this->db->get('member_privilege_setting');
		return $query->result();
	}

	public function SelectPrivilege($pvrivId = null){
		$active = $this->config->item('status_active');
		$this->db->select('ps.mps_id, ps.mps_name, ps.mps_image, ps.mps_detail, ps.mps_end_action_used, ps.mpt_id, pt.mpt_type ');
		$this->db->from('member_privilege_setting ps');
		$this->db->join("member_privilege_type pt", "ps.mpt_id = pt.mpt_id AND pt.mpt_status = '".$active."'", "left");
		$this->db->where('ps.mps_id', $pvrivId);
		$this->db->where('ps.mps_status', $active);
		// $this->db->order_by('activity_commu.commuType');
		$query = $this->db->get();
		return $query;
	}
	
	public function SelectConditionPrivilege($pvrivId = null){
		$active = $this->config->item('status_active');
		$this->db->select('ps.mps_id, ps.mps_name, ps.mps_image, ps.mps_detail, ps.mps_end_action_used, ps.mpt_id, pt.mpt_type ');
		$this->db->from('member_privilege_setting ps');
		$this->db->join("member_privilege_type pt", "ps.mpt_id = pt.mpt_id AND pt.mpt_status = '".$active."'", "left");
		$this->db->where('ps.mps_id', $pvrivId);
		$this->db->where('ps.mps_status', $active);
		$query = $this->db->get();
		return $query;
	}

	public function getViewLifeStyle()
	{
		$query = $this->dbcdp->get('V_CDPLifeStyleMaster');
		return $query->result();
	}
	
	
	public function getPersonLifeStyleReuslt($personId)
	{
		$this->db->select('plf_id, lf_id, plf_name, category_id, category_name, sub_category_id, sub_category_name');
		$this->db->where('personId', $personId);
		$this->db->where('plf_status', $this->config->item('status_active'));
		$this->db->order_by('category_id ASC, sub_category_id ASC, lf_id ASC');
		$query = $this->db->get('person_lifestyle');
		return $query->result();
	}
	
	public function getPersonLifeStyle($personId, $category_id, $sub_category_id, $lf_id)
	{
		$this->db->where('personId', $personId);
		$this->db->where('category_id', $category_id);
		$this->db->where('sub_category_id', $sub_category_id);
		$this->db->where('lf_id', $lf_id);
		$this->db->where('plf_status', $this->config->item('status_active'));
		$query = $this->db->get('person_lifestyle');
		return $query->row();
	}
	
	public function deletePersonLifeStyle($personId)
	{
		$this->db->set('plf_status', $this->config->item('status_delete'));
		$this->db->where('personId', $personId);
		$this->db->where('plf_status', $this->config->item('status_active'));
		$query = $this->db->update('person_lifestyle');
		return $query;
	}

	public function insertPersonLifeStyle($data)
	{
		$this->db->set('personId', $data['personId']);
		$this->db->set('lf_id', $data['lf_id']);
		$this->db->set('plf_name', $data['plf_name']);
		$this->db->set('plf_usable', $data['plf_usable']);
		$this->db->set('plf_status', $data['plf_status']);
		$this->db->set('plf_createdatetime', $data['now']);
		$this->db->set('plf_createby', $data['personId']);
		$this->db->set('plf_updatedatetime', $data['now']);
		$this->db->set('plf_updateby', $data['personId']);
		$this->db->set('category_id', $data['category_id']);
		$this->db->set('category_name', $data['category_name']);
		$this->db->set('sub_category_id', $data['sub_category_id']);
		$this->db->set('sub_category_name', $data['sub_category_name']);
		$query = $this->db->insert('person_lifestyle');
		return $query;
	}
	
	public function updatePersonLifeStyle($data)
	{
		$this->db->set('lf_id', $data['lf_id']);
		$this->db->set('plf_name', $data['plf_name']);
		$this->db->set('plf_usable', $data['plf_usable']);
		$this->db->set('plf_status', $data['plf_status']);
		$this->db->set('plf_updatedatetime', $data['now']);
		$this->db->set('plf_updateby', $data['personId']);
		$this->db->set('category_id', $data['category_id']);
		$this->db->set('category_name', $data['category_name']);
		$this->db->set('sub_category_id', $data['sub_category_id']);
		$this->db->set('sub_category_name', $data['sub_category_name']);
		$this->db->where('personId', $data['personId']);
		if($data['plf_id']){
			$this->db->where('plf_id', $data['plf_id']);
		}
		$query = $this->db->update('person_lifestyle');
		return $query;
	}

	public function getActivityTargetPersonal($activityId, $personId)
	{
		$this->db->where('activityId', $activityId);
		$this->db->where('personId', $personId);
		$this->db->where('tgl_status', $this->config->item('status_active'));
		$query = $this->db->get('activity_target_personal');
		return $query->result();
	}
	
	// new filter shop 
	public function getBuildingShops()
	{
		$this->db->select('shop_plaza as id, shop_plaza_name as name');
		$this->db->where('shop_status', $this->config->item('status_active'));
		$this->db->group_by('shop_plaza, shop_plaza_name'); 
		$query = $this->db->get('master_shopLine');
		return $query->result();
	}
	
	public function getFloorShops()
	{
		// $this->db->distinct();
		$this->db->select('floor_ref_id as id, floor_name_th as name');
		$this->db->where('floor_status', $this->config->item('status_active'));
		$this->db->group_by('floor_ref_id, floor_name_th'); 
		$this->db->order_by('floor_name_th'); 
		$query = $this->db->get('master_floor');
		return $query->result();
	}
	
	public function getCategoryShops()
	{
		$this->db->select('cat_id as id, cat_name_th as name');
		$this->db->where('cat_status', $this->config->item('status_active'));
		$this->db->group_by('cat_id, cat_name_th'); 
		$query = $this->db->get('master_shop_categoryLine');
		return $query->result();
	}
	// end new filter shop 
	
	// new find api 
	public function getToken($appID = null, $token = null, $date = null)
	{
		$this->db->select('logId,access_token, app_id,refresh_token,token_type,status,starttime,endtime');
		$this->db->where('app_id', $appID);
		if ($token) {
			$this->db->where('access_token', $token);
		}
		if ($date) {
			$this->db->where('endtime >=', $date);
		}
		$query = $this->db->get('log_token');
		return $query->row();
	}
	// end new find api 

	// promotion page 
	public function getMasterActivityLink($activityType = null)
	{
		$this->db->where('activityType', $activityType);
		$query = $this->db->get('master_activity_link');
		return $query->row();
	}
	// end promotion page 

	public function insertLogUID($data)
	{
		$this->db->set('phone', $data['phone']);
        $this->db->set('uid', $data['uid']);
		$this->db->insert('log_uid');
		return $this->db->insert_id();
	}

	public function getLogUID()
	{
		$query = $this->db->get('log_uid');
		return $query->last_row();
	}
    
}
?>

<?php
