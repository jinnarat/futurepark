<?php
class MainModel extends CI_Model 
{
    function __construct()
    {
        parent::__construct();
	}
	public function convert_data($date=null,$format=null){
		if($date != ''){
			$time = strtotime(str_replace("/" , "-", $date));
			if($format == 'datetime'){
				$newformat = date('d/m/Y H:i',$time);
			}elseif($format == 'time'){
				$newformat = date('H:i',$time);
			}elseif($format == 'dateToDB'){
				$newformat = date('Y-m-d',$time);
			}elseif($format == 'datetimeToDB'){
				$newformat = date('Y-m-d H:i:s',$time);
			}else{
				$newformat = date('d/m/Y',$time);
			}
			return $newformat;
		}else{
			return '';
		}
	}

	public function validationDateFomat($date){
		$errValid = array();
		$errValid['status'] = false;
		$errValid['desc'] = NULL;

		$format_date = explode('/', $date);
		if(count($format_date) == 3){
				
			// if(!preg_match('/^[0-9]{4}/(0[1-9]|1[0-2])/(0[1-9]|[1-2][0-9]|3[0-1])$/', $date)){
			// if(!preg_match('/^(0[1-9]|[1-2][0-9]|3[0-1])/(0[1-9]|1[0-2])/[0-9]{4}$/', $date)){
			//	$errValid['status'] = true;
			//	$errValid['desc'] = "Err date date format.";
						
			// }else if($effect_date[0] > 2116){
			//	$err_eff_date[] = "Line ". $row . "(ระบุปีเป็น ค.ศ. เท่านั้น)";
			//	$errValidation = true;
			
			if(!checkdate($format_date[1], $format_date[0], $format_date[2])){
				$errValid['status'] = true;
				$errValid['desc'] = "Err date current time.";
			}

		}else{
			$errValid['status'] = true;
			$errValid['desc'] = "Err date type.";
		}

		return $errValid;
	}
	
	function generateRandomString($length=null, $type=null) {
		if($length == null || $length == ''){
			$length = 10;
		}
		if($type == 'number'){
			$characters = '0123456789';
		}else if($type == 'lower'){
			$characters = '0123456789abcdefghijklmnopqrstuvwxyz';
		}else{
			$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		}
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	

	public function trimKeyWord($text, $keyworReplace = NULL, $resetReplace = FALSE){   
		$keyword = array("'", "&quot;", "%", " select ", " insert ", " update ", " delete ", "--", "++", ";", "$");
		if($resetReplace == TRUE) $keyword = array();

		// KeyworReplace DATA TYPE ARRAY
		if($keyworReplace != ""){
			$kw = count($keyworReplace);
			for($i=0; $i<$kw; $i++){
				$keyword[] = $keyworReplace[$i];
			}
		}
		
		$data = str_replace($keyword, "", $text);
		return $data;

	}

	public function convertStrToSignQuestion($data){
		// EX $x = "'1',"2",..."
		$res = array();
		$dataQuesArr = array();
		$dataValArr = array();
		$dataArr = explode(",", $data);
        foreach($dataArr as $k){
			array_push($dataQuesArr, "?");
			array_push($dataValArr, $k);
		}
		$res['QEUSTION'] = implode($dataQuesArr, ",");
		$res['DATA_ARRAY'] = $dataArr;

		return $res;
	}
		
	function Base64Encrypt($data)
	{
		return urlencode(base64_encode(base64_encode($data)));
	}
	
	function Base64Decrypt($data)
	{
		return urldecode(base64_decode(base64_decode($data)));
	}
	
	function AESEncrypt($data) {		
		$key 	= 'bRuD5WYw5wd0rdHR9yLlM6wt2vteuiniQBqE70nAuhU=';
		$method = 'AES-256-CBC';
		// Remove the base64 encoding from our key
		$encryption_key = base64_decode($key);
		// Generate an initialization vector
		$iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length($method));
		// Encrypt the data using AES 256 encryption in CBC mode using our encryption key and initialization vector.
		$encrypted = openssl_encrypt($data, $method, $encryption_key, 0, $iv);
		// The $iv is just as important as the key for decrypting, so save it with our encrypted data using a unique separator (::)
		return base64_encode($encrypted . '::' . $iv);	
	}
	
	function AESDecrypt($data) {	
		$key	= 'bRuD5WYw5wd0rdHR9yLlM6wt2vteuiniQBqE70nAuhU=';
		$method = 'AES-256-CBC';
		// Remove the base64 encoding from our key
		$encryption_key = base64_decode($key);
		// To decrypt, split the encrypted data from our IV - our unique separator used was "::"
		list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
		return openssl_decrypt($encrypted_data, $method, $encryption_key, 0, $iv);
	}
	
	function bahtText(float $amount): string
	{
		[$integer, $fraction] = explode('.', number_format(abs($amount), 2, '.', ''));

		$baht = $this->convert_text($integer);
		$satang = $this->convert_text($fraction);

		$output = $amount < 0 ? 'ลบ' : '';
		$output .= $baht ? $baht.'บาท' : '';
		$output .= $satang ? $satang.'สตางค์' : 'ถ้วน';

		return $baht.$satang === '' ? 'ศูนย์บาทถ้วน' : $output;
	}

	function convert_text(string $number): string
	{
		$values = ['', 'หนึ่ง', 'สอง', 'สาม', 'สี่', 'ห้า', 'หก', 'เจ็ด', 'แปด', 'เก้า'];
		$places = ['', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน', 'ล้าน'];
		$exceptions = ['หนึ่งสิบ' => 'สิบ', 'สองสิบ' => 'ยี่สิบ', 'สิบหนึ่ง' => 'สิบเอ็ด'];

		$output = '';

		foreach (str_split(strrev($number)) as $place => $value) {
			if ($place % 6 === 0 && $place > 0) {
				$output = $places[6].$output;
			}

			if ($value !== '0') {
				$output = $values[$value].$places[$place % 6].$output;
			}
		}

		foreach ($exceptions as $search => $replace) {
			$output = str_replace($search, $replace, $output);
		}

		return $output;
	}

	function number_format($number=null) {
		$output = number_format($number,2);
		return $output;
	}
	
	function getFullNameMonth($month=null,$type='TH')
	{
		$array_month_th = array("มกราคม","กุมภาพันธ์","มีนาคม","เมษายน","พฤษภาคม","มิถุนายน","กรกฎาคม","สิงหาคม","กันยายน","ตุลาคม","พฤศจิกายน","ธันวาคม");
		$array_month_en = array("January","February","March","April","May","June","July","August","September","October","November","December");
		
		if($type == 'EN')
		{
			$output = $array_month_en[$month-1];
		}else{
			$output = $array_month_th[$month-1];
		}
		return $output;
	}
	
	function getNameExcludePrefix($name){
		$prefix = array("คุณ","นาง","นางสาว","นาย","ด.ช","ด.ช.","เด็กชาย","ด.ญ","ด.ญ.","เด็กหญิง");
		return str_replace($prefix,"",$name);
	}
	
	function getMBStringSplit($data){
		$length	= mb_strlen($data);
		$length = 3;
		$x = "";
		for($i=0;$i<$length;$i++)
		{
			$x .= "x";
		}
		return mb_substr($data,0,3).$x;
	}
	
	function getDataBind($sqlStmt, $whereStmt = NULL, $valArray = NULL, $GroupbyStmt = NULL, $OderbyStmt = NULL, $OtherStmt = NULL, $escapeStr = FALSE){
        $STMT; $WHERE; $OTHER; $RESULT = 0; $resultValArr = $valArray;

        $WHERE = ($whereStmt === NULL)? "": $whereStmt;
        $GROUPBY = ($GroupbyStmt === NULL)? "": $GroupbyStmt;
        $ORDERBY = ($OderbyStmt === NULL)? "": $OderbyStmt;
        $OTHER = ($OtherStmt === NULL)? "": $OtherStmt;
        $STMT = $sqlStmt." ".$WHERE." ".$GROUPBY." ".$ORDERBY." ".$OTHER;
        
        if($escapeStr === TRUE){
            $resultValArr = array();
            foreach($valArray as $v){
                $resultValArr[] = $this->db->escape_str($v);
            }
        }

        if($resultValArr === NULL){
            $RESULT = $this->db->query($STMT);
        
        }else{
            $RESULT = $this->db->query($STMT, $resultValArr);
        }

        return $RESULT;
        
    }
	
	function usedDetect()
	{
		$this->load->library('Mobile_Detect');
		$userAgent  = $_SERVER['HTTP_USER_AGENT'];			
		
		$detect 	= new Mobile_Detect;			
		$detect->setUserAgent($userAgent);
				
		if ($detect->isMobile())
		{
			$device = 'Mobile';
		}else if ($detect->isTablet())
		{
			$device = 'Tablet';
		}else
		{
			$device = 'Desktop';
		}
		
		return $device;
	}
	
	function calculateAgeFromBirthday($dateOfBirth=null)
	{		
		$age 	= "";
		if($dateOfBirth != null)
		{
			$today 	= date("Y-m-d");
			$diff 	= date_diff(date_create($dateOfBirth), date_create($today));
			$age 	= $diff->format('%y');
		}
		return $age;
	}

	public function insertLogIussLine($detail)
	{
		$this->db->set('details', $detail);
		$this->db->insert('log_issue_line');
		return $this->db->insert_id();
	}
	
}