<?php

class History_model extends CI_Model{
	
    function __construct(){
		parent::__construct();
		$this->load->model('MainModel');  
    }

    function selectLogBadgeActivity($pid=null,$subId=null,$actId=null){
		$sql = "SELECT logId,abId,l.campId,l.subcampId,activityId,personId,l.lastupdatetime,l.badgeId,badgeName,file_path,badgeStatus,l.lastupdatetime
		FROM log_activity_badge l WITH (NOLOCK) 
		LEFT JOIN master_badge m ON l.badgeId = m.badgeId 
		WHERE 1=1";

		if($pid != "" || $pid != null)
		{
			$sql .= " AND personId = '".$pid."' ";
		}

		if($subId != "" || $subId != null)
		{
			$sql .= " AND l.subcampId = '".$subId."' ";
		}

		if($actId != "" || $actId != null)
		{
			$sql .= " AND l.activityId = '".$actId."' ";
		}

		$sql .= " ORDER BY createtime ASC";

		return $this->db->query($sql);
	}


    public function selectPersonHis($pId=null,$mount=null,$year=null,$order=null)
	{	
		$condition_field 	= '';
		$condition_value 	= array();
		$condition_value[] = $this->config->item('status_active');

		$ORDERBY 			= NULL;
		$OTHER 				= NULL;

		if($pId != "" || $pId != null)
		{
			$condition_field .= ' AND h.pers_id = ?';
			$condition_value[] = $pId;
        }
        
        if($year != "" || $year != null)
		{
			$condition_field .= " AND  FORMAT(perh_createdatetime, 'yyyy') = ?";
			$condition_value[] = $year;
        }
        
        if($mount != "" || $mount != null)
		{
			$condition_field .= " AND  FORMAT(perh_createdatetime, 'MM') = ?";
			$condition_value[] = $mount;
		}

		$condition_field .= " AND  ref_id IS NOT NULL";
		
		if($order != "" || $order != null)
		{
			$ORDERBY = "ORDER BY ".$order;
        } 


		$sql = $this->MainModel->getDataBind("SELECT  perh_id ,h.pers_id,h.ref_type_id,h.ref_id,perh_createby,perh_createdatetime,FORMAT(perh_createdatetime, 'd/MM/yy  hh:mm')as usedDate, FORMAT(perh_createdatetime, 'yyyy')as dateMount,pers_status,hist_id,hist_name,hist_status 
                                            FROM person_history h WITH (NOLOCK) 
                                            INNER JOIN master_history_type m ON m.hist_id = h.ref_type_id"
											,"WHERE perh_status = ? ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY
											,$OTHER);
		return $sql;
    }

    public function selectPersonPoint($pId=null,$ref_type = null,$ref_id = null,$order=null)
	{	
		$condition_field 	= '';
		$condition_value 	= array();
		$condition_value[] = $this->config->item('status_delete');

		$ORDERBY 			= NULL;
		$OTHER 				= NULL;

		if($pId != "" || $pId != null)
		{
			$condition_field .= ' AND p.pers_id = ?';
			$condition_value[] = $pId;
        }
        
        if($ref_type != "" || $ref_type != null)
		{
			$condition_field .= ' AND p.ref_type_id = ?';
			$condition_value[] = $ref_type;
        }

        if($ref_id != "" || $ref_id != null)
		{
			$condition_field .= ' AND p.ref_id = ?';
			$condition_value[] = $ref_id;
		}
		
		
		if($order != "" || $order != null)
		{
			$ORDERBY = "ORDER BY ".$order;
        }


		$sql = $this->MainModel->getDataBind("SELECT DISTINCT perp_id ,pers_id,ref_type_id,ref_id,hist_id,hist_name,hist_status ,perp_type,perp_point,perp_status,perp_createdatetime,perp_createby
                                            FROM person_point p WITH (NOLOCK) 
                                            LEFT JOIN master_history_type m ON m.hist_id = p.ref_type_id"
											,"WHERE perp_status != ? ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY
											,$OTHER);
		return $sql;
    }

    function selectHistoryMount($pers_id=null, $year=null){
		$sql = "SELECT FORMAT(perh_createdatetime, 'MM') as mount,pers_id
				FROM person_history  WITH (NOLOCK) 
                WHERE perh_status = 'A' AND pers_id = '".$pers_id."' AND FORMAT(perh_createdatetime, 'yyyy') = '".$year."' GROUP BY FORMAT(perh_createdatetime, 'MM') ,pers_id
				ORDER BY FORMAT(perh_createdatetime, 'MM') DESC";

		return $this->db->query($sql);
	}

	function SelectHisPrivilege($tier=null,$ref_id=null,$dateNow=null){
		$sql = "SELECT mpcId,c.ti_id,c.mprivId,mprivCode,is_used,usedby,usedtime,c.mprivType,codeExpired,mprivName,imgBanner,detail
				FROM member_privilege_code c WITH (NOLOCK) 
				LEFT JOIN member_privilege_setting s ON s.mprivId = c.mprivId
				WHERE c.mprivStatus = 'A' ";

		if($tier != "" || $tier != null)
		{
			$sql .= " AND c.ti_id = '".$tier."' ";
		}

		if($ref_id != "" || $ref_id != null)
		{
			$sql .= " AND c.mpcId = '".$ref_id."' ";
		}

		if($dateNow != "" || $dateNow != null)
		{
			$sql .= " AND startDisplay <= '".$dateNow."' AND endDisplay >= '".$dateNow."' ";
		}

		$sql .= " ORDER BY c.createtime DESC";

		return $this->db->query($sql);
	}
	
	function SelectHisService($id=null, $ref_id=null){
		$sql = "SELECT servId,peronId,caseType,quantity,serv_status,createtime,building,remark
				FROM service_request  WITH (NOLOCK) 
				WHERE source = 'LINE' ";

		if($id != "" || $id != null)
		{
			$sql .= " AND peronId = '".$id."' ";
		}
		
		if($ref_id != "" || $ref_id != null)
		{
			$sql .= " AND servId = '".$ref_id."' ";
		}

		$sql .= " ORDER BY servId DESC";

		return $this->db->query($sql);
	}

	public function SelectHisRedemp($pId=null,$ref_id = null,$order=null)
	{	
		$condition_field 	= '';
		$condition_value 	= array();
		$condition_value[] = $this->config->item('status_delete');

		$ORDERBY 			= NULL;
		$OTHER 				= NULL;

		if($pId != "" || $pId != null)
		{
			$condition_field .= ' AND t.person_id = ?';
			$condition_value[] = $pId;
        }

        if($ref_id != "" || $ref_id != null)
		{
			$condition_field .= ' AND t.rdt_id = ?';
			$condition_value[] = $ref_id;
		}
		
		
		if($order != "" || $order != null)
		{
			$ORDERBY = "ORDER BY ".$order;
		}
	  
		$sql = $this->MainModel->getDataBind("SELECT t.rdt_id, t.person_id, rdt_transnumber, rdt_createdatetime, 
		
		-- shpt_id,st.shop_id,shpt_payment_type,st.partner_id,crdt_id,shpt_card_no,shpt_card_holder,shpt_spending,shpt_remark,shpt_status,buld_id,shop_name,part_name,part_nation,
		rt.act_id,itm_id,item_code,item_type,item_name,rt.rwt_id,perp_type,perp_point,ref_type_id,activityCode,activityType,activityName,imgBanner,detail
                                            FROM redemption_transaction t WITH (NOLOCK) 
											-- LEFT JOIN redemption_shop_transaction st ON st.rdt_id = t.rdt_id
											-- LEFT JOIN master_shop s ON st.shop_id = s.shop_id
											-- LEFT JOIN master_partner mp ON st.partner_id = mp.part_id
											LEFT JOIN redemption_reward_transaction rt ON rt.rdt_id = t.rdt_id
											LEFT JOIN person_point p ON rt.rwt_id = p.ref_id AND p.ref_type_id = 1
											LEFT JOIN master_item i ON rt.itm_id = i.item_id
											LEFT JOIN activity a ON rt.act_id = a.activityI
											"
											,"WHERE perp_status != ? ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY
											,$OTHER);
		return $sql;
	}
	
	public function SelectHisRedemp_trans($pId=null,$ref_id = null,$order=null)
	{	
		$condition_field 	= '';
		$condition_value 	= array();
		$condition_value[] = $this->config->item('status_delete');

		$ORDERBY 			= NULL;
		$OTHER 				= NULL;

		if($pId != "" || $pId != null)
		{
			$condition_field .= ' AND person_id = ?';
			$condition_value[] = $pId;
        }

        if($ref_id != "" || $ref_id != null)
		{
			$condition_field .= ' AND rdt_id = ?';
			$condition_value[] = $ref_id;
		}
		
		
		if($order != "" || $order != null)
		{
			$ORDERBY = "ORDER BY ".$order;
		}
	  
		$sql = $this->MainModel->getDataBind("SELECT rdt_id, person_id, rdt_transnumber, rdt_createdatetime,rdt_status
                                            FROM redemption_transaction WITH (NOLOCK)" 
											,"WHERE rdt_status != ? ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY
											,$OTHER);
		return $sql;
	}

	
	
	public function SelectHisRedemp_reward($pId=null,$ref_id = null,$tarns = null,$order=null)
	{	
		$condition_field 	= '';
		$condition_value 	= array();
		// $condition_value[] = $this->config->item('status_delete');

		$ORDERBY 			= NULL;
		$OTHER 				= NULL;

		if($pId != "" || $pId != null)
		{
			$condition_field .= ' AND t.person_id = ?';
			$condition_value[] = $pId;
        }

        if($ref_id != "" || $ref_id != null)
		{
			$condition_field .= ' AND rt.rdt_id = ?';
			$condition_value[] = $ref_id;
		}

		if($tarns != "" || $tarns != null)
		{
			$condition_field .= ' AND rdt_transnumber = ?';
			$condition_value[] = $tarns;
		}
		
		
		if($order != "" || $order != null)
		{
			$ORDERBY = "ORDER BY ".$order;
		}
	  
		$sql = $this->MainModel->getDataBind("SELECT 
		-- t.rdt_id, t.person_id, rdt_transnumber, rdt_createdatetime,
		rt.act_id,itm_id,item_code,item_type,item_name,rt.rwt_id,rt.rwt_point,perp_type,perp_point,ref_type_id,activityCode,activityType,activityName,imgBanner,detail,rwt_id,rdt_id
                                            FROM redemption_reward_transaction rt WITH (NOLOCK) 
											-- LEFT JOIN redemption_reward_transaction rt ON rt.rdt_id = t.rdt_id
											-- LEFT JOIN person_point p ON rt.rwt_id = p.ref_id AND p.ref_type_id = 1
											LEFT JOIN person_point p ON rt.rwt_id = p.ref_id
											LEFT JOIN master_item i ON rt.itm_id = i.item_id
											LEFT JOIN activity a ON rt.act_id = a.activityId
											"
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY
											,$OTHER);
		return $sql;
    }

	public function SelectHisRedemp_rewardGroup($ref_id)
	{
		$this->db->select('sum(rwt_point) as rwt_point, i.item_name, a.activityName, a.imgBanner, p.perp_type');
		$this->db->from('redemption_reward_transaction rt WITH (NOLOCK)');
		$this->db->join('master_item i', 'rt.itm_id = i.item_id', 'left');
		$this->db->join('activity a', 'rt.act_id = a.activityId', 'left');
		$this->db->join('person_point p', 'rt.rwt_id = p.ref_id', 'left');
		$this->db->where('rt.rdt_id', $ref_id);
		$this->db->group_by('i.item_name, a.activityName, a.imgBanner, p.perp_type');
		$query = $this->db->get();
		return $query;
	}

	public function getActivity($activityId)
	{
		$this->db->where('activityId', $activityId);
		$query = $this->db->get('activity');
		return $query->row();
	}
	
	public function getActivityCode($historyId, $activityId)
	{
		$this->db->where('codeStatus', $this->config->item('status_active'));
		$this->db->where('historyId', $historyId);
		$this->db->where('activityId', $activityId);
		$query = $this->db->get('activity_code');
		return $query->row();
	}
	
	public function getActivityCodeByCodeId($codeId)
	{
		$this->db->where('codeStatus', $this->config->item('status_active'));
		$this->db->where('codeId', $codeId);
		$query = $this->db->get('activity_code');
		return $query->row();
	}
	
	public function getActivityRewardGetCodeID($codeId)
	{
		$this->db->where('rwStatus', $this->config->item('status_active'));
		$this->db->where('codeId', $codeId);
		$query = $this->db->get('activity_reward');
		return $query->row();
	}
	
	public function getActivityRewardCode($codeId, $activityId)
	{
		$this->db->where('rwStatus', $this->config->item('status_active'));
		$this->db->where('codeId', $codeId);
		$this->db->where('activityId', $activityId);
		$query = $this->db->get('activity_reward');
		return $query->row();
	}
	
	public function insertActivityReward($data)
	{
		$this->db->set('campId', $data['campId']);
		$this->db->set('subcampId', $data['subcampId']);
		$this->db->set('activityId', $data['activityId']);
		$this->db->set('ti_id', $data['ti_id']);
		$this->db->set('personId', $data['personId']);
		$this->db->set('codeId', $data['codeId']);
		$this->db->set('rwt_id', $data['rwt_id']);
		$this->db->set('rwStatus', $data['status']);
		$this->db->set('rewardStatus', $data['rewardStatus']);
		$this->db->set('usedtime', $data['usedtime']);
		$this->db->set('createtime', $data['dateTimeNow']);
		$this->db->set('balance', $data['balance']);
		$this->db->set('shopCode', $data['shopCode']);
		$this->db->set('voucher', $data['voucher']);
		$this->db->set('refChannel', $data['refChannel']);
		$query = $this->db->insert('activity_reward');
		return $query;
	}
	
	public function getActivityCheckIn($act_id, $pers_id)
	{
		// $this->db->where('chk_event', 'check-in');
		$this->db->where('chk_status', $this->config->item('status_active'));
		$this->db->where('act_id', $act_id);
		$this->db->where('pers_id', $pers_id);
		$query = $this->db->get('activity_check_in');
		return $query->result();
	}
	
	public function getActivityCheckInGrop($act_id, $pers_id, $historyId)
	{
		$sql = "SELECT
			c1.chk_id,
			c1.act_id,
			c1.historyId,
			c1.chk_event,
			c1.chk_telephone,
			c1.chk_createdatetime AS chk_checkin,
			(
			SELECT TOP
				( 1 ) c2.chk_createdatetime 
			FROM
				[cdpmkt].[dbo].[activity_check_in] c2 
			WHERE
				c2.chk_event = 'check-out' 
				AND c2.chk_id > c1.chk_id 
				AND c2.chk_telephone = c1.chk_telephone 
				AND c2.act_id = c1.act_id 
			) AS chk_checkout 
		FROM
			[cdpmkt].[dbo].[activity_check_in] c1 
		WHERE
			c1.chk_event = 'check-in' AND c1.act_id = ? AND c1.pers_id = ? AND c1.historyId = ? AND c1.chk_status = 'A'
		ORDER BY
			c1.chk_id DESC";
		$query = $this->db->query($sql, array($act_id, $pers_id, $historyId));
		return $query->result();
	}
	
	public function getActivityCheckOut($act_id, $pers_id)
	{
		$this->db->where('chk_event', 'check-out');
		$this->db->where('chk_status', $this->config->item('status_active'));
		$this->db->where('act_id', $act_id);
		$this->db->where('pers_id', $pers_id);
		$query = $this->db->get('activity_check_in');
		return $query->last_row();
	}
	
	public function getActivityReward($act_id, $pers_id)
	{
		$this->db->where('rwStatus', $this->config->item('status_active'));
		$this->db->where('activityId', $act_id);
		$this->db->where('personId', $pers_id);
		$query = $this->db->get('activity_reward');
		return $query->last_row();
	}
	
	public function getActivityData($historyId, $personId, $activityId)
	{
		$this->db->where('status', 'Complete');
		$this->db->where('historyId', $historyId);
		$this->db->where('personId', $personId);
		$this->db->where('activityId', $activityId);
		$query = $this->db->get('activity_data');
		return $query->row();
	}
	
	public function getPivilegeCodeAndSetting($personId, $ti_id, $ref_id)
	{
		$this->db->where('member_privilege_code.mprivStatus', $this->config->item('status_active'));
		$this->db->where('member_privilege_code.usedby', $personId);
		$this->db->where('member_privilege_code.ti_id', $ti_id);
		$this->db->where('member_privilege_code.mpcId', $ref_id);
		$this->db->from('member_privilege_code');
		$this->db->join('member_privilege_condition', 'member_privilege_code.mpc_id = member_privilege_condition.mpc_id', 'left');
		$this->db->join('member_privilege_setting', 'member_privilege_code.mprivId = member_privilege_setting.mprivId', 'left');
		$query = $this->db->get();
		return $query->last_row();
	}

	public function getPivilegeType($mptcId)
	{
		$this->db->where('mptcStatus', $this->config->item('status_active'));
		$this->db->where('mptcId', $mptcId);
		$query = $this->db->get('member_privilege_type');
		return $query->row();
	}
	
	public function getPersonPoint($personId, $ref_id, $ref_type_id, $historyId = null)
	{
		$this->db->where('perp_status', $this->config->item('status_active'));
		$this->db->where('pers_id', $personId);
		if ($historyId) {
			$this->db->where('historyId', $historyId); //data อันเก่า ก่อนหน้านี้ไม่มีมันจะหาไม่เจอ
		}
		$this->db->where('ref_id', $ref_id);
		$this->db->where('ref_type_id', $ref_type_id);
		$query = $this->db->get('person_point');
		return $query->last_row();
	}
	
	public function getPersonSumPoint($personId, $ref_id, $ref_type_id)
	{
		$this->db->select('perp_type, sum(perp_point)');
		$this->db->where('perp_status', $this->config->item('status_active'));
		$this->db->where('pers_id', $personId);
		// $this->db->where('historyId', $historyId); //data อันเก่า ก่อนหน้านี้ไม่มีมันจะหาไม่เจอ
		$this->db->where('ref_id', $ref_id);
		$this->db->where('ref_type_id', $ref_type_id);
		$this->db->group_by('perp_type, perp_point');
		$query = $this->db->get('person_point');
		return $query->last_row();
	}

	public function getPersonPointBirthday($personId, $month, $year, $ref_type_id)
	{
		$this->db->where('ref_type_id', $ref_type_id);
		$this->db->where('pers_id',$personId);
		$this->db->where("FORMAT(perp_createdatetime, 'MM') =", $month);
    	$this->db->where("FORMAT(perp_createdatetime, 'yyyy') =", $year);
		// $this->db->where('MONTH(perp_createdatetime)',$month);
    	// $this->db->where('YEAR(perp_createdatetime)',$year);
		$this->db->where('perp_status', $this->config->item('status_active'));
		$this->db->order_by('perp_createdatetime', 'DESC');
		$query = $this->db->get('person_point');
		return $query->result();
	}

	public function getMaster_shop($shopCode)
	{
		$this->db->where('shop_customer_number', $shopCode);
		$this->db->where('shop_status', $this->config->item('status_active'));
		$query = $this->db->get('master_shop');
		return $query->row();
	}
	

}
?>