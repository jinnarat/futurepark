<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Redeem_model extends CI_Model
{
    public function _get_redemption_activity($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity @type = ?, @activity_type = ?, @activity_start_datetime = ?, @activity_end_datetime = ?, @activity_status = ?, @activity_approval = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic @type = ?, @activity_id = ?, @mechanic_nation = ?, @mechanic_status = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_limit($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Limit @type = ?, @mechanic_id = ?, @limit_variable = ?, @limit_status = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_item_condition($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Item_Condition @type = ?, @mechanic_id = ?, @redemption_point_id = ?, @condition_status = ?, @condition_start_datetime = ?, @condition_end_datetime = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_item_condition_shop($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Item_Condition @type = ?, @mechanic_condition_id = ?, @shop_id = ?, @condition_status = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_item_condition_partner($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Item_Condition @type = ?, @mechanic_condition_id = ?, @partner_id = ?, @payment_type_id = ?, @card_type_id = ?, @condition_status = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_item_condition_no_slip($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Item_Condition @type = ?, @person_id = ?, @partner_id = ?, @redemption_point_id = ?, @condition_status = ?, @condition_start_datetime = ?, @condition_end_datetime = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_item_condition_reward($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Item_Condition_Reward @type = ?, @person_id = ?, @mechanic_condition_id = ?, @redemption_point_id = ?, @shop_id = ?, @is_member = ?, @mechanic_condition_spending = ?, @partner_id = ?, @payment_type_id = ?, @card_type_id = ?, @condition_status = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_limit_member_reward($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Limit @type = ?, @person_id = ?, @mechanic_id = ?, @item_id = ?, @exclude_transaction_number = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_limit_member_cashback($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Limit @type = ?, @person_id = ?, @mechanic_id = ?, @item_id = ?, @exclude_transaction_number = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_limit_member_point($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Limit @type = ?, @person_id = ?, @mechanic_id = ?, @item_id = ?, @exclude_transaction_number = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_limit_item_reward($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Limit @type = ?, @mechanic_id = ?, @item_id = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_limit_item_cashback($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Limit @type = ?, @mechanic_id = ?, @item_id = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_limit_item_point($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Limit @type = ?, @mechanic_id = ?, @item_id = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function _get_redemption_activity_mechanic_limit_item_shop($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Limit @type = ?, @person_id = ?, @shop_id = ?, @payment_type = ?, @partner_id = ?, @card_type_id = ?, @exclude_transaction_number = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function _get_redemption_point($parameter)
    {
        return $this->db->query('EXEC _Redemption_Point @type = ?, @member_tier_id = ?, @person_id = ?, @reward_type = ?, @item_type = ?, @redemption_reward_type_id = ?, @privilege_reward_type_id = ?, @privilege_code = ?, @activity_start_datetime = ?, @activity_end_datetime = ?, @condition_status = ?', $parameter);
    }

    public function _get_privilege_birthday($parameter)
    {
        return $this->db->query('EXEC _Redemption_Point @type = ?, @member_tier_id = ?, @activity_start_datetime = ?, @activity_end_datetime = ?, @condition_status = ?', $parameter);
    }

    public function _get_privilege_check_in_check_out_status($parameter)
    {
        return $this->db->query('EXEC _Redemption_Point @type = ?, @person_id = ?, @privilege_id = ?, @privilege_condition_id = ?, @privilege_code = ?, @condition_status = ?, @transaction_date = ?', $parameter);
    }

    public function _get_privilege_code_status($parameter)
    {
        return $this->db->query('EXEC _Redemption_Point @type = ?, @person_id = ?, @privilege_condition_id = ?, @privilege_code_id = ?, @condition_status = ?', $parameter);
    }

    public function _get_member_point_mechanic($parameter)
    {
        return $this->db->query('EXEC _Member_Point_Mechanic @type = ?, @mechanic_status = ?', $parameter);
    }

    public function _get_member_point_mechanic_item_condition($parameter)
    {
        return $this->db->query('EXEC _Member_Point_Mechanic_Item_Condition @type = ?, @mechanic_id = ?, @condition_status = ?', $parameter);
    }

    public function _get_member_point_mechanic_item_condition_shop($parameter)
    {
        return $this->db->query('EXEC _Member_Point_Mechanic_Item_Condition @type = ?, @mechanic_condition_id = ?, @shop_id = ?, @condition_status = ?', $parameter);
    }

    public function _get_member_point_mechanic_item_condition_partner($parameter)
    {
        return $this->db->query('EXEC _Member_Point_Mechanic_Item_Condition @type = ?, @mechanic_condition_id = ?, @partner_id = ?, @payment_type_id = ?, @card_type_id = ?, @condition_status = ?', $parameter);
    }

    public function _get_member_point_mechanic_item_condition_reward($parameter)
    {
        return $this->db->query('EXEC  _Member_Point_Mechanic_Item_Condition_Reward @type = ?, @person_id = ?, @mechanic_condition_id = ?, @shop_id = ?, @mechanic_condition_spending = ?, @partner_id = ?, @payment_type_id = ?, @card_type_id = ?, @condition_status = ?', $parameter);
    }

    public function _get_member_point_mechanic_limit($parameter)
    {
        return $this->db->query('EXEC  _Member_Point_Mechanic_Limit @type = ?, @mechanic_id = ?, @limit_variable = ?, @limit_status = ?', $parameter);
    }

    public function _get_member_point_mechanic_limit_member_reward($parameter)
    {
        return $this->db->query('EXEC _Member_Point_Mechanic_Limit @type = ?, @person_id = ?, @mechanic_id = ?, @item_id = ?, @exclude_transaction_number = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function _get_member_point_mechanic_limit_member_cashback($parameter)
    {
        return $this->db->query('EXEC _Member_Point_Mechanic_Limit @type = ?, @person_id = ?, @mechanic_id = ?, @item_id = ?, @exclude_transaction_number = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function _get_member_point_mechanic_limit_member_point($parameter)
    {
        return $this->db->query('EXEC _Member_Point_Mechanic_Limit @type = ?, @person_id = ?, @mechanic_id = ?, @item_id = ?, @exclude_transaction_number = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function _get_member_point_mechanic_limit_item_reward($parameter)
    {
        return $this->db->query('EXEC _Member_Point_Mechanic_Limit @type = ?, @mechanic_id = ?, @item_id = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function _get_member_point_mechanic_limit_item_cashback($parameter)
    {
        return $this->db->query('EXEC _Member_Point_Mechanic_Limit @type = ?, @mechanic_id = ?, @item_id = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function _get_member_point_mechanic_limit_item_point($parameter)
    {
        return $this->db->query('EXEC _Member_Point_Mechanic_Limit @type = ?, @mechanic_id = ?, @item_id = ?, @transaction_start_datetime = ?, @transaction_end_datetime = ?, @transaction_status = ?', $parameter);
    }

    public function get_redeem_point_status($parameter)
    {
        return $this->db->query('EXEC _Redemption_Point @type = ?, @person_id = ?, @point_reference_1_id = ?, @point_reference_2_id = ?, @point_reference_3_id = ?, @point_reference_4_id = ?', $parameter);
    }

    public function _check_redeem_code($parameter)
    {
        return $this->db->query('EXEC _Redemption_Point @type = ?, @point_reference_1_id = ?, @point_reference_2_id = ?, @point_reference_3_id = ?, @point_reference_4_id = ?, @privilege_code = ?, @condition_status = ?', $parameter);
    }

    public function _get_redeem_point_limit($parameter)
    {
        return $this->db->query('EXEC _Redemption_Activity_Mechanic_Limit @type = ?, @mechanic_id = ?, @limit_status = ?', $parameter);
    }

    public function _get_redeem_point_limit_customer_reward($parameter)
    {
        return $this->db->query('EXEC _Redemption_Point @type = ?, @person_id = ?, @point_reference_1_id = ?, @point_reference_2_id = ?, @point_reference_3_id = ?, @point_reference_4_id = ?, @point_status = ?', $parameter);
    }

    public function _get_redeem_point_limit_item_reward($parameter)
    {
        return $this->db->query('EXEC _Redemption_Point @type = ?, @point_reference_1_id = ?, @point_reference_2_id = ?, @point_reference_3_id = ?, @point_reference_4_id = ?, @point_status = ?', $parameter);
    }

    public function _get_redeem_point_period($parameter)
    {
        return $this->db->query('EXEC _Redemption_Point @type = ?, @point_reference_1_id = ?,', $parameter);
    }
}
