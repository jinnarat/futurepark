<?php
class QRCodeModel extends CI_Model 
{
    function __construct()
    {
        parent::__construct();
		$this->load->library('phpqrcode/qrlib');
    }
	
    public function qrcodeGenerator($qrtext=null,$actCode=null,$person_id=null)
    {		
		$result	= "";
		if($qrtext != '' || $qrtext != null)
		{
			//file path for store images
			$path = "uploads/qrcode/".$actCode;
			if (!file_exists($path)) {
				mkdir($path,0755, true);
			} 					
		    $SERVERFILEPATH = $path."/"; //$_SERVER['DOCUMENT_ROOT'].'/qrcode-generation-in-codeigniter/images/';
		   
			$enTextGenQr = $this->MainModel->Base64Encrypt($qrtext);

			$text = $enTextGenQr;
			$text1= substr($text, 0,10);
			
			$folder = $SERVERFILEPATH;
			$file_name1 = $person_id."-Qrcode.png";
			$file_name = $folder.$file_name1;
			QRcode::png($text,$file_name,$margin = 2);
			
			$result	= $file_name;			
		}
		
		return $result;
	}	
	
	public function qrcodeGeneratorPriv($qrtext=null,$privilegeCode=null,$filename=null)
    {		
		$result	= "";
		if($qrtext != '' || $qrtext != null)
		{
			//file path for store images
			$path = PATHIMGSHOP."uploads/privilege/qrcode/".$privilegeCode;
			if (!file_exists($path)) {
				mkdir($path,0755, true);
			} 					
		    $SERVERFILEPATH = $path."/"; //$_SERVER['DOCUMENT_ROOT'].'/qrcode-generation-in-codeigniter/images/';


			$text = $qrtext;
			// $text1= substr($text, 0,10);
			
			$folder = $SERVERFILEPATH;
			$file_name1 = $filename."-Qrcode.png";
			$file_name = $folder.$file_name1;
			QRcode::png($text,$file_name,$margin = 2);
			
			$result	= $file_name;			
		}
		
		return $result;
    }
}