<?php
class PersonModel extends CI_Model 
{
    function __construct()
    {
        parent::__construct();
	}
	
	public function getPerson($personId=null,$mobileNo=null,$idCardNo=null,$email=null,$status=null,$ORDERBY=null,$unique=null,$passaport=null,$conCheck=null,$uniMem = null){
		
		$condition_field = '';
		$condition_value = array();
		
		if($personId != "" || $personId != null)
		{
			$condition_field .= ' AND personId = ?';
			$condition_value[] = $personId;
		}
		
		if($mobileNo != "" || $mobileNo != null)
		{
			$condition_field .= " AND REPLACE(REPLACE(mobileNo, '-', ''),' ','') = ? ";
			$condition_value[] = $mobileNo;
		}
		
		if($idCardNo != "" || $idCardNo != null)
		{
			$condition_field .= ' AND idCardNo = ?';
			$condition_value[] = $idCardNo;
		}
		
		if($email != "" || $email != null)
		{
			$condition_field .= ' AND email = ?';
			$condition_value[] = $email;
		}	

		if($status != "" || $status != null)
		{
			$condition_field .= ' AND personStatus = ?';
			$condition_value[] = $status;
		}
		
		if($unique != "" || $unique != null)
		{
			$condition_field .= ' AND (verify_phone = ? OR verify_email = ? OR verify_idcard = ?)';
			$condition_value[] = $unique;			
			$condition_value[] = $unique;			
			$condition_value[] = $unique;			
		}

		if($passaport != "" || $passaport != null)
		{
			$condition_field .= ' AND passportNo = ?';
			$condition_value[] = $passaport;
		}

		if($conCheck != "" || $conCheck != null)
		{
			$condition_field .= ' AND personId != ?';
			$condition_value[] = $conCheck;
		}

		if($uniMem != "" || $uniMem != null)
		{
			$condition_field .= ' AND is_member != ?';
			$condition_value[] = $uniMem;
		}

		if($unique != "" || $unique != null)
		{
			$condition_field .= ' AND (verify_phone = ? OR verify_email = ? OR verify_idcard = ?)';
			$condition_value[] = $unique;			
			$condition_value[] = $unique;			
			$condition_value[] = $unique;			
		}
		
		if($ORDERBY == null || $ORDERBY == "")
		{
			$ORDERBY = " ORDER BY personId";
		}else{
			$ORDERBY = " ORDER BY ".$ORDERBY;
		}
			
		$sql = $this->MainModel->getDataBind("SELECT personId, memberNo, idCardNo, passportNo, mobileNo, mobileFullNo, email, firstname, lastname,gender, birthdate, age, nationCode, technologyAdoption, preferredChannel, source, personStatus, createtime, lastupdatetime, firstname as displayFirstname, lastname as displayLastname, person_point_spending,person_point_accumulate,person_point_balance,
												verify_phone, verify_email, verify_idcard
											 FROM person WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY);
		return $sql;
	}


	public function getPersonSelect($personId=null,$mobileNo=null,$status=null,$ORDERBY=null,$unique=null){
		
		$condition_field = '';
		$condition_value = array();
		
		if($personId != "" || $personId != null)
		{
			$condition_field .= ' AND personId = ?';
			$condition_value[] = $personId;
		}
		
		if($mobileNo != "" || $mobileNo != null)
		{
			$condition_field .= " AND REPLACE(REPLACE(mobileNo, '-', ''),' ','') = ? ";
			$condition_value[] = $mobileNo;
		}

		if($status != "" || $status != null)
		{
			$condition_field .= ' AND personStatus = ?';
			$condition_value[] = $status;
		}
		
		if($unique != "" || $unique != null)
		{
			$condition_field .= ' AND (verify_phone = ? OR verify_email = ? OR verify_idcard = ? OR is_member = ?)';
			$condition_value[] = $unique;			
			$condition_value[] = $unique;			
			$condition_value[] = $unique;	
			$condition_value[] = $unique;		
		}

		if($ORDERBY == null || $ORDERBY == "")
		{
			$ORDERBY = " ORDER BY personId";
		}else{
			$ORDERBY = " ORDER BY ".$ORDERBY;
		}
			
		$sql = $this->MainModel->getDataBind("SELECT personId, memberNo, idCardNo, passportNo, mobileNo, mobileFullNo, email, firstname, lastname,gender, birthdate, age, nationCode, technologyAdoption, preferredChannel, source, personStatus, createtime, lastupdatetime, firstname as displayFirstname, lastname as displayLastname, person_point_spending,person_point_accumulate,person_point_balance,
												verify_phone, verify_email, verify_idcard,is_member
											 FROM person WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY);
		return $sql;
	}

	public function getPersonOldSelect($mobileNo=null,$memNo=null,$ORDERBY=null){
		
		$condition_field = '';
		$condition_value = array();
		
		
		if($mobileNo != "" || $mobileNo != null)
		{
			$condition_field .= " AND REPLACE(REPLACE(mobileNo, '-', ''),' ','') = ? ";
			$condition_value[] = $mobileNo;
		}

		if($memNo != "" || $memNo != null)
		{
			$condition_field .= ' AND memberNoRef = ?';
			$condition_value[] = $memNo;
		}

		if($ORDERBY == null || $ORDERBY == "")
		{
			$ORDERBY = " ORDER BY verify_phone DESC, personId DESC";
		}else{
			$ORDERBY = " ORDER BY ".$ORDERBY;
		}
			
		$sql = $this->MainModel->getDataBind("SELECT personId, memberNo, idCardNo, passportNo, mobileNo, mobileFullNo, email, firstname, lastname,gender, birthdate, age, nationCode, technologyAdoption, preferredChannel, source, personStatus, createtime, lastupdatetime, firstname as displayFirstname, lastname as displayLastname, person_point_spending,person_point_accumulate,person_point_balance,memberNoRef,register_datetime,verify_phone, verify_email, verify_idcard,is_member
											 FROM person WITH (NOLOCK) "
											,"WHERE personStatus = 'A' ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY);
		return $sql;
	}
	
	public function getAddressPerson($personId=null,$addrId=null,$addrType=null,$status=null){
		
		$condition_field = '';
		$condition_value = array();
		
		if($personId != "" || $personId != null)
		{
			$condition_field .= ' AND personId = ?';
			$condition_value[] = $personId;
		}		
		
		if($addrId != "" || $addrId != null)
		{
			$condition_field .= ' AND addrId = ?';
			$condition_value[] = $addrId;
		}
		
		if($addrType != "" || $addrType != null)
		{
			$condition_field .= ' AND addrType = ?';
			$condition_value[] = $addrType;
		}	

		if($status != "" || $status != null)
		{
			$condition_field .= ' AND addrStatus = ?';
			$condition_value[] = $status;
		}		
				
		$sql = $this->MainModel->getDataBind("SELECT addrId, personId, memberNo, addrType, detail, subDistrictCode, districtCode, provinceCode, 
												postcode, addrStatus, isDefault, createby, createtime, lastupdateby, lastupdatetime
											 FROM person_address a WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = NULL);
		return $sql;
	}
	
	public function getSocialPerson($personId=null,$socialId=null,$socialType=null,$status=null){
		
		$condition_field = '';
		$condition_value = array();
		
		if($personId != "" || $personId != null)
		{
			$condition_field .= ' AND personId = ?';
			$condition_value[] = $personId;
		}		
		
		if($socialId != "" || $socialId != null)
		{
			$condition_field .= ' AND socialId = ?';
			$condition_value[] = $socialId;
		}
		
		if($socialType != "" || $socialType != null)
		{
			$condition_field .= ' AND socialType = ?';
			$condition_value[] = $socialType;
		}	

		if($status != "" || $status != null)
		{
			$condition_field .= ' AND socialStatus = ?';
			$condition_value[] = $status;
		}		
				
		$sql = $this->MainModel->getDataBind("SELECT socialId, personId, memberNo, socialType, socialValue, socialStatus, 
												createby, createtime, lastupdateby, lastupdatetime
											 FROM person_social a WITH (NOLOCK) "
											,"WHERE 1=1 ".$condition_field
											,$VALUE = $condition_value
											,$GROUPBY = NULL
											,$ORDERBY = NULL);
		return $sql;
	}
	
	public function getMemberPrivilegeSettingByID($mps_id)
	{
		$this->db->where('mps_id', $mps_id);
		$this->db->where('mps_status', $this->config->item('status_active'));
		$query = $this->db->get('member_privilege_setting');
		return $query->row();
	}
	
	public function getMemberPrivilegeCode($personId, $mprivId)
	{
		$this->db->where('usedby', $personId);
		$this->db->where('mprivId', $mprivId);
		$this->db->where('status', $this->config->item('status_active'));
		$query = $this->db->get('member_privilege_code');
		return $query->reuslt();
	}
	
	public function getMemberPrivilegeCondition($mprivId, $ti_id)
	{
		$this->db->where('mprivId', $mprivId);
		$this->db->where('ti_id', $ti_id);
		$this->db->where('status', $this->config->item('status_active'));
		$query = $this->db->get('member_privilege_condition');
		return $query->row();
	}
	
	public function getCountAllLimitCode($mprivId, $ti_id, $pId)
	{
		$this->db->where('mprivId', $mprivId);
		$this->db->where('ti_id', $ti_id);
		$this->db->where('usedby', $pId);
		$this->db->where('mprivStatus', 'A');
		$this->db->where('is_used', 'Y');
		$query = $this->db->get('member_privilege_code');
		return $query->num_rows();
	}
	
	public function getCountDayLimitCode($mprivId, $ti_id, $pId)
	{
		$this->db->where('mprivId', $mprivId);
		$this->db->where('ti_id', $ti_id);
		$this->db->where('usedby', $pId);
		$this->db->where('mprivStatus', 'A');
		$this->db->where('is_used', 'Y');
		$this->db->where('usedtime >=', date('Y-m-d 00:00:00'));
		$this->db->where('usedtime <=', date('Y-m-d 23:59:59'));
		$query = $this->db->get('member_privilege_code');
		return $query->num_rows();
	}

	public function getPersonData($personId)
	{
		$this->db->where('personId', $personId);
		$this->db->where('is_member', 'Y');
		// $this->db->where('personStatus', $this->config->item('status_active'));
		$this->db->where('personStatus !=', $this->config->item('status_delete'));
		$query = $this->db->get('person');
		return $query->row();
	}
	
	public function getPersonDataByPersonID($personId)
	{
		$this->db->where('personId', $personId);
		$this->db->where('personStatus !=', $this->config->item('status_delete'));
		$query = $this->db->get('person');
		return $query->row();
	}
	
	public function getPersonDataByPhone($mobileNo)
	{
		$this->db->where('mobileNo', $mobileNo);
		$this->db->where('personStatus !=', $this->config->item('status_delete'));
		$query = $this->db->get('person');
		return $query->result();
	}

	public function updatePointPerson($data)
    {
        // $this->db->set('person_point_bonus', $data['point_bonus']);
        // $this->db->set('person_point_accumulate', $data['point_accumulate']);
        $this->db->set('person_point_spending', $data['point_spending']);
        $this->db->set('person_point_balance', $data['point_balance']);
        $this->db->set('lastupdatetime', $data['datetime_now']);
        $this->db->set('lastupdateby', $data['person_id']);
        $this->db->where('personId', $data['person_id']);
        $query = $this->db->update('person');
        return $query;
    }

	public function insertPersonHistory($data)
	{
		$this->db->set('pers_id', $data['personId']);
		$this->db->set('ref_type_id', $data['ref_type_id']);
		$this->db->set('ref_id', $data['ref_id']);
		$this->db->set('perh_createby', $data['personId']);
		$this->db->set('perh_createdatetime', $data['dateTimeNow']);
		$this->db->set('perh_status', $this->config->item('status_active'));
		$this->db->set('pers_status', $data['pers_status']);
		$this->db->insert('person_history');
		return $this->db->insert_id();
	}

	public function insertPersonPoint($data)
	{
		$this->db->set('ref_type_id', $data['ref_type_id']);
		$this->db->set('ref_id', $data['ref_id']);
		$this->db->set('historyId', $data['personHistoryID']);
		$this->db->set('ti_id', $data['tierId']);
		$this->db->set('pers_id', $data['personId']);
		$this->db->set('perp_type', $data['perp_type']);
		$this->db->set('perp_point', $data['perp_point']);
		$this->db->set('perp_status', $data['perp_status']);
		$this->db->set('perp_createdatetime', $data['dateTimeNow']);
		$this->db->set('perp_createby', $data['personId']);
		$this->db->set('perp_updatedatetime', $data['dateTimeNow']);
		$this->db->set('perp_updateby', $data['personId']);
		$this->db->insert('person_point');
		return $this->db->insert_id();
	}

	public function getDuplicate($dataCheck = null, $dataType = null, $personId)
	{
		if ($dataType) {
			if ($dataType == 'phone') {
				$this->db->where('mobileNo', $dataCheck);
			}else if ($dataType == 'email') {
				$this->db->where('email', $dataCheck);
			}else if ($dataType == 'idcard') {
				$this->db->where('idCardNo', $dataCheck);
			}else if ($dataType == 'memberNoRef') {
				$this->db->where('memberNoRef', $dataCheck);
			}else if ($dataType == 'passport') {
				$this->db->where('passportNo', $dataCheck);
			}else {
				return false;
			}
			if ($personId) {
				$this->db->where('personId !=', $personId);
			}
			$this->db->where('personStatus !=', $this->config->item('status_delete'));
			$query =$this->db->get('person');
			return $query->row();
		}else {
			return false;
		}
	}

	public function getPersonSessionId($personId)
	{
		$this->db->select('psid_session_id');
		$this->db->where('personId', $personId);
		$this->db->where('psid_status', 'Active');
		$query = $this->db->get('person_session_id');
		return $query->row() ? $query->row()->psid_session_id : null;
	}
	
	public function getCurrentAddressPersonByPersonId($personId)
	{
		$this->db->where('personId', $personId);
		$this->db->where('addrType', 'Current');
		$this->db->where('addrStatus', $this->config->item('status_active'));
		$query = $this->db->get('person_address');
		return $query->row();
	}
}