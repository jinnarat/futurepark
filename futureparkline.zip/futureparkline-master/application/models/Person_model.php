<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Person_model extends CI_Model
{
    public function _get($parameter)
    {
        return $this->db->query('EXEC _Redemption_Person @type = ?, @mobile_no = ?, @id_card = ?, @member_number = ?, @privilege_code = ?, @include_person_status = ?, @exclude_person_status = ?, @include_member_status = ?, @exclude_member_status = ?', $parameter);
    }

    public function _get_point($parameter)
    {
        return $this->db->query('EXEC _Person_Point @type = ?, @person_id = ?', $parameter);
    }

    public function _get_point_awarded($parameter)
    {
        return $this->db->query('EXEC _Person_Point @type = ?, @person_id = ?, @point_type = ?, @reference_type_id = ?, @transaction_status = ?', $parameter);
    }

    public function _get_point_per_day($parameter)
    {
        return $this->db->query('EXEC _Redemption_Person @type = ?, @person_id = ?, @exclude_transaction_number = ?, @transaction_date = ?, @include_point_status = ?, @exclude_point_status = ?', $parameter);
    }

    public function _get_reward_received_list($parameter)
    {
        return $this->db->query('EXEC _Person_Received @type = ?, @mobile_no = ?, @id_card = ?, @member_number = ?, @activity_reward_id = ?, @activity_id = ?, @transaction_status = ?', $parameter);
    }

    public function _get_form_data($parameter)
    {
        return $this->db->query('EXEC _Person_Received @type = ?,  @activity_id = ?, @history_id = ?', $parameter);
    }

    public function _insert($parameter)
    {
        return $this->db->query('EXEC _Redemption_Person @type = ?, @firstname = ?, @lastname = ?, @date_of_birth = ?, @gender = ?, @age = ?, @nation_code = ?, @id_card = ?, @passport_no = ?, @mobile_no = ?, @email = ?, @chanel = ?, @is_redemption = ?, @person_status = ?,  @createdatetime = ?, @updatedatetime = ?', $parameter);
    }

    public function _insert_history($parameter)
    {
        return $this->db->query('EXEC _Person_History @type = ?, @person_id = ?, @reference_type_id = ?, @reference_id = ?, @reference_source = ?, @history_status = ?, @history_createdatetime = ?, @history_createby = ?, @person_status = ?', $parameter);
    }

    public function _insert_point($parameter)
    {
        return $this->db->query('EXEC _Person_Point @type = ?, @person_id = ?, @reference_type_id = ?, @reference_id = ?, @point_type = ?, @point_value = ?, @point_status = ?, @point_createdatetime = ?, @point_createby = ?, @point_updatedatetime = ?, @point_updateby = ?', $parameter);
    }

    public function _insert_address($parameter)
    {
        return $this->db->query('EXEC _Person_Address @type = ?, @person_id = ?, @member_no = ?, @address_type = ?, @address_no = ?, @sub_district_code = ?, @district_code = ?, @province_code = ?, @postcode = ?, @status = ?, @createdatetime = ?, @updatedatetime = ?', $parameter);
    }

    public function _insert_reward_received($parameter)
    {
        return $this->db->query('EXEC _Person_Received @type = ?, @redemption_point_id = ?, @campagn_id = ?, @sub_campaign_id = ?, @activity_id = ?, @tier_id = ?, @person_id = ?, @history_id = ?, @activity_reward_id = ?, @item_id = ?, @use_datetime = ?, @received_status = ?, @transaction_status = ?, @received_remark = ?, @transaction_createdatetime = ?, @transaction_createby = ?, @transaction_updatedatetime = ?, @transaction_updateby = ?', $parameter);
    }

    public function _update($parameter)
    {
        return $this->db->query('EXEC _Redemption_Person @type = ?, @person_id = ?, @is_redemption = ?', $parameter);
    }

    public function _update_point($parameter)
    {
        return $this->db->query('EXEC _Person_Point @type = ?, @point_id = ?, @reference_type_id = ?, @transaction_number = ?, @include_reference_type_id = ?, @exclude_reference_type_id = ?, @reference_id = ?, @history_id = ?, @point_type = ?, @point_status = ?, @point_updatedatetime = ?, @point_updateby = ?', $parameter);
    }

    public function _update_person_point($parameter)
    {
        return $this->db->query('EXEC _Person_Point @type = ?, @person_id = ?, @person_point_accumulate = ?, @person_point_balance = ?, @person_point_spending = ?', $parameter);
    }

    public function _udpate_reward_received($parameter)
    {
        return $this->db->query('EXEC _Person_Received @type = ?, @activity_reward_id = ?, @received_remark = ?, @received_status = ?, @received_datetime = ?, @received_by = ?', $parameter);
    }
}
