<?php

class Main_function extends CI_Model
{
    function __construct(){
        parent::__construct();
    }
    function convertToTIS($string){
        return iconv("utf-8","tis-620//IGNORE",$string);
    }
    function convertToUTF($string){
        return iconv("tis-620","UTF-8//IGNORE",$string);
    }
	function showMessage($mess, $url) {
		print "<script language = 'JavaScript'>\n";
		print "     mess = \"".$mess."\";\n";
		print "		alert(mess)\n";
		print "</script>\n";
		if ($url != "null") {
			print  "<meta http-equiv=\"refresh\" content=\"0;url=$url\">";
			exit;
		}
	}
	function showMessageThenBack($mess) {
		print "<script language = 'JavaScript'>\n";
		print "     mess = \"".$mess."\";\n";
		print "		alert(mess);	\n";
		print "		window.history.back();	\n";
		//print "		return false; \n";
		print "</script>\n";
		exit();
	}	
	
	function addUserLog($info=null, $code=null, $table=null){
		$data['user_id'] 	= $this->session->userdata('uid');
		$data['name'] 	= $this->session->userdata('uname');
		$data['lastupdate'] = date("Y-m-d H:i:s");
		$data['action_info'] = $info;
		$data['action_url'] = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$data['action_code'] = $code;
		$data['action_table'] = $table;
		$data['ip'] = $_SERVER['REMOTE_ADDR'];
		
		$result = "uid : ".$data['user_id']." uname : ".$data['name']." url : ".$data['action_url']." info : ".$data['action_info']." code : ".$data['action_code']." table : ".$data['action_table']." ip : ".$data['ip'];
		if($this->db->insert('user_log', $data))
		{
			//echo "pass";
			$result = "pass";
		}
		return $result;
	}
	
	
	function html_chars($text=null){
		$result = htmlspecialchars(stripslashes(trim($text)), ENT_QUOTES);
		return $result;
	}

	function replace_introtext($text=null){		
		$result = preg_replace("/[^a-z0-9\.,\_\-ก-ฮะาิีุูเะแำไใๆ่้๊๋ั็์ึื ]/i", "", trim($text));		
		return $result;
	}

	function send_email($from=null, $email_to=null, $subject=null, $body=null, $bcc="jinnarat.r@sundae.co.th"){		
		$user_id 	= $this->session->userdata('uid');

		$this->load->library('email');
		
		$config['protocol']    = 'smtp';
        $config['smtp_host']    = SMTPHOST;
        $config['smtp_port']    = SMTPPORT;
		// $config['smtp_crypto']    = 'ssl';
        $config['smtp_timeout'] = '60';
        $config['smtp_user']    = SMTPUSER;
        $config['smtp_pass']    = SMTPPASSWORD;
        $config['charset']    = 'utf-8';
        $config['newline']    = "\r\n";
		//$config['crlf']    = "\r\n";
        $config['mailtype'] = 'html'; // or html
		$config['validation'] = TRUE; // bool whether to validate email or not      

        $this->email->initialize($config);
		
		$this->email->clear();
		$this->email->from('jinnarat.r@sundae.co.th', 'Fostat');
		$this->email->to($email_to);
		$this->email->bcc($bcc);
		$this->email->subject($subject);
		$this->email->message($body);
		
		// echo $this->email->print_debugger();
		if($this->email->send()){
			return true;
		}else{
			return false;  
		}
	}

	function template_mail($subject=null, $body=null){
		$uri = base_url();

		$html = "";
		$html .= "<table align='center' width='100%' style='width: 100%;' border='0' cellspacing='0' cellpadding='0'>";
		$html .= "
			<tr height='15'></tr>
			<tr>
				<td width='10%'></td>
				<td width='80%' align='center'>
					<table  width='100%' style='width: 100%;' border='0' cellspacing='0' cellpadding='0'>
						<tr>
							<td width='300' align='left'>
								<img src='".$uri."/assets/images/logo_infosearch.png?v=1.0' height='48' />
							</td>
							<td align='right' valign='bottom' style='font-family: Tahoma, Geneva, sans-serif; font-size: 16px; font-weight: bold; text-align: right;color:#0b6aff;'>
								<span style='color:#0b6aff;: Tahoma, Geneva, sans-serif; font-size: 16px;line-height:30px;'>".$subject."</span>
							</td>
							<td width='20'></td>
						</tr>
					</table>
				</td>
				<td width='10%'></td>
			</tr>
			<tr height='7'><td width='100%' colspan='3'></td></tr>
			<tr height='1'><td width='100%' colspan='3'></td></tr>
			<tr height='20'></tr>
			<tr>
				<td width='100%' colspan='3' bgcolor='#eeeeee'>".$body."</td>
			</tr>
			<tr height='20'></tr>
			<tr bgcolor='#414143'>
				<td width='8%'></td>
				<td width='84%' align='center'>
					<table  width='100%' style='width: 100%;' border='0' cellspacing='0' cellpadding='0'>
						<tr height='30'></tr>
						<tr>
							<td width='4%'></td>
							<td width='20%' valign='top' style='font-family: Tahoma, Geneva, sans-serif; font-size: 16px;'>
								<p style='margin:0 0 15px;'><a href='#'><span style='color:#ffffff;: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:30px;'>About Us</span></a></p>
								<p style='margin:0;'><a href='".$uri.$this->Main_function->getsMenu("ABOUT_INFO")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>About Infosearch</span></a></p>
								<p style='margin:0;'><a href='".$uri.$this->Main_function->getsMenu("MANAGEMENT")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>Management</span></a></p>
								<p style='margin:0;'><a href='".$uri.$this->Main_function->getsMenu("FACILITY")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>Facility</span></a></p>
								<p style='margin:0;'><a href='".$uri.$this->Main_function->getsMenu("MEMBERSHIP")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>Membership</span></a></p>
							</td>
							<td width='22%' valign='top' style='font-family: Tahoma, Geneva, sans-serif; font-size: 16px;'>
								<p style='margin:0 0 15px;'><a href='#'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:30px;'>Product &#38; Service</span></a></p>
								<p style='margin:0;'><a href='".$uri.$this->Main_function->getsMenu("PRODUCT_HEAD")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>Products</span></a></p>
								<p style='margin:0;'><a href='".$uri.$this->Main_function->getsMenu("SERVICE_HEAD")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>Servies</span></a></p>
								<p style='margin:0;'><a href='".$uri.$this->Main_function->getsMenu("METHODOLOGY_RESEARCH")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>Research Methodology</span></a></p>
								<p style='margin:0;'><a href='".$uri.$this->Main_function->getsMenu("QUANTITATIVE_RESEARCH")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>Quantitative Research</span></a></p>
								<p style='margin:0;'><a href='".$uri.$this->Main_function->getsMenu("QUALITATIVE_RESEARCH")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>Qualitative Research</span></a></p>
								<p style='margin:0;'><a href='".$uri.$this->Main_function->getsMenu("SYNDICATE_HEAD")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>Syndicate Studies</span></a></p>
							</td>
							<td width='24%' valign='top' style='font-family: Tahoma, Geneva, sans-serif; font-size: 16px;'>
								<p style='margin:0 0 15px;'><a href='".$uri.$this->Main_function->getsMenu("ARTICLE_HEAD")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>Article</span></a></p>
								<p style='margin:0 0 15px;'><a href='".$this->Main_function->getsUrlFriendly("ONLINE_PANEL")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>Infosearch Online Panel</span></a></p>
								<p style='margin:0;'><a href='".$uri.$this->Main_function->getsMenu("JOB")."'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:28px;'>Job Opportunities</span></a></p>
							</td>
							<td width='22%' valign='top' style='font-family: Tahoma, Geneva, sans-serif; font-size: 16px;color:#ffffff;'>
								<p style='margin:0 0 15px;'><a href='#'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:30px;'>Contact Us</span></a></p>
								<p style='margin:0 0 7px;'>163 Thai Samut Buiding 20th Floor, Room No.20 C-D, Surawongse Road Suriyawongse, Bangrak Bangkok 10500, Thailand</p>
								<p style='margin:0;'>Tel : <a href='tel:020531771'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:30px;'>(662) 053-1771-5</span></a></p>
								<p style='margin:0;'>Fax : <a href='tel:020531776'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:30px;'>(662) 053-1776</span></a></p>
								<p style='margin:0;'>Email : <a href='mailto:info@infosearch.co.th'><span style='color:#ffffff;font-family: Tahoma, Geneva, sans-serif; font-size: 16px;text-decoration:none;line-height:30px;'>info@infosearch.co.th</span></a></p>
							</td>
							<td width='4%'></td>
						</tr>
						<tr height='30'></tr>
					</table>
				</td>
				<td width='8%'></td>
			</tr>";
		$html .= "</table>";
				
		return $html;
	}

	// start_cms
	
	function getsBirthDate() {
		$result = "";
		for($i = 1; $i < 32; $i++){ $result .= '<option value="'.$i.'">'.$i.'</option>'; }
		return $result;
	}
	
	function getsBirthMonth($lang=null) {
		$result = "";
		for($i = 1; $i < 13; $i++){			
			if($lang == 'th'){
				$m = $this->Main_function->FullMonthTH($i);
			}else{
				$m = $this->Main_function->FullMonthEN($i);
			}
			$result .= '<option value="'.$i.'">'.$m.'</option>';
		}
		return $result;
	}	
	
	function getsBirthYear($type=null) {
		$now_year = date("Y");
		if($type != "" || $type != null){
			$now_year = date("Y")+543;
		}		
		$result = "";
		for($i = 0; $i < 100; $i++){
			$result .= '<option value="'.$now_year.'">'.$now_year.'</option>';
			$now_year--;
		}
		return $result;
	}
	
	function ShortDayTH($Day=null){
	  $sDay = array("Sun" => "อาทิตย์", "Mon" => "จันทร์", "Tue" => "อังคาร", "Wed" => "พุธ", "Thu" => "พฤหัสบดี", "Fri" => "ศุกร์", "Sat" => "เสาร์");
	  $result = $sDay[$Day];
	  return $result;
	}
	
	function ShortMonthTH($Month=null){
	  $sMonth = array("","ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค.");
	  $result = $sMonth[$Month];
	  return $result;
	}
	
	function FullMonthTH($Month=null){
	  $sMonth = array("","มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฏาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม");
	  $result = $sMonth[$Month];
	  return $result;
	}
	
	function ShortMonthEN($Month=null){
	  $sMonth = array("","Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec") ;
	  $result = $sMonth[$Month];	
	  return $result;
	}
	
	function FullMonthEN($Month=null){
	  $sMonth = array("","January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December") ;
	  $result = $sMonth[$Month];	
	  return $result;
	}
	
	function FullMonthCH($Month=null){
	  $sMonth = array("","一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月") ;
	  $result = $sMonth[$Month];	
	  return $result;
	}
	
	function FullMonthAll($Month=null, $lang=null){
		if($lang == "th"){
			$result = $this->Main_function->FullMonthTH($Month);
		}else{
			$result = $this->Main_function->FullMonthEN($Month);
		}
		return $result;
	}
	
	function getsNumericMonthEN($Month=null){
	  $sMonth = array("Jan" => "1", "Feb" => "2", "Mar" => "3", "Apr" => "4", "May" => "5", "Jun" => "6", "Jul" => "7", "Aug" => "8", "Sep" => "9", "Oct" => "10", "Nov" => "11", "Dec" => "12");
	  $result = $sMonth[$Month];	
	  return $result;
	}
	
	function siteURL(){
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		$domainName = $_SERVER['HTTP_HOST'];
		return $protocol.$domainName;
	}
	
	function DateThai($strDate){
		$strYear = date("Y",strtotime($strDate))+543;
		$strMonth= date("n",strtotime($strDate));
		$strDay= date("j",strtotime($strDate));
		$strHour= date("H",strtotime($strDate));
		$strMinute= date("i",strtotime($strDate));
		$strSeconds= date("s",strtotime($strDate));
		$strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
		$strMonthThai=$strMonthCut[$strMonth];
		return "$strDay/$strMonth/$strYear";
	}
	
	function DatePreview($strDate, $time=null){
		$strYear = date("Y",strtotime($strDate))+543;
		// $strYear = date("Y",strtotime($strDate));
		$strMonth= date("n",strtotime($strDate));
		$strDay= date("j",strtotime($strDate));
		$strHour= date("H",strtotime($strDate));
		$strMinute= date("i",strtotime($strDate));
		$strSeconds= date("s",strtotime($strDate));
		$strMonthCut = Array("","ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค.");
		// $strMonthCut = array("","Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec") ;
		// $strMonthCut = array("","January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December") ;
		$strMonthThai=$strMonthCut[$strMonth];
		$strTime = "";
		if($time != null || $time != ""){
			$strTime = $strHour.':'.$strMinute.':'.$strSeconds;
		}
		return "$strDay $strMonthThai $strYear $strTime";
	}
	
	function DateDecode($strDate){
		$strDate = explode(" ", $strDate);
		$strMonthNum = Array("ม.ค." => "1","ก.พ." => "2","มี.ค." => "3","เม.ย." => "4","พ.ค." => "5","มิ.ย." => "6","ก.ค." => "7","ส.ค." => "8","ก.ย." => "9","ต.ค." => "10","พ.ย." => "11","ธ.ค." => "12");
		if(count($strDate) > 0){
			$strYear = $strDate[2]-543;
			$strDay = $strDate[0];
			$strMonth = $strMonthNum[$strDate[1]];
		}
		// return "$strYear-$strMonth-$strDay ".date("H:i:s");
		return "$strYear-$strMonth-$strDay";
	}
	
	function genRandomString($length=null) {
		//$length = 8;
		$characters = '0123456789abcdefghijklmnopqrstuvwxyz';
		$string = '';    
		for ($p = 0; $p < $length; $p++) {
			$string .= $characters[mt_rand(0, strlen($characters))];
		}
		return $string;
	}

	function genCodeUrl($length = null) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyz';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
	
	// function randomString($length) { 
	// 	$text = '';
	// 	$key_chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
	// 	$rand_max  = strlen($key_chars) - 1;
	// 	for ($i = 0; $i < $length; $i++) {
	// 		$rand_pos  = rand(0, $rand_max);
	// 		$text .= $key_chars{$rand_pos};
	// 	}
	// 	return $text;
	// }
	
	function getsMenuHeader($uri=null){
		$uauth = $this->session->userdata('ufostatauthorsize');
		$umenu = $this->session->userdata('umenuid');
		
		$result = "";
		if($uauth == "Admin" || in_array("1", $umenu) ){
			$result .= '
				<li class="nav-item">
					<div class="panel-group">
						<a class="nav-link" class="btn btn-info" id="m_home" data-toggle="collapse" data-target="#home">
							<span data-feather="home"></span> Home
							<span data-feather="chevron-down"></span>
						</a>
						<div id="home" class="collapse-show collapse">
							<ul class="list-group">
								<ol><a class="nav-link" id="m_home6" href="'.$uri.'index.php/cmsbackend/Home/slide_list" class="active"><span data-feather="minus"></span>Upcoming events</a></ol>
								<ol><a class="nav-link" id="m_home1" href="'.$uri.'index.php/cmsbackend/Home/home_from" class="active"><span data-feather="minus"></span>Home Detail</a></ol>
								<ol><a class="nav-link" id="m_home2" href="'.$uri.'index.php/cmsbackend/Home/about_from"><span data-feather="minus"></span>About Us</a></ol>
								<ol><a class="nav-link" id="m_home3" href="'.$uri.'index.php/cmsbackend/Home/commit_from"><span data-feather="minus"></span>Committee</a></ol>
								<ol><a class="nav-link" id="m_home4" href="'.$uri.'index.php/cmsbackend/Home/report_list"><span data-feather="minus"></span>FoSTAT Annual Report</a></ol>
								<ol><a class="nav-link" id="m_home5" href="'.$uri.'index.php/cmsbackend/Home/image_list"><span data-feather="minus"></span>รูปภาพ</a></ol>			
							</ul>
						</div>
					</div>	
				</li>';
		}

		if($uauth == "Admin" || in_array("2", $umenu)){
			$result .= '
				<li class="nav-item">
					<div class="panel-group">
						<a class="nav-link" class="btn btn-info" id="m_pro" data-toggle="collapse" data-target="#program" style="padding-right:7px;">
							<span data-feather="award"></span>Program
							<span data-feather="chevron-down"></span>
						</a>
						<div id="program" class="collapse-show collapse">
							<ul class="list-group">
								<ol>
									<a class="nav-link" id="m_pro2" href="#"><span data-feather="minus"></span>Awads</a>
									<ul style="padding-left: 25px;">
										<ol style="padding-left: 0;"><a class="nav-link" id="m_pro_list1" href="'.$uri.'index.php/cmsbackend/program/awads_list" style="padding-right: 0;"><span data-feather="circle"></span>Awads</a></ol>
										<ol style="padding-left: 0;"><a class="nav-link" id="m_pro_list2" href="'.$uri.'index.php/cmsbackend/program/past_awads_list" style="padding-right: 0;"><span data-feather="circle"></span>Past Awads</a></ol>
										
									</ul>
								</ol>
								<ol>
									<a class="nav-link" id="m_pro10" href="#"><span data-feather="minus"></span>Food Scinence</a>
									<ul style="padding-left: 25px;">
										<ol style="padding-left: 0;"><a class="nav-link" id="m_pro_list3" href="'.$uri.'index.php/cmsbackend/program/cfp_from" style="padding-right: 0;"><span data-feather="circle"></span>Certified Food Professional</a></ol>
										<ol style="padding-left: 0;"><a class="nav-link" id="m_pro_list4" href="'.$uri.'index.php/cmsbackend/program/standard_from" style="padding-right: 0;"><span data-feather="circle"></span>มาตราฐานอาชีพ</a></ol>
										
									</ul>
								</ol>
								<ol>
									<a class="nav-link" id="m_pro3" href="#"><span data-feather="minus"></span>Conference and workshop</a>
									<ul style="padding-left: 25px;">
										<ol style="padding-left: 0;"><a class="nav-link" id="m_pro_list5" href="'.$uri.'index.php/cmsbackend/program/inno_from" style="padding-right: 0;"><span data-feather="circle"></span>Food Innovation</a></ol>
										<ol style="padding-left: 0;"><a class="nav-link" id="m_pro_list6" href="'.$uri.'index.php/cmsbackend/program/ingred_from" style="padding-right: 0;"><span data-feather="circle"></span>Food Ingredients</a></ol>
										
									</ul>
								</ol>
								<ol><a class="nav-link" id="m_pro4" href="'.$uri.'index.php/cmsbackend/program/consul_from" class="active"><span data-feather="minus"></span>Consultation</a></ol>
								<ol>
									<a class="nav-link" id="m_pro5" href="#"><span data-feather="minus"></span>Curriculum And Scholarship</a>
									<ul style="padding-left: 25px;">
										<ol style="padding-left: 0;"><a class="nav-link" id="m_pro_list7" href="'.$uri.'index.php/cmsbackend/program/cur_list" style="padding-right: 0;"><span data-feather="circle" ></span>Curriculum</a></ol>
										<ol style="padding-left: 0;"><a class="nav-link" id="m_pro_list8" href="'.$uri.'index.php/cmsbackend/program/agro_list" style="padding-right: 0;"><span data-feather="circle"></span>Ago-Industry</a></ol>
										
									</ul>
								</ol>
								<ol><a class="nav-link" id="m_pro6" href="'.$uri.'index.php/cmsbackend/program/fnqb_from" class="active"><span data-feather="minus"></span>FNQB</a></ol>
								<ol><a class="nav-link" id="m_pro7" href="'.$uri.'index.php/cmsbackend/program/fic_from" class="active"><span data-feather="minus"></span>FIC</a></ol>
								<ol><a class="nav-link" id="m_pro8" href="'.$uri.'index.php/cmsbackend/program/past_win_list" class="active"><span data-feather="minus"></span>Past winners</a></ol>
								<ol><a class="nav-link" id="m_pro9" href="'.$uri.'index.php/cmsbackend/program/FIRN_form" class="active"><span data-feather="minus"></span>FIRN</a></ol>
								<ol>
									<a class="nav-link" id="m_pro10" href="#"><span data-feather="minus"></span>Corporate Social Responsibility (CSR)</a>
									<ul style="padding-left: 25px;">
										<ol style="padding-left: 0;"><a class="nav-link" id="m_pro_list9" href="'.$uri.'index.php/cmsbackend/program/csr_from" style="padding-right: 0;"><span data-feather="circle"></span>CSR Detail</a></ol>
										<ol style="padding-left: 0;"><a class="nav-link" id="m_pro_list10" href="'.$uri.'index.php/cmsbackend/program/csrKid_list" style="padding-right: 0;"><span data-feather="circle"></span>โครงการเด็กฉลาด</a></ol>
										
									</ul>
								</ol>
							</ul>
						</div>
					</div>
				</li>';
		}
		if($uauth == "Admin" || in_array("3", $umenu)){
			$result .= '
				<li class="nav-item">
					<div class="panel-group">
						<a class="nav-link" class="btn btn-info" id="m_train" data-toggle="collapse" data-target="#tran" style="padding-right:7px;">
							<span data-feather="activity"></span> Training
							<span data-feather="chevron-down"></span>
						</a>
						<div id="tran" class="collapse-show collapse">
							<ul class="list-group">
								<ol><a class="nav-link" id="m_train5" href="'.$uri.'index.php/cmsbackend/training/train_from" class="active"><span data-feather="minus"></span>Training Dedail</a></ol>
								<ol><a class="nav-link" id="m_train1" href="'.$uri.'index.php/cmsbackend/training/public_list"><span data-feather="minus"></span>Public Training</a></ol>
								<ol><a class="nav-link" id="m_train2" href="'.$uri.'index.php/cmsbackend/training/food_list"><span data-feather="minus"></span>Food Safety Forum</a></ol>
								<ol><a class="nav-link" id="m_train3" href="'.$uri.'index.php/cmsbackend/training/fda_list"><span data-feather="minus"></span>FoSTAT-FDA Training</a></ol>
								<ol><a class="nav-link" id="m_train4" href="'.$uri.'index.php/cmsbackend/training/in_form" class="active"><span data-feather="minus"></span>In-house Training</a></ol>
							</ul>
						</div>
					</div>
				</li>';
		}

		if($uauth == "Admin" || in_array("4", $umenu)){
			$result .= '
				<li class="nav-item">
					<a class="nav-link" id="m_commu" href="'.$uri.'index.php/cmsbackend/commu/commu_list">
						<span data-feather="map"></span> Communication
					</a>
				</li>';
		}

		if($uauth == "Admin" || in_array("5", $umenu)){
			$result .= '
				<li class="nav-item">
					<div class="panel-group">
						<a class="nav-link" class="btn btn-info" id="m_mem" data-toggle="collapse" data-target="#mem" style="padding-right:7px;">
							<span data-feather="credit-card"></span> Membership
							<span data-feather="chevron-down"></span>
						</a>
						<div id="mem" class="collapse-show collapse">
							<ul class="list-group">
								<ol><a class="nav-link" id="m_mem1" href="'.$uri.'index.php/cmsbackend/member/mem_from"><span data-feather="minus"></span>Membership drive</a></ol>
								<ol><a class="nav-link" id="m_mem2" href="'.$uri.'index.php/cmsbackend/member/career_from" class="active"><span data-feather="minus"></span>Career Center</a></ol>
							</ul>
						</div>
					</div>
				</li>';
		}

		if($uauth == "Admin" || in_array("6", $umenu)){
			$result .= '
				<li class="nav-item">
					<a class="nav-link" id="m_con" href="'.$uri.'index.php/cmsbackend/contact/con_from">
						<span data-feather="map-pin"></span> Contact Us
					</a>
				</li>';
		}

		if($uauth == "Admin" || in_array("7", $umenu)){
			$result .= '
				<li class="nav-item">
					<a class="nav-link" id="m_memList" href="'.$uri.'index.php/cmsbackend/memberList/member">
						<span data-feather="users"></span> Member List
					</a>
				</li>';
		}

		if($uauth == "Admin" || in_array("8", $umenu)){
			$result .= '
				<li class="nav-item">
					<a class="nav-link" id="m_trainList" href="'.$uri.'index.php/cmsbackend/trainList/train">
						<span data-feather="book"></span> Training List
					</a>
				</li>';
		}

		if($uauth == "Admin"){
			$result .= '
				<li class="nav-item">
					<a class="nav-link" id="m_user" href="'.$uri.'index.php/cmsbackend/user/user_list">
						<span data-feather="user"></span> User Management
					</a>
				</li>';
		}
		
		
		return $result;
	}
	
	public function convert_data($date=null,$format=null){
		if($date != ''){
		  $time = strtotime(str_replace("/" , "-", $date));
			if($format == 'time'){  
				$newformat = date('H:i',$time);
			}elseif($format == 'dateToDB'){
				$newformat = date('Y-m-d',$time); 
			}elseif($format == 'datetimeToDB'){
				$newformat = date('Y-m-d H:i:s',$time);
			}elseif($format == 'dateTobx'){
				$newformat = date('d M Y',$time);
			}
			else{
			$newformat = date('d-m-Y',$time);
			}
			 return $newformat;
		}else{
		 return '';
		}
	}

	// end_cms
}
?>