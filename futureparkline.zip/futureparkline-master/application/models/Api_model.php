<?php

class Api_model extends CI_Model{
	
    function __construct(){
        parent::__construct();
    }

    function auth(){
		$uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		$path_menu = "profile";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

		$this->load->library('oauth2');
		$test = $this->oauth2->get_token();
		$test2 = json_decode($test);
		$access_token = $test2->access_token;
		print_r($test2);

		$data_header['access_token'] = $access_token;
        
        $this->load->view('template/header',$data_header);
		
	}
}
?>