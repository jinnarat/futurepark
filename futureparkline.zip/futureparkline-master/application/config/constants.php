<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Display Debug backtrace
|--------------------------------------------------------------------------
|
| If set to TRUE, a backtrace will be displayed along with php errors. If
| error_reporting is disabled, the backtrace will not display, regardless
| of this setting
|
*/
defined('SHOW_DEBUG_BACKTRACE') OR define('SHOW_DEBUG_BACKTRACE', TRUE);

/*
|--------------------------------------------------------------------------
| File and Directory Modes
|--------------------------------------------------------------------------
|
| These prefs are used when checking and setting modes when working
| with the file system.  The defaults are fine on servers with proper
| security, but you may wish (or even need) to change the values in
| certain environments (Apache running a separate process for each
| user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
| always be used to set the mode correctly.
|
*/
defined('FILE_READ_MODE')  OR define('FILE_READ_MODE', 0644);
defined('FILE_WRITE_MODE') OR define('FILE_WRITE_MODE', 0666);
defined('DIR_READ_MODE')   OR define('DIR_READ_MODE', 0755);
defined('DIR_WRITE_MODE')  OR define('DIR_WRITE_MODE', 0755);

/*
|--------------------------------------------------------------------------
| File Stream Modes
|--------------------------------------------------------------------------
|
| These modes are used when working with fopen()/popen()
|
*/
defined('FOPEN_READ')                           OR define('FOPEN_READ', 'rb');
defined('FOPEN_READ_WRITE')                     OR define('FOPEN_READ_WRITE', 'r+b');
defined('FOPEN_WRITE_CREATE_DESTRUCTIVE')       OR define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 'wb'); // truncates existing file data, use with care
defined('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE')  OR define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 'w+b'); // truncates existing file data, use with care
defined('FOPEN_WRITE_CREATE')                   OR define('FOPEN_WRITE_CREATE', 'ab');
defined('FOPEN_READ_WRITE_CREATE')              OR define('FOPEN_READ_WRITE_CREATE', 'a+b');
defined('FOPEN_WRITE_CREATE_STRICT')            OR define('FOPEN_WRITE_CREATE_STRICT', 'xb');
defined('FOPEN_READ_WRITE_CREATE_STRICT')       OR define('FOPEN_READ_WRITE_CREATE_STRICT', 'x+b');


$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$domainName = htmlspecialchars(stripslashes(trim($_SERVER['HTTP_HOST'])), ENT_QUOTES);
$request_uri = htmlspecialchars(stripslashes(trim(urldecode($_SERVER['REQUEST_URI']))), ENT_QUOTES);
$sv_name = str_replace("www.", "", $_SERVER["SERVER_NAME"]);
if($sv_name == "lineapp"){
	$base_url = $protocol.$_SERVER['HTTP_HOST'].'/';
	$folder_main = "../lineapp/";
}else{
	$base_url = $protocol.$_SERVER['HTTP_HOST'].'/lineapp/';
	$folder_main = "../lineapp/";
}

$path_cdpmkt	= "cdpmkt";
// $path_cdpmkt	= "cdpmkt_production";

$folder_upload	= "uploads";

define('URLFRONT', $base_url);
define('URLFRONT_Login', $base_url.'login/');
define('URL_Login', $base_url.'index.php/cmsbackend/login');
define('PATHFRONTUPLOAD', $folder_main.$folder_upload.'/');
define('UPLOAD_IMPORT_PATH','../'.$folder_main.$folder_upload.'/f_excel/');

define('PATHIMGPROMOTION', $protocol.$_SERVER['HTTP_HOST'].'/'.$path_cdpmkt.'/');
define('PATHIMGSHOP','../'.$path_cdpmkt.'/');
define('PATHBTNCAMP', $protocol.$_SERVER['HTTP_HOST'].'/'.$path_cdpmkt.'/campaign/');
define('PATHIMGCAMPAIGN', $protocol.$_SERVER['HTTP_HOST'].'/'.$path_cdpmkt.'/');

define('FOLDERFRONTUPLOAD',$folder_upload);
define('FOLDERFRONTMAIN',$folder_main);

define('TITLE_CMS', 'Line Appilcation');
define('TITLE', 'Line Appilcation');
define('META_KEYWORDS', 'Line Appilcation');
define('META_DESC', 'Line Appilcation');

define('SEO_META_KEY', 'Line Appilcation');
define('SEO_META_DESC', 'Line Appilcation');
define('OG_TITLE', 'Line Appilcation');
define('OG_SITENAME', 'Line Appilcation');
define('OG_URL', $protocol.$domainName.$request_uri);
define('OG_IMAGE', $protocol.$domainName.'/assets/images/logo/logo.jpg');
define('OG_IMG', $protocol.$domainName.'/assets/images/logo/logo.jpg');
define('OG_IMG_ALT', 'Line Appilcation');
// define('CDPMKT_PHYSICAL_PATH', 'D:/Developers/Projects/Sundae/Dev/cdpmkt/'); // localhost pc
// define('CDPMKT_PHYSICAL_PATH', 'D:/sundae/Projects/Dev/cdpmkt/'); // localhost note book
define('CDPMKT_PHYSICAL_PATH', 'D:/www/'.$path_cdpmkt.'/'); // uat
define('OG_DESC', '');

define('PATH_IMG', $base_url.'uploads/');
define('ERROR_DATA', '<div style="padding: 12% 0;" align="center"><h2 style="font-size:72px;">404</h2><p>SORRY, PAGE NOT FOUND</p></div>');

define ('HMAC_SHA256', 'sha256');
define ('SECRET_KEY', '97860a9013d1456780d3a51405f738a81964fdfc7af24a2a9f678962bf3c5a4ede84d9541c684a91ad35feae965a17c72915bb8b3d9b4f09a336cb8bfe47f35a27ba445fdc454bdcaf7e5975980c5673131f7f2089ab42c3948e84cf6b2cdb71fee75e9295114203aefa334f3ebcee584b50e57688004b57b86112d58909b6d7');

/* LOCALHOST CONFIG */
/*
// API
define('OAUTHHOST',$protocol.$_SERVER['HTTP_HOST'].'/api/');
define('CLIENTID','G6QicNPuedvN5gBS4y32097Oi5qsYZhh');
define('CLIENTSECRET','KBa5H1qeNAirAfF3qUS0NIL77kHOjcBq');  
define('APPID','FB-PRO-VEND-0002');

// LIFF LINE 
define('LIFFSOCIALLink','https://liff.line.me/1655824985-2KwrQMor'); // social
define('LIFFSOCIALCODE','1655824985-2KwrQMor'); // social
define('LIFFSOCIALOLDLink','https://liff.line.me/1655824985-lVr6nbQ6'); // socialOld
define('LIFFSOCIALOLDCODE','1655824985-lVr6nbQ6'); // socialOld

// API CRM
define('SENDCASE','http://128.128.0.198'); // UAT
*/
/* END LOCALHOST CONFIG */

/* UAT CONFIG */
/*
// API
define('OAUTHHOST','128.127.0.5/api/');
define('OAUTHHOST','http://cdpuat.futurepark.co.th/api/');
define('CLIENTID','G6QicNPuedvN5gBS4y32097Oi5qsYZhh');
define('CLIENTSECRET','KBa5H1qeNAirAfF3qUS0NIL77kHOjcBq');  
define('APPID','FB-PRO-VEND-0002');

// LIFF LINE 
define('LIFFSOCIALLink','https://liff.line.me/1655995582-p8yBWKzy'); // social
define('LIFFSOCIALCODE','1655995582-p8yBWKzy'); // social
define('LIFFSOCIALOLDLink','https://liff.line.me/1655995582-0JGwWaRG'); // socialOld
define('LIFFSOCIALOLDCODE','1655995582-0JGwWaRG'); // socialOld

// API CRM
define('SENDCASE','http://128.128.0.198'); // UAT
*/
/* END UAT CONFIG */

/* UAT PRODUCTION CONFIG */
/*
// API
define('OAUTHHOST','128.127.0.5/api_production/');
define('OAUTHHOST','http://cdpuat.futurepark.co.th/api_production/');
define('CLIENTID','G6QicNPuedvN5gBS4y32097Oi5qsYZhh');
define('CLIENTSECRET','KBa5H1qeNAirAfF3qUS0NIL77kHOjcBq');  
define('APPID','FB-PRO-VEND-0002');

// LIFF LINE 
define('LIFFSOCIALLink','https://liff.line.me/1655995582-aOyR6q2y'); // social
define('LIFFSOCIALCODE','1655995582-aOyR6q2y'); // social
define('LIFFSOCIALOLDLink','https://liff.line.me/1655995582-6MLwOQPL'); // socialOld
define('LIFFSOCIALOLDCODE','1655995582-6MLwOQPL'); // socialOld

// API CRM
define('SENDCASE','http://128.128.0.198'); // UAT
*/
/* END UAT PRODUCTION CONFIG */

/* PRODUCTION CONFIG */
/*
// API
define('OAUTHHOST','https://mkt.futurepark.co.th/api/');
define('CLIENTID','G6QicNPuedvN5gBS4y32097Oi5qsYZhh');
define('CLIENTSECRET','KBa5H1qeNAirAfF3qUS0NIL77kHOjcBq');  
define('APPID','FB-PRO-VEND-002');

// LIFF LINE 
define('LIFFSOCIALLink','https://liff.line.me/1655812134-M01w8264'); // social
define('LIFFSOCIALCODE','1655812134-M01w8264'); // social
define('LIFFSOCIALOLDLink','https://liff.line.me/1655812134-B0OpWLxG'); // socialOld
define('LIFFSOCIALOLDCODE','1655812134-B0OpWLxG'); // socialOld

// API CRM
define('SENDCASE','http://128.128.0.199'); // production
*/
/* END PRODUCTION CONFIG */

/* DMS CONFIG */

// API
define('OAUTHHOST',$protocol.$_SERVER['HTTP_HOST'].'/api/');
define('CLIENTID','G6QicNPuedvN5gBS4y32097Oi5qsYZhh');
define('CLIENTSECRET','KBa5H1qeNAirAfF3qUS0NIL77kHOjcBq');  
define('APPID','FB-PRO-VEND-0002');

// LIFF LINE 
define('LIFFSOCIALLink','https://liff.line.me/1655995582-KLdJgQed'); // social
define('LIFFSOCIALCODE','1655995582-KLdJgQed'); // social
define('LIFFSOCIALOLDLink','https://liff.line.me/1655995582-9bOVNpmO'); // socialOld
define('LIFFSOCIALOLDCODE','1655995582-9bOVNpmO'); // socialOld

// API CRM
define('SENDCASE','http://128.128.0.198'); // UAT

/* END DMS CONFIG */

/* ใช้สำหรับกำหนด TRACKING
default : true
*/
define('OPENTRACKING', false);
define('TRACKINGURL', "https://cdpuat.futurepark.co.th/tracking/script/tracking.js");

/* set auto insert opt SMS to input
default : define('OTPSMSAUTOINSERT', false);
! ถ้าเป็น true ใช้กรณี test เท่านั้น อยู่ขั้นตอนการส่ง opt ไปหน้า VERIFICATION OTP 
*/
define('OTPSMSAUTOINSERT', true);

/* ใช้สำหรับกำหนด เชื่อม liff ใหม่ หรือ เก่า
default : false
! ถ้าเป็น true : จะเป็นการเชื่อม liff ใหม่ 
*/
define('NEWUIDFLOW', false);

// EMAIL
define('SMTPHOST', 'mail.sundae.co.th');
define('SMTPPORT', '25'); 
define('SMTPUSER', 'jinnarat.r@sundae.co.th'); 
define('SMTPPASSWORD', '$undae@2o19;');
// SMS
define('SMSHOST','http://api2.infobip.com');
define('SMSUSER','SundaeDemo');  
define('SMSPASSWORD','Sundae_2019');
define('SMSSENDER','FuturePark'); 

/*
|--------------------------------------------------------------------------
| Exit Status Codes
|--------------------------------------------------------------------------
|
| Used to indicate the conditions under which the script is exit()ing.
| While there is no universal standard for error codes, there are some
| broad conventions.  Three such conventions are mentioned below, for
| those who wish to make use of them.  The CodeIgniter defaults were
| chosen for the least overlap with these conventions, while still
| leaving room for others to be defined in future versions and user
| applications.
|
| The three main conventions used for determining exit status codes
| are as follows:
|
|    Standard C/C++ Library (stdlibc):
|       http://www.gnu.org/software/libc/manual/html_node/Exit-Status.html
|       (This link also contains other GNU-specific conventions)
|    BSD sysexits.h:
|       http://www.gsp.com/cgi-bin/man.cgi?section=3&topic=sysexits
|    Bash scripting:
|       http://tldp.org/LDP/abs/html/exitcodes.html
|
*/
defined('EXIT_SUCCESS')        OR define('EXIT_SUCCESS', 0); // no errors
defined('EXIT_ERROR')          OR define('EXIT_ERROR', 1); // generic error
defined('EXIT_CONFIG')         OR define('EXIT_CONFIG', 3); // configuration error
defined('EXIT_UNKNOWN_FILE')   OR define('EXIT_UNKNOWN_FILE', 4); // file not found
defined('EXIT_UNKNOWN_CLASS')  OR define('EXIT_UNKNOWN_CLASS', 5); // unknown class
defined('EXIT_UNKNOWN_METHOD') OR define('EXIT_UNKNOWN_METHOD', 6); // unknown class member
defined('EXIT_USER_INPUT')     OR define('EXIT_USER_INPUT', 7); // invalid user input
defined('EXIT_DATABASE')       OR define('EXIT_DATABASE', 8); // database error
defined('EXIT__AUTO_MIN')      OR define('EXIT__AUTO_MIN', 9); // lowest automatically-assigned error code
defined('EXIT__AUTO_MAX')      OR define('EXIT__AUTO_MAX', 125); // highest automatically-assigned error code
