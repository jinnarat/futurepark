<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fncsms extends DB_Controller {
    
    function __construct(){
        parent::__construct();              
		$this->load->model('LogModel');   
		$this->load->model('MainModel');         
    }
    
    function genOTPandSMS()
	{
		$ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
		
		try{
			
			$refId 		= $this->MainModel->Base64Decrypt(trim($this->input->post('refId')));
			$refCode 	= $this->MainModel->Base64Decrypt(trim($this->input->post('refCode')));
			$phone 		= trim($this->input->post('phone'));
			
			if($phone == "")
			{
				$ERR_STATUS = 400; throw new exception('Err data phone is empty'); 
			}
			
			$p_tel = substr($phone,1,strlen($phone));

			// echo 'p_tel :'.$p_tel; exit;
			if(substr($phone,0,1) == "0")
			{
				$smsmobile = "66".$p_tel;
			}else{
				$smsmobile = $phone;
			}	
			
			$SQL 	= "SELECT logId FROM log_sms WITH (NOLOCK) WHERE mobileFullNo = ? AND status !=  ? AND refId = ? ";	
			$NUMROW = $this->db->query($SQL, array($smsmobile,'Use',$refId))->num_rows();
			if($NUMROW > 0)
			{
				$this->db->trans_start();
			
				$dataUpdate = array(					
					'status' => 'Expired'
				);
				$this->db->where(array('mobileFullNo = ' => $smsmobile, 'status != ' => 'Use', 'refId = ' => $refId));
				$this->db->update('log_sms',$dataUpdate);	
				
				if(!$this->db->affected_rows()){
					$this->db->trans_rollback();
					$this->db->trans_complete();
					$ERR_STATUS = 400; throw new exception('err update data into database');
				}	
					
				$this->db->trans_complete();		
				if ($this->db->trans_status() === FALSE) {
					$this->db->trans_rollback();				
				} 
				else {
					$this->db->trans_commit();
				}
			}				
			
			$otp	= $this->MainModel->generateRandomString(4,'number');
			$ref	= $this->MainModel->generateRandomString(4);		
			$message= "OTP:".$otp." สำหรับลงทะเบียนร่วมกิจกรรม  ใช้ภายใน 5 นาที <Ref:".$ref.">";
			
			if(trim($message) == "")
			{
				$ERR_STATUS = 400; throw new exception('Err data message sms is empty'); 
			}

			if(trim($otp) == "")
			{
				$ERR_STATUS = 400; throw new exception('Err data OTP is empty'); 
			}
			
			if(trim($ref) == "")
			{
				$ERR_STATUS = 400; throw new exception('Err data REF is empty'); 
			}
						
			$result	= $this->LogModel->UpdateLogSMS($refId, $refCode, $smsmobile, $otp, $ref, $message);
			$resObj	= json_decode($result);			
			
			if($resObj->STATUS == 'Unsuccessfully')
			{
				$ERR_STATUS = 400; throw new exception($resObj->ERRDESC); 					
			}
			
			$this->load->library('sms');
			$smsId		= $resObj->ID;
			$smsOTP		= $resObj->OTP;
			$smsRef		= $resObj->REF;			
			$smstext 	= "OTP:".$smsOTP." สำหรับลงทะเบียนร่วมกิจกรรม  ใช้ภายใน 5 นาที  <Ref:".$smsRef.">";
			$resultSMS	= $this->sms->SendSMS($smstext,$smsmobile);	
			$resptext	= $this->sms->getResponseValue($resultSMS);	

			// $resultSMS = '';		
			// $resptext = "Request was successful (all recipients)";

			$response	= $this->LogModel->UpdateLogSMS(null, null, null, null, null, null, $resultSMS, $resptext, $smsId);
			
			$dataRes['detail']	= $resObj;
			$dataRes['status'] 	= array('STATUS' => 'Successfully');
			echo json_encode($dataRes);	
			
		}catch(exception $e){
            if($ERR_STATUS == 400)
            {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
			echo json_encode($Err);            
        }
	}
	
	function checkOTP()
	{
		$ERR_STATUS = 400;        
		
		try{
			
			$refId 		= $this->MainModel->Base64Decrypt(trim($this->input->post('refId')));
			$refCode 	= $this->MainModel->Base64Decrypt(trim($this->input->post('refCode')));
			$phone 		= trim($this->input->post('phone'));
			$otp 		= trim($this->input->post('otp'));
			$ref 		= trim($this->input->post('ref'));
			
			if($phone == "")
			{
				$ERR_STATUS = 400; throw new exception('Err data phone is empty'); 
			}
			
			if($otp == "")
			{
				$ERR_STATUS = 400; throw new exception('Err data OTP is empty'); 
			}
			
			if($ref == "")
			{
				$ERR_STATUS = 400; throw new exception('Err data REF is empty'); 
			}
			
			$DATE_TIME = date("Y-m-d H:i:s");			
			
			$ResOTP	= $this->LogModel->CheckOTP($refId, $refCode, 'Send', $phone, $otp, $ref, $DATE_TIME, $DATE_TIME)->result_array();
			
			if(!$ResOTP)
			{
				$ERR_STATUS = 400; throw new exception('Err data OTP incorrect'); 
			}
			
			$ID	= $ResOTP[0]['logId'];
			if($ID != "")
			{				
				$this->db->trans_start();
			
				$dataUpdate = array(					
					'status' 	=> 'Use',
					'usedby' 	=> $phone,
					'usedtime'	=> date("Y-m-d H:i:s")
				);
				$this->db->where(array('logId' => $ID));
				$this->db->update('log_sms',$dataUpdate);	
				
				if(!$this->db->affected_rows()){
					$this->db->trans_rollback();
					$this->db->trans_complete();
					$ERR_STATUS = 400; throw new exception('err update data into database');
				}	
					
				$this->db->trans_complete();		
				if ($this->db->trans_status() === FALSE) {
					$this->db->trans_rollback();				
				} 
				else {
					$this->db->trans_commit();
				}
			}
			
			$dataRes['detail']	= array('refId' ); 
			$dataRes['status'] 	= array('STATUS' => 'Successfully');
			echo json_encode($dataRes);	
			
		}catch(exception $e){
            if($ERR_STATUS == 400)
            {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
			echo json_encode($Err);            
        }
	}
}

