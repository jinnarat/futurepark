<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);
class History extends DB_Controller {

	protected $authDataPerson;
    function __construct(){
        parent::__construct();
        $this->load->model('Main_function');
        $this->load->model('Select_data');
        $this->load->model('Lists_model');

		$this->load->model('PersonModel');
		$personID = $this->session->userdata('userfprid');
		if (!$personID) {
			redirect(URLFRONT_Login);
		}else {
			$resutlPerson = $this->PersonModel->getPersonData($personID);
			if ($resutlPerson) {
				$this->authDataPerson = $resutlPerson;
			}else {
				redirect(URLFRONT_Login);
			}
		}
    }
    public function index(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view('his_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function event(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view('his_detail',$data);  
		$this->load->view('template/footer',$data_header);
		
	}
}
