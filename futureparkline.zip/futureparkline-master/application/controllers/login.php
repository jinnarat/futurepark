<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);

ini_set('max_execution_time', 0);
set_time_limit(9000);
ini_set('memory_limit','-1');

ini_set('sqlsrv.ClientBufferMaxKBSize','524288'); // Setting to 512M
ini_set('pdo_sqlsrv.client_buffer_max_kb_size','524288'); // Setting to 512M - for pdo_sqlsrv
// defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends DB_Controller {

    function __construct(){
        parent::__construct();
        $this->load->model('Select_data');
		$this->load->model('Lists_model');
		$this->load->model('PersonModel');
		$this->load->model('MainModel');
		$this->load->model('ActivityModel');
		$this->load->library('oauth2');
		$this->load->library('oauth2');
		
    }
    public function index(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			// "isHeader"        => false
        );

        
        $this->load->view('template/header',$data_header);
        $this->load->view('login/login_from',$data);  
		$this->load->view('template/footer');
		
	}
	function chack_phone(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		
		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';

		$data_header['fb_title'] = OG_TITLE;
		$data_header['fb_image'] = OG_IMAGE;
		$data_header['fb_description'] = OG_DESC;

		
        
        $this->load->view('template/header',$data_header);
        $this->load->view('login/phone_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function person_member(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		
		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';

		$data_header['fb_title'] = OG_TITLE;
		$data_header['fb_image'] = OG_IMAGE;
		$data_header['fb_description'] = OG_DESC;
		$data_header['myModal'] = true;

		$starttime	= date("Y-m-d").' 00:00:00';
		$endtime	= date("Y-m-d").' 23:59:59';
		$data['uid'] = '';

		// $rsCamp		= $this->ActivityModel->getActivityLists(null,null,null,'A',$starttime,$endtime)->result_array();
		// 		echo '<pre>';
		// 		print_r($rsCamp); 
		// 		echo '</pre>'; 
		
		// if(count($rsCamp) > 0)
		// {

			$getParam	= $this->input->get('c');

			// echo 'getParam : '.$getParam;
			if(isset($getParam))
			{	
				$array_param	= $this->MainModel->Base64Decrypt($getParam);			
				$param 			= explode(";",$array_param);
				

				// print_r($param);
				if(!isset($param[0])){ $ERR_STATUS = 400; throw new exception($this->not_error); }
				if(!isset($param[1])){ $ERR_STATUS = 400; throw new exception($this->not_error); }
				if(!isset($param[2])){ 
					$uid = '';
				}else{
					$uid = $param[2];
				}
				
				$personId 	= "";
				$dataperson	= "";
				$countPerson= 0;
				$noVerPhone = false;
				$noRegister = false;
				$dataPersonSelect = [];
				$class="";

				// ถ้ามี perid ให้เอาไปหา ถ้าไม่มีให้เอา phone ไปหา
				// getPersonSelect($personId=null,$mobileNo=null,$status=null,$ORDERBY=null,$unique=null)
				// $checkRegister = $this->PersonModel->getPersonSelect(null,$param[0],'A',null,'Y')->result_array();
				$checkRegister = $this->PersonModel->getPersonDataByPhone($param[0]);
				if ($checkRegister) {
					foreach ($checkRegister as $rowDataRegis) {
						if ($rowDataRegis->personStatus == $this->config->item('status_ban') || $rowDataRegis->personStatus == $this->config->item('status_close_down')) {
							$noRegister = true;
							$dataperson = '<br/> <p>คุณไม่สามารถสมัครได้ในขณะนี้ กรุณาติดต่อเจ้าหน้าที่เพื่อทำการตรวจสอบ</p>';
							$countPerson++;
							break;
						}else if ($rowDataRegis->verify_phone == 'Y') {
							if ($personId == "") {
								// $personId = $this->MainModel->Base64Encrypt($rowDataRegis->personId);
								$personId = $rowDataRegis->personId;
							}
						}else {
							$noVerPhone = true;
							$fullname	= $this->MainModel->getMBStringSplit($rowDataRegis->firstname)." ".$this->MainModel->getMBStringSplit($rowDataRegis->lastname);
							array_push($dataPersonSelect, array('fullname' => $fullname, 'personId' => $rowDataRegis->personId));
						}
					}

					if ($noRegister == false && $personId == "") {
						if ($noVerPhone) {
							$countPerson++;
							foreach ($dataPersonSelect as $rowPerson) {
								$dataperson .= '<div class="card cs-pointer" pid="'.$rowPerson["personId"].'">							
													<div class="my-checkfield text-center '.$class.'">
													<h4 class="card-text card-block">'.$rowPerson["fullname"].'</h4>
													</div>
												</div>';
							}
							$data['newphone'] = substr($param[0],0, 2).'x-xxx-'.substr($param[0],6, 10);
							$dataperson .= '<div class="card cs-pointer" pid="">							
													<div class="my-checkfield text-center">
													<h4 class="card-text card-block pt-2">ไม่ใช่คุณ</h4>
													</div>
												</div>';
						}
					}
					
				}

				// echo "<br>count :".count($checkRegister);
				// print_r($checkRegister);
				
				// $dataref 	= new stdClass();
				// $dataref->PERSID 		= $personId;
				// $dataref->REFID 			= $param[0];
				// $dataref->REFCODE		= $param[1];
				// $dataref->REFCAMPID 		= $param[2];
				// $dataref->REFCAMPCODE	= $param[3];
				// $dataref->REFPH			= $param[4];
				// $dataref->REFREFER 		= $param[5];
				// $dataref->REFTMP		= $this->MainModel->Base64Encrypt($rsCamp[0]['tmpDataSet']);

				$dataref 	= new stdClass();
				$dataref->PERSID 		= $personId;
				$dataref->REFPH			= $param[0];
				$dataref->REFREFER 		= $param[1];
				$dataref->UID 			= $uid;

				// $dataref->REFTMP		= $this->MainModel->Base64Encrypt($rsCamp[0]['tmpDataSet']);
									
				// $data = array(
				// 		// "Body"			=> "campaign/_Form",            
				// 		// "isHeader"		=> true,
				// 		// "isFooter"		=> false,
				// 		// "myModal"		=> true,				
				// 		// "getDatePicker"	=> true,				
				// 		// "banner"		=> $img_banner,
				// 		"detail"		=> $rsCamp,
				// 		"countPerson"	=> $countPerson,
				// 		"DataRef"		=> $dataref,
				// 		"DataPerson"	=> $dataperson
				// 	);

				$data['countPerson'] = $countPerson;
				// $data['detail'] =  $rsCamp;
				$data['uid'] = $uid;
				$data['regisNew'] = $param[3];
				$data['DataRef'] = $dataref;
				$data['DataPerson'] = $dataperson;

			}
		// }

		
        $this->load->view('template/header',$data_header);
        $this->load->view('login/checkperson_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function forget(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		
		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';

		$data_header['fb_title'] = OG_TITLE;
		$data_header['fb_image'] = OG_IMAGE;
		$data_header['fb_description'] = OG_DESC;

        
        $this->load->view('template/header',$data_header);
        $this->load->view('login/forget_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function social(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		
		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';

		$data_header['fb_title'] = OG_TITLE;
		$data_header['fb_image'] = OG_IMAGE;
		$data_header['fb_description'] = OG_DESC;

        
        $this->load->view('template/header',$data_header);
        $this->load->view('login/social_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function socialOld(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;

		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';

		$data_header['fb_title'] = OG_TITLE;
		$data_header['fb_image'] = OG_IMAGE;
		$data_header['fb_description'] = OG_DESC;

        
        $this->load->view('template/header',$data_header);
        $this->load->view('login/socialOld_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function social_pond(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		
		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';

		$data_header['fb_title'] = OG_TITLE;
		$data_header['fb_image'] = OG_IMAGE;
		$data_header['fb_description'] = OG_DESC;

        
        $this->load->view('template/header',$data_header);
        $this->load->view('login/social_pond',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	public function thankpage(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		$data['menu'] = 'thank';
		$data['uid'] = '';
		
		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';

		$data_header['fb_title'] = OG_TITLE;
		$data_header['fb_image'] = OG_IMAGE;
		$data_header['fb_description'] = OG_DESC;

        
        $this->load->view('template/header',$data_header);
        $this->load->view('login/thank_from',$data);  
		$this->load->view('template/footer');
		
	}

	public function thankPageMail(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		$data['menu'] = 'mail';
		$data['uid'] = '';
		
		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';

		$data_header['fb_title'] = OG_TITLE;
		$data_header['fb_image'] = OG_IMAGE;
		$data_header['fb_description'] = OG_DESC;

        
        $this->load->view('template/header',$data_header);
        $this->load->view('login/thank_from',$data);  
		$this->load->view('template/footer');
		
	}

	function nextpage(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		$data['menu'] = 'next';
		
		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';

		$data_header['fb_title'] = OG_TITLE;
		$data_header['fb_image'] = OG_IMAGE;
		$data_header['fb_description'] = OG_DESC;

		$data['uid'] = '';

		
		$getParam	= $this->input->get('u');

		// echo 'getParam : '.$getParam;

		if(isset($getParam))
		{	
			$uid	= $this->MainModel->Base64Decrypt($getParam);		
			$data['uid'] = $uid;
		}
        
        $this->load->view('template/header',$data_header);
        $this->load->view('login/thank_from',$data);  
		$this->load->view('template/footer');
	}

	function selectMemberOld(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		
		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';

		$data_header['fb_title'] = OG_TITLE;
		$data_header['fb_image'] = OG_IMAGE;
		$data_header['fb_description'] = OG_DESC;

        
        $this->load->view('template/header',$data_header);
        $this->load->view('login/loginOld_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function chack_memberold(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		
		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';

		$data_header['fb_title'] = OG_TITLE;
		$data_header['fb_image'] = OG_IMAGE;
		$data_header['fb_description'] = OG_DESC;

		
        
        $this->load->view('template/header',$data_header);
        $this->load->view('login/memberold_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function person_memberOld(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;

		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		$data_header['stylesheet'] = '';
		$data_header['javascript'] = '';

		$data_header['fb_title'] = OG_TITLE;
		$data_header['fb_image'] = OG_IMAGE;
		$data_header['fb_description'] = OG_DESC;
		$data_header['myModal'] = true;

		$starttime	= date("Y-m-d").' 00:00:00';
		$endtime	= date("Y-m-d").' 23:59:59';
		$data['uid'] = '';
		$countPerson = 0;

			$getParam	= $this->input->get('c');

			// echo 'getParam : '.$getParam;
			if(isset($getParam))
			{	
				$array_param	= $this->MainModel->Base64Decrypt($getParam);			
				$param 			= explode(";",$array_param);

				// print_r($param);
				if(!isset($param[0])){ $ERR_STATUS = 400; throw new exception($this->not_error); }
				if(!isset($param[1])){ $ERR_STATUS = 400; throw new exception($this->not_error); }
				if(!isset($param[2])){ 
					$uid = '';
				}else{
					$uid = $param[2];
				}

				if(!isset($param[3])){ $ERR_STATUS = 400; throw new exception($this->not_error); }
				
				$personId 	= "";
				$dataperson	= "";
				
				$personIdVer= "";

				// getPersonSelect($personId=null,$mobileNo=null,$status=null,$ORDERBY=null,$unique=null)
				$checkRegister = $this->PersonModel->getPersonSelect($param[3],$param[0],'A',null)->result_array();
				// echo "<br>count :".count($checkRegister);
				// print_r($checkRegister);
				if(empty($checkRegister))
				{	
					// $personId=null,$mobileNo=null,$idCardNo=null,$email=null,$status=null,$ORDERBY=null,$unique=null,$passaport=null 
					$resPerson 	= $this->PersonModel->getPerson(null,$param[0],null,null,'A')->result_array();
					// echo "<br>count resPerson :".count($resPerson);
					if(count($resPerson) > 0)
					{							
						$no = 1;
						$class="";
						$countPerson = 1;
						foreach($resPerson as $r)
						{ 
							//if($no == 1){ $class="my-checkfield-selected"; $personId = $this->MainModel->Base64Encrypt($r['personId']); }else{ $class=""; }
							$firstname	= $this->MainModel->getNameExcludePrefix($r['displayFirstname']);
							$lastname	= $r['displayLastname'];								
							$fullname	= $this->MainModel->getMBStringSplit($firstname)." ".$this->MainModel->getMBStringSplit($lastname);

							$dataperson .= '<div class="card cs-pointer" pid="'.$r['personId'].'">							
												<div class="my-checkfield text-center '.$class.'">
												<h4 class="card-text card-block">'.$fullname.'</h4>
												</div>
											</div>';
							$no++;
						}
						$dataperson .= '<div class="card cs-pointer" pid="">							
											<div class="my-checkfield text-center">
											<h4 class="card-text card-block pt-2">ไม่ใช่คุณ</h4>
											</div>
										</div>';

						$data['newphone'] = substr($param[0],0, 2).'x-xxx-'.substr($param[0],6, 10);
					}
				}else{
					$countPerson = 2;
					$personId = $this->MainModel->Base64Encrypt($checkRegister[0]['personId']);
					$data['pid']  = $param[3];

					$SQL = "SELECT *  FROM person WITH (NOLOCK) WHERE  personId = '".$checkRegister[0]['personId']."' ";
					$rs = $this->db->query($SQL)->result_array();
					// echo '<pre>';
					// print_r($rs); 
					// echo '</per>';

					// echo '<br>'.$uid; exit;
						
					
				}

				$dataref 	= new stdClass();
				$dataref->PERSID 		= $personId;
				$dataref->REFPH			= $param[0];
				$dataref->REFREFER 		= $param[1];
				$dataref->UID 			= $uid;

				$data['countPerson'] = $countPerson;
				// $data['detail'] =  $rsCamp;
				$data['uid'] = $uid;
				$data['DataRef'] = $dataref;
				$data['DataPerson'] = $dataperson;

			}

		
        $this->load->view('template/header',$data_header);
        $this->load->view('login/checkpersonOld_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

}
