<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);
// ini_set('memory_limit', '1024M');
ini_set('sqlsrv.ClientBufferMaxKBSize','524288'); 
ini_set('pdo_sqlsrv.client_buffer_max_kb_size','524288');
class Profile extends DB_Controller {

	protected $authDataPerson;
    function __construct(){
        parent::__construct();
        $this->load->model('Main_function');
        $this->load->model('Select_data');
		$this->load->model('Lists_model');
		$this->load->model('History_model');
		$this->load->model('privilegeModel');
		$this->load->model('RedemptionModel');

		$this->load->model('PersonModel');
		$personID = $this->session->userdata('userfprid');
		if (!$personID) {
			redirect(URLFRONT_Login);
		}else {
			$resutlPerson = $this->PersonModel->getPersonData($personID);
			if ($resutlPerson) {
				$this->authDataPerson = $resutlPerson;
				$this->authDataPerson->session_id = $this->PersonModel->getPersonSessionId($personID);
			}else {
				redirect(URLFRONT_Login);
			}
		}
			
    }
    public function index(){
		$uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		$path_menu = "profile";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

		$getParam	= $this->input->get('c');

		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $getParam;
		}else{
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			$person_id = $check_session;

			$data['person_id'] = $param;
		}

		$point_balance = '';
		$memberNo = '';
		
		$SQL = "SELECT person_point_balance, memberNo FROM person WITH (NOLOCK) WHERE  personStatus != ? AND personId = ?";
		$rs = $this->db->query($SQL,array('D',$person_id))->result_array();
		if(count($rs) > 0){
			foreach($rs as $r){
				$point_balance = (int)htmlspecialchars_decode(trim($r['person_point_balance']));
				$memberNo = $r['memberNo'];
			}
		}

		if(empty($point_balance)){
			$point_balance = '0';
		}else{
			$point_balance = number_format($point_balance);
		}

		$data['point_balance'] = $point_balance;

		$data['imgBadge'] = '';
		$data['imgCard'] = '';
		$data['memberNo'] = $memberNo ? $memberNo : '';

		$sqlBadge = $this->Lists_model->selectBadgeActivity($person_id)->result_array();
		if(count($sqlBadge) > 0){
			foreach($sqlBadge as $b){
				$badgeName = htmlspecialchars_decode(trim($b['badgeName']));
				$file_path = htmlspecialchars_decode(trim($b['file_path']));

				if($file_path != '' ||$file_path != null){
					$imageBadge = '<img src="'.PATHIMGCAMPAIGN.$file_path.'?v="'.date('his').' alt="'.$badgeName.' " class="responsive size-img">';
				}

				$data['imgBadge'] .= '<div class="col-3">
										'.$imageBadge.'
									</div>';
			}
		}

		$sqlCard = $this->Lists_model->SelectMember($person_id)->result_array();
		if(count($sqlCard) > 0){
			foreach($sqlCard as $c){
				$ti_id = htmlspecialchars_decode(trim($c['ti_id']));
				$ti_name = htmlspecialchars_decode(trim($c['ti_name']));
				$file_path = htmlspecialchars_decode(trim($c['ti_img']));

				if($file_path != '' ||$file_path != null){
					$data['imgCard'] = "<img src='".PATHIMGCAMPAIGN.$file_path."?v=".date('his')."' alt='".$ti_name."' class='responsive top10' style='width: 100%;'>";
				}
			}
		}

        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view($path_menu.'/profile_from',$data);  
		$this->load->view('template/footer',$data_header);	
	}

	function basic(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		
		$path_menu = "profile";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

		$getParam	= $this->input->get('c');
		if(isset($getParam))
		{
			$person_id	= $this->MainModel->Base64Decrypt($getParam);	
			$data['param'] = $getParam;
			$data['person_id'] = $person_id;
		}

		$data['personData'] = $this->authDataPerson;

        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view($path_menu.'/basic_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}
	function profile_edit(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		
		$path_menu = "profile";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view($path_menu.'/profile_edit',$data);  
		$this->load->view('template/footer',$data_header);
		
	}
	function contact(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		
		$path_menu = "profile";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true,
        );

		$getParam	= $this->input->get('c');

		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);
			//  echo $check_session.'<br>param : '.$param;
			$data['param'] = $param;
			$data['person_id'] = $check_session;
		}

		$data['personData'] = $this->authDataPerson;
        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view($path_menu.'/contact_from',$data);  
		$this->load->view('template/footer',$data_header);
	}

	function changepassword(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		
		$path_menu = "profile";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

		$getParam	= $this->input->get('c');

		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			//  echo $check_session.'<br>param : '.$param;

			$data['param'] = $param;
			$data['person_id'] = $check_session;
		}

        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view($path_menu.'/changepass_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function info(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		
		$path_menu = "profile";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

		$getParam	= $this->input->get('c');

		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			//  echo $check_session.'<br>param : '.$param;

			$data['param'] = $param;
			$data['person_id'] = $check_session;
		}

        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view($path_menu.'/person_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function history(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		
		$path_menu = "profile";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );
		
		$i = 1;
		$history = '';
		$historyHeader = '';
		$historyDetail = '';
		$nameEvent = '';
		$hist_name = '';
		$pointType = '';
		$perp_point = '';
		$usedDate	= '';
		$imageDisplay = '';
		$detail = '';
		$description = '';
		$title_data = '';
		$mprivId = '';
		$historyCount = 0;
		$isCheckDuplication = array();
		$isCheckDuplicationActivityCheckin = array();

		$isActivityCheckinOut = array();
		$isActivityCheckinOutDate = array();

		$showPointText = '';

		$DATE_TIME = date("Y-m-d H:i:s");
		$YEARTODAY = date("Y");

		$getParam	= $this->input->get('c');

		if(isset($getParam))
		{	
			$personId	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $getParam;
		}else{
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			$personId = $check_session;

			$data['person_id'] = $param;
		}
		
		$SQL = "SELECT ti_id FROM person WITH (NOLOCK) WHERE  personStatus = ? AND personId = ?";
		$rs = $this->db->query($SQL,array('A',$personId))->result_array();
		if(count($rs) > 0){
			foreach($rs as $r){
				$ti_id = htmlspecialchars_decode(trim($r['ti_id']));
			}
		}

		$yearSel = $this->MainModel->Base64Decrypt($this->input->get('y'));
		if(!empty($yearSel)){
			$YEARS = $yearSel;
		}else{
			$YEARS = date("Y");
		}

		$yearshow = '<div class="row" id="from" y="'.$YEARS.'">
						<div class="col-5">
							<a id="btnSubmit" class="iconYear btn-back" href="javascript:void(0)">
							<i class="fa fa-chevron-left"></i>
							</a>
						</div>
						<div class="col-2" class="text-color textBold">'.$YEARS.'</div>
						<div class="col-5">
							<a id="btnSubmit" class="iconYear btn-next" href="javascript:void(0)">
								<i class="fa fa-chevron-right"></i>
							</a>
						</div>
					</div>';

		$data['yearshow'] = $yearshow;

		$sqlMount = $this->History_model->selectHistoryMount($personId,$YEARS)->result_array();
		if(count($sqlMount) > 0){
			foreach($sqlMount as $m){

				$mount = htmlspecialchars_decode(trim($m['mount']));
				// $mount = date("m", strtotime($createdatetime)); //01-12
				// $year = date("Y", strtotime($createdatetime));

				if($mount == 'Jan' || $mount == '01'){
					$textMount = 'January';
				}else if($mount == 'Feb' || $mount == '02'){
					$textMount = 'February';
				}else if($mount == 'Mar' || $mount == '03'){
					$textMount = 'March';
				}else if($mount == 'Apr' || $mount == '04'){
					$textMount = 'April';
				}else if($mount == 'May' || $mount == '05'){
					$textMount = 'May';
				}else if($mount == 'Jun' || $mount == '06'){
					$textMount = 'June';
				}else if($mount == 'Jul' || $mount == '07'){
					$textMount = 'July';
				}else if($mount == 'Aug' || $mount == '08'){
					$textMount = 'August';
				}else if($mount == 'Sep' || $mount == '09'){
					$textMount = 'September';
				}else if($mount == 'Oct' || $mount == '10'){
					$textMount = 'October';
				}else if($mount == 'Nov' || $mount == '11'){
					$textMount = 'November';
				}else if($mount == 'Dec' || $mount == '12'){
					$textMount = 'December';
				}

				$sqlhis = $this->History_model->selectPersonHis($personId,$mount,$YEARS,'perh_createdatetime DESC')->result_array();
			
				$perh_id = null;
				$historyDetail = '';
				$historyCount = 0;
				$historyDate = array();

				// if($textMount == 'January'){
				// 	echo 'check';
				// }

				// $history .= '<div class="text-highlight">'.$textMount.' ['.count($sqlhis).']</div>';
				// $history .= '
				// <div class="d-flex justify-content-between">
				// 	<div class="text-highlight">'.$textMount.'</div>
				// 	<div class="text-highlight">'.count($sqlhis).' รายการ</div>
				// </div>';
				
				if(count($sqlhis) > 0){
					foreach($sqlhis as $s){
						$perh_id = htmlspecialchars_decode(trim($s['perh_id']));
						$personId = htmlspecialchars_decode(trim($s['pers_id']));
						$ref_type_id = $s['ref_type_id'];
						$ref_id = $s['ref_id'];
						$hist_name = htmlspecialchars_decode(trim($s['hist_name']));
						$perh_createdatetime = htmlspecialchars_decode(trim($s['perh_createdatetime']));
						$hisDate = date("Y-m-d", strtotime(htmlspecialchars_decode(trim($s['usedDate']))));
						// $hisDate = htmlspecialchars_decode(trim($s['usedDate']));
						$usedDate = date("d/m/Y  H:i:s", strtotime($perh_createdatetime));
						// echo $ref_id.'<br>'.gettype($ref_id).'<br>'; 

						// 1	Redemption					: done
						// 2	Register 					: done
						// 3	Promotion					: done
						// 4	Check-in & Check-out	
						// 5	Privilege					: done
						// 6	Earn point
						// 7	Burn point
						// 8	Badge
						// 9	Edit Redemption
						// 10	Redeem Redemption Point
						// 11	Service Request				: done original
						// 12	Bonus Point
						// 13	Activity Checkin Check-out	: done
						// 14	Survery
						// 15	Lucky Draw Random			: done
						// 16	Birthday Point				: done
						// 17	CRM Point

						$nameEvent = '';
						$imgBanner = '';
						$description = '';
						$codeExpired = '';
						$img_qrcodeLink = '';
						$codeShow = '';
						$imageDisplay = '';
						$img_qrcode = '';
						$codeText = '';
						$showPointText = '';
						$is_used = ''; // กดใช้ไปหรือยัง
						$user_success = ''; // ใช้ตรวจว่าใช้ไปแล้วหรือยัง Y : ใช้แล้ว N : ยังไม่ใช้
						$dateChekOut = '';
						$dateUpdateChekOut = ''; // เอาไว้ กด check out
						$itemNameList = ''; // ชื่อของรางวัล
						
						if($ref_type_id == 1){
							// ได้แต้ม กับได้ของ ไม่มีเสียแต้ม ดึงแต้มจาก rwt_point
							$activityName = '';

							$trans = $this->History_model->SelectHisRedemp_trans($personId,$ref_id)->result_array(); // $pId=null,$ref_id = null,$order=null
							if(count($trans) > 0){
								foreach($trans as $tt){

									$rdt_transnumber = htmlspecialchars_decode(trim($tt['rdt_transnumber']));

									$title_data = '<div><b>เลขธุรกรรม :</b> '.$rdt_transnumber.'</div>';
								}
							}
							$totalPoint = 0;
							$perp_type = '';
							$description .= '<p class="text-break mb-1" style="line-height: 0.9;">';
							// $redemp = $this->History_model->SelectHisRedemp_reward(null,$ref_id)->result_array(); // $pId=null,$ref_id = null,$order=null
							$redemp = $this->History_model->SelectHisRedemp_rewardGroup($ref_id)->result_array(); // $pId=null,$ref_id = null,$order=null
							if(count($redemp) > 0){
								// $itemCheckDup = array();
								foreach($redemp as $d){
									// $rdt_id = htmlspecialchars_decode(trim($d['rdt_id']));
									$item_name = htmlspecialchars_decode(trim($d['item_name']));
									$perp_type = htmlspecialchars_decode(trim($d['perp_type']));
									// $perp_point = htmlspecialchars_decode(trim($d['perp_point']));
									$activityName = htmlspecialchars_decode(trim($d['activityName']));
									$imgBanner = htmlspecialchars_decode(trim($d['imgBanner']));
									$rwt_point = htmlspecialchars_decode(trim($d['rwt_point']));
									// $detail = htmlspecialchars_decode(trim($d['detail']));

									$totalPoint += (int) $rwt_point;
									// if(!empty($perp_type) && !empty($perp_point)){

									$rwt_point_text = $rwt_point > 0 ? '('.number_format((int) $rwt_point).')' : '';

									// 	if($perp_type == 'Burn'){
									// 		$pointType = 'ใช้คะแนน';
									// 		$showPointText = '<small class="card-text text-danger">- '.$perp_point.' คะแนน</small>';
									// 	}else{
									// 		$showPointText = '<small class="card-text text-success">+ '.$perp_point.' คะแนน</small>';
									// 		$pointType = 'ได้รับคะแนน';
									// 	}
									// 	$pointRedemp = '<div><b>'.$pointType.'</b>&nbsp;&nbsp;'.$perp_point.' แต้ม</div>';
									// }else{
									// 	$pointRedemp = '<div><b>ใช้คะแนน</b>&nbsp;&nbsp; 0  แต้ม</div>';
									// }

									// if($item_name != 'Member Point'){
										// if(in_array($item_name,$itemCheckDup)){
											$description .= '<small class="text-muted" style="font-size: 69%;"> <i class="fas fa-gifts" style="font-size: 12px;"></i> '.$item_name.'</small> <small style="font-size: 69%;"> '.$rwt_point_text.'</small> <br>';
										// }
									// }
								}
								$description .= '</p>';

								if($totalPoint > 0){
									$showPointText = '<small class="card-text text-success">+ '.number_format($totalPoint).' คะแนน</small>';
									// if($perp_type){
									// 	if($perp_type == 'Burn'){
									// 		$showPointText = '<small class="card-text text-danger">- '.$totalPoint.' คะแนน</small>';
									// 	}else{
									// 		$showPointText = '<small class="card-text text-success">+ '.$totalPoint.' คะแนน</small>';
									// 	}
									// }else {
									// 	$showPointText = '';
									// }
								}else {
									$showPointText = '';
								}

								if($activityName){
									$nameEvent = $activityName;
								}
							}
							if($activityName == ''){
								$nameEvent = 'Member Point';
							}
						}

						if($ref_type_id == 2){ // done
							$is_used = 'Y';
							$user_success = 'Y';
							$rowActivity = $this->History_model->getActivity($ref_id);
							if($rowActivity){
								$nameEvent = htmlspecialchars_decode(trim($rowActivity->activityName));
								$imgBanner = htmlspecialchars_decode(trim($rowActivity->imgBanner));
								$detail = htmlspecialchars_decode(trim($rowActivity->detail));
								if(!empty($imgBanner)){
									if(getimagesize(PATHIMGCAMPAIGN.$imgBanner)){
										$imageDisplay = '<img src="'.PATHIMGCAMPAIGN.$imgBanner.'?v="'.date('his').' alt="image" onerror="isImg()" class="card-img">';
									}else {
										$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="card-img">';
									}
								}else{
									$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="card-img">';
								}
							}
							$rowActivityData = $this->History_model->getActivityData($perh_id, $personId, $ref_id);
							if($rowActivityData){
								// $img_qrcode = htmlspecialchars_decode(trim($rowActivityData->imgQr));
								// $codeExpired = htmlspecialchars_decode(trim($rowActivityData->codeExpired));
								// $codeText = htmlspecialchars_decode(trim($rowActivityData->code));
								// $is_used = htmlspecialchars_decode(trim($rowActivityData->status));
								
								// $img_qrcodeLink = PATHIMGCAMPAIGN.$img_qrcode.'?v='.date('his');
								// $codeShow = substr($codeText,-6);
							}
							
							$rowPersonPoint = $this->History_model->getPersonPoint($personId, $ref_id, $ref_type_id);
							if($rowPersonPoint){
								$is_used = 'Y'; // ดักเผื่อลงไปแล้ว แต่ is_used ไม่เป็น Y แต่ใน point มีแล้ว
								$user_success = 'Y'; // ดักเผื่อลงไปแล้ว แต่ is_used ไม่เป็น Y แต่ใน point มีแล้ว
								if($rowPersonPoint->perp_type == 'Burn'){
									$showPointText = '<small class="card-text text-danger">- '.$rowPersonPoint->perp_point.' คะแนน</small>';
								}else{
									$showPointText = '<small class="card-text text-success">+ '.$rowPersonPoint->perp_point.' คะแนน</small>';
								}
							}else {
								$showPointText = '';
							}
						}
						
						if($ref_type_id == 3){ // done
							$rowActivity = $this->History_model->getActivity($ref_id);
							if($rowActivity){
								$nameEvent = htmlspecialchars_decode(trim($rowActivity->activityName));
								$imgBanner = htmlspecialchars_decode(trim($rowActivity->imgBanner));
								$detail = htmlspecialchars_decode(trim($rowActivity->detail));
								if(!empty($imgBanner)){
									if(getimagesize(PATHIMGCAMPAIGN.$imgBanner)){
										$imageDisplay = '<img src="'.PATHIMGCAMPAIGN.$imgBanner.'?v="'.date('his').' alt="image" onerror="isImg()" class="card-img">';
									}else {
										$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="card-img">';
									}
								}else{
									$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="card-img">';
								}
							}
							
							$rowActivityCode = $this->History_model->getActivityCode($perh_id, $ref_id);
							if($rowActivityCode){
								$img_qrcode = htmlspecialchars_decode(trim($rowActivityCode->imgQr));
								$codeExpired = htmlspecialchars_decode(trim($rowActivityCode->codeExpired));
								$codeText = htmlspecialchars_decode(trim($rowActivityCode->code));
								$is_used = htmlspecialchars_decode(trim($rowActivityCode->is_used));
								
								$img_qrcodeLink = PATHIMGCAMPAIGN.$img_qrcode.'?v='.date('his');
								// $codeShow = substr($codeText,-6);
								$originCode = $codeText;
								if($originCode){
									$arrCode = explode("-", $originCode);
									if(isset($arrCode[1])){ 
										$codeShow = $arrCode[1]; 
									}
								}
								$rowActivityRewardCode = $this->History_model->getActivityRewardCode($rowActivityCode->codeId, $ref_id);
								if($rowActivityRewardCode){
									$user_success = 'Y';
								}else {
									$user_success = 'N';
									$dateUpdateChekOut = '<small id="check-out-person" codeId="'.$rowActivityCode->codeId.'" pId="'.$personId.'" mpCode="'.$rowActivityCode->code.'" nameBtn="ใช้สิทธิ์ (สำหรับเจ้าหน้าที่กด)" btnDetail="สำหรับเจ้าหน้าที่"></small>';
								}
							}else {
								continue;
							}
							$rowPersonPoint = $this->History_model->getPersonPoint($personId, $ref_id, $ref_type_id, $perh_id);
							if($rowPersonPoint){
								$is_used = 'Y'; // ดักเผื่อลงไปแล้ว แต่ is_used ไม่เป็น Y แต่ใน point มีแล้ว
								// $user_success = 'Y'; // ดักเผื่อลงไปแล้ว แต่ is_used ไม่เป็น Y แต่ใน point มีแล้ว
								if($rowPersonPoint->perp_type == 'Burn'){
									$showPointText = '<small class="card-text text-danger">- '.$rowPersonPoint->perp_point.' คะแนน</small>';
								}else{
									$showPointText = '<small class="card-text text-success">+ '.$rowPersonPoint->perp_point.' คะแนน</small>';
								}
							}else {
								$showPointText = '';
							}
						}
						
						if($ref_type_id == 5){ // done
							if (in_array($ref_id, $isCheckDuplication)){
								continue;
							}

							$this->load->library('PrivilegeLib');
							// $resultCheck = $this->privilegelib->testPrivilege($ref_id);
							$checkIsUse = false;
							$rowPrivilegeCode = $this->privilegeModel->getPrivilegeCodeByID($ref_id);
							if($rowPrivilegeCode){
								$rowConditionSetting = $this->PrivilegeModel->getPrivilegeConditionSettingNoStatus($rowPrivilegeCode->mpc_id);
								if($rowConditionSetting){
									$rowSettingType = $this->PrivilegeModel->getPrivilegeSettingType($rowConditionSetting->mps_id);
									$nameEvent = $rowConditionSetting->mps_name;
									$imgBanner = $rowConditionSetting->mps_image;
									$img_qrcode = $rowPrivilegeCode->mp_qr_image;
									$img_qrcodeLink = PATHIMGCAMPAIGN.$rowPrivilegeCode->mp_qr_image.'?v='.date('his');
									$codeExpired = $rowPrivilegeCode->mp_code_expired;
									$codeText = $rowPrivilegeCode->mp_code;
									$codeShow = $rowPrivilegeCode->mp_code;
									// $resultCheck = $this->privilegelib->checkPrivilege($personId, $rowConditionSetting->mps_id, 1, $rowConditionSetting->ti_id, $DATE_TIME, false, $ref_id);
									if($rowSettingType->mpt_type == "Check-inCheck-out"){
										if($rowPrivilegeCode->mp_used_check_out_datetime || $rowPrivilegeCode->mp_admin_check_out_datetime){
											$checkIsUse = true;
										}
									}else {
										if($rowPrivilegeCode->mp_admin_check_in_datetime || $rowPrivilegeCode->mp_admin_check_in_by){
											$checkIsUse = true;
										}else {
											if($rowSettingType->mpt_value == "Redeemed Point"){
												// $checkIsUse = true;
												if ($rowPrivilegeCode->mp_shop_code == NULL || $rowPrivilegeCode->mp_shop_code == '') {
													$checkIsUse = false;
													$user_success = 'N';
												}else {
													$user_success = 'Y';
												}
											}
										}
									}
									
									if($checkIsUse == false){
										if($rowSettingType->mpt_type == "Check-inCheck-out"){
											if ($rowSettingType->mpt_value == 'Exclusive Parking') {
												if ($rowPrivilegeCode->mp_staff_code == NULL || $rowPrivilegeCode->mp_staff_code == '') {
													$is_used = 'Y'; 
													$user_success = 'N';
													$dateUpdateChekOut = '<small id="check-out-person" staffBtn="true" pId="'.$personId.'" mpCode="'.$rowPrivilegeCode->mp_id.'" nameBtnStaff="ใช้สิทธิ์ (สำหรับเจ้าหน้าที่กด)" btnDetail="สำหรับเจ้าหน้าที่"></small>';
												}else {
													$is_used = 'Y'; 
													$user_success = 'Y';
												}
											}else {
												$is_used = 'Y'; 
												$user_success = 'N';
												$dateUpdateChekOut = '<small id="check-out-person" pId="'.$personId.'" mpCode="'.$rowPrivilegeCode->mp_id.'"></small>';
											}
										}else {
											$is_used = 'Y'; 
											if($rowSettingType->mpt_value == "Redeemed Point"){
												// $checkIsUse = true;
												if ($rowPrivilegeCode->mp_shop_code == NULL || $rowPrivilegeCode->mp_shop_code == '') {
													$checkIsUse = false;
													$user_success = 'N';
													$dateUpdateChekOut = '<small id="check-out-person" staffBtn="true" pId="'.$personId.'" mpCode="'.$rowPrivilegeCode->mp_code.'" nameBtnShop="ใช้สิทธิ์ (สำหรับเจ้าหน้าที่กด)" btnDetail="สำหรับเจ้าหน้าที่" btnDisabledcheckout="true"></small>';
													// $dateUpdateChekOut = '<small id="check-out-person" codeId="'.$rowActivityCode->codeId.'" pId="'.$personId.'" mpCode="'.$rowActivityCode->code.'" nameBtn="ใช้สิทธิ์ (สำหรับเจ้าหน้าที่กด)" btnDetail="สำหรับเจ้าหน้าที่"></small>';
												}else {
													$user_success = 'Y';
												}
											}
											// $user_success = 'N';
										}
										// redirect('privilege/userEvent?r=Line&pvId='.$enCodePrivId.'&pId='.$enCodePersonId.'&date='.$dateTimeNow.'&tId='.$enCodeTierId.'&code='.$resultCheck->code, 'refresh');
									}else {
										$dateChekOutDay = '';
										if($rowPrivilegeCode->mp_used_check_out_datetime){
											$dateChekOutDay = $rowPrivilegeCode->mp_used_check_out_datetime;
										}else if($rowPrivilegeCode->mp_admin_check_out_datetime){
											$dateChekOutDay = $rowPrivilegeCode->mp_admin_check_out_datetime;
										}
										if($dateChekOutDay){
											$dateChekOut = '
											<p class="card-text d-flex align-items-center mb-0 text-muted">
												<i class="far fa-clock fa-xs" style="font-size: 12px;"></i>
												<small class="text-muted ml-2 usedDate" style="font-size: 69%;"> '.date('d/m/Y H:i:s', strtotime($dateChekOutDay)).'</small>
											</p>';
										}
										// $showBtn = false;
										$is_used = 'Y'; 
										$user_success = 'Y';
									}
									
									if($rowConditionSetting->mps_status != $this->config->item('status_active')){
										$is_used = 'Y'; 
										$user_success = 'Y';
									}
									
								}else {
									continue;
								}
								// $c = $this->checkPrivilege($personId, $privId, 1, $tierId, $dateTimeNow);
							}else {
								continue;
							}
							
							$rowPersonPoint = $this->History_model->getPersonPoint($personId, $ref_id, $ref_type_id);
							if($rowPersonPoint){
								// $user_success = 'Y'; // ดักเผื่อลงไปแล้ว แต่ is_used ไม่เป็น Y แต่ใน point มีแล้ว
								if($rowPersonPoint->perp_point && $rowPersonPoint->perp_point > 0){
									if($rowPersonPoint->perp_type == 'Burn'){
										$showPointText = '<small class="card-text text-danger">- '.$rowPersonPoint->perp_point.' คะแนน</small>';
									}else{
										$showPointText = '<small class="card-text text-success">+ '.$rowPersonPoint->perp_point.' คะแนน</small>';
									}
								}
							}else {
								$showPointText = '';
							}
							array_push($isCheckDuplication,$ref_id);
						}

						if($ref_type_id == 10){ 
							$activityName = '';
							$rowPointTransaction = $this->RedemptionModel->getRedemptionPointTransactionByID($ref_id);
							if ($rowPointTransaction) {
								$rowActivityData = $this->RedemptionModel->getActivityByMachanicID_NO_Status($rowPointTransaction->mec_id);
								$rowMasterItem = $this->RedemptionModel->getMasterItemRedemptionPoint($rowPointTransaction->item_id);
								if ($rowMasterItem) {
									$description .= '<p class="text-break mb-1" style="line-height: 0.9;">';
									$description .= '<small class="text-muted" style="font-size: 69%;"> <i class="fas fa-gifts" style="font-size: 12px;"></i> '.$rowMasterItem->item_name.'</small> <br>';
								}
								$img_qrcode = $rowPointTransaction->pntt_qr_image;
								$img_qrcodeLink = PATHIMGCAMPAIGN.$rowPointTransaction->pntt_qr_image.'?v='.date('his');
								$codeExpired = $rowPointTransaction->pntt_code_expire;
								$codeText = $rowPointTransaction->pntt_code;
								$codeShow = $rowPointTransaction->pntt_code;
								if ($rowPointTransaction->pntt_code_expire >= $DATE_TIME && $rowPointTransaction->pntt_admin_redeem_by == null && $rowPointTransaction->pntt_admin_redeem_datetime == null) {
									$user_success = 'N';
									$is_used = 'Y';
									$dateUpdateChekOut = '<small id="check-out-person" codeId="'.$rowPointTransaction->mec_id.'" pId="'.$personId.'" mpCode="'.$rowPointTransaction->pntt_code.'" nameBtn="ใช้สิทธิ์ (สำหรับเจ้าหน้าที่กด)" btnDetail="สำหรับเจ้าหน้าที่" btnDisabled="true"></small>';
								}
								$showPointText = '<small class="card-text text-danger">- '.$rowPointTransaction->pntt_redeem_point.' คะแนน</small>';
								if ($rowActivityData) {
									$nameEvent = htmlspecialchars_decode(trim($rowActivityData->activityName));
									$imgBanner = htmlspecialchars_decode(trim($rowActivityData->imgBanner));
									
								}
							}else {
								continue;
							}
						}

						if($ref_type_id == 11){ // done
							$serv = $this->History_model->SelectHisService($personId, $ref_id)->result_array();
							if(count($serv) > 0){
								foreach($serv as $sv){
									$servId = htmlspecialchars_decode(trim($sv['servId']));
									$caseType = htmlspecialchars_decode(trim($sv['caseType']));
									$quantity = htmlspecialchars_decode(trim($sv['quantity']));
									$building = htmlspecialchars_decode(trim($sv['building']));
									$remark = htmlspecialchars_decode(trim($sv['remark']));

									$picup_point = substr($building,-3);

									if(empty($remark)){
										$remark = '-';
									}

									$pickup = "SELECT puDisplay FROM master_pickUpPoint WITH (NOLOCK) WHERE  puStatus = ? AND puVale = ?";
									$pp = $this->db->query($pickup,array('A',$building))->result_array();
									if(count($pp) > 0){
										foreach($pp as $pi){
											$puDisplay = htmlspecialchars_decode(trim($pi['puDisplay']));
										}
									}

									// CC050601  รถเข็นเด็ก /
									// CC050602  รถ WHEELCHAIR /
									// CC050603  อื่นๆ
									// CC050604  รถเข็น Shopping /
									// CC050605  รถเข็น Kids Car 
									// CC050606  รถเข็นช่วยพยุง /

									if($caseType == 'CC050601'){
										$servName = 'รถเข็นเด็ก (Kids cart)';
									}else if($caseType == 'CC050602'){
										$servName = 'รถเข็นคน (Wheelchair)';
									}else if($caseType == 'CC050604'){
										$servName = 'รถเข็นช้อปปิ้ง (Shopping cart)';
									}else if($caseType == 'CC050606'){
										$servName = 'รถเข็นช่วยพยุง (Support cart)';
									}

								}

								$nameEvent = 'ขอใช้บริการ: '.$servName;

								$description .= '<p class="text-break mb-1" style="line-height: 0.9;">
								<small class="text-muted" style="font-size: 69%;"> '.$puDisplay.'</small> <br>
								<small class="text-muted" style="font-size: 69%;"> จำนวน: '.$quantity.'</small> <br>
								<small class="text-muted" style="font-size: 69%;"> หมายเหตุ: '.$remark.'</small>
								</p>';
							}
						}

						if($ref_type_id == 13){ // done
							$user_success = 'Y';
							// if (in_array($ref_id, $isCheckDuplicationActivityCheckin) && in_array($hisDate, $isActivityCheckinOutDate)){
							// 	continue;
							// }
							$rowActivity = $this->History_model->getActivity($ref_id);
							if($rowActivity){
								$nameEvent = htmlspecialchars_decode(trim($rowActivity->activityName));
								$imgBanner = htmlspecialchars_decode(trim($rowActivity->imgBanner));
								$detail = htmlspecialchars_decode(trim($rowActivity->detail));
								if(!empty($imgBanner)){
									if(getimagesize(PATHIMGCAMPAIGN.$imgBanner)){
										$imageDisplay = '<img src="'.PATHIMGCAMPAIGN.$imgBanner.'?v="'.date('his').' alt="image" onerror="isImg()" class="card-img">';
									}else {
										$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="card-img">';
									}
								}else{
									$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="card-img">';
								}
							}

							$description .= '<p class="text-break mb-1" style="line-height: 0.9;">';
							// $resultActivityCheckIn = $this->History_model->getActivityCheckIn($ref_id, $personId);
							$resultActivityCheckIn = $this->History_model->getActivityCheckInGrop($ref_id, $personId, $perh_id);
							if($resultActivityCheckIn){
								foreach ($resultActivityCheckIn as $rowActivityCheckIn) {
									$datecheckIn = date("d/m/Y  H:i:s", strtotime($rowActivityCheckIn->chk_checkin));
									$datecheckOut = date("d/m/Y  H:i:s", strtotime($rowActivityCheckIn->chk_checkout));
									// if($rowActivityCheckIn->chk_event == 'check-in'){
										$description .= '<small class="text-muted" style="font-size: 69%;"> <i class="far fa-clock fa-xs" style="font-size: 12px;"></i> '.$datecheckIn.'</small> <br>';
									// }else {
										if($rowActivityCheckIn->chk_checkout){
											$description .= '<small class="text-muted" style="font-size: 69%;"> <i class="far fa-clock fa-xs" style="font-size: 12px;"></i> '.$datecheckOut.'</small> <br>';
										}
									// }
								}
							}else {
								continue;
							}
							$description .= '</p>';

							$usedDate = '';
							
							$rowPersonPoint = $this->History_model->getPersonSumPoint($personId, $ref_id, $ref_type_id);
							if($rowPersonPoint){
								$is_used = 'Y'; // ดักเผื่อลงไปแล้ว แต่ is_used ไม่เป็น Y แต่ใน point มีแล้ว
								$user_success = 'Y'; // ดักเผื่อลงไปแล้ว แต่ is_used ไม่เป็น Y แต่ใน point มีแล้ว
								if($rowPersonPoint->perp_type == 'Burn'){
									$showPointText = '<small class="card-text text-danger">- '.$rowPersonPoint->perp_point.' คะแนน</small>';
								}else{
									$showPointText = '<small class="card-text text-success">+ '.$rowPersonPoint->perp_point.' คะแนน</small>';
								}
							}else {
								$showPointText = '';
							}
							// array_push($isCheckDuplicationActivityCheckin,$ref_id);
							// array_push($isActivityCheckinOutDate, $hisDate);
						}
						
						if($ref_type_id == 15){ // done
							// $user_success = 'Y';
							$rowActivity = $this->History_model->getActivity($ref_id);
							if($rowActivity){
								$nameEvent = htmlspecialchars_decode(trim($rowActivity->activityName));
								$imgBanner = htmlspecialchars_decode(trim($rowActivity->imgBanner));
								$detail = htmlspecialchars_decode(trim($rowActivity->detail));
								if(!empty($imgBanner)){
									if(getimagesize(PATHIMGCAMPAIGN.$imgBanner)){
										$imageDisplay = '<img src="'.PATHIMGCAMPAIGN.$imgBanner.'?v="'.date('his').' alt="image" onerror="isImg()" class="card-img">';
									}else {
										$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="card-img">';
									}
								}else{
									$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="card-img">';
								}
							}
							$rowActivityCheckIn = $this->History_model->getActivityReward($ref_id, $personId);
							if(!$rowActivityCheckIn){
								continue;
							}
							$rowPersonPoint = $this->History_model->getPersonPoint($personId, $ref_id, $ref_type_id);
							if($rowPersonPoint){
								$is_used = 'Y'; // ดักเผื่อลงไปแล้ว แต่ is_used ไม่เป็น Y แต่ใน point มีแล้ว
								$user_success = 'Y'; // ดักเผื่อลงไปแล้ว แต่ is_used ไม่เป็น Y แต่ใน point มีแล้ว
								if($rowPersonPoint->perp_type == 'Burn'){
									$showPointText = '<small class="card-text text-danger">- '.$rowPersonPoint->perp_point.' คะแนน</small>';
								}else{
									$showPointText = '<small class="card-text text-success">+ '.$rowPersonPoint->perp_point.' คะแนน</small>';
								}
							}else {
								$showPointText = '';
							}
						}

						if(!empty($imgBanner)){
							if(getimagesize(PATHIMGCAMPAIGN.$imgBanner)){
								$imageDisplay = '<img src="'.PATHIMGCAMPAIGN.$imgBanner.'?v="'.date('his').' alt="image" onerror="isImg()" class="card-img">';
							}else {
								$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="card-img">';
							}
						}else{
							$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="card-img">';
						}

						if($hist_name != 'Edit Redemption'){
							if($codeExpired){
								$endDate = date('H:i:s', strtotime($codeExpired));
								if($endDate == '00:00:00'){
									$codeExpired = date('Y-m-d', strtotime($codeExpired)).' 23:59:59';
								}
							}

							// $history .= '<div class="panel panel-default top10">
							// 			<div class="panel-heading" role="tab" id="REPORT'.$i.'">
							// 				<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse'.$i.'" aria-expanded="false" aria-controls="collapseOne" class="collapsed">
							// 					<div class="panel-title">
							// 						<div><b>'.$nameEvent.'</b></div>
							// 						<div> <b>ประเภท : </b>'.$hist_name.'</div>
							// 						'.$showPointText.'
							// 						<div><b>ใช้เมื่อวันที่ : </b>'.$usedDate.'</div>
							// 					</div>
							// 				</a>
							// 			</div>
							// 			<div id="collapse'.$i.'" class="panel-collapse collapse" role="tabpanel" aria-labelledby="REPORT'.$i.'">
							// 				<div class="panel-body">
							// 					<div class="his-box">'.$imageDisplay.'</div>
							// 					<div class="top10" style="font-size: 20px;">'.$detail.'</div>
							// 					'.$description.'
							// 				</div>
							// 			</div>
							// 		</div>';
							// if($description){
							if($usedDate){
								$userDateText = '
								<p class="card-text d-flex align-items-center mb-0 text-muted">
									<i class="far fa-clock fa-xs" style="font-size: 12px;"></i>
									<small class="text-muted ml-2 usedDate" style="font-size: 69%;"> '.$usedDate.'</small>
								</p>';
							}else {
								$userDateText = '';
							}
							if($DATE_TIME < $codeExpired && $is_used == 'Y' && $user_success == 'N'){
								$historyDetail .= '
								<div class="card mb-3 p-2 card-data-value" imgr="'.$img_qrcodeLink.'" codeShow="'.$codeShow.'" codeExpired="'.$codeExpired.'">
									<div class="row no-gutters mx-0">
										<div class="col-xs-4 col-md-3 col-lg-3">
											'.$imageDisplay.'
										</div>
										<div class="col-xs-8">
											<div class="card-body py-0" style="line-height: 1.3;">
												<h4 class="card-title mt-0 mb-0 text-break text-truncate text-truncate"><strong>'.$nameEvent.'</strong></h4>
												<p class="card-text d-flex align-items-center mb-0">
												<small class="text-muted" style="font-size: 69%;"> '.$hist_name.'</small>
												</p>
												'.$userDateText.'
												'.$dateChekOut.'
												'.$description.'
												<p class="card-text d-flex align-items-center mb-0" style="font-size: 75%;">
												'.$showPointText.'
												</p>
												<p class="card-text d-flex align-items-center mb-0">
												<small class="ml-2 use-code-text" style="font-size: 69%;"> <i class="fas fa-gift"></i> กดเพื่อใช้รหัส </small>
												'.$dateUpdateChekOut.'
												</p>
											</div>
										</div>
									</div>
								</div>';
							}else {
								$historyDetail .= '
								<div class="card mb-3 p-2">
									<div class="row no-gutters mx-0">
										<div class="col-xs-4 col-md-3 col-lg-3">
											'.$imageDisplay.'
										</div>
										<div class="col-xs-8">
											<div class="card-body py-0" style="line-height: 1.3;">
												<h4 class="card-title mt-0 mb-0 text-break text-truncate text-truncate"><strong>'.$nameEvent.'</strong></h4>
												<p class="card-text d-flex align-items-center mb-0">
												<small class="text-muted" style="font-size: 69%;"> '.$hist_name.'</small>
												</p>
												'.$userDateText.'
												'.$dateChekOut.'
												'.$description.'
												<p class="card-text d-flex align-items-center mb-0" style="font-size: 75%;">
												'.$showPointText.'
												</p>
											</div>
										</div>
									</div>
								</div>';
							}
							$historyCount++;
						}
						$i++;
					}
				}

				$resultBirthday = $this->History_model->getPersonPointBirthday($personId,$mount,$YEARS, 16);
				if($resultBirthday){
					foreach ($resultBirthday as $rowBirthday) {
						$usedDate = date("d/m/Y  H:i:s", strtotime($rowBirthday->perp_createdatetime));
						if($rowBirthday->perp_point > 0){
							$showPointText = '<small class="card-text text-success">+ '.$rowBirthday->perp_point.' คะแนน</small>';
						}else {
							$showPointText = '';
						}
						$userDateText = '
								<p class="card-text d-flex align-items-center mb-0 text-muted">
									<i class="far fa-clock fa-xs" style="font-size: 12px;"></i>
									<small class="text-muted ml-2 usedDate" style="font-size: 69%;"> '.$usedDate.'</small>
								</p>';
						$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="card-img">';
						$historyDetail .= '
								<div class="card mb-3 p-2">
									<div class="row no-gutters mx-0">
										<div class="col-xs-4 col-md-3 col-lg-3">
											'.$imageDisplay.'
										</div>
										<div class="col-xs-8">
											<div class="card-body py-0" style="line-height: 1.3;">
												<h4 class="card-title mt-0 mb-0 text-break text-truncate text-truncate"><strong> Birthday Point </strong></h4>
												<p class="card-text d-flex align-items-center mb-0">
												</p>
												'.$userDateText.'
												<p class="card-text d-flex align-items-center mb-0" style="font-size: 75%;">
												'.$showPointText.'
												</p>
											</div>
										</div>
									</div>
								</div>';
								$historyCount++;
					}
				}

				$history .= '
				<div class="d-flex justify-content-between">
					<div class="text-highlight">'.$textMount.'</div>
					<div class="text-highlight">'.$historyCount.' รายการ</div>
				</div>';
				$history .= $historyDetail;
			}
		}else{
			$history = '<div class="text-highlight text-center">ไม่พบข้อมูล</div>';
		}

		$data['historyData'] = $history;
		$data['DATE_TIME'] = $DATE_TIME;
		$clsImg = date('his');
		$data['default_image'] = $uri.'assets/images/default_image.jpg?v='.$clsImg;

        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view($path_menu.'/his_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function updateActivityPromotion()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('shopCode', 'รหัสร้านค้า', 'required|trim|numeric|max_length[11]');
		$this->form_validation->set_rules('balance', 'จำนวนเงิน', 'numeric|max_length[20]');
		$this->form_validation->set_rules('voucher', 'รหัส Voucher', 'max_length[20]');
		$codeId = $this->input->post('codeId');
		if(!$codeId){
			echo json_encode(array('error' => 'ผิดพลาดกรุณาลองใหม่'));
			exit;
		}
		$this->form_validation->set_message('required', 'กรุณาระบุ %s');
		$this->form_validation->set_message('numeric', '%s ต้องระบุเป็นตัวเลข');
		$this->form_validation->set_message('max_length', '{field} ต้องไม่เกิน {param} ตัว');
        $this->form_validation->set_message('trim', 'กรุณาระบุ %s');
		
        if ($this->form_validation->run() == FALSE) {
			echo json_encode(array('error' => $this->form_validation->error_string()));
        } else {
			$personId = $this->session->userdata('userfprid');
			$rowActivityReward = $this->History_model->getActivityCodeByCodeId($codeId);
			if ($rowActivityReward) {
				echo json_encode(array('error' => 'ขออภัย คุณได้ใช้สิทธิ์นี้แล้ว'));
				exit;
			}
			$rowActivityCode = $this->History_model->getActivityCodeByCodeId($codeId);
			if($rowActivityCode){
				$dateTimeNow = date('Y-m-d H:i:s');
				$shopCode = $this->input->post('shopCode');
				
				$rowMasterShop = $this->History_model->getMaster_shop($shopCode);
				if(!$rowMasterShop){
					echo json_encode(array('error' => 'รหัสร้านค้า ไม่ถูกต้อง'));
					exit;
				}
				
				$balance = $this->input->post('balance');
				$voucher = $this->input->post('voucher');

				$dataInsert = array(
					'campId' => $rowActivityCode->campId,
					'subcampId' => $rowActivityCode->subcampId,
					'activityId' => $rowActivityCode->activityId,
					'ti_id' => $rowActivityCode->ti_id,
					'personId' => $personId,
					'codeId' => $codeId,
					'rwt_id' => $rowActivityCode->historyId,
					'status' => $this->config->item('status_active'),
					'usedtime' => $rowActivityCode->usedtime,
					'rewardStatus' => 'Completed',
					'shopCode' => $shopCode,
					'balance' => $balance ? $balance : null,
					'voucher' => $voucher,
					'refChannel' => 'Line',
					'dateTimeNow' => $dateTimeNow,
				);
				$this->db->trans_begin();
				$insertData = $this->History_model->insertActivityReward($dataInsert);
				if ($this->db->trans_status() === FALSE)
				{
					$this->db->trans_rollback();
					log_message('error', $this->db->_error_message());
				}
				else
				{
					$this->db->trans_commit();
					echo json_encode(array('success' => 'success'));
				}
			}else {
				echo json_encode(array('error' => 'ผิดพลาดไม่พบ Code กรุณาลองใหม่'));
				exit;
			}
			

		}
	}

	function badge(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		
		$path_menu = "profile";
		

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

		$getParam	= $this->input->get('c');

		if(isset($getParam))
		{
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $getParam;
		}else{
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);
			$person_id = $check_session;
			$data['person_id'] = $param;
		}
		$dataResponse = [];
		$sqlsub = $this->Lists_model->selectBadgeSubcamp()->result();
		foreach ($sqlsub as $subCampainData) {
			$detailBage = [];
			$sqlBadge = $this->Lists_model->selectBadgeActivity($subCampainData->subcampId)->result();
			if($sqlBadge){
				foreach ($sqlBadge as $dataBadge) {
					$countBadge = $this->Lists_model->selectLogBadgeActivityNew($person_id, $dataBadge->subcampId, $dataBadge->activityId, $dataBadge->badgeId);
					$found_key = array_search($dataBadge->activityId, array_column($detailBage, 'activityId'));
					if($found_key === false){
						array_push($detailBage, array(
							'badgeName' => $dataBadge->badgeName, 
							'badgeImg' => PATHIMGCAMPAIGN.$dataBadge->file_path.'?v='.date('his'), 
							'activityId' => $dataBadge->activityId,
							'badgeId' => $dataBadge->badgeId,
							'badgeQty' => $countBadge, 
						));
					}
				}
			}
			array_push($dataResponse, array(
				'subcampName' => $subCampainData->subcampName,
				'detailBage' => $detailBage,
			));
		}
		$data['dataResponse'] = $dataResponse;
        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view($path_menu.'/badge_from',$data);  
		$this->load->view('template/footer',$data_header);
	}

	function lifestyle(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		
		$path_menu = "profile";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

		$getParam	= $this->input->get('c');

		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			$data['param'] = $param;
			$data['person_id'] = $check_session;
		}

		$data['list_style'] = '';
		$list_style = '';
		$i = 1;

		$rs = $this->Lists_model->person_lifestyle($data['person_id'])->result_array();
		if(count($rs) > 0){
			foreach($rs as $r){
				$lf_id = htmlspecialchars_decode(trim($r['lf_id']));
				$lf_name = htmlspecialchars_decode(trim($r['plf_name']));

				$checked = '';

				$list_style .= '
						<div class="col-6 layout" sid="'.$lf_id.'" >
							<span class="box-life" id="style_'.$lf_id.'" check="" sid="'.$lf_id.'" name="'.$lf_name.'">
							<i class="fa fa-check icon-life"></i>
							'.$lf_name.'</span>
						</div>';

				

			}

			$data['list_style'] = $list_style;
		}

        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view($path_menu.'/life_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function editlifestyle(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		
		$path_menu = "profile";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true,
			"myModal"	      => true,
        );

		$getParam	= $this->input->get('c');

		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			$data['param'] = $param;
			$data['person_id'] = $check_session;
		}

		$data['list_style'] = '';
		$list_style = '';

		$rs = $this->Lists_model->master_lifestyle()->result_array();
		$count = count($rs);
		if(count($rs) > 0){
			foreach($rs as $r){
				$lf_id = htmlspecialchars_decode(trim($r['lf_id']));
				$lf_name = htmlspecialchars_decode(trim($r['lf_name']));

				$style = '';
				$none = 'd-none';
				$plf_id = '';
				$check = '';

				$life = $this->Lists_model->person_lifestyle($data['person_id'],$lf_id)->result_array();
				if(count($life) > 0){
					foreach($life as $l){
						$perlf_id = htmlspecialchars_decode(trim($l['lf_id']));
						$plf_id = htmlspecialchars_decode(trim($l['plf_id']));
					
						
						if($lf_id == $perlf_id){
							$style = 'box-life-selected';
							$none = '';
							$check = 'check';
							
						}
					}
				}

				$list_style .= '
						<div class="col-6 layout" sid="'.$lf_id.'" onclick="select_lifestyle('.$lf_id.')"; >
							<span class="box-life '.$style.'" id="style_'.$lf_id.'" check="'.$check.'" sid="'.$lf_id.'" name="'.$lf_name.'" plf_id ="'.$plf_id.'" >
							<i class="fa fa-check icon-life '.$none.'"></i>
							'.$lf_name.'</span>
						</div>';

			}

			$data['list_style'] = $list_style;
			
		}

        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view($path_menu.'/life_edit',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function update_lifestyle() {
		
		$personId = $this->input->post('pid');
		$rs = $this->Lists_model->person_lifestyle($personId)->result_array();
		$count = count($rs);
		if(count($rs) > 0){
			$data['plf_usable'] = '';
			$data['plf_status'] = 'I';

			$array_where = array('personId' => $personId);
			$this->db->where($array_where);
			$this->db->update('person_lifestyle', $data);
		}

		
		$detail = json_decode($this->input->post('data'),true);
		// print_r($detail); exit;
		foreach($detail as $d){
			$data['lf_id'] = trim($d['id']);
			$data['plf_name'] = trim($d['name']);
			$data['plf_usable'] = 'Y';
			$data['plf_status'] = 'A';
			$data['personId'] = $personId;
			$plf_id = trim($d['plf_id']);

			if($plf_id == ''){
				$this->db->insert('person_lifestyle', $data);
			}else{
				$array_where = array('personId' => $personId,'plf_id' => $plf_id);
				$this->db->where($array_where);
				$this->db->update('person_lifestyle', $data);
			}
		}

		echo "Success";
	}

	function logout(){
		$this->session->unset_userdata('userfprid');
		$this->session->sess_destroy();
								
			redirect(URLFRONT_Login);
		
	}

	// lifestyle
	public function getMasterLifeStyle()
	{
		$getParam	= $this->input->get('c');

		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$person_id = $this->session->userdata('userfprid');
		}

		$masterLifeStyle = $this->Lists_model->getViewLifeStyle();
		$myLifeStyle = $this->Lists_model->getPersonLifeStyleReuslt($person_id);
		$dataMaster = array(
			'masterLifeStyle' => $masterLifeStyle,
			'myLifeStyle' => $myLifeStyle,
		);
		echo json_encode($dataMaster);
	}
	
	public function getMyLifeStyle()
	{
		$getParam	= $this->input->get('c');

		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$person_id = $this->session->userdata('userfprid');
		}

		$myLifeStyle = $this->Lists_model->getPersonLifeStyleReuslt($person_id);
		$dataMaster = array(
			'myLifeStyle' => $myLifeStyle,
		);
		echo json_encode($dataMaster);
	}

	public function postLifeStyle()
	{
		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$person_id = $this->session->userdata('userfprid');
		}

		$dataPost = $this->input->post("dataLifeStyle");
		$dataLifeStyle = json_decode($dataPost);
		// print_r($dataLifeStyle);
		// exit;
		$this->Lists_model->deletePersonLifeStyle($person_id);
		if($dataLifeStyle){
			$isSave = false;
			foreach ($dataLifeStyle as $rowLifeStyle) {
				$myLifeStyleOld = $this->Lists_model->getPersonLifeStyle($person_id, $rowLifeStyle->cat, $rowLifeStyle->subCat, $rowLifeStyle->life);
				// note : getPersonLifeStyle ใน model ปิด plf_status เพื่อให้หาเจอ ใช้ update ได้ แต่จะเก็บประวัติไม่ได้ 
				$dataLifeStyle = array(
					'plf_id' => $myLifeStyleOld ? $myLifeStyleOld->plf_id : null,
					'personId' => $person_id,
					'lf_id' => $rowLifeStyle->life,
					'plf_name' => $rowLifeStyle->lifeName,
					'plf_usable' => 'Y',
					'plf_status' => $this->config->item('status_active'),
					'category_id' => $rowLifeStyle->cat,
					'category_name' => $rowLifeStyle->catName,
					'sub_category_id' => $rowLifeStyle->subCat,
					'sub_category_name' => $rowLifeStyle->subCatName,
					'now' => date('Y-m-d H:i:s'),
				);
				if($myLifeStyleOld){ // update
					$resultQuery = $this->Lists_model->updatePersonLifeStyle($dataLifeStyle);
					if($resultQuery){
						$isSave = true;
					}else {
						$isSave = false;
					}
				}else {
					$resultQuery = $this->Lists_model->insertPersonLifeStyle($dataLifeStyle);
					if($resultQuery){
						$isSave = true;
					}else {
						$isSave = false;
					}
				}
			}

			if($isSave){
				echo json_encode(array('success' => 'บันทึกสำเร็จ'));
			}else {
				echo json_encode(array('error' => 'บันทึกไม่สำเร็จ'));
			}
		}else {
			// user ลบออกหมด
			echo json_encode(array('success' => 'บันทึกสำเร็จ'));
		}
	}
	// lifestyle
}
