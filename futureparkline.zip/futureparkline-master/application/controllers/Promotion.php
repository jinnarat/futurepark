<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);
ini_set('memory_limit', '1024M');
ini_set('sqlsrv.ClientBufferMaxKBSize', '524288');
ini_set('pdo_sqlsrv.client_buffer_max_kb_size', '524288');

class Promotion extends DB_Controller
{
	protected $authDataPerson;
	function __construct()
	{
		parent::__construct();
		$this->load->model('Main_function');
		$this->load->model('Select_data');
		$this->load->model('Lists_model');
		$this->load->model('QRCodeModel');
		
		$this->load->model('PersonModel');
		$personID = $this->session->userdata('userfprid');
		if (!$personID) {
			redirect(URLFRONT_Login);
		}else {
			$resutlPerson = $this->PersonModel->getPersonData($personID);
			if ($resutlPerson) {
				$this->authDataPerson = $resutlPerson;
			}else {
				redirect(URLFRONT_Login);
			}
		}
	}
	public function index()
	{
		$uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,
			"META_DESC"       => META_DESC,
			"stylesheet"      => '',
			"javascript"      => '',
			"fb_title"        => OG_TITLE,
			"fb_image"        => OG_IMAGE,
			"fb_description"  => OG_DESC,
			"myModal"	      => true,
			"isHeader"        => true
		);

		$getParam	= $this->input->get('c');
		if (isset($getParam)) {
			$person_id	= $this->MainModel->Base64Decrypt($getParam);
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		} else {
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			$data['param'] = $param;
			$data['person_id'] = $check_session;
		}

		$personId = $data['person_id'];
		$data['list_promotion'] = '';
		$DATE_TIME = date("Y-m-d H:i:s");

		$sql = $this->Lists_model->SelectPromotion(null, null, $DATE_TIME)->result_array();

		if (count($sql) > 0) {

			foreach ($sql as $a) {
				$activityId = htmlspecialchars_decode(trim($a['activityId']));
				$is_only_member = trim($a['is_only_member']);
				$usedTargetCDP = trim($a['usedTargetCDP']);
				$activityType = trim($a['activityType']);
				$regis_new_system = trim($a['regis_new_system']);
				$insertData = trim($a['insertData']);
				$isShowAct = false;
				if ($a['campStatus'] != 'A' || $a['subcampStatus'] != 'A') {
					continue;
				}

				$regis_new_system = strtolower($regis_new_system);

				if ($usedTargetCDP == 'Y' || ($regis_new_system != '' && $regis_new_system != NULL)){
					if ($insertData == 'Y') {
						$isShowAct = false;
					}else {
						$checkCdpTarget = $this->Lists_model->getActivityTargetPersonal($activityId, $personId);
						if ($checkCdpTarget) {
							$isShowAct = true;
						} else {
							$isShowAct = false;
						}
					}
				} else {
					if ($activityType == 'Promotion') {
						if ($is_only_member == 'Y') {
							$actMember = $this->Lists_model->getActivityMember($a['activityId']);
							if ($actMember) {
								$personData = $this->Lists_model->getPerson($data['person_id']);
								foreach ($actMember as  $rowActMem) {
									if ($personData->ti_id == $rowActMem->tier_id) {
										$isShowAct = true;
									}
								}
							} else {
								$isShowAct = false;
							}
						} else {
							$isShowAct = true;
						}
					}
				}

				if (!$isShowAct) {
					continue;
				}

				$campId = htmlspecialchars_decode(trim($a['campId']));
				$activityCode = htmlspecialchars_decode(trim($a['activityCode']));
				$activityType = htmlspecialchars_decode(trim($a['activityType']));
				$activityName = htmlspecialchars_decode(trim($a['activityName']));
				$urlfriendly = htmlspecialchars_decode(trim($a['urlfriendly']));
				$imgBanner = htmlspecialchars_decode(trim($a['imgBanner']));
				$detail = htmlspecialchars_decode(trim($a['detail']));
				$limit = htmlspecialchars_decode(trim($a['limit']));
				$startDate = htmlspecialchars_decode(trim($a['startDate']));
				$endDate = htmlspecialchars_decode(trim($a['endDate']));
				$endDisplay = htmlspecialchars_decode(trim($a['endDisplay']));

				if (!empty($imgBanner)) {
					if (getimagesize(PATHIMGCAMPAIGN . $imgBanner)) {
						$imageDisplay = '<span class="landing-item-cover landing-item-cover-short"><img src="' . PATHIMGCAMPAIGN . $imgBanner . '?v="' . date('his') . ' alt=" " class="responsive size-img"></span>';
					} else {
						$imageDisplay = '<span class="landing-item-cover landing-item-cover-short"><img src="' . $uri . 'assets/images/default_image.jpg?v="' . date('his') . '" alt=" " class="responsive size-img default-img"></span>';
					}
				} else {
					$imageDisplay = '<span class="landing-item-cover landing-item-cover-short"><img src="' . $uri . 'assets/images/default_image.jpg?v="' . date('his') . '" alt=" " class="responsive size-img default-img"></span>';
				}

				$enAid = $this->MainModel->Base64Encrypt($activityId);
				$enPid = $this->MainModel->Base64Encrypt($personId);

				if ($endDisplay >= $DATE_TIME) {

					$mapLink = 'promotion';
					$rowMasterActivityLink = $this->Lists_model->getMasterActivityLink($activityType);
					if ($rowMasterActivityLink) {
						$mapLink = $rowMasterActivityLink->mapLink;
					}

					$data['list_promotion'] .= '<div class="borderBox">
													<div class="promo-img">
														<a href="' . PATHIMGCAMPAIGN . $mapLink.'/' . $urlfriendly . '?r=Line&aId=' . $enAid . '&pId=' . $enPid . '" target="_blank">
															' . $imageDisplay . '
														</a>
													</div>
													<div class="container promo-detail">
														<p><b class="activityName">' . $activityName . '</b></p>
														<p>' . $startDate . ' - ' . $endDate . '</p>
													</div>
												</div>';
				}
			}
		} else {
			$data['list_promotion'] .= '<div class="container promo-detail text-center">
										<p><b>ไม่มีข้อมูล</b></p>
									</div>';
		}

		if ($data['list_promotion'] == '') {
			$data['list_promotion'] .= '<div class="container promo-detail text-center">
										<p><b>ไม่มีข้อมูล</b></p>
									</div>';
		}

		$data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header', $data_header);
		$this->load->view('promo_from', $data);
		$this->load->view('template/footer', $data_header);
	}
}
