<?php
defined('BASEPATH') or exit('No direct script access allowed');

ini_set('max_execution_time', 0);
set_time_limit(9000);
ini_set('memory_limit', '-1');
ini_set('sqlsrv.ClientBufferMaxKBSize', '524288'); // Setting to 512M
ini_set('pdo_sqlsrv.client_buffer_max_kb_size', '524288'); // Setting to 512M - for pdo_sqlsrv

class Fncauth extends DB_Controller
{

    function __construct()
    {
        parent::__construct();
        $this->load->model('Lists_model');
        $this->load->model('PersonModel');
        $this->load->model('MainModel');
        $this->load->library('oauth2');
        // $this->load->library('authorization');       
    }

    function check_member()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
        $resutlAPI = new stdClass;
        $resutlAPI->success = false;
        $resutlAPI->message = false;
        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            if ($this->session->userdata('dataPhoneNumber')) {
                $phone         = trim($this->session->userdata('dataPhoneNumber'));
            } else {
                $phone         = trim($this->input->post('phone'));
            }

            $email         = trim($this->input->post('email'));
            if ($phone == "" && $email == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data phone and email is empty');
            }

            if ($phone != '') {
                $data = "mobile_no=" . $phone;
            } else {
                $data = "email=" . $email;
            }

            // $data .= "&exclude_status=D";

            $checkStatus = $this->oauth2->check_status($token, $data);

            $responseData = $this->checkAPIData($checkStatus);
            if ($responseData->success) {
                $decodecheck = $responseData->data;

                if ($decodecheck->success == false) {
                    $dataRes['detail']    = array('STATUS' => 'NEW_MEMBER', 'is_member' => 'N', 'phone' => $phone);
                    $dataRes['status']     = array('STATUS' => 'NEW_MEMBER', 'is_member' => 'N');
                } else {
                    $is_member      = $decodecheck->response_body->is_member;
                    $verify_phone   = $decodecheck->response_body->verify_phone;
                    $verify_email   = $decodecheck->response_body->verify_email;

                    // if(($verify_phone && $verify_email )||$verify_phone){
                    if ($verify_phone) {
                        if ($is_member) {
                            $person_id  = $decodecheck->response_body->person[0]->id;
                            $firstname  = $decodecheck->response_body->person[0]->firstname;
                            $lastname   = $decodecheck->response_body->person[0]->lastname;
                            $date_of_birth   = $decodecheck->response_body->person[0]->date_of_birth;
                            $email      = $decodecheck->response_body->person[0]->email;
                            $gender     = $decodecheck->response_body->person[0]->gender;
                            $id_card_no = $decodecheck->response_body->person[0]->id_card_no;
                            $consent    = $decodecheck->response_body->person[0]->consent;
                            $subscribe  = $decodecheck->response_body->person[0]->subscribe;
                            $nationality = $decodecheck->response_body->person[0]->nationality;
                            $passport_no = $decodecheck->response_body->person[0]->passport_no;

                            $register_datetime = '';
                            $pid_session = '';

                            $this->session->set_userdata('dataID', $person_id);

                            $personLine = "SELECT register_datetime FROM person WITH (NOLOCK) WHERE personId = ? AND personStatus = ? ";
                            $sqlPerson = $this->db->query($personLine, array($person_id, 'A'))->result_array();
                            if (count($sqlPerson) > 0) {
                                foreach ($sqlPerson as $r) {
                                    $register_datetime = htmlspecialchars_decode(trim($r['register_datetime']));
                                }

                                if (!empty($register_datetime) && $register_datetime != '00-00-00 00:00:00') {
                                    $person = "SELECT psid_session_id FROM person_session_id WITH (NOLOCK) WHERE personId = ? AND psid_status = ? ";
                                    $sql = $this->db->query($person, array($person_id, 'Active'))->result_array();
                                    if (count($sql) > 0) {
                                        foreach ($sql as $r) {
                                            $pid_session = htmlspecialchars_decode(trim($r['psid_session_id']));
                                        }
                                    }

                                    $dataRes['status']     = array('STATUS' => 'Success_memberLine');
                                } else {
                                    $dataRes['status']     = array('STATUS' => 'Success_member');
                                }
                            } else {
                                $dataRes['status']     = array('STATUS' => 'Success_member');
                            }
                            // $resObj    = array('is_member' => 'Y', 'ID' => $person_id, 'FIRST' => $firstname, 'LAST' => $lastname, 'BIRTH' => $date_of_birth, 'EMAIL' => $email, 'GENDER' => $gender, 'IDCARD' => $id_card_no, 'CONSENT' => $consent, 'SUB' => $subscribe, 'NATIONAL' => $nationality, 'PASSPORT' => $passport_no, 'session_id' => $pid_session);
                            $resObj    = array('is_member' => 'Y', 'phone' => $phone);
                            $dataRes['detail']    = $resObj;
                        } else {
                            $count = count($decodecheck->response_body->person);
                            $dataRes['status']     = array('STATUS' => 'Successfully', 'is_member' => 'N');
                        }
                    } else {

                        //เลือกสมาชิก
                        $count = count($decodecheck->response_body->person);

                        $dataRes['status']     = array('STATUS' => 'Select_Person', 'is_member' => 'N');
                    }
                }
            } else {
                $dataRes['status']     = array('STATUS' => 'Unsuccessfully', 'message' => $responseData->message);
            }


            echo  json_encode($dataRes);
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }

    function get_member()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            $phone         = trim($this->input->post('phone'));
            $pid        = trim($this->input->post('pid'));
            $reigs        = trim($this->input->post('reigs'));
            $checkF  = '';
            $checkM  = '';

            $birthYear     = '';
            $birthMonth    = '';
            $birthDay     = '';

            // echo 'pid  :'.$pid;
            if ($phone == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data phone is empty');
            }

            // $data = "mobile_no=" . $phone . "&id=" . $pid;
            // $data = "mobile_no=" . $phone;

            // echo 'data :'.$data; exit;
            // $data .= "&exclude_status=D";
            $responseData = new stdClass;

            if ($pid) {
                $rowPerson = $this->PersonModel->getPersonDataByPersonID($pid);
                if ($rowPerson) {
                    $person_id      = $rowPerson->personId;
                    $firstname  = $rowPerson->firstname;
                    $lastname   = $rowPerson->lastname;
                    $date_of_birth   = $rowPerson->birthdate;
                    $email      = $rowPerson->email;
                    $gender     = $rowPerson->gender;
                    $id_card_no = $rowPerson->idCardNo;
                    // $id_card_no = '';
                    $consent    = $rowPerson->is_consent;
                    $subscribe  = $rowPerson->preferredChannel;
                    $nationality = $rowPerson->nationCode;
                    $passport_no = $rowPerson->passportNo;
                    $member_number_ref = $rowPerson->memberNoRef;
                    $checkF = '';
                    $checkM = '';
                        if ($gender) {
                            $checkF = $gender == 'F' ? 'checked' : '';
                            $checkM = $gender == 'M' ? 'checked' : '';
                        }
                        $f_gender = ' <div class="radio-tile-group top30 row">
                        <div class="input-container col-5">
                            <input class="radio-button" required type="radio" name="gender"  value="Male" ' . $checkM . '/>
                            <div class="radio-tile">
                                <div class="icon text-center">
                                    <h3 class="mt-2"><i class="fa fa-male"></i></h3>
                                </div>
                            </div>
                        </div>
                        <div class="input-container col-5">
                            <input class="radio-button" required type="radio" name="gender" value="Female"  ' . $checkF . ' />
                            <div class="radio-tile">
                                <div class="icon text-center">
                                    <h3 class="mt-2"><i class="fa fa-female"></i></h3>
                                </div>
                            </div>
                        </div>
                    </div>';

                    if ($date_of_birth != "" && $date_of_birth != '0000-00-00') {
                        $arrBirth    = explode("-", $date_of_birth);
                        if (isset($arrBirth[0])) $birthYear    = $arrBirth[0];
                        if (isset($arrBirth[1])) $birthMonth    = $arrBirth[1];
                        if (isset($arrBirth[2])) $birthDay    = $arrBirth[2];
                    }
                    // $date_of_birth 	= trim($r['birthdate']);
                    $birthYear     = $birthYear ? (int)$birthYear : '';
                    $birthMonth    = $birthMonth ? (int)$birthMonth : '';
                    $birthDay     = $birthDay ? (int)$birthDay : '';

                    $resObj    = array(
                        'birthdate' => $date_of_birth,
                        'birthYear' => $birthYear,
                        'birthMonth' => $birthMonth,
                        'birthDay' => $birthDay,
                        'ID' => $person_id,
                        'FIRST' => $firstname,
                        'LAST' => $lastname,
                        'BIRTH' => $date_of_birth,
                        'EMAIL' => $email,
                        'GENDER' => $f_gender,
                        'IDCARD' => $id_card_no,
                        'CONSENT' => $consent,
                        'SUB' => $subscribe,
                        'NATIONAL' => $nationality,
                        'PASSPORT' => $passport_no,
                        'MEMNOCRM' => $member_number_ref
                    );
                    $dataRes['detail']    = $resObj;
                    $dataRes['status']     = array('STATUS' => 'Success_member');
                }

            }else {
                $data = "mobile_no=" . $phone;
                $checkStatus = $this->oauth2->check_status($token, $data);
                // $checkStatus = $this->oauth2->check_status($token, $data);
                $responseData = $this->checkAPIData($checkStatus);
                if ($responseData->success) {
                    $decodecheck = $responseData->data;
    
                    if ($decodecheck->success == false) {
                        $formgender = ' <div class="radio-tile-group top30 row">
                                <div class="input-container col-5">
                                    <input class="radio-button" required type="radio" name="gender"  value="Male"/>
                                    <div class="radio-tile">
                                        <div class="icon text-center">
                                            <h3 class="mt-2"><i class="fa fa-male"></i></h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="input-container col-5">
                                    <input class="radio-button" required type="radio" name="gender"  value="Female" />
                                    <div class="radio-tile">
                                        <div class="icon text-center">
                                            <h3 class="mt-2"><i class="fa fa-female"></i></h3>
                                        </div>
                                    </div>
                                </div>
                            </div>';
    
    
                        $resObj = array('STATUS' => 'NEW_MEMBER', 'GENDER' => $formgender);
    
                        $dataRes['detail']    = $resObj;
                        $dataRes['status']     = array('STATUS' => 'NEW_MEMBER');
                    } else {
    
                        $is_member      = $decodecheck->response_body->is_member;
                        $verify_phone   = $decodecheck->response_body->verify_phone;
                        $register_datetime = '';
    
                        if ($verify_phone =='Y' && $is_member == 'Y') {
                            $person_id      = $decodecheck->response_body->person[0]->id;
                            $firstname  = $decodecheck->response_body->person[0]->firstname;
                            $lastname   = $decodecheck->response_body->person[0]->lastname;
                            $date_of_birth   = $decodecheck->response_body->person[0]->date_of_birth;
                            $email      = $decodecheck->response_body->person[0]->email;
                            $gender     = $decodecheck->response_body->person[0]->gender;
                            $id_card_no = $decodecheck->response_body->person[0]->id_card_no;
                            // $id_card_no = '';
                            $consent    = $decodecheck->response_body->person[0]->consent;
                            $subscribe  = $decodecheck->response_body->person[0]->subscribe;
                            $nationality = $decodecheck->response_body->person[0]->nationality;
                            $passport_no = $decodecheck->response_body->person[0]->passport_no;
                            $member_number_ref = $decodecheck->response_body->person[0]->member_number_ref;
    
                            $personLine = "SELECT register_datetime FROM person WITH (NOLOCK) WHERE personId = ? AND personStatus = ? ";
                            $sqlPerson = $this->db->query($personLine, array($person_id, 'A'))->result_array();
                            if (count($sqlPerson) > 0) {
    
                                foreach ($sqlPerson as $r) {
                                    $register_datetime = htmlspecialchars_decode(trim($r['register_datetime']));
                                }
    
                                if (!empty($register_datetime) && $register_datetime != '00-00-00 00:00:00') {
    
                                    $personLine = "SELECT personId FROM person_social WITH (NOLOCK) WHERE socialType = ? AND socialStatus = ?  AND personId = ? ";
                                    $NumrowLine = $this->db->query($personLine, array('Line', 'A', $person_id))->num_rows();
                                    $checkF = '';
                                    $checkM = '';
                                    if ($NumrowLine == 0 || $reigs) {
                                        if ($gender == 'Female') {
                                            $checkF = 'checked';
                                        } else {
                                            $checkM = 'checked';
                                        }
                                        $f_gender = ' <div class="radio-tile-group top30 row">
                                        <div class="input-container col-5">
                                            <input class="radio-button" required type="radio" name="gender"  value="Male" ' . $checkM . '/>
                                            <div class="radio-tile">
                                                <div class="icon text-center">
                                                    <h3 class="mt-2"><i class="fa fa-male"></i></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-container col-5">
                                            <input class="radio-button" required type="radio" name="gender" value="Female"  ' . $checkF . ' />
                                            <div class="radio-tile">
                                                <div class="icon text-center">
                                                    <h3 class="mt-2"><i class="fa fa-female"></i></h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>';
                                    } else {
                                        $f_gender = $gender;
                                    }
    
                                    if ($date_of_birth != "" && $date_of_birth != '0000-00-00') {
                                        $arrBirth    = explode("-", $date_of_birth);
                                        if (isset($arrBirth[0])) $birthYear    = $arrBirth[0];
                                        if (isset($arrBirth[1])) $birthMonth    = $arrBirth[1];
                                        if (isset($arrBirth[2])) $birthDay    = $arrBirth[2];
                                    }
                                    // $date_of_birth 	= trim($r['birthdate']);
                                    
                                    $birthYear     = $birthYear ? (int)$birthYear : '';
                                    $birthMonth    = $birthMonth ? (int)$birthMonth : '';
                                    $birthDay     = $birthDay ? (int)$birthDay : '';
    
                                    $resObj    = array('birthdate' => $date_of_birth, 'birthYear' => $birthYear, 'birthMonth' => $birthMonth, 'birthDay' => $birthDay, 'ID' => $person_id, 'FIRST' => $firstname, 'LAST' => $lastname, 'BIRTH' => $date_of_birth, 'EMAIL' => $email, 'GENDER' => $f_gender, 'IDCARD' => $id_card_no, 'CONSENT' => $consent, 'SUB' => $subscribe, 'NATIONAL' => $nationality, 'PASSPORT' => $passport_no, 'MEMNOCRM' => $member_number_ref);
                                    // $resObj	= array('ID' => $person_id, 'FIRST' => $firstname, 'LAST' => $lastname, 'BIRTH' =>$date_of_birth, 'EMAIL' =>$email, 'GENDER' =>$f_gender, 'IDCARD' =>$id_card_no, 'CONSENT' =>$consent, 'SUB' =>$subscribe, 'NATIONAL' =>$nationality, 'PASSPORT' =>$passport_no,'MEMNOCRM' => $member_number_ref);
    
                                    $dataRes['detail']    = $resObj;
                                    $dataRes['status']     = array('STATUS' => 'Success_member');
                                } else {
                                    $checkF = '';
                                    $checkM = '';
                                    if ($gender == 'Female') {
                                        $checkF = 'checked';
                                    } else {
                                        $checkM = 'checked';
                                    }
    
                                    $formgender = ' <div class="radio-tile-group top30 row">
                                        <div class="input-container col-6">
                                            <input class="radio-button" required type="radio" name="gender"  value="Male" ' . $checkM . '/>
                                            <div class="radio-tile">
                                                <div class="icon text-center">
                                                    <h3 class="mt-2"><i class="fa fa-male"></i></h3>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="input-container col-6">
                                            <input class="radio-button" required type="radio" name="gender" value="Female"  ' . $checkF . ' />
                                            <div class="radio-tile">
                                                <div class="icon text-center">
                                                    <h3 class="mt-2"><i class="fa fa-female"></i></h3>
                                                </div>
                                            </div>
                                        </div>
                                    </div>';
    
                                    if ($date_of_birth != "" || $date_of_birth != '0000-00-00') {
                                        $arrBirth    = explode("-", $date_of_birth);
                                        if (isset($arrBirth[0])) $birthYear    = $arrBirth[0];
                                        if (isset($arrBirth[1])) $birthMonth    = $arrBirth[1];
                                        if (isset($arrBirth[2])) $birthDay    = $arrBirth[2];
                                    }
                                    // $date_of_birth 	= trim($r['birthdate']);
                                    $birthYear     = $birthYear ? (int)$birthYear : '';
                                    $birthMonth    = $birthMonth ? (int)$birthMonth : '';
                                    $birthDay     = $birthDay ? (int)$birthDay : '';
    
    
                                    $resObj    = array('birthdate' => $date_of_birth, 'ID' => $person_id, 'FIRST' => $firstname, 'LAST' => $lastname,  'GENDER' => $formgender, 'CONSENT' => $consent, 'SUB' => $subscribe, 'NATIONAL' => $nationality, 'MEMNOCRM' => $member_number_ref);
    
                                    $dataRes['detail']    = $resObj;
                                    $dataRes['status']     = array('STATUS' => 'Success_member');
                                }
                            }
                        } else if ($verify_phone =='Y' || $is_member =='Y') {
                            $person_id  = $decodecheck->response_body->person[0]->id;
                            $firstname  = $decodecheck->response_body->person[0]->firstname;
                            $lastname   = $decodecheck->response_body->person[0]->lastname;
                            $date_of_birth   = $decodecheck->response_body->person[0]->date_of_birth;
                            $email      = $decodecheck->response_body->person[0]->email;
                            $gender     = $decodecheck->response_body->person[0]->gender;
                            $id_card_no = $decodecheck->response_body->person[0]->id_card_no;
                            // $id_card_no = '';
                            $consent    = $decodecheck->response_body->person[0]->consent;
                            $subscribe  = $decodecheck->response_body->person[0]->subscribe;
                            $nationality = $decodecheck->response_body->person[0]->nationality;
                            $passport_no = $decodecheck->response_body->person[0]->passport_no;
                            $member_number_ref = $decodecheck->response_body->person[0]->member_number_ref;
    
                            $checkF = '';
                            $checkM = '';
                            if ($gender == 'Female') {
                                $checkF = 'checked';
                            } else {
                                $checkM = 'checked';
                            }
    
                            $formgender = ' <div class="radio-tile-group top30 row">
                                                    <div class="input-container col-5">
                                                        <input class="radio-button" required type="radio" name="gender"  value="Male" ' . $checkM . '/>
                                                        <div class="radio-tile">
                                                            <div class="icon text-center">
                                                                <h3 class="mt-2"><i class="fa fa-male"></i></h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="input-container col-5">
                                                        <input class="radio-button" required type="radio" name="gender" value="Female"  ' . $checkF . ' />
                                                        <div class="radio-tile">
                                                            <div class="icon text-center">
                                                                <h3 class="mt-2"><i class="fa fa-female"></i></h3>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>';
    
                            if ($date_of_birth != "" && $date_of_birth != '0000-00-00') {
                                $arrBirth    = explode("-", $date_of_birth);
                                if (isset($arrBirth[0])) $birthYear    = $arrBirth[0];
                                if (isset($arrBirth[1])) $birthMonth    = $arrBirth[1];
                                if (isset($arrBirth[2])) $birthDay    = $arrBirth[2];
                            }
                            // $date_of_birth 	= trim($r['birthdate']);
                            $birthYear     = $birthYear ? (int)$birthYear : '';
                            $birthMonth    = $birthMonth ? (int)$birthMonth : '';
                            $birthDay     = $birthDay ? (int)$birthDay : '';
    
                            // echo 'birthYear : '.$birthYear.'<br>birthMonth :'.$birthMonth.'<br>birthDay :'.$birthDay.'<br>date_of_birth :'.$date_of_birth;
                            // $resObj	= array('ID' => $person_id, 'FIRST' => $firstname, 'LAST' => $lastname, 'BIRTH' =>$date_of_birth, 'EMAIL' =>$email, 'GENDER' =>$formgender, 'IDCARD' =>$id_card_no, 'CONSENT' =>$consent, 'SUB' =>$subscribe, 'NATIONAL' =>$nationality, 'PASSPORT' =>$passport_no,'birthYear' => $birthYear,'birthMonth' => $birthMonth,'birthDay' => $birthDay);
    
                            $resObj    = array('birthdate' => $date_of_birth, 'BIRTH' => $date_of_birth, 'birthYear' => $birthYear, 'birthMonth' => $birthMonth, 'birthDay' => $birthDay, 'ID' => $person_id, 'FIRST' => $firstname, 'LAST' => $lastname,  'GENDER' => $formgender, 'CONSENT' => $consent, 'SUB' => $subscribe, 'NATIONAL' => $nationality, 'MEMNOCRM' => $member_number_ref);
    
                            $dataRes['detail']    = $resObj;
                            $dataRes['status']     = array('STATUS' => 'regis_member');
                        } else {
                            //เลือกสมาชิก
                            $count = count($decodecheck->response_body->person);
    
                            for ($x = 0; $x < $count; $x++) {
                                $person_id = $decodecheck->response_body->person[$x]->id;
                                $firstname  = $decodecheck->response_body->person[$x]->firstname;
                                $lastname   = $decodecheck->response_body->person[$x]->lastname;
                                $date_of_birth   = $decodecheck->response_body->person[$x]->date_of_birth;
                                $email      = $decodecheck->response_body->person[$x]->email;
                                $gender     = $decodecheck->response_body->person[$x]->gender;
                                // $id_card_no = $decodecheck ->response_body ->person[$x]->id_card_no;
                                $id_card_no = '';
                                $consent    = $decodecheck->response_body->person[$x]->consent;
                                $subscribe  = $decodecheck->response_body->person[$x]->subscribe;
                                $nationality = $decodecheck->response_body->person[$x]->nationality;
                                $passport_no = $decodecheck->response_body->person[$x]->passport_no;
                                $member_number_ref = $decodecheck->response_body->person[0]->member_number_ref;
    
                                $checkF = '';
                                $checkM = '';
                                if ($gender == 'Female') {
                                    $checkF = 'checked';
                                } else {
                                    $checkM = 'checked';
                                }
    
                                $formgender = ' <div class="radio-tile-group top30 row">
                                    <div class="input-container col-5">
                                        <input class="radio-button" required type="radio" name="gender"  value="Male" ' . $checkM . '/>
                                        <div class="radio-tile">
                                            <div class="icon text-center">
                                                <h3 class="mt-2"><i class="fa fa-male"></i></h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="input-container col-5">
                                        <input class="radio-button" required type="radio" name="gender" value="Female" ' . $checkF . ' />
                                        <div class="radio-tile">
                                            <div class="icon text-center">
                                                <h3 class="mt-2"><i class="fa fa-female"></i></h3>
                                            </div>
                                        </div>
                                    </div>
                                </div>';
    
                                if ($date_of_birth != "" && $date_of_birth != '0000-00-00') {
                                    $arrBirth    = explode("-", $date_of_birth);
                                    if (isset($arrBirth[0])) $birthYear    = $arrBirth[0];
                                    if (isset($arrBirth[1])) $birthMonth    = $arrBirth[1];
                                    if (isset($arrBirth[2])) $birthDay    = $arrBirth[2];
                                }
                                // $date_of_birth 	= trim($r['birthdate']);
                                $birthYear     = $birthYear ? (int)$birthYear : '';
                                $birthMonth    = $birthMonth ? (int)$birthMonth : '';
                                $birthDay     = $birthDay ? (int)$birthDay : '';
    
                                if ($pid  == $person_id || $pid == "") {
                                    // $resObj	= array('ID' => $person_id, 'FIRST' => $firstname, 'LAST' => $lastname, 'BIRTH' =>$date_of_birth, 'EMAIL' =>$email, 'GENDER' =>$formgender, 'IDCARD' =>$id_card_no, 'CONSENT' =>$consent, 'SUB' =>$subscribe, 'NATIONAL' =>$nationality, 'PASSPORT' =>$passport_no);
                                    // $resObj    = array('ID' => $person_id, 'FIRST'  => $firstname,  'LAST' => $lastname,  'GENDER' => $formgender, 'CONSENT' => $consent, 'SUB' => $subscribe, 'NATIONAL' => $nationality, 'MEMNOCRM' => $member_number_ref);
                                    $resObj    = array('ID' => $person_id, 'FIRST'  => $firstname, 'birthYear' => $birthYear, 'birthMonth' => $birthMonth, 'birthDay' => $birthDay, 'LAST' => $lastname,  'GENDER' => $formgender, 'CONSENT' => $consent, 'SUB' => $subscribe, 'NATIONAL' => $nationality, 'MEMNOCRM' => $member_number_ref);
    
                                    $dataRes['detail']    = $resObj;
                                }
                            }
    
                            if ($pid == "") {
                                $resObj    = array('ID' => '', 'FIRST' => '', 'LAST' => '', 'BIRTH' => '', 'EMAIL' => '', 'GENDER' => $formgender, 'IDCARD' => '', 'CONSENT' => '', 'SUB' => '', 'NATIONAL' => '', 'PASSPORT' => '', 'MEMNOCRM' => '');
    
                                $dataRes['detail']    = $resObj;
                            }
    
                            $dataRes['status']     = array('STATUS' => 'regis_member');
                        }
                    }
                } else {
                    $dataRes['status']     = array('STATUS' => 'Unsuccessfully', 'message' => $responseData->message);
                }
            }

            echo  json_encode($dataRes);
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }

    // done
    function get_token()
    {
        $DATE_TIME = date("Y-m-d H:i:s");
        $ERR_STATUS = 400;
        $responseData = new stdClass;
        $access_token = "";
        try {
            $token     = trim($this->input->post('token'));
            // $rs = $this->Lists_model->select_token();
            $resultToken = $this->Lists_model->getToken(APPID);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
                $dbid = htmlspecialchars_decode(trim($resultToken->logId));
                $endtime = htmlspecialchars_decode(trim($resultToken->endtime));
                $retoken = htmlspecialchars_decode(trim($resultToken->refresh_token));

                if ($DATE_TIME >= $endtime) {
                    if ($retoken != '' || $retoken != null) {
                        $resutlOauth = $this->oauth2->re_token($retoken);
                        $responseData = $this->checkAPIData($resutlOauth);

                        if ($responseData->success) {
                            $decode_auth = $responseData->data;

                            $access_token   = $decode_auth->access_token;
                            $app_id         = $decode_auth->app_id;
                            $expires_in     = $decode_auth->expires_in;
                            $refresh_token  = $decode_auth->refresh_token;
                            $token_type     = $decode_auth->token_type;
                            $status         = 'Use';
                            $starttime      = date("Y-m-d H:i:s");
                            $endtime        = date('Y-m-d H:i:s', strtotime("+2 hours"));
                            $pass           = 'Successfully';

                            $dataUpdate = array(
                                'access_token' =>  $access_token,
                                'app_id' => $app_id,
                                'expires_in' => $expires_in,
                                'refresh_token' => $refresh_token,
                                'token_type' => $token_type,
                                'status' => $status,
                                'starttime' => $starttime,
                                'endtime' => $endtime
                            );
                            $this->db->trans_start();
                            $this->db->where(array('logId = ' => $dbid));
                            $this->db->update('log_token', $dataUpdate);
                            $db_id    = $this->db->insert_id();
                            if ($this->db->trans_status() === FALSE) {
                                $this->db->trans_rollback();
                            } else {
                                $this->db->trans_commit();
                            }
                        }
                    }
                } else {
                    $oauth = $this->oauth2->get_token();
                    $responseData = $this->checkAPIData($oauth);

                    if ($responseData->success) {
                        $decode_auth = $responseData->data;

                        $access_token   = $decode_auth->access_token;
                        $app_id         = $decode_auth->app_id;
                        $expires_in     = $decode_auth->expires_in;
                        $refresh_token  = $decode_auth->refresh_token;
                        $token_type     = $decode_auth->token_type;
                        $status         = 'Use';
                        $starttime      = date("Y-m-d H:i:s");
                        $endtime        = date('Y-m-d H:i:s', strtotime("+5 min"));
                        $pass           = 'Successfully';

                        $dataUpdate = array(
                            'access_token' =>  $access_token,
                            'app_id' => $app_id,
                            'expires_in' => $expires_in,
                            'refresh_token' => $refresh_token,
                            'token_type' => $token_type,
                            'status' => $status,
                            'starttime' => $starttime,
                            'endtime' => $endtime
                        );
                        $this->db->trans_start();
                        $this->db->where(array('logId = ' => $dbid));
                        $this->db->update('log_token', $dataUpdate);
                        $db_id    = $this->db->insert_id();
                        if ($this->db->trans_status() === FALSE) {
                            $this->db->trans_rollback();
                        } else {
                            $this->db->trans_commit();
                        }
                    }
                }
            } else {
                $oauth = $this->oauth2->get_token();
                $responseData = $this->checkAPIData($oauth);

                if ($responseData->success) {
                    $decode_auth = $responseData->data;

                    $access_token   = $decode_auth->access_token;
                    $app_id         = $decode_auth->app_id;
                    $expires_in     = $decode_auth->expires_in;
                    $refresh_token  = $decode_auth->refresh_token;
                    $token_type     = $decode_auth->token_type;

                    $status         = 'Use';
                    $starttime      = date("Y-m-d H:i:s");
                    $endtime        = date('Y-m-d H:i:s', strtotime("+" . $expires_in . " second"));
                    $pass           = 'Successfully';

                    $dataInsert = array(
                        'access_token' =>  $access_token,
                        'app_id' => $app_id,
                        'expires_in' => $expires_in,
                        'refresh_token' => $refresh_token,
                        'token_type' => $token_type,
                        'status' => $status,
                        'starttime' => $starttime,
                        'endtime' => $endtime
                    );

                    $this->db->trans_start();
                    $this->db->insert('log_token', $dataInsert);
                    $db_id    = $this->db->insert_id();
                    if ($this->db->trans_status() === FALSE) {
                        $this->db->trans_rollback();
                    } else {
                        $this->db->trans_commit();
                    }
                }
            }

            return $responseData;
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());

            return json_encode($Err);
        }
    }

    function genOTPandSMS()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
        $dataRes = array();
        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }


            $phone     = trim($this->input->post('phone'));
            $email     = trim($this->input->post('email'));

            if (!$phone) {
                $phone = $this->session->userdata('dataPhoneNumber');
            }

            // echo 'email : '.$email;

            if ($phone == "" && $email == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data phone and email is empty');
            }

            $SQL     = "SELECT logId FROM log_sms WITH (NOLOCK) WHERE mobileFullNo = ? OR email = ? AND status !=  ? ";
            $NUMROW = $this->db->query($SQL, array($phone, $email, 'Use'))->num_rows();
            if ($NUMROW > 0) {
                $this->db->trans_start();

                $dataUpdate = array(
                    'status' => 'Expired'
                );

                if ($email != "") {
                    $this->db->where(array('email = ' => $email, 'status != ' => 'Use'));
                } else {
                    $this->db->where(array('mobileFullNo = ' => $phone, 'status != ' => 'Use'));
                }

                $this->db->update('log_sms', $dataUpdate);

                if (!$this->db->affected_rows()) {
                    $this->db->trans_rollback();
                    $this->db->trans_complete();
                    $ERR_STATUS = 400;
                    throw new exception('err update data into database');
                }

                $this->db->trans_complete();
                if ($this->db->trans_status() === FALSE) {
                    $this->db->trans_rollback();
                } else {
                    $this->db->trans_commit();
                }
            }



            if ($email != '') {
                $data = "chanel=email&email=" . $email . "&source=FB-VEND-0001&type=verify_email";

                // echo 'data : '.$data;

                $resultSMS = $this->oauth2->SendOTP($token, $data);
                // $decodeSMS = json_decode($resultSMS);
                // $success   = $decodeSMS->success;
                $responseData = $this->checkAPIData($resultSMS);

                if ($responseData->success) {
                    $decodeSMS = $responseData->data;

                    $otp       = $decodeSMS->response_body->otp;
                    $ref       = $decodeSMS->response_body->ref;
                    $starttime = $decodeSMS->response_body->request_datetime;
                    $endtime   = $decodeSMS->response_body->expire_datetime;
                    $email     = $decodeSMS->response_body->email;
                    $type      = $decodeSMS->response_body->chanel;
                    $status    = 'Send';

                    $this->db->trans_start();
                    $dataInsert = array(
                        'email' =>  $email,
                        'otp' => $otp,
                        'reference' => $ref,
                        'status' => $status,
                        'starttime' => $starttime,
                        'endtime' => $endtime,
                    );

                    $this->db->insert('log_sms', $dataInsert);

                    if (!$this->db->affected_rows()) {
                        $this->db->trans_rollback();
                        $this->db->trans_complete();
                        $ERR_STATUS = 400;
                        throw new exception('err write data into database');
                    }

                    $db_id    = $this->db->insert_id();

                    $dataRes['detail']    = array('otp' => $otp, 'REF' => $ref, 'phone' => $phone);
                    // $dataRes['detail']    = array('TYPE' =>  $type, 'email' => $email, 'otp' => $otp, 'REF' => $ref, 'ID' => $db_id);
                    $dataRes['status']     = array('STATUS' => 'Successfully');
                } else {
                    $message = $responseData->message;

                    $dataRes['detail']    = array('message' => $message);
                    $dataRes['status']     = array('STATUS' => 'DATANOTVERIFLY');
                }
            }else if ($phone != '') {
                $data = "chanel=sms&mobile_no=" . $phone . "&source=FB-VEND-0001&type=verify_phone";

                $smsmobile = '';
                $p_tel = substr($phone, 1, strlen($phone));
                if (substr($phone, 0, 1) == "0") {
                    $smsmobile = "66" . $p_tel;
                }
                $resultSMS = $this->oauth2->SendOTP($token, $data);
                // $decodeSMS = json_decode($resultSMS);
                $responseData = $this->checkAPIData($resultSMS);
                if ($responseData->success) {
                    $decodeSMS = $responseData->data;

                    if ($decodeSMS->success) {
                        $otp       = $decodeSMS->response_body->otp;
                        $ref       = $decodeSMS->response_body->ref;
                        $starttime = $decodeSMS->response_body->request_datetime;
                        $endtime   = $decodeSMS->response_body->expire_datetime;
                        $mobile_no = $decodeSMS->response_body->mobile_no;
                        $type      = $decodeSMS->response_body->chanel;
                        $status    = 'Send';

                        $this->db->trans_start();
                        $dataInsert = array(
                            'mobileFullNo' => $smsmobile,
                            'mobileNo' => $phone,
                            'otp' => $otp,
                            'reference' => $ref,
                            'status' => $status,
                            'starttime' => $starttime,
                            'endtime' => $endtime,
                        );

                        $this->db->insert('log_sms', $dataInsert);

                        if (!$this->db->affected_rows()) {
                            $this->db->trans_rollback();
                            $this->db->trans_complete();
                            $ERR_STATUS = 400;
                            throw new exception('err write data into database');
                        }

                        $db_id    = $this->db->insert_id();
                        // up to production ให้ เอา otp ออก
                        if (OTPSMSAUTOINSERT) {
                            $dataRes['detail']    = array('otp' => $otp, 'REF' => $ref, 'phone' => $phone);
                        }else {
                            $dataRes['detail']    = array('REF' => $ref, 'phone' => $phone);
                        }
                        $dataRes['status']     = array('STATUS' => 'Successfully');
                    } else {
                        $dataRes['status']     = array('STATUS' => 'Successfully', 'ERRDESC' => $decodeSMS->message);
                    }
                } else {
                    $message = $responseData->message;

                    $dataRes['detail']    = array('message' => $message);
                    $dataRes['status']     = array('STATUS' => 'DATANOTVERIFLY');
                }
            }

            echo json_encode($dataRes);
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }

    function genOTPforget()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");

        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            $phone     = trim($this->input->post('phone'));
            $email     = trim($this->input->post('email'));


            if ($phone == "" && $email == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data phone and email is empty');
            }

            $SQL     = "SELECT logId FROM log_sms WITH (NOLOCK) WHERE mobileFullNo = ? OR email = ? AND status !=  ? ";
            $NUMROW = $this->db->query($SQL, array($phone, $email, 'Use'))->num_rows();
            if ($NUMROW > 0) {
                $this->db->trans_start();

                $dataUpdate = array(
                    'status' => 'Expired'
                );
                if ($phone != "" || $phone != NULL) {
                    $this->db->where(array('mobileNo = ' => $phone, 'status != ' => 'Use'));
                } else {
                    $this->db->where(array('email = ' => $email, 'status != ' => 'Use'));
                }

                $this->db->update('log_sms', $dataUpdate);

                if (!$this->db->affected_rows()) {
                    $this->db->trans_rollback();
                    $this->db->trans_complete();
                    $ERR_STATUS = 400;
                    throw new exception('err update data into database');
                }

                $this->db->trans_complete();
                if ($this->db->trans_status() === FALSE) {
                    $this->db->trans_rollback();
                } else {
                    $this->db->trans_commit();
                }
            }

            if ($phone != '') {
                $data = "chanel=sms&mobile_no=" . $phone . "&source=FB-VEND-0001&type=forgot_password";

                $smsmobile = '';
                $p_tel = substr($phone, 1, strlen($phone));
                if (substr($phone, 0, 1) == "0") {
                    $smsmobile = "66" . $p_tel;
                }
                $resultSMS = $this->oauth2->SendOTP($token, $data);
                $responseData = $this->checkAPIData($resultSMS);
                if ($responseData->success) {
                    $decodeSMS = $responseData->data;

                    $otp       = $decodeSMS->response_body->otp;
                    $ref       = $decodeSMS->response_body->ref;
                    $starttime = $decodeSMS->response_body->request_datetime;
                    $endtime   = $decodeSMS->response_body->expire_datetime;
                    $mobile_no = $decodeSMS->response_body->mobile_no;
                    $type      = $decodeSMS->response_body->chanel;
                    $status    = 'Send';

                    $this->db->trans_start();
                    $dataInsert = array(
                        'mobileFullNo' => $smsmobile,
                        'mobileNo' => $phone,
                        'otp' => $otp,
                        'reference' => $ref,
                        'status' => $status,
                        'starttime' => $starttime,
                        'endtime' => $endtime,
                    );

                    $this->db->insert('log_sms', $dataInsert);

                    if (!$this->db->affected_rows()) {
                        $this->db->trans_rollback();
                        $this->db->trans_complete();
                        $ERR_STATUS = 400;
                        throw new exception('err write data into database');
                    }

                    $db_id    = $this->db->insert_id();

                    $dataRes['detail']    = array('TYPE' =>  $type, 'mobile' => $mobile_no, 'otp' => $otp, 'REF' => $ref, 'ID' => $db_id);
                    $dataRes['status']     = array('STATUS' => 'Successfully');
                } else {
                    $message = $responseData->message;

                    $dataRes['detail']    = array('message' => $message);
                    $dataRes['status']     = array('STATUS' => 'DATANOTVERIFLY');
                }
            } else if ($email != '') {
                $data = "chanel=email&email=" . $email . "&source=FB-VEND-0001&type=forgot_password";

                $resultSMS = $this->oauth2->SendOTP($token, $data);
                $responseData = $this->checkAPIData($resultSMS);
                if ($responseData->success) {
                    $decodeSMS = $responseData->data;

                    $otp       = $decodeSMS->response_body->otp;
                    $ref       = $decodeSMS->response_body->ref;
                    $starttime = $decodeSMS->response_body->request_datetime;
                    $endtime   = $decodeSMS->response_body->expire_datetime;
                    $email     = $decodeSMS->response_body->email;
                    $type      = $decodeSMS->response_body->chanel;
                    $status    = 'Send';

                    $this->db->trans_start();
                    $dataInsert = array(
                        'email' =>  $email,
                        'otp' => $otp,
                        'reference' => $ref,
                        'status' => $status,
                        'starttime' => $starttime,
                        'endtime' => $endtime,
                    );

                    $this->db->insert('log_sms', $dataInsert);

                    if (!$this->db->affected_rows()) {
                        $this->db->trans_rollback();
                        $this->db->trans_complete();
                        $ERR_STATUS = 400;
                        throw new exception('err write data into database');
                    }

                    $db_id    = $this->db->insert_id();

                    $dataRes['detail']    = array('TYPE' =>  $type, 'email' => $email, 'otp' => $otp, 'REF' => $ref, 'ID' => $db_id);
                    $dataRes['status']     = array('STATUS' => 'Successfully');
                } else {
                    $message = $responseData->message;

                    $dataRes['detail']    = array('message' => $message);
                    $dataRes['status']     = array('STATUS' => 'DATANOTVERIFLY');
                }
            }

            // print_r($dataRes); exit;

            echo json_encode($dataRes);
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }

    function checkOTP()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
        $minutes_to_add = 6;
        $time = new DateTime($DATE_TIME);
        $time->add(new DateInterval('PT' . $minutes_to_add . 'M'));
        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            $phone         = trim($this->input->post('phone'));
            $otp         = trim($this->input->post('otp'));
            $ref         = trim($this->input->post('ref'));
            $chanel     = trim($this->input->post('chanel'));
            $email         = trim($this->input->post('email'));
            $refPID     = trim($this->input->post('refpid'));

            if ($phone == "" && $email == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data phone and email is empty');
            }

            if ($otp == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data OTP is empty');
            }

            if ($ref == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data REF is empty');
            }

            $success = false;
            $decodeSMS = null;
            $message = null;

            if ($phone) {
                $resultSMS = $this->oauth2->verify_OTP($token, $phone, $otp, $ref);
                $responseData = $this->checkAPIData($resultSMS);
                $success   = $responseData->success;
            }

            if ($email) {
                $resultSMS = $this->oauth2->verify_OTP_Email($token, $email, $otp, $ref);
                $responseData = $this->checkAPIData($resultSMS);
                $success   = $responseData->success;
            }

            if ($success) {
                $decodecheck = $responseData->data;
                if ($decodecheck->success) {
                    $dataRes['status']     = array('STATUS' => 'Successfully', 'phone' => $phone, 'dataID' => $this->session->userdata('dataID'), 'message' => $decodecheck->response_body->message);
                } else {
                    $dataRes['status']     = array('STATUS' => 'UNSuccessfully', 'phone' => $phone, 'dataID' => $this->session->userdata('dataID'), 'message' => $decodecheck->response_body->message);
                }
                echo json_encode($dataRes);
            } else {
                $dataRes['status']     = array('STATUS' => 'UNSuccessfully', 'phone' => $phone, 'dataID' => $this->session->userdata('dataID'), 'message' => $responseData->message);
                echo json_encode($dataRes);
            }
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }


    function checkOTPFoget()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");

        $minutes_to_add = 6;

        $time = new DateTime($DATE_TIME);
        $time->add(new DateInterval('PT' . $minutes_to_add . 'M'));

        $stamp = $time->format('Y-m-d H:i:s');

        // echo 'now : '.$DATE_TIME.'<br>date'.$stamp.'<br>'; 

        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            $phone         = trim($this->input->post('phone'));
            $otp         = trim($this->input->post('otp'));
            $ref         = trim($this->input->post('ref'));
            $chanel     = trim($this->input->post('chanel'));
            $email         = trim($this->input->post('email'));

            if ($phone == "" && $email == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data phone and email is empty');
            }

            if ($otp == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data OTP is empty');
            }

            if ($ref == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data REF is empty');
            }

            // echo 'phone : '.$phone.'<br> :'.$otp.'<br> :'.$ref.'<br> :'.$DATE_TIME.'<br> email:'.$email.'<br> chanel:'.$chanel.'<br>';

            $ResOTP    = $this->Lists_model->CheckOTP('Send', $phone, $otp, $ref, $DATE_TIME, $stamp, $chanel, $email)->result_array();

            if (!$ResOTP) {
                $ERR_STATUS = 400;
                throw new exception('Err data OTP incorrect');
            }

            $ID    = $ResOTP[0]['logId'];

            if ($ID != "") {
                $this->db->trans_start();

                $dataUpdate = array(
                    'status'     => 'Use',
                    'usedby'     => $phone,
                    'usedtime'    => date("Y-m-d H:i:s")
                );

                $this->db->where(array('logId' => $ID));
                $this->db->update('log_sms', $dataUpdate);

                if (!$this->db->affected_rows()) {
                    $this->db->trans_rollback();
                    $this->db->trans_complete();
                    $ERR_STATUS = 400;
                    throw new exception('err update data into database');
                }

                $this->db->trans_complete();
                if ($this->db->trans_status() === FALSE) {
                    $this->db->trans_rollback();
                } else {
                    $this->db->trans_commit();
                }
            }

            $pid = '';
            $pid_session = '';

            if (!empty($phone)) {
                $unique = 'AND verify_phone = ? AND mobileNo = ?';
                $dataCon = $phone;
            } else {
                $unique = 'AND verify_email = ? AND email = ? ';
                $dataCon = $email;
            }

            $person = "SELECT personId,idCardNo FROM person WITH (NOLOCK) WHERE is_member = ?  AND personStatus = ? " . $unique;
            $sql = $this->db->query($person, array('Y', 'A', 'Y', $dataCon))->result_array();
            // print_r($sql); exit;
            if (count($sql) > 0) {
                foreach ($sql as $r) {
                    $pid = htmlspecialchars_decode(trim($r['personId']));
                    $idCardNo = htmlspecialchars_decode(trim($r['idCardNo']));
                }

                if ($email != "") {
                    $this->db->trans_start();

                    $dataUpdate = array(
                        'verify_email'     => 'Y'
                    );

                    $this->db->where(array('personId' => $pid, 'email' => $email));
                    $this->db->update('person', $dataUpdate);

                    if (!$this->db->affected_rows()) {
                        $this->db->trans_rollback();
                        $this->db->trans_complete();
                        $ERR_STATUS = 400;
                        throw new exception('err update data into database');
                    }

                    $this->db->trans_complete();
                    if ($this->db->trans_status() === FALSE) {
                        $this->db->trans_rollback();
                    } else {
                        $this->db->trans_commit();
                    }
                }

                $person = "SELECT psid_session_id FROM person_session_id WITH (NOLOCK) WHERE personId = ? AND psid_status = ? ";
                $sql = $this->db->query($person, array($pid, 'Active'))->result_array();
                if (count($sql) > 0) {
                    foreach ($sql as $r) {
                        $pid_session = htmlspecialchars_decode(trim($r['psid_session_id']));
                    }
                } else {
                    if (!empty($phone)) {
                        $session_id = base64_encode($phone . $idCardNo);

                        $dataSession = array(
                            'personId'     => $pid,
                            'psid_session_id'     => $session_id,
                            'psid_status'    => 'Active',
                            'psid_createdatetime'    => date("Y-m-d H:i:s"),
                            'psid_updatedatetime'    => date("Y-m-d H:i:s")
                        );

                        $this->db->insert('person_session_id', $dataSession);

                        if (!$this->db->affected_rows()) {
                            $this->db->trans_rollback();
                            $this->db->trans_complete();
                            $ERR_STATUS = 400;
                            throw new exception('err insert data into table person_session_id database');
                        }

                        $this->db->trans_complete();
                        if ($this->db->trans_status() === FALSE) {
                            $this->db->trans_rollback();
                        } else {
                            $this->db->trans_commit();
                        }
                    }
                }
            }

            $dataRes['detail']    = array('pid' => $pid, 'email' => $email, 'phone' => $phone, 'pid_session' => $pid_session, 'idCardNo' => $idCardNo);
            $dataRes['status']     = array('STATUS' => 'Successfully');
            echo json_encode($dataRes);
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }

    function insert_data()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }


            // pid: id,uid: uid,phone: phone,email: email,session:session
            $pid        = trim($this->input->post('pid'));
            $firstname     = trim($this->input->post('firstname'));
            $lastname     = trim($this->input->post('lastname'));
            $birth         = trim($this->input->post('birth'));
            $gender     = trim($this->input->post('gender'));
            $idcard     = trim($this->input->post('idcard'));
            $passport     = trim($this->input->post('passport'));
            $national     = trim($this->input->post('national'));
            $email         = trim($this->input->post('email'));
            $pass         = trim($this->input->post('pass'));
            $phone      = trim($this->input->post('phone'));
            $regisNew   = trim($this->input->post('regisNew'));
            $chanel     = 'Line';
            $device     = 'Mobile';
            $session_id = base64_encode($phone . $idcard);
            $subscribe  = strtoupper(trim($this->input->post('subscribe')));
            $consent    = trim($this->input->post('consent'));
            $uid  = trim($this->input->post('uid'));

            $address   = trim($this->input->post('address'));
            $province   = trim($this->input->post('province'));
            $district   = trim($this->input->post('district'));
            $subdist   = trim($this->input->post('subdist'));
            $postcode   = trim($this->input->post('postcode'));

            if (!$uid && !$this->session->userdata('socialUID')) {
            // if (true) {
                $logUid = $this->Lists_model->getLogUID();
                if ($logUid) {
                    $uid = $logUid->uid;
                }else {
                    $dataRes['detail']    = 'ไม่พบการเชื่อมต่อ Line กรุณาทำรายการใหม่อีกครั้ง';
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => 'ไม่พบการเชื่อมต่อ Line',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            $personResult = null;
            if ($pid) {
                $personQuery = "SELECT memberNoRef FROM person WITH (NOLOCK) WHERE personId = ? ";
                $personResult = $this->db->query($personQuery, array($pid))->row();
            }

            // print_r();
            if ($phone == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data phone is empty');
            }
            $member_no_ref = '';
            if ($personResult && !$regisNew) {
                $member_no_ref = $personResult->memberNoRef ? '&member_number_ref=' . $personResult->memberNoRef  : '';
            }
            $data = 'chanel=Line&consent=true&device=Mobile&date_of_birth=' . $birth . '&firstname=' . $firstname . '&gender=' . $gender . '&lastname=' . $lastname . '&mobile_no=' . $phone . '&nationality=' . $national . '&password=' . $pass . '&session_id=' . $session_id . '&verify_phone=true&subscribe=' . $subscribe . $member_no_ref;

            if ($passport != "" && $passport != "null" && $passport != null) {
                $data .= '&passport_no=' . $passport;
            }

            if (trim($email) != "") {
                $data .= '&email=' . trim($email);
            }

            if ($idcard != "") {
                $data .= '&id_card_no=' . $idcard;
            }

            if ($pid != "") {
                $data .= '&id=' . $pid;
                if ($dataPerson = $this->PersonModel->getPerson($pid)->row()) {
                    if ($dataPerson->personStatus == $this->config->item('status_ban') || $dataPerson->personStatus == $this->config->item('status_close') || $dataPerson->personStatus == $this->config->item('status_hold') || $dataPerson->personStatus == $this->config->item('status_close_down')) {
                        $data .= '&person_status='.$dataPerson->personStatus;
                    }
                }
            }
            $data .= '&is_member=Y';
            if ($uid != "" || $uid != null) {
                $data .= '&line_user_id=' . $uid;
            } else {
                if ($this->session->userdata('socialUID')) {
                    $data .= '&line_user_id=' . $this->session->userdata('socialUID');
                }
            }

            if ($this->session->userdata('socialDisplayName')) {
                $data .= '&line_display_name=' . $this->session->userdata('socialDisplayName');
            }
            
            if ($this->session->userdata('socialPictureUrl')) {
                $data .= '&line_picture_url=' . $this->session->userdata('socialPictureUrl');
            }
            
            if ($this->session->userdata('socialStatusMessage')) {
                $data .= '&line_status_message=' . $this->session->userdata('socialStatusMessage');
            }
            
            // if ($this->session->userdata('socialEmail')) {
            //     $data .= '&line_display_name=' . $pid;
            // }

            $insert_data = $this->oauth2->register($token, $data);
            $responseData = $this->checkAPIData($insert_data);
            if ($responseData->success) {
                $decodecheck = $responseData->data;
                if ($decodecheck->success) {
                    $status     = $decodecheck->response_body->message;
                    $dataRes['detail']    = $status;
                    $dataRes['status']     = array('STATUS' => 'successfully');
                    $array_items = array('dataPhoneNumber', 'dataIdcard', 'dataTypeIdcard', 'dataUID', 'socialDisplayName', 'socialPictureUrl', 'socialStatusMessage');
                    $this->session->unset_userdata($array_items);

                    $person_id     = $decodecheck ->response_body->person_id;
                    // get address
                    $address_id = '';
                    $currentAddress = $this->PersonModel->getCurrentAddressPersonByPersonId($person_id);
                    if ($currentAddress) {
                        $address_id = $currentAddress->addrId;
                    }

                    $data = 'id='.$person_id.'&session_id='.$session_id.'&address_type=Current';

                    if($address_id != ""){
                        $data .='&address_id='.$address_id;
                    }
                    if($address != ""){
                        $data .='&address_no='.$address;
                    }
                    if($province != ""){
                        $data .='&province_code='.$province;
                    }
                    if($district != ""){
                        $data .='&district_code='.$district;
                    }
                    if($subdist != ""){
                        $data .='&sub_district_code='.$subdist;
                    }
                    if($postcode != ""){
                        $data .='&postcode='.$postcode;
                    }

                    $update_address = $this->oauth2->UpdateAddress($token,$data);
                    $responseData = $this->checkAPIData($update_address);
                    if ($responseData->success) {
                        $decodecheck = $responseData->data;
                        if ($decodecheck->success) {
                            $dataRes['detail']	= $status;
                            $dataRes['status'] 	= array('STATUS' => 'successfully');
                        }else {
                            $dataRes['detail']    = $decodecheck->error->message;
                            $dataRes['status']     = array('STATUS' => 'Unsuccessfully');
                        }
                    }else {
                        $dataRes['detail']    = $responseData->message;
                        $dataRes['status']     = array('STATUS' => 'Unsuccessfully');
                    }
                } else {
                    $dataRes['detail']    = $decodecheck->error->message;
                    $dataRes['status']     = array('STATUS' => 'Unsuccessfully');
                }
            } else {
                // $error     = $decodecheck ->error->message;
                // if($error = 'email already used.'){
                //     $error = 'มีผู้ยืนยันการใช้งานแล้ว กรุณาตรวจสอบอีเมล.';
                // }
                $dataRes['detail']    = $responseData->message;
                $dataRes['status']     = array('STATUS' => 'Unsuccessfully');
            }

            echo  json_encode($dataRes);
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }

    function update_data()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            // echo 'update'; exit;

            $pid        = trim($this->input->post('pid'));
            $firstname     = trim($this->input->post('firstname'));
            $lastname     = trim($this->input->post('lastname'));
            $birth         = trim($this->input->post('birth'));
            $gender     = trim($this->input->post('gender'));
            $idcard     = trim($this->input->post('idcard'));
            $passport     = trim($this->input->post('passport'));
            $national     = trim($this->input->post('national'));
            $email         = trim($this->input->post('email'));
            $pass         = trim($this->input->post('pass'));
            $phone      = trim($this->input->post('phone'));
            $session_id = trim($this->input->post('session'));
            $verify_email = trim($this->input->post('verify_email'));
            $subscribe  = strtoupper(trim($this->input->post('subscribe')));
            $consent    = trim($this->input->post('consent'));
            $line_id  = trim($this->input->post('uid'));

            if ($session_id == '') {
                $session_id = base64_encode($phone . $idcard);
            }

            if ($pid == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data personId is empty');
            }

            $data = 'id=' . $pid . '&session_id=' . $session_id;
            if ($passport != "") {
                $data .= '&passport_no=' . $passport;
            }
            if ($birth != "") {
                $data .= '&date_of_birth=' . $birth;
            }
            if (trim($email) != "") {
                $data .= '&email=' . trim($email);
            }
            if ($firstname != "") {
                $data .= '&firstname=' . $firstname;
            }
            if ($gender != "") {
                $data .= '&gender=' . $gender;
            }
            if ($idcard != "") {
                $data .= '&id_card_no=' . $idcard;
            }
            if ($lastname != "") {
                $data .= '&lastname=' . $lastname;
            }
            if ($phone != "") {
                $data .= '&mobile_no=' . $phone;
            }
            if ($national != "") {
                $data .= '&nationality=' . $national;
            }
            if ($verify_email != "") {
                $data .= '&verify_email=' . $verify_email;
            }
            if ($pass != "") {
                $data .= '&password=' . $pass;
            }
            if ($line_id != "") {
                $data .= '&line_user_id=' . $line_id;
            }

            // echo 'birth : '.$birth; exit;

            // echo 'data : '.$data; exit;

            $update_data = $this->oauth2->update($token, $data);
            // $decodecheck = json_decode($update_data);

            $responseData = $this->checkAPIData($update_data);
            if ($responseData->success) {
                $decodecheck = $responseData->data;

                $message     = $decodecheck->response_body->message;

                $dataRes['detail']    = array('message' => $message);
                $dataRes['status']     = array('STATUS' => 'successfully');
            } else {
                $error     = $responseData->message;
                $dataRes['status']     = array('STATUS' => 'Unsuccessfully', 'error' => $error);
            }

            echo  json_encode($dataRes);
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }

    function update_address()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            $pid        = trim($this->input->post('pid'));
            $session_id = trim($this->input->post('session'));
            $address_id = trim($this->input->post('address_id'));
            $address     = trim($this->input->post('address'));
            $province     = trim($this->input->post('province'));
            $district     = trim($this->input->post('district'));
            $subdist     = trim($this->input->post('subdist'));
            $postcode     = trim($this->input->post('postcode'));
            $idCard     = trim($this->input->post('idCard'));
            $passNo     = trim($this->input->post('passNo'));

            if ($pid == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data personId is empty');
            }
            if ($session_id == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data session_id is empty');
            }

            if (empty($idCard)) {
                $addType = 'Foreigner';
            } else {
                $addType = 'Current';
            }

            $data = 'id=' . $pid . '&session_id=' . $session_id . '&address_type=' . $addType;

            if ($address_id != "") {
                $data .= '&address_id=' . $address_id;
            }
            if ($address != "") {
                $data .= '&address_no=' . $address;
            }
            if ($province != "") {
                $data .= '&province_code=' . $province;
            }
            if ($district != "") {
                $data .= '&district_code=' . $district;
            }
            if ($subdist != "") {
                $data .= '&sub_district_code=' . $subdist;
            }
            if ($postcode != "") {
                $data .= '&postcode=' . $postcode;
            }

            // echo 'data : '.$data; exit;

            $update_address = $this->oauth2->UpdateAddress($token, $data);

            $responseData = $this->checkAPIData($update_address);
            if ($responseData->success) {
                $decodecheck = $responseData->data;

                $message     = $decodecheck->response_body->message;

                $dataRes['detail']    = array('message' => $message);
                $dataRes['status']     = array('STATUS' => 'successfully');
            } else {
                $error     = $responseData->message;
                $dataRes['status']     = array('STATUS' => 'Unsuccessfully', 'error' => $error);
            }

            echo  json_encode($dataRes);
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }

    function changePass()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            $pid        = trim($this->input->post('pid'));
            $pass         = trim($this->input->post('pass'));
            $newpass    = trim($this->input->post('newpass'));
            $session_id = trim($this->input->post('session'));

            if ($pid == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data personId is empty');
            }

            $data = 'id=' . $pid . '&password=' . $pass . '&new_password=' . $newpass;

            $change_data = $this->oauth2->change_password($token, $data);
            // $decodecheck = json_decode($change_data);

            $responseData = $this->checkAPIData($change_data);
            if ($responseData->success) {
                $decodecheck = $responseData->data;

                $message     = $decodecheck->response_body->message;
                if ($message == "Change password success.") {
                    $message = 'เปลี่ยนรหัสผ่านเรียบร้อยแล้ว';
                }

                $dataRes['detail']    = array('message' => $message);
                $dataRes['status']     = array('STATUS' => 'successfully');
            } else {
                $error     = $responseData->message;
                if ($error  == "password invalid.") {
                    $error  = "รหัสผ่านไม่ถูกต้อง";
                }
                $dataRes['status']     = array('STATUS' => 'Unsuccessfully', 'detail' => $error);
            }

            echo  json_encode($dataRes);
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }


    function get_nation()
    {
        $rs = $this->Lists_model->SelectNation(null, null, 'A')->result_array();
        $i = 0;
        if (count($rs) > 0) {
            $result = "{data:<option value='TH' selected >ไทย (Thailand)</option>,";
            foreach ($rs as $ty) {

                $nationCode = htmlspecialchars_decode(trim($ty['nationCode']));
                $nationNameThai = htmlspecialchars_decode(trim($ty['nationNameThai']));
                $countryNameEng = htmlspecialchars_decode(trim($ty['countryNameEng']));

                // $result .= '"data" :"<option value="' . $nationCode . '" >' . $nationNameThai . ' (' . $countryNameEng . ')</option>,"';
                $result .= '"data" :"<option value="' . $nationCode . '" >' . $nationNameThai . '</option>,"';
                $i++;
            }
            $result .= '}';
        }

        echo json_encode($result);
    }

    function getProvince()
    {
        $pvCode = $this->input->post('pvCode');

        $rs = $this->Lists_model->SelectProvice()->result_array();
        $i = 0;
        if (count($rs) > 0) {
            $result = "{data:<option value=''>-- เลือก --</option>,";
            foreach ($rs as $ty) {
                $provinceId = htmlspecialchars_decode(trim($ty['provinceId']));
                $provinceCode = htmlspecialchars_decode(trim($ty['provinceCode']));
                $provinceNameThai = htmlspecialchars_decode(trim($ty['provinceNameThai']));
                $provinceNameEng = htmlspecialchars_decode(trim($ty['provinceNameEng']));

                if ($pvCode == $provinceCode) {
                    $select = 'selected';
                } else {
                    $select = '';
                }

                $result .= '"data" :"<option value="' . $provinceCode . '"' . $select . ' >' . $provinceNameThai . ' (' . $provinceNameEng . ')</option>,"';
            }
            $result .= '}';
        }

        echo json_encode($result);
    }

    function getDistrict()
    {
        $pvCode = $this->input->post('pvCode');
        $sdCode = $this->input->post('sdCode');
        $dCode = $this->input->post('dCode');

        // echo 'pvCode'.$pvCode.'<br>';
        // echo 'sdCode'.$sdCode.'<br>';
        // echo 'dCode'.$dCode.'<br>';

        $rs_pv = $this->Lists_model->Selectdistrict($pvCode)->result_array();
        $i = 0;
        $result = "{data:<option value=''>-- เลือก --</option>,";

        if (count($rs_pv) > 0) {
            foreach ($rs_pv as $ty) {
                $i++;
                $districtId = htmlspecialchars_decode(trim($ty['districtId']));
                $districtCode = htmlspecialchars_decode(trim($ty['districtCode']));
                $districtNameEng = htmlspecialchars_decode(trim($ty['districtNameEng']));
                $districtNameThai = str_replace("อำเภอ", "", htmlspecialchars_decode(trim($ty['districtNameThai'])));
                $select = '';

                if ($dCode == $districtCode) {
                    $select = 'selected';
                }
                $result .= '"data" :"<option value=' . $districtCode . ' ' . $select . '>' . $districtNameThai . ' (' . $districtNameEng . ')</option>",';
            }
            $result .= '}';
        }

        echo json_encode($result);
    }

    function getSubdist()
    {
        $pvCode = $this->input->post('pvCode');
        $sdCode = $this->input->post('sdCode');
        $dCode = $this->input->post('dCode');

        $rs_sd = $this->Lists_model->Selectsubdis($dCode)->result_array();
        $i = 0;
        $result = "{data:<option value=''>-- เลือก --</option>,";

        if (count($rs_sd) > 0) {
            foreach ($rs_sd as $ty) {
                $i++;
                $subDistrictCode = htmlspecialchars_decode(trim($ty['subDistrictCode']));
                $subDistrictNameThai = htmlspecialchars_decode(trim($ty['subDistrictNameThai']));
                $subDistrictNameEng = htmlspecialchars_decode(trim($ty['subDistrictNameEng']));
                $select = '';
                if ($sdCode == $subDistrictCode) {
                    $select = ' selected ';
                }
                $result .= '"data" :"<option value=' . $subDistrictCode . ' ' . $select . '>' . $subDistrictNameThai . ' (' . $subDistrictNameEng . ')</option>",';
            }
            $result .= '}';
        }

        echo json_encode($result);
    }

    function selectAddress()
    {
        $id = $this->input->post('id');
        $menu = $this->input->post('menu');
        //$data['districts'] = '';
        $dis_id = "0";
        $sd_id = '0';

        if ($menu == "province") {
            // $rs_pv = $this->Select_data->select_data("*", "master_districts","AND pv_id = '".$id."'","dis_name_th")->result_array();
            $rs_pv = $this->Lists_model->Selectdistrict($id)->result_array();
            $i = 0;
            $result = "{data:<option value=''>-- เลือก --</option>,";

            if (count($rs_pv) > 0) {
                foreach ($rs_pv as $ty) {
                    $i++;
                    $districtId = htmlspecialchars_decode(trim($ty['districtId']));
                    $districtCode = htmlspecialchars_decode(trim($ty['districtCode']));
                    $districtNameThai     = htmlspecialchars_decode(trim($ty['districtNameThai']));
                    $select = '';
                    if ($districtId == $dis_id) {
                        $select = ' selected ';
                    }

                    $result .= '"data" :"<option value=' . $districtCode . ' ' . $select . '>' . $districtNameThai . '</option>",';
                }
                $result .= '}';
            }
        } else {
            // $rs_sd = $this->Select_data->select_data("*", "master_subdistricts","AND dis_id = '".$id."'","sd_name_th")->result_array();
            $rs_sd = $this->Lists_model->Selectsubdis($id)->result_array();
            $i = 0;
            $result = "{data:<option value=''>-- เลือก --</option>,";
            if (count($rs_sd) > 0) {
                foreach ($rs_sd as $ty) {
                    $i++;
                    $subDistrictCode = htmlspecialchars_decode(trim($ty['subDistrictCode']));
                    $subDistrictNameThai     = htmlspecialchars_decode(trim($ty['subDistrictNameThai']));
                    $select = '';
                    if ($subDistrictCode == $sd_id) {
                        $select = ' selected ';
                    }
                    $result .= '"data" :"<option value=' . $subDistrictCode . ' ' . $select . '>' . $subDistrictNameThai . '</option>",';
                }
                $result .= '}';
            }
        }

        echo json_encode($result);
    }

    function selectPostcode()
    {
        $id = $this->input->post('id');

        $rs_sd = $this->Lists_model->Selectsubdis($id)->result_array();
        if (count($rs_sd) > 0) {
            foreach ($rs_sd as $ty) {
                $postcode     = htmlspecialchars_decode(trim($ty['postcode']));
                $result = $postcode;
            }
        }

        echo $postcode;
    }


    function login()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            $username   = trim($this->input->post('username'));
            $password     = trim($this->input->post('password'));
            $uid         = trim($this->input->post('uid'));
            $socialPictureUrl     = trim($this->input->post('socialPictureUrl'));
            $socialDisplayName     = trim($this->input->post('socialDisplayName'));
            $socialStatusMessage     = trim($this->input->post('socialStatusMessage'));
            $socialEmail     = trim($this->input->post('socialEmail'));

            // var_dump($this->session->userdata());
            // $this->session->userdata('item');
            $this->session->set_userdata(array(
                'socialUID' => $uid,
                'socialPictureUrl' => $socialPictureUrl,
                'socialDisplayName' => $socialDisplayName,
                'socialStatusMessage' => $socialStatusMessage,
                'socialEmail' => $socialEmail,
            ));

            if (!empty($uid)) {
                $data = '&line_user_id=' . $uid;
            } else {
                if ($password == "") {
                    $ERR_STATUS = 400;
                    throw new exception('Err data password is empty');
                }

                $data = 'password=' . $password;

                if (strlen($username) == 10) {
                    $data .= '&mobile_no=' . $username;
                } else {
                    $data .= '&email=' . $username;
                }
            }

            $login_data = $this->oauth2->login_verify($token, $data);

            $responseData = $this->checkAPIData($login_data);
            if ($responseData->success) {
                $decodecheck = $responseData->data;
                if ($decodecheck->success) {
                    $pid     = $decodecheck->response_body->person[0]->id;
                    $this->db->where('personId', $pid);
                    $this->db->where('psid_status', 'Active');
                    $personSessionID = $this->db->get('person_session_id')->last_row();
                    $session = array(
                        'userfprid' => $decodecheck->response_body->person[0]->id,
                        'userfprname' => $decodecheck->response_body->person[0]->firstname,
                        'person_session' => $personSessionID ? $personSessionID->psid_session_id : '',
                    );
                    $this->session->set_userdata($session);

                    // change status person auto from inactive to active
                    $this->db->where('personId', $pid);
                    $this->db->where('personStatus', $this->config->item('status_inactive'));
                    $rowPerson = $this->db->get('person')->row();
                    if ($rowPerson) {
                        $this->db->set('personStatus', $this->config->item('status_active'));
                        $this->db->where('personId', $pid);
                        $this->db->update('person');
                    }

                    $dataRes['detail']    = array('ID' => $pid);
                    $dataRes['status']     = array('STATUS' => 'successfully');
                } else {
                    $dataRes['status']     = array('STATUS' => 'Unsuccessfully', 'message' => $decodecheck->response_body->message);
                }
            } else {
                $dataRes['status']     = array(
                    'STATUS' => 'Unsuccessfully',
                    'message' => $responseData->message,
                    'error' => isset($responseData->error) ? $responseData->error : '',
                );
            }
            echo  json_encode($dataRes);
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }

    function getDataMem()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            $pid   = trim($this->input->post('p_id'));

            if ($pid == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data PersonId is empty');
            }

            $data = 'id=' . $pid;
            $checkF = '';
            $checkM = '';
            $addrId = '';
            $addrDetail = '';
            $sub_district_code = '';
            $sub_district_th = '';
            $sub_district_en = '';
            $district_code = '';
            $district_th = '';
            $district_en = '';
            $province_code = '';
            $province_th = '';
            $province_en = '';
            $postcode = '';

            $profile_data = $this->oauth2->getProfile($token, $data);

            $responseData = $this->checkAPIData($profile_data);
            if ($responseData->success) {
                $decodecheck = $responseData->data;

                if ($decodecheck->success) {
                    $person_id  = $decodecheck->response_body->person->id;
                    $member_no  = $decodecheck->response_body->person->member_no;
                    $tier       = $decodecheck->response_body->person->tier;
                    $firstname  = $decodecheck->response_body->person->firstname;
                    $lastname   = $decodecheck->response_body->person->lastname;
                    $age        = $decodecheck->response_body->person->age;
                    $date_of_birth   = $decodecheck->response_body->person->date_of_birth;
                    $mobile_no  = $decodecheck->response_body->person->mobile_no;
                    $email      = $decodecheck->response_body->person->email;
                    $gender     = $decodecheck->response_body->person->gender;
                    $id_card_no = $decodecheck->response_body->person->id_card_no;
                    $consent    = $decodecheck->response_body->person->consent;
                    $subscribe  = $decodecheck->response_body->person->subscribe;
                    $nationality = $decodecheck->response_body->person->nationality;
                    $passport_no = $decodecheck->response_body->person->passport_no;
    
                    $point_accumulate = $decodecheck->response_body->person->point_accumulate;
                    $point_spending = $decodecheck->response_body->person->point_spending;
                    $point_balance = $decodecheck->response_body->person->point_balance;
                    $point_expire = $decodecheck->response_body->person->point_expire;
                    $register_datetime = $decodecheck->response_body->person->register_datetime;
    
                    if (!empty($decodecheck->response_body->person->address)) {
                        $addrId = $decodecheck->response_body->person->address[0]->id;
                        $addrDetail = $decodecheck->response_body->person->address[0]->address_no;
                        $sub_district_code = $decodecheck->response_body->person->address[0]->sub_district_code;
                        $sub_district_th = $decodecheck->response_body->person->address[0]->sub_district_th;
                        $sub_district_en = $decodecheck->response_body->person->address[0]->sub_district_en;
                        $district_code = $decodecheck->response_body->person->address[0]->district_code;
                        $district_th = $decodecheck->response_body->person->address[0]->district_th;
                        $district_en = $decodecheck->response_body->person->address[0]->district_en;
                        $province_code = $decodecheck->response_body->person->address[0]->province_code;
                        $province_th = $decodecheck->response_body->person->address[0]->province_th;
                        $province_en = $decodecheck->response_body->person->address[0]->province_en;
                        $postcode = $decodecheck->response_body->person->address[0]->postcode;
                    }
    
                    if ($gender == 'Female') {
                        $checkF = 'checked';
                    } else {
                        $checkM = 'checked';
                    }
    
                    if ($date_of_birth != "" || $date_of_birth != '0000-00-00') {
                        $arrBirth    = explode("-", $date_of_birth);
                        if (isset($arrBirth[0])) $birthYear    = $arrBirth[0];
                        if (isset($arrBirth[1])) $birthMonth    = $arrBirth[1];
                        if (isset($arrBirth[2])) $birthDay    = $arrBirth[2];
                    }
                    // $date_of_birth 	= trim($r['birthdate']);
                    $birthYear     = (int)$birthYear;
                    $birthMonth    = (int)$birthMonth;
                    $birthDay     = (int)$birthDay;
    
                    // echo 'birthYear : '.$birthYear.'<br>birthMonth :'.$birthMonth.'<br>birthDay :'.$birthDay.'<br>date_of_birth :'.$date_of_birth;
    
                    $person = "SELECT psid_session_id FROM person_session_id WITH (NOLOCK) WHERE personId = ? AND psid_status = ? ";
                    $sql = $this->db->query($person, array($pid, 'Active'))->result_array();
                    if (count($sql) > 0) {
                        foreach ($sql as $r) {
                            $pid_session = htmlspecialchars_decode(trim($r['psid_session_id']));
                        }
                    } else {
                        $mobileNo = '';
                        $idcard = '';
    
                        $personTB = "SELECT mobileNo,idCardNo FROM person WITH (NOLOCK) WHERE personId = ? AND personStatus = ? ";
                        $sqlPerson = $this->db->query($personTB, array($pid, 'A'))->result_array();
                        if (count($sqlPerson) > 0) {
                            foreach ($sqlPerson as $r) {
                                $mobileNo = htmlspecialchars_decode(trim($r['mobileNo']));
                                $idcard = htmlspecialchars_decode(trim($r['idCardNo']));
                            }
                        }
    
                        $pid_session = base64_encode($mobileNo . $idcard);
                    }
    
                    $resObj    = array('ID' => $person_id, 'FIRST' => $firstname, 'LAST' => $lastname, 'BIRTH' => $date_of_birth, 'EMAIL' => $email, 'PHONE' => $mobile_no, 'GENDERM' => $checkM, 'GENDERF' => $checkF, 'IDCARD' => $id_card_no, 'CONSENT' => $consent, 'SUB' => $subscribe, 'NATIONAL' => $nationality, 'PASSPORT' => $passport_no, 'birthYear' => $birthYear, 'birthMonth' => $birthMonth, 'birthDay' => $birthDay, 'addrId' => $addrId, 'addrDetail' => $addrDetail, 'sub_district_code' => $sub_district_code, 'sub_district_th' => $sub_district_th, 'sub_district_en' => $sub_district_en, 'district_code' => $district_code, 'district_th' => $district_th, 'district_en' => $district_en, 'province_code' => $province_code, 'province_th' => $province_th, 'province_en' => $province_en, 'postcode' => $postcode, 'session_id' => $pid_session);
    
                    $dataRes['detail']    = $resObj;
                    $dataRes['status']     = array('STATUS' => 'successfully');
                }else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $decodecheck->response_body->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                }
            } else {
                $dataRes['status']     = array(
                    'STATUS' => 'Unsuccessfully',
                    'message' => $responseData->message,
                    'error' => isset($resultToken->error) ? $resultToken->error : '',
                );
            }

            echo  json_encode($dataRes);
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }

    function getDataMemStatus()
    {
        $ERR_STATUS = 400;
        $DATE_TIME = date("Y-m-d H:i:s");
        try {
            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            $pid   = trim($this->input->post('p_id'));
            $status   = trim($this->input->post('status'));

            if ($pid == "") {
                $ERR_STATUS = 400;
                throw new exception('Err data PersonId is empty');
            }

            $data = 'id=' . $pid;
            $data .= '&person_status=' . $status;
            
            $checkF = '';
            $checkM = '';
            $addrId = '';
            $addrDetail = '';
            $sub_district_code = '';
            $sub_district_th = '';
            $sub_district_en = '';
            $district_code = '';
            $district_th = '';
            $district_en = '';
            $province_code = '';
            $province_th = '';
            $province_en = '';
            $postcode = '';

            $profile_data = $this->oauth2->getProfile($token, $data);

            $responseData = $this->checkAPIData($profile_data);
            if ($responseData->success) {
                $decodecheck = $responseData->data;

                if ($decodecheck->success) {
                    $person_id  = $decodecheck->response_body->person->id;
                    $member_no  = $decodecheck->response_body->person->member_no;
                    $tier       = $decodecheck->response_body->person->tier;
                    $firstname  = $decodecheck->response_body->person->firstname;
                    $lastname   = $decodecheck->response_body->person->lastname;
                    $age        = $decodecheck->response_body->person->age;
                    $date_of_birth   = $decodecheck->response_body->person->date_of_birth;
                    $mobile_no  = $decodecheck->response_body->person->mobile_no;
                    $email      = $decodecheck->response_body->person->email;
                    $gender     = $decodecheck->response_body->person->gender;
                    $id_card_no = $decodecheck->response_body->person->id_card_no;
                    $consent    = $decodecheck->response_body->person->consent;
                    $subscribe  = $decodecheck->response_body->person->subscribe;
                    $nationality = $decodecheck->response_body->person->nationality;
                    $passport_no = $decodecheck->response_body->person->passport_no;
    
                    $point_accumulate = $decodecheck->response_body->person->point_accumulate;
                    $point_spending = $decodecheck->response_body->person->point_spending;
                    $point_balance = $decodecheck->response_body->person->point_balance;
                    $point_expire = $decodecheck->response_body->person->point_expire;
                    $register_datetime = $decodecheck->response_body->person->register_datetime;
    
                    if (!empty($decodecheck->response_body->person->address)) {
                        $addrId = $decodecheck->response_body->person->address[0]->id;
                        $addrDetail = $decodecheck->response_body->person->address[0]->address_no;
                        $sub_district_code = $decodecheck->response_body->person->address[0]->sub_district_code;
                        $sub_district_th = $decodecheck->response_body->person->address[0]->sub_district_th;
                        $sub_district_en = $decodecheck->response_body->person->address[0]->sub_district_en;
                        $district_code = $decodecheck->response_body->person->address[0]->district_code;
                        $district_th = $decodecheck->response_body->person->address[0]->district_th;
                        $district_en = $decodecheck->response_body->person->address[0]->district_en;
                        $province_code = $decodecheck->response_body->person->address[0]->province_code;
                        $province_th = $decodecheck->response_body->person->address[0]->province_th;
                        $province_en = $decodecheck->response_body->person->address[0]->province_en;
                        $postcode = $decodecheck->response_body->person->address[0]->postcode;
                    }
    
                    if ($gender == 'Female') {
                        $checkF = 'checked';
                    } else {
                        $checkM = 'checked';
                    }
    
                    if ($date_of_birth != "" || $date_of_birth != '0000-00-00') {
                        $arrBirth    = explode("-", $date_of_birth);
                        if (isset($arrBirth[0])) $birthYear    = $arrBirth[0];
                        if (isset($arrBirth[1])) $birthMonth    = $arrBirth[1];
                        if (isset($arrBirth[2])) $birthDay    = $arrBirth[2];
                    }
                    // $date_of_birth 	= trim($r['birthdate']);
                    $birthYear     = (int)$birthYear;
                    $birthMonth    = (int)$birthMonth;
                    $birthDay     = (int)$birthDay;
    
                    // echo 'birthYear : '.$birthYear.'<br>birthMonth :'.$birthMonth.'<br>birthDay :'.$birthDay.'<br>date_of_birth :'.$date_of_birth;
    
                    $person = "SELECT psid_session_id FROM person_session_id WITH (NOLOCK) WHERE personId = ? AND psid_status = ? ";
                    $sql = $this->db->query($person, array($pid, 'Active'))->result_array();
                    if (count($sql) > 0) {
                        foreach ($sql as $r) {
                            $pid_session = htmlspecialchars_decode(trim($r['psid_session_id']));
                        }
                    } else {
                        $mobileNo = '';
                        $idcard = '';
    
                        $personTB = "SELECT mobileNo,idCardNo FROM person WITH (NOLOCK) WHERE personId = ? AND personStatus = ? ";
                        $sqlPerson = $this->db->query($personTB, array($pid, 'A'))->result_array();
                        if (count($sqlPerson) > 0) {
                            foreach ($sqlPerson as $r) {
                                $mobileNo = htmlspecialchars_decode(trim($r['mobileNo']));
                                $idcard = htmlspecialchars_decode(trim($r['idCardNo']));
                            }
                        }
    
                        $pid_session = base64_encode($mobileNo . $idcard);
                    }
    
                    $resObj    = array('ID' => $person_id, 'FIRST' => $firstname, 'LAST' => $lastname, 'BIRTH' => $date_of_birth, 'EMAIL' => $email, 'PHONE' => $mobile_no, 'GENDERM' => $checkM, 'GENDERF' => $checkF, 'IDCARD' => $id_card_no, 'CONSENT' => $consent, 'SUB' => $subscribe, 'NATIONAL' => $nationality, 'PASSPORT' => $passport_no, 'birthYear' => $birthYear, 'birthMonth' => $birthMonth, 'birthDay' => $birthDay, 'addrId' => $addrId, 'addrDetail' => $addrDetail, 'sub_district_code' => $sub_district_code, 'sub_district_th' => $sub_district_th, 'sub_district_en' => $sub_district_en, 'district_code' => $district_code, 'district_th' => $district_th, 'district_en' => $district_en, 'province_code' => $province_code, 'province_th' => $province_th, 'province_en' => $province_en, 'postcode' => $postcode, 'session_id' => $pid_session);
    
                    $dataRes['detail']    = $resObj;
                    $dataRes['status']     = array('STATUS' => 'successfully');
                }else {
                    $dataRes['status']     = array(
                        'STATUS' => 'Unsuccessfully',
                        'message' => $decodecheck->response_body->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                }
            } else {
                $dataRes['status']     = array(
                    'STATUS' => 'Unsuccessfully',
                    'message' => $responseData->message,
                    'error' => isset($resultToken->error) ? $resultToken->error : '',
                );
            }

            echo  json_encode($dataRes);
        } catch (exception $e) {
            if ($ERR_STATUS == 400) {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
            echo json_encode($Err);
        }
    }

    function selectDupIdcard()
    {
        $dataCheck     = null;
        $menu = $this->input->post('menu');
        $person_id = $this->input->post('pId');

        if ($menu == 'idcard') {
            $dataCheck = $this->input->post('idCard');
            $unique = 'Y';
        } else if ($menu == 'email') {
            $dataCheck = $this->input->post('email');
            $unique = 'Y';
        } else {
            $dataCheck = $this->input->post('passport');
        }
        $sql = $this->PersonModel->getDuplicate($dataCheck, $menu, $person_id);
        // $sql = $this->PersonModel->getPerson(null, null, $idCard, $email, 'A', null, $unique, $passaport, $person_id)->result_array();
        if ($sql) {
            $result = "fail";
        } else {
            $result = "pass";
        }
        echo $result;
    }

    function select_memberOld()
    {
        $phone = $this->input->post('phone');
        $memNo = $this->input->post('memNo');

        $sql = $this->PersonModel->getPersonOldSelect($phone, $memNo)->result_array();
        if (count($sql) > 0) {
            $is_member      = $sql[0]['is_member'];
            $verify_phone   = $sql[0]['verify_phone'];
            $verify_email   = $sql[0]['verify_email'];
            $person_id      = $sql[0]['personId'];

            $this->session->set_userdata('person_id', $person_id);

            if (($verify_phone && $verify_email) || $verify_phone) {
                if ($is_member) {
                    $register_datetime = '';

                    $personLine = "SELECT register_datetime FROM person WITH (NOLOCK) WHERE mobileNo = ? AND personStatus = ? ";
                    // $personLine = "SELECT register_datetime FROM person_social WITH (NOLOCK) WHERE socialType = ? AND socialStatus = ?  AND personId = ? ";
                    // $sqlPerson = $this->db->query($personLine,array('Line','A',$person_id))->result_array();
                    $sqlPerson = $this->db->query($personLine, array($phone, 'A'))->result_array();
                    if (count($sqlPerson) > 0) {
                        foreach ($sqlPerson as $r) {
                            $register_datetime = htmlspecialchars_decode(trim($r['register_datetime']));
                        }
                        if (!empty($register_datetime) && $register_datetime != '00-00-00 00:00:00') {
                            $dataRes['status']     = array('STATUS' => 'Success_memberLine', 'is_member' => $is_member);
                            // $person = "SELECT psid_session_id FROM person_session_id WITH (NOLOCK) WHERE personId = ? AND psid_status = ? ";
                            // $sql = $this->db->query($person, array($person_id, 'Active'))->result_array();
                            // if (count($sql) > 0) {
                            //     foreach ($sql as $r) {
                            //         $pid_session = htmlspecialchars_decode(trim($r['psid_session_id']));
                            //     }
                            // } else {
                            //     $pid_session = null;
                            // }

                            // $personLine = "SELECT personId FROM person_social WITH (NOLOCK) WHERE socialType = ? AND socialStatus = ?  AND personId = ? ";
                            // $NumrowLine = $this->db->query($personLine, array('Line', 'A', $person_id))->num_rows();
                            // if ($NumrowLine == 0) {
                            //     $dataRes['status']     = array('STATUS' => 'Success_member', 'is_member' => $is_member, 'session_id' => $pid_session);
                            // } else {
                            //     $dataRes['status']     = array('STATUS' => 'Success_memberLine', 'is_member' => $is_member, 'session_id' => $pid_session);
                            // }
                        } else {
                            $dataRes['status']     = array('STATUS' => 'Success_member');
                        }
                    } else {
                        $dataRes['status']     = array('STATUS' => 'Success_member');
                    }
                } else {
                    $dataRes['status']     = array('STATUS' => 'Successfully', 'is_member' => 'N');
                }
            } else {
                //เลือกสมาชิก
                // $count = count($decodecheck ->response_body ->person);
                $dataRes['status']     = array('STATUS' => 'Select_Person', 'is_member' => 'N');
            }
        } else {
            $dataRes['status']     = array('STATUS' => 'NEW_MEMBER');
        }
        echo  json_encode($dataRes);
    }

    public function checkLineID()
    {
        // form_validation
        $this->load->library('form_validation');
        $this->form_validation->set_rules('phone', 'เบอร์โทรศัพท์มือถือ', 'required|trim|numeric|min_length[10]|max_length[10]');
        $this->form_validation->set_rules('type', 'ประเภท', 'required|trim');
        $this->form_validation->set_rules('uid', 'LINE ID', 'required|trim', array('required' => 'ไม่พบ %s กรุณาปิดแล้วเข้าใหม่อีกครั้ง', 'trim' => 'ไม่พบ %s กรุณาปิดแล้วเข้าใหม่อีกครั้ง'));
        $type = $this->input->post('type');
        if ($type == 'Thai') {
            $this->form_validation->set_rules('idcard', 'เลขบัตรประชาชน หรือ เลขหนังสือเดินทาง', 'required|trim|min_length[10]|max_length[13]');
        } else {
            $this->form_validation->set_rules('idcard', 'เลขบัตรประชาชน หรือ เลขหนังสือเดินทาง', 'required|trim|min_length[10]|max_length[13]');
        }
        $this->form_validation->set_message('required', 'กรุณาระบุ %s');
        $this->form_validation->set_message('trim', 'กรุณาระบุ %s');
        $this->form_validation->set_message('min_length', '{field} อย่างน้อย {param} หลัก.');
        $this->form_validation->set_message('max_length', '{field} ต้องไม่เกิน {param} หลัก.');

        if ($this->form_validation->run() == FALSE) {
            echo json_encode(array('status' => false, 'error' => $this->form_validation->error_array()));
        } else {
            $DATE_TIME = date("Y-m-d H:i:s");

            $phone = $this->input->post('phone');
            $idcard = $this->input->post('idcard');
            $uid = $this->input->post('uid');

            $resultToken = $this->Lists_model->getToken(APPID, null, $DATE_TIME);
            if ($resultToken) {
                $token = htmlspecialchars_decode(trim($resultToken->access_token));
            } else {
                $resultToken = $this->get_token();
                if ($resultToken->success) {
                    $token = $resultToken->data->access_token;
                } else {
                    $dataRes = array(
                        'status' => false,
                        'message' => $resultToken->message,
                        'error' => isset($resultToken->error) ? $resultToken->error : '',
                    );
                    echo  json_encode($dataRes);
                    exit;
                }
            }

            $data = 'mobile_no=' . $phone;
            if ($type == 'Thai') {
                $data .= '&id_card_no=' . $idcard;
            } else {
                $data .= '&passport_no=' . $idcard;
            }

            $this->session->set_userdata(array(
                'dataPhoneNumber' => $phone,
                'dataIdcard' => $idcard,
                'dataTypeIdcard' => $type,
                'dataUID' => $uid,
            ));
            $checkStatus = $this->oauth2->check_line_id($token, $data);

            $responseData = $this->checkAPIData($checkStatus);
            if ($responseData->success) {
                $decodecheck = $responseData->data;
                if ($decodecheck->success) {

                    $dataUid = array(
                        'phone' => $phone,
                        'uid' => $uid,
                    );
                    $this->Lists_model->insertLogUID($dataUid);

                    $selectPerson = null;

                    if (count($decodecheck->response_body->person) > 1) {
                        foreach ($decodecheck->response_body->person as $dataPerson) {
                            if ($dataPerson->verify_phone == 'Y') {
                                $selectPerson = $dataPerson;
                            }
                        }
                        if ($selectPerson == null) {
                            $dataRes = array('status' => false, 'newUser' => true, 'message' => "Member not found.");
                        }
                        // $dataRes = array('status' => $decodecheck->success, 'message' => $decodecheck->response_body, 'count' => count($decodecheck->response_body->person));
                    } else {
                        $selectPerson = $decodecheck->response_body->person[0];
                    }
                    if ($selectPerson) {
                        if ($selectPerson->line_user_id_old) {
                            if ($selectPerson->line_user_id) {
                                if ($selectPerson->line_user_id == $uid) {
                                    // ไม่ควรเข้าเคสนี้ เพราะว่า uid ตรงกันอยู่แล้ว
                                    $dataRes = array('status' => true, 'login' => true, 'message' => 'go to login');
                                } else {
                                    $dataRes = array('status' => false, 'fail' => true, 'message' => 'acountนี้ ได้มีการ acitive ไปแล้ว');
                                }
                                $array_items = array('dataPhoneNumber', 'dataIdcard', 'dataTypeIdcard', 'dataUID', 'socialDisplayName', 'socialPictureUrl', 'socialStatusMessage');
                                $this->session->unset_userdata($array_items);
                            } else {
                                $session_id = base64_encode($phone . $idcard);
                                $dataUpdate = 'id=' . $selectPerson->id . '&session_id=' . $session_id . '&line_user_id=' . $uid;
                                if ($this->session->userdata('socialDisplayName')) {
                                    $dataUpdate .= '&line_display_name=' . $this->session->userdata('socialDisplayName');
                                }
                                
                                if ($this->session->userdata('socialPictureUrl')) {
                                    $dataUpdate .= '&line_picture_url=' . $this->session->userdata('socialPictureUrl');
                                }
                                
                                if ($this->session->userdata('socialStatusMessage')) {
                                    $dataUpdate .= '&line_status_message=' . $this->session->userdata('socialStatusMessage');
                                }
                                $responseUpdate = $this->oauth2->update($token, $dataUpdate);
                                $responseDataUpdate = $this->checkAPIData($responseUpdate);
                                if ($responseDataUpdate->success) {
                                    $decodecheck = $responseDataUpdate->data;
                                    if ($decodecheck->success) {
                                        $dataRes = array('status' => true, 'login' => true, 'message' => 'go to login');
                                    } else {
                                        $dataRes = array('status' => false, 'fail' => true, 'message' => $responseDataUpdate->message);
                                    }
                                    $array_items = array('dataPhoneNumber', 'dataIdcard', 'dataTypeIdcard', 'dataUID', 'socialDisplayName', 'socialPictureUrl', 'socialStatusMessage');
                                    $this->session->unset_userdata($array_items);
                                } else {
                                    $dataRes = array('status' => $responseDataUpdate->success, 'fail' => true, 'message' => $responseDataUpdate->message);
                                }
                            }
                        } else {
                            $dataRes = array('status' => false, 'newUser' => true, 'message' => "Member not found.");
                        }
                    }else {
                        $dataRes = array('status' => false, 'newUser' => true, 'message' => "Member not found.");
                    }
                } else {
                    $dataRes = array('status' => $decodecheck->success, 'newUser' => true, 'message' => $decodecheck->response_body->message);
                }
            } else {
                $dataRes = array('status' => $responseData->success, 'fail' => true, 'message' => $responseData->message);
            }

            echo json_encode($dataRes);
            // $this->db->trans_begin();
            // $insertData = $this->History_model->insertActivityReward($dataInsert);
            // if ($this->db->trans_status() === FALSE)
            // {
            //     $this->db->trans_rollback();
            //     log_message('error', $this->db->_error_message());
            // }
            // else
            // {
            //     $this->db->trans_commit();
            //     echo json_encode(array('success' => 'success'));
            // }
        }
    }

    // assets function
    private function checkAPIData($dataAPI)
    {
        $responseData = new stdClass;
        $errorAPI = strpos($dataAPI, 'internal error');
        $dataDecode = json_decode($dataAPI);
        if ($errorAPI > 0 || !$dataDecode) {
            $this->db->trans_start();
            $this->db->set('details', $dataAPI);
            $this->db->insert('log_issue_line');
            $insertID = $this->db->insert_id();
            if ($this->db->trans_status() === FALSE) {
                $this->db->trans_rollback();
            } else {
                $this->db->trans_commit();
            }
            $responseData->success = false;
            $responseData->error = $dataAPI;
            $issueCode = $insertID ? ' ISSUE CODE: AP' . $insertID . '</br><small> เพื่อความสะดวกกรุณาแจ้ง ISSUE CODE แก่เจ้าหน้าที่</small>' : '';
            $responseData->message = "ไม่สามารถดำเนินการในขณะนี้ กรุณาติดต่อเจ้าหน้าที่" . $issueCode;
        } else {
            $responseData->success = true;
            $responseData->data = $dataDecode;
            $responseData->message = "Successfully";
        }
        return $responseData;
    }
    // end assets function
}
