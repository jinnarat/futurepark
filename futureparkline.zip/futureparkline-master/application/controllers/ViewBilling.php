<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class ViewBilling extends CI_Controller
{    
    public function __construct()
    {
        parent::__construct();
		$this->load->model('MainFunction');
		$this->load->model('QRCodeModel');
		if ($this->session->userdata('userid') == '') {
            redirect('signin', 'refresh');
        }
    }

    public function index() {	
		$data = array(
			"Body" => "modules/ViewBilling",
			"isHeader" => true,
			"isFooter" => true
		);		
		$this->load->view("_Template", $data);
	}	
	
	public function detail($BillNo=null,$SoNo=null,$page=null)
	{			
		
		$delivery 		= "";
		$delivery_ship 	= "";	
		$pricing		= "";
		$billing		= "";
		$page_so		= "";

		$asSOValue		= "";
		$getSO			= "";
		$asPOValue		= "";
		$po_number		= "";
		
		$ctypeid 		= $this->session->userdata('ctypeid');
		$company_code	= $this->session->userdata('company_code');
		
		//$PoHeader 		= $this->MainModel->getPoHeader($DocNo)->result_array();
		
		$p 				= array();
		$address 		= '';
		$SalePrice 		= '';
		$ShipDetail 	= '';
		$Plant 			= '';
		$Truck 			= '';
		$FileUpload 	= '';
		$poh_incoterms 	= '';
		$purchase 		= '';
		$m_address 		= '';
		$Incoterms 		= '';
		$m_contact 		= '';
		$m_truck 		= '';
		$m_contact_phone = '';
		
		
		$cus_nameLC 		= '';
		$cus_code			= '';
		$cus_phone			= '';
		$cus_taxid			= '';
		$cus_address		= '';
		$cus_branch			= '';
		
		$company_name 	 	= '';
		$company_address 	= '';
		$company_name_en   	= '';
		$company_address_en = '';
		$company_tel     	= '';
		$company_taxid   	= '';
		
		$p['BillNo']	= $BillNo;		
		
		$filename_qr	= "fuploads/qrcode/".$BillNo."/".$BillNo."-Qrcode.png";
		
		if(!is_file($filename_qr))
		{
			$qrcode		= $this->QRCodeModel->qrcodeGenerator($BillNo);			
		}else{
			$qrcode		= $filename_qr;
		}
		
		
		$p['img_qrcode'] 	= '<img src="'.base_url().$filename_qr.'">'; 
		
		$due_date	= "";
		$paymentterm= "";
		$create_date= "";
		$page_so	= array();
		$condition  = "";		
		$ResHeader = $this->MainModel->getDataBind("SELECT mbillno, poh_purchase												  
													  ,CONVERT(varchar,mduedate,103) as mduedate 
													  ,msoldto													 
													  ,mpayterm													 
													  ,cus_nameLC, cus_taxid, cus_branch
													  --,(mpayterm+'-'+payt_name_th) as paymentterm
													  ,payt_name_th as paymentterm
													  ,CONVERT(varchar,mbilldate,103) as mbilldate
													  ,add_text, mdistrict, mcity, mphone, add_zipcode
													  ,company_name, company_address, company_tel, company_taxid, company_name_en, company_address_en
											  FROM vwbillingtxt 											  
											  LEFT JOIN customer ON customer.cus_code = vwbillingtxt.msoldto AND customer.cus_status = 'A'
											  LEFT JOIN customer_address ON customer.cus_code = customer_address.add_cus_code AND add_invoice = 'Y'
											  LEFT JOIN po_header ON  ( vwbillingtxt.mrefwebid = po_header.poh_document_code OR vwbillingtxt.mincoterm1 = po_header.poh_document_code ) 
											  LEFT JOIN master_paymentterm ON master_paymentterm.payt_value = vwbillingtxt.mpayterm
											  LEFT JOIN company ON company.company_code = customer.company_code
											  "					  
					  ,"WHERE mbillno = ? ".$condition
					  ,$VALUE = array($BillNo) 
					  ,$GROUPBY = NULL
					  ,$ORDERBY = NULL)->result_array();
		
		if(count($ResHeader) > 0)
		{
			$cus_nameLC	= $ResHeader[0]['cus_nameLC'];
			$cus_code	= $ResHeader[0]['msoldto'];
			$due_date	= str_replace("/",".",$ResHeader[0]['mduedate']);
			$paymentterm= $ResHeader[0]['paymentterm'];
			$create_date= str_replace("/",".",$ResHeader[0]['mbilldate']);
			$cus_phone 	= $ResHeader[0]['mphone'];
			$cus_taxid	= $ResHeader[0]['cus_taxid'];
			$cus_branch	= $ResHeader[0]['cus_branch'];
			$cus_address= "<BR>".$ResHeader[0]['add_text']."<BR>".$ResHeader[0]['mdistrict']."<BR>".$ResHeader[0]['mcity']." ".$ResHeader[0]['add_zipcode']."<BR>";
			$asPOValue	= $ResHeader[0]['poh_purchase'];			
			$company_name    	= $ResHeader[0]['company_name'];
			$company_name_en 	= $ResHeader[0]['company_name_en'];
			$company_address 	= $ResHeader[0]['company_address'];
			$company_address_en = $ResHeader[0]['company_address_en'];
			$company_tel     	= $ResHeader[0]['company_tel'];
			$company_taxid   	= $ResHeader[0]['company_taxid'];
			
			$branch = intval($cus_branch);
			if($branch > 0)
			{
				$cus_branch = "สาขาที่ ".$branch;
			}else{
				$cus_branch	= "สำนักงานใหญ่";
			}				
		}
		
		$p['due_date']		= $due_date;
		$p['paymentterm']	= $paymentterm;
		$p['create_date']	= $create_date;	
		
		$p['cus_nameLC']	= $cus_nameLC;
		$p['cus_code']		= $cus_code;
		$p['cus_phone']		= $cus_phone;
		$p['cus_taxid']		= $cus_taxid;		
		$p['cus_address'] 	= $cus_address;
		$p['cus_branch'] 	= $cus_branch;
		
		$p['company_name']    = $company_name."<br>";
		$p['company_address'] = $company_address;
		$p['company_tel']     = $company_tel;
		$p['company_taxid']   = $company_taxid; 
		$p['company_code']    = $company_code; 
		
		$p['company_name_en']    = "<br>".$company_name_en."<br>";
		$p['company_address_en'] = $company_address_en;
		
		if($page == null) $page = 1;
		
		$total_page = 1;
		$page_so	= array();
		$condition  = "";
		
		$res_so	= $this->MainModel->getDataBind("SELECT msaledocno FROM vwbillingtxt WHERE mbillno = '".$BillNo."' GROUP BY msaledocno ")->result_array();
		
		if(count($res_so) > 0)
		{
			foreach($res_so as $rs) 
			{ 
				$page_so[] 	= $rs['msaledocno'];
				$total_page = count($page_so);
			}
			if(!empty($SoNo)){				
				
				$asSOValue = $SoNo;
			}else{				
				
				$asSOValue = $page_so[0];
			}
			$condition = " AND msaledocno = '".$asSOValue."' "; 			
		}		
		
		$p['asPOValue'] = $asPOValue;

		$saleorder = array(); 
		$poh_reference = "";
		$mrefwebid = "";
		$msaledocno = "";
		
		if(count($page_so)>0){
		  $chk_numpage = 0;
		
		  foreach($page_so as $index =>  $val){
			
			$res_so = $this->MainModel->getDataBind("SELECT mrefitemno FROM vwbillingtxt WHERE mbillno = '".$BillNo."' and msaledocno = '".$val."'")->result_array();						
			$numrow_so 		= count($res_so);
			$totalpage_so 	= ceil($numrow_so/10);
			$allpage 		= $totalpage_so;						
			$chk_numpage++;			
		  }
		  
		}else{
			if($getSO == null){
			  $chk_getSO = $msaledocno;
			}
		}
		
		$p['page']	= $page.'/'.$total_page;
		
		
		
		$databilling	= "";	
		
		
		$ResBilling = $this->MainModel->getDataBind("SELECT mrefdocno, product_nameLC, mmatno, mbillqty, msaleunit, msaledocno, 
													  unitprice, unitdiscamt, unitdiscper, unitadamt, unitadper, unitnetamt, mnetamt
													  ,CASE WHEN (msaleunit = pu.uomunit AND msaleunit = pu.baseunit) THEN pu.baseunit_th 
															WHEN (msaleunit = pu.uomunit) THEN pu.uomunit_th
															WHEN (msaleunit = pu.baseunit) THEN 
																	CASE WHEN RTRIM(LTRIM(product_base_unit)) <> '' THEN product_base_unit ELSE pu.baseunit_th END
													  END as baseunit_th
													  FROM vwbillingtxt 
													  LEFT JOIN product_lists ON product_lists.erp_productno = vwbillingtxt.mmatno
													  LEFT JOIN product_group ON product_lists.product_grpcode = product_group.product_grpcode
													  LEFT JOIN product_unit pu ON product_lists.erp_productno = pu.erp_productno"
													  ,"WHERE mbillno = ? ".$condition
													  ,$VALUE = array($BillNo) 
													  ,$GROUPBY = NULL
													  ,$ORDERBY = " ORDER BY mrefdocno, mrefitemno")->result_array();
		
		$total 		= 0;
		$alltotal	= 0;
		$totalvat	= 0;
		$sumtotal	= 0;
		$i 			= 1;	
		$getsono	= '';
		if(count($ResBilling) > 0){		
			
			foreach($ResBilling as $r){
				$totalunit = $r['unitdiscamt'] + $r['unitadamt'];
				
				if($getsono != $r['msaledocno']){
					$msaledocno	= $r['msaledocno'];
				}else{
					$msaledocno	= '';
				}
			
				$databilling .= '<tr>
								<td data-column="ใบสั่งสินค้า (SALES ORDER)">'.$msaledocno.'</td>
								<td data-column="ใบจ่ายสินค้าเลขที่ (D/P NO.)">'.$r['mrefdocno'].'</td>
								<td data-column="รหัสสินค้า (PRODUCT CODE)">'.$r['mmatno'].'</td>
								<td data-column="ชื่อสินค้า (PRODUCT DESCRIPTION)" class="nowrap">'.$r['product_nameLC'].'</td>
								<td class="currency" data-column="จำนวนสินค้า (QUANTITY)">'.$r['mbillqty'].'</td>
								<td data-column="หน่วย (UNIT)" class="text-center">'.$r['baseunit_th'].'</td>
								<td class="currency" data-column="ราคาขายต่อหน่วย (LIST PRICE/UNIT)">'.number_format($r['unitprice'],2,'.',',').'</td>
								<td class="currency" data-column="ส่วนลดต่อหน่วย (DISCOUNT/UNIT)">'.number_format($totalunit,2,'.',',').'</td>
								<td class="currency" data-column="ราคาขายสุทธิต่อหน่วย (NET PRICE/UNIT)">'.number_format($r['unitnetamt'],2,'.',',').'</td>
								<td class="currency" data-column="จำนวนเงิน (AMOUNT)">'.number_format($r['mnetamt'],2,'.',',').'</td>
							</tr>';
							
				$total = $total + $r['mnetamt'];
				$getsono = $r['msaledocno'];
				$i++;
			}
			
			$databilling .= '<tr>
								<td></td>
								<td></td>
								<td></td>
								<td class="text-right">PO '.$asPOValue.'</td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td></td>
								<td class="currency font-bold">'.number_format($total,2,'.',',').'</td>
							</tr>';
		}
		
		$tr_blank	= '<br>';
		
		
		for($j=$i;$j<=10;$j++){
			$tr_blank	.= '<br>';
		}
		
		
		$p['tr_blank']	= $tr_blank;
		
		$p['total']		= $total;
		
		$ResVat			= $this->MainModel->getDataBind("SELECT vat FROM master_vat")->result_array(); 
		$vat			= $ResVat[0]['vat'];
		
		$ResTotal 		= $this->MainModel->getDataBind("SELECT sum(mnetamt) as sumTotal FROM vwbillingtxt WHERE mbillno = '".$BillNo."' ")->result_array(); 
		$alltotal		= $ResTotal[0]['sumTotal'];
		$totalvat		= ($alltotal*$vat)/100;
		
		$sumtotal		= $alltotal + $totalvat;
		$sumtotalthai 	= $this->MainFunction->bahtText($sumtotal);
		
		$p['vat']		= $vat;
		$p['alltotal']	= $alltotal;
		$p['totalvat']	= $totalvat;
		$p['sumtotal']	= $sumtotal;
		$p['sumtotalthai']	= $sumtotalthai;
		
		$data = array(
			"Body" 			=> "modules/ViewBilling",
			"DataLists" 	=> $databilling,			
			"p"  			=> $p,
			"page_so"		=> $page_so,
			"isHeader" 		=> false,
			"isFooter" 		=> false
		);		
		$this->load->view("_Template", $data);
	}
}