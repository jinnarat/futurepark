<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);
class Home extends DB_Controller
{
	// class Home extends  CI_Controller {
	protected $authDataPerson;

	function __construct()
	{
		parent::__construct();
		$this->load->model('Select_data');
		$this->load->model('Lists_model');
		$this->load->model('RedemptionModel');

		$this->load->model('PersonModel');
		$personID = $this->session->userdata('userfprid');
		if (!$personID) {
			redirect(URLFRONT_Login);
		}else {
			$resutlPerson = $this->PersonModel->getPersonData($personID);
			if ($resutlPerson) {
				$this->authDataPerson = $resutlPerson;
			}else {
				redirect(URLFRONT_Login);
			}
		}
	}
	public function index()
	{
		$uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,
			"META_DESC"       => META_DESC,
			"stylesheet"      => '',
			"javascript"      => '',
			"fb_title"        => OG_TITLE,
			"fb_image"        => OG_IMAGE,
			"fb_description"  => OG_DESC,
			"isHeader"        => true,
			"myModal"        => true
		);

		$getParam	= $this->input->get('c');

		// echo 'getParam : '.$getParam;

		if (isset($getParam)) {
			$person_id	= $this->MainModel->Base64Decrypt($getParam);
			// $param 			= explode(";",$array_param);
			$data['person_id'] = $getParam;
			// echo $person_id;
			// if(!isset($param[0])){ $ERR_STATUS = 400; throw new exception($this->not_error); }
			// if(!isset($param[1])){ $ERR_STATUS = 400; throw new exception($this->not_error); }
			$personId = $person_id;
		} else {
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			$data['person_id'] = $param;
			$personId = $check_session;
		}
		$DATE_TIME = date("Y-m-d H:i:s");
		$data['highlight_slider'] = array();
		$data['act_slider'] = array();
		$select_img = '';
		$select_imgAct = '';
		$is_highlight = '';

		

		$act = $this->Lists_model->SelectActAll(null, null, $DATE_TIME)->result_array();
		if (count($act) > 0) {
			foreach ($act as $a) {
				$activityId = htmlspecialchars_decode(trim($a['activityId']));
				$is_only_member = trim($a['is_only_member']);
				$usedTargetCDP = trim($a['usedTargetCDP']);
				$regis_new_system = trim($a['regis_new_system']);
				$insertData = trim($a['insertData']);
				$subDetail = trim($a['subDetail']);
				$activityType = htmlspecialchars_decode(trim($a['activityType']));
				$isShowAct = false;
				
				$mapLink = '';
				$rowMasterActivityLink = $this->Lists_model->getMasterActivityLink($activityType);
				if ($rowMasterActivityLink) {
					$mapLink = $rowMasterActivityLink->mapLink;
				}

				if ($a['campStatus'] != 'A' || $a['subcampStatus'] != 'A') {
					continue;
				}
				$regis_new_system = strtolower($regis_new_system);

				if ($usedTargetCDP == 'Y' || ($regis_new_system != '' && $regis_new_system != NULL)){
					if ($insertData == 'Y') {
						$isShowAct = false;
					}else {
						$checkCdpTarget = $this->Lists_model->getActivityTargetPersonal($activityId, $personId);
						if ($checkCdpTarget) {
							$isShowAct = true;
						} else {
							$isShowAct = false;
						}
					}
				} else {
					if ($is_only_member == 'Y') {
						$actMember = $this->Lists_model->getActivityMember($a['activityId']);
						if ($actMember) {
							$personData = $this->Lists_model->getPerson($personId);
							foreach ($actMember as  $rowActMem) {
								if ($personData->ti_id == $rowActMem->tier_id) {
									$isShowAct = true;
								}
							}
						} else {
							$isShowAct = false;
						}
					} else {
						$isShowAct = true;
					}
				}

				if (!$isShowAct) {
					continue;
				}

				$campId = htmlspecialchars_decode(trim($a['campId']));
				$activityCode = htmlspecialchars_decode(trim($a['activityCode']));
				
				$activityName = htmlspecialchars_decode(trim($a['activityName']));
				$urlfriendly = htmlspecialchars_decode(trim($a['urlfriendly']));
				$imgBanner = htmlspecialchars_decode(trim($a['imgBanner']));
				$detail = htmlspecialchars_decode(trim($a['detail']));
				$limit = htmlspecialchars_decode(trim($a['limit']));
				$startDate = htmlspecialchars_decode(trim($a['startDate']));
				$endDate = htmlspecialchars_decode(trim($a['endDate']));
				$endDisplay = htmlspecialchars_decode(trim($a['endDisplay']));
				$is_highlight = htmlspecialchars_decode(trim($a['is_highlight']));

				$enAid = $this->MainModel->Base64Encrypt($activityId);
				$enPid = $this->MainModel->Base64Encrypt($personId);

				if (!empty($imgBanner)) {
					if (getimagesize(PATHIMGCAMPAIGN . $imgBanner)) {
						$imageDisplay = '<img src="' . PATHIMGCAMPAIGN . $imgBanner . '?v="' . date('his') . ' alt=" " class="responsive size-img">';
					} else {
						$imageDisplay = '<img src="' . $uri . 'assets/images/default_image.jpg?v="' . date('his') . '" alt=" " class="responsive size-img default-img">';
					}
				} else {
					$imageDisplay = '<img src="' . $uri . 'assets/images/default_image.jpg?v="' . date('his') . '" alt=" " class="responsive size-img default-img">';
				}

				if ($endDisplay >= $DATE_TIME) {
					if ($is_highlight == 'Y') {
						$classAction = '';
						if ($activityType == 'Promotion') {
							$link = '<a href="' . PATHIMGCAMPAIGN . 'promotion/' . $urlfriendly . '?r=Line&aId=' . $enAid . '&pId=' . $enPid . '">
										' . $imageDisplay . '	
									</a>';
							$classAction = 'item-ifram';
						} else {
							$link = '<a href="' . $uri . 'campaign/activity/' . $activityId . '">
										' . $imageDisplay . '	
									</a>';
						}

						$select_img = '<div class="item '.$classAction.'">
												<div class="promo-img">
													' . $link . '
												</div>
												<div class="container promo-detail">
													<p class="activityName">' . $activityName . '</p>
													<p class="text-eng">' . $startDate . ' - ' . $endDate . '</p>
												</div>
											</div>';

						$data['pr'][$campId] = $select_img;
						array_push($data['highlight_slider'], $data['pr'][$campId]);
					} else {
						if ($activityType != 'Promotion') {
							if ($activityType == 'Redemption') {
								$resultActivity = $this->RedemptionModel->getActivityRedemptionBurnPoint();
								if ($resultActivity) {
									$select_imgAct = '<div class="item" type="burnPoint">
													<div class="promo-img">
														<a href="' . $uri . 'campaign/activity/' . $activityId . '">
															' . $imageDisplay . '	
														</a>
													</div>
													<div class="container promo-detail">
														<p class="activityName">' . $activityName . '</p>
														<p class="text-eng">' . $startDate . ' - ' . $endDate . '</p>
													</div>
												</div>';
								}else {
									continue;
								}
							}else {
								$select_imgAct = '<div class="item">
													<div class="promo-img">
														<a href="' . $uri . 'campaign/activity/' . $activityId . '">
															' . $imageDisplay . '	
														</a>
													</div>
													<div class="container promo-detail">
														<p class="activityName">' . $activityName . '</p>
														<p class="text-eng">' . $startDate . ' - ' . $endDate . '</p>
													</div>
												</div>';
							}

							$data['pr'][$campId] = $select_imgAct;
							array_push($data['act_slider'], $data['pr'][$campId]);
						}
						
					}
				}
			}
		}

		//privilege
		$dataPerson = $this->Lists_model->getPerson($personId);
		$privilegeHtmlArray = [];
		if($dataPerson){
			if($dataPerson->ti_id && $dataPerson->personStatus == $this->config->item('status_active')){
				$privilegeHighlight = $this->Lists_model->SelectPrivilegeHighlight();
				if ($privilegeHighlight) {
					foreach ($privilegeHighlight as $rowHighlight) {

						if (!empty($rowHighlight->mps_image)) {
							if (getimagesize(PATHIMGCAMPAIGN . $rowHighlight->mps_image)) {
								$imageDisplay = '<img src="' . PATHIMGCAMPAIGN . $rowHighlight->mps_image . '?v="' . date('his') . ' alt=" " class="responsive size-img">';
							} else {
								$imageDisplay = '<img src="' . $uri . 'assets/images/default_image.jpg?v="' . date('his') . '" alt=" " class="responsive size-img default-img">';
							}
						} else {
							$imageDisplay = '<img src="' . $uri . 'assets/images/default_image.jpg?v="' . date('his') . '" alt=" " class="responsive size-img default-img">';
						}
						// <a href="'.$uri.'privilege/event?r=Line&pvId='.$enPrivid.'&pId='.$enPid.'&tId='.$enTid.'">
						// $code	= $this->MainModel->Base64Encrypt($mp_code);
						$personIdEncrypt	= $this->MainModel->Base64Encrypt($personId);
						$ti_idEncrypt	= $this->MainModel->Base64Encrypt($dataPerson->ti_id);
						$privilegeEncrypt	= $this->MainModel->Base64Encrypt($rowHighlight->mps_id);
						$privilegeHtml = '<div class="item">
												<div class="promo-img">
													<a href="'.$uri.'privilege/event?r=Line&pvId='.$privilegeEncrypt.'&pId='.$personIdEncrypt.'&tId='.$ti_idEncrypt.'">
														' . $imageDisplay . '	
													</a>
												</div>
												<div class="container promo-detail">
													<p>' . $rowHighlight->mps_name . '</p>
													<p class="text-eng">' . date('d-m-Y', strtotime($rowHighlight->mps_start_action_used)) . ' - ' . date('d-m-Y', strtotime($rowHighlight->mps_end_action_used)) . '</p>
												</div>
											</div>';
		
						array_push($privilegeHtmlArray, $privilegeHtml);
					}
				}
			}
		}
		$data['privilege_slider'] = $privilegeHtmlArray;
		$data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header', $data_header);
		$this->load->view('home', $data);
		$this->load->view('template/footer', $data_header);
	}

	public function logout()
	{
		// $this->session->sess_destroy();
		echo base_url();
		exit;
		$this->session->unset_userdata('userfprid');
	}
}
