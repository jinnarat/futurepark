<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);
ini_set('memory_limit', '512M'); 

class Register extends DB_Controller {
	
    function __construct()
    {
		parent::__construct();
		
		
		$this->load->model('Main_function');
		$this->load->model('Select_data');	
		
	}

	public function index(){
		$data['uri'] = $this->Main_function->html_chars(base_url());
		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		
		$data_header['menu_type'] = '';
		$data_header['menu'] = '';


        $this->load->view('header',$data_header);
        $this->load->view('register_from',$data);  
		$this->load->view('footer');
	}

	function thankpage(){
		$data['uri'] = $this->Main_function->html_chars(base_url());
		$data_header['TITLE'] = TITLE;
		$data_header['META_KEYWORDS'] = META_KEYWORDS;
		$data_header['META_DESC'] = META_DESC;
		
		$data_header['menu_type'] = '';
		$data_header['menu'] = '';


        $this->load->view('header');
        $this->load->view('thank_from',$data);  
		$this->load->view('footer');
	}

	function update_data(){
		$uri = $this->Main_function->html_chars(base_url());

		$data['u_name']		= htmlspecialchars($this->input->post('inputname'),ENT_QUOTES);	
		$data['u_surname']	= htmlspecialchars($this->input->post('inputsurname'),ENT_QUOTES);			
		$data['u_tel']		= htmlspecialchars($this->input->post('inputtel'),ENT_QUOTES);
		$data['u_email']	= htmlspecialchars($this->input->post('inputemail'),ENT_QUOTES);
		$bill	= htmlspecialchars($this->input->post('inputreceipt'),ENT_QUOTES);
		$data['u_toc']	= 'Y';
		$data['u_consent']	= htmlspecialchars($this->input->post('value_consent'),ENT_QUOTES);
		$data['u_create_date'] = date("Y-m-d H:i:s");	

		$bill_num = str_replace("-","",$bill);
		$sql = $this->Select_data->select_data("u_id", "user_register")->result_array();
		$id = count($sql) + 1;

		$b = $this->Select_data->select_data("u_bill_num", "user_register","AND u_bill_num = '".$bill."' ")->result_array();
        if(count($b) > 0)
        {
			alert("มีข้อมูลในระบบแล้วค่ะ");
		}else{
			$data['u_bill_num'] = $bill;
		}

		$folder = 'f_'.date("Ymd");
		
		$data['path_file'] = $folder;
		$folderFile		= $folder.'/';
		$MKfolder   	= PATHFRONTUPLOAD.$folderFile; 
        $img_name       = '';
		
		if (!file_exists($MKfolder)) {
			mkdir($MKfolder, 0777, true);
		} 
		if(!empty($_FILES["inputImg"]['name'])){
			
			$file_original		= $_FILES["inputImg"]["name"];
            $file_content_type	= $_FILES["inputImg"]["type"];
			$ext 				= pathinfo($file_original, PATHINFO_EXTENSION);	
            $img_name 			= 'r-'.date("YmdHi")."-".$bill_num."-".$id.".".$ext;
			// echo '../'.PATHFRONTUPLOAD.$folderFile.$img_name; exit;
			$file_path 			= PATHFRONTUPLOAD.$folderFile.$img_name;	

			$fileinfo = @getimagesize($_FILES['inputImg']['tmp_name']);
			
			$width = $fileinfo[0];
			$height = $fileinfo[1];
			//$maxheight = 1024;
			$maxDim = 600;
			
			$file_name = $_FILES['inputImg']['tmp_name'];


			list($width, $height, $type, $attr) = getimagesize( $file_name );

			if($width > $height){
			
				if ( $width > $maxDim  ) {
					// echo 'width'; exit;
				
					$target_filename = $file_name;
					$ratio = $width/$height;

					$new_width = $maxDim;
						$new_height = $maxDim/$ratio;
				
					$src = imagecreatefromstring( file_get_contents( $file_name ) );
					$dst = imagecreatetruecolor( $new_width, $new_height );
					imagecopyresampled( $dst, $src, 0, 0, 0, 0, $new_width, $new_height, $width, $height );
					imagedestroy( $src );
					imagepng( $dst, $target_filename ); // adjust format as needed
					
					imagedestroy( $dst );
				}else{
					$target_filename = $file_name;
					$src = imagecreatefromstring( file_get_contents( $file_name ) );
						$dst = imagecreatetruecolor( $width, $height );
						imagecopyresampled( $dst, $src, 0, 0, 0, 0, $width, $height, $width, $height );
						imagedestroy( $src );
						imagepng( $dst, $target_filename ); // adjust format as needed
						imagedestroy( $dst );
				}
			}else {
				// echo 'height'; exit

				if($height > $maxDim){
					$target_filename = $file_name;
					$ratio = $width/$height;
			
					$new_width = $maxDim*$ratio;
					$new_height = $maxDim;
					
					$src = imagecreatefromstring( file_get_contents( $file_name ) );
					$dst = imagecreatetruecolor( $new_width, $new_height );
					imagecopyresampled( $dst, $src, 0, 0, 0, 0, $new_width, $new_height, $width, $height );
					imagedestroy( $src );
					imagepng( $dst, $target_filename ); // adjust format as needed
					imagedestroy( $dst );
				}else{
					$target_filename = $file_name;
					$src = imagecreatefromstring( file_get_contents( $file_name ) );
					$dst = imagecreatetruecolor( $width, $height );
					imagecopyresampled( $dst, $src, 0, 0, 0, 0, $width, $height, $width, $height );
					imagedestroy( $src );
					imagepng( $dst, $target_filename ); // adjust format as needed
					imagedestroy( $dst );
				}
			}

			if(move_uploaded_file($target_filename, $file_path)){
				$data['u_image'] = $img_name;
			}
		}
		
		
		if($data['u_name'] != ""){
			if($this->db->insert('user_register', $data)){
				// $max_id = $this->db->insert_id();
				echo "<script>location.href='".$uri."register/thankpage';</script>";
			}else{
				echo "fail";
			}
		}
	}

	function billRepeat($bill=null)
	{
		$bill = $this->input->post('bill');

		$rs= $this->Select_data->select_data("u_bill_num", "user_register","AND u_bill_num = '".$bill."'")->result_array();

		if(count($rs) > 0)
		{   
			$result = array(
				'status' => 500,
				'description' => 'Member is already used.'
			);

		}
		else
		{
			$result = array(
				'status' => 200,
				'description' => 'OK'
			);	
		}

		echo json_encode($result);
	}
}
?>