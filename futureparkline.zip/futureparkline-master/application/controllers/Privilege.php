<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);
class Privilege extends DB_Controller {

	protected $authDataPerson;
    function __construct(){
        parent::__construct();
        $this->load->model('Main_function');
        $this->load->model('Select_data');
		$this->load->model('Lists_model');
		$this->load->model('QRCodeModel');
		$this->load->model('PrivilegeModel');
		
		$this->load->model('PersonModel');
		$personID = $this->session->userdata('userfprid');
		if (!$personID) {
			redirect(URLFRONT_Login);
		}else {
			$resutlPerson = $this->PersonModel->getPersonData($personID);
			if ($resutlPerson) {
				$this->authDataPerson = $resutlPerson;
			}else {
				redirect(URLFRONT_Login);
			}
		}
    }
    public function index(){
        $uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		
		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
		);
		

		$getParam	= $this->input->get('c');
		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			$data['param'] = $param;
			$data['person_id'] = $check_session;
		}

		$personId = $data['person_id'];

		$data['list_promotion'] = '';
		$DATE_TIME = date("Y-m-d");
		$ti_id = $this->authDataPerson ? $this->authDataPerson->ti_id : null;

		// $sql = $this->Lists_model->SelectPrivilege($ti_id,null,$DATE_TIME)->result_array();
		$sql = $this->PrivilegeModel->SelectPrivilegeALL($ti_id)->result_array();
		// $sqlPrivilege = $this->Lists_model->SelectPrivilegeALL();
		// echo '<pre>';
		// print_r($sql); 
		// echo '</pre>';
		// echo '<br>'.count($sql);
		// exit;
		if(count($sql) > 0){
			foreach($sql as $a){
				$mprivId = htmlspecialchars_decode(trim($a['mps_id']));
				$mprivName = htmlspecialchars_decode(trim($a['mps_name']));
				$imgBanner = htmlspecialchars_decode(trim($a['mps_image']));
				$startDate = htmlspecialchars_decode(trim($a['mps_start_display']));
				$endDate = htmlspecialchars_decode(trim($a['mps_end_display']));

				if(!empty($imgBanner)){
					if (getimagesize(PATHIMGCAMPAIGN.$imgBanner)){
						$imageDisplay = '<img src="'.PATHIMGCAMPAIGN.$imgBanner.'?v="'.date('his').' alt=" " class="responsive size-img">';
					}else {
						$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="responsive size-img default-img">';
					}
				}else{
					$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="responsive size-img default-img">';
				}

				$enPrivid = $this->MainModel->Base64Encrypt($mprivId);
				$enPid = $this->MainModel->Base64Encrypt($personId);
				$enTid = $this->MainModel->Base64Encrypt($ti_id);

				// if($endDisplay >= $DATE_TIME){

					$data['list_promotion'] .= '<div class="borderBox">
													<div class="promo-img">
														<a href="'.$uri.'privilege/event?r=Line&pvId='.$enPrivid.'&pId='.$enPid.'&tId='.$enTid.'">
															'.$imageDisplay.'
														</a>
													</div>
													<div class="container promo-detail">
														<p><a href="'.$uri.'privilege/event?r=Line&pvId='.$enPrivid.'&pId='.$enPid.'&tId='.$enTid.'"><b>'.$mprivName.'</b></a></p>
														<p>'.date('d/m/Y', strtotime($startDate)).' - '.date('d/m/Y', strtotime($endDate)).'</p>
													</div>
												</div>';
					
				// }
					
			}
		}else{
			$data['list_promotion'] .= '<div class="container promo-detail text-center">
											<p><b>ไม่มีข้อมูล</b></p>
										</div>';
		}
        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view('privi_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function event(){
		$uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true,
			"myModal"	      => true
		);

		$enCodePrivId	= $this->input->get('pvId');
		$enCodePersonId	= $this->input->get('pId');
		$enCodeTierId	= $this->input->get('tId');

		$data['pvId'] = $enCodePrivId;
		$data['pId'] = $enCodePersonId;
		$data['tid'] = $enCodeTierId;
		
		$privId	= $this->MainModel->Base64Decrypt($enCodePrivId);
		$personId	= $this->MainModel->Base64Decrypt($enCodePersonId);
		$tierId	= $this->MainModel->Base64Decrypt($enCodeTierId);
		
		$showBtn = false;
		$dateTimeNow = date('Y-m-d H:i:s');
		$quantity = null;

		$this->load->library('PrivilegeLib');
		$resultCheck = $this->privilegelib->checkPrivilege($personId, $privId, 1, $tierId, $dateTimeNow, true, false);
		// $resultCheck = $this->checkPrivilege($personId, $privId, 1, $tierId, $dateTimeNow);

		if($resultCheck->status == 500){
			redirect('privilege', 'refresh');
		}else if($resultCheck->status == 200 || $resultCheck->status == 201){
			$showBtn = true;
			$quantity = isset($resultCheck->quantity)  ? $resultCheck->quantity : null;
		}else if($resultCheck->status == 202){
			if($resultCheck->privilegeData->mpt_type == 'Check-inCheck-out'){
				$showBtn = true;
			}else {
				$showBtn = false;
				// $resultCheck->message = '';
			}
			redirect('privilege/userEvent?r=Line&pvId='.$enCodePrivId.'&pId='.$enCodePersonId.'&date='.$dateTimeNow.'&tId='.$enCodeTierId.'&code='.$resultCheck->code, 'refresh');
		}else if($resultCheck->status == 204){
			// redirect('privilege/userEvent?r=Line&pvId='.$enCodePrivId.'&pId='.$enCodePersonId.'&date='.$dateTimeNow.'&tId='.$enCodeTierId.'&code='.$resultCheck->code, 'refresh');
			$showBtn = false;
			// $resultCheck->message = '';
		}else {
			$showBtn = false;
		}

		$data['showBtn'] = $showBtn;
		$data['messageBtn'] = $resultCheck->message;
		$data['type'] = $resultCheck->privilegeData->mpt_type;
		$data['privilegeData'] = $resultCheck->privilegeData;
		$data['privilegeImage'] = $resultCheck->privilegeData->mps_image;
		$data['privilegeName'] = $resultCheck->privilegeData->mps_name;
		$data['privilegeDetail'] = $resultCheck->privilegeData->mps_detail;
		$data['status'] = $resultCheck->status;
		$data['point'] = $resultCheck->point;
		$data['quantity'] = $quantity;

        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view('privi_detail',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	public function getPrivilegeList()
	{
		$privilegeSetting = $this->PrivilegeModel->getPrivilegeList();
		$dataPrivilege = array(
			'privilegeList' => $privilegeSetting,
			// 'base_url' => $this->Main_function->html_chars(base_url()),
	 	);
	 	echo json_encode($dataPrivilege);
	}

	function updateUse(){
        $ERR_STATUS = 400; 
        // $DATE_TIME = date("Y-m-d H:i:s");	 
		$dateTimeNow = date("Y-m-d H:i:s");
		$dateDay = date('Y-m-d', strtotime($dateTimeNow));
		$active = $this->config->item('status_active');
		$dataReuslt = new stdClass;
		try{
            $priviEnCode = $this->input->post('pvId');
			$personEnCode = $this->input->post('pId');
			$tierEnCode = $this->input->post('tierId');
			$quantity = $this->input->post('quantity');
			$pointRedeem = intval(trim($this->input->post('pointRedeem')));
			$type = trim($this->input->post('type'));

			if(isset($_POST["quantity"])){
				if(!is_numeric($quantity)){
					echo json_encode(array('status' => 'UnSuccessfully', 'messege' => 'จำนวนต้องเป็นตัวเลข'));
					exit;
				}else if($quantity < 0){
					echo json_encode(array('status' => 'UnSuccessfully', 'messege' => 'จำนวนต้องมากกว่า 0'));
					exit;
				}else if(strlen($quantity) > 11){
					echo json_encode(array('status' => 'UnSuccessfully', 'messege' => 'จำนวนต้องไม่เกิน 11 หลัก'));
					exit;
				}
			}else {
				$quantity = 0;
			}

			$privId	= $this->MainModel->Base64Decrypt($priviEnCode);
			$personId	= $this->MainModel->Base64Decrypt($personEnCode);
			$tierId	= $this->MainModel->Base64Decrypt($tierEnCode);

			if($personId == "")
			{
				$ERR_STATUS = 400; throw new exception('Err data personId is empty'); 
			}

			if($tierId == '' || $tierId == null){
				$tierId = '1';
			}

			$this->load->library('PrivilegeLib');
			$resultCheck = $this->privilegelib->checkPrivilege($personId, $privId, $quantity, $tierId, $dateTimeNow, true, false);
			
			// if (!isset($resultCheck->code)) {
			// 	echo json_encode(array('status' => 'UnSuccessfully', 'messege' => 'ไม่สามารถใช้สิทธิพิเศษในช่วงเวลานี้ได้'));
			// 	exit;
			// }
			// $resultCheck = $this->checkPrivilege($personId, $privId, $quantity, $tierId, $dateTimeNow);
			if($resultCheck->status == 500){
				echo json_encode(array('status' => 'UnSuccessfully', 'messege' => 'ไม่พบสิทธิพิเศษ'));
				exit;
			}

			$poinBalance = 0;
			$poinSpending = 0;
			$privilegeCodeID = null;
			$totalPeple = 0;
			$totalPointCut = 0;
			$status = false;
			$quantityFree = null;
			
			if($resultCheck->status == 200){
				// ตัดแต้ม
				// member_free_usage สมาชิก
				// follow_free_usage ผู้ติดตาม
				// -1 : ไม่ได้ set มา หรือ unlimit

				$member_free_usage = ($resultCheck->member_free_usage != 0 ? $resultCheck->member_free_usage : 0);
				$follow_free_usage = ($resultCheck->follow_free_usage != 0 ? $resultCheck->follow_free_usage : 0);

				$member_point_use = 0;
				$follow_point_use = 0;							
				$follower_use = 0;
				$point_use = 0;

				$point_redemp_person = 0;
				$point_redemp_follow = 0;

				$mp_used_type = NULL;

				$dataPerson  = $this->PrivilegeModel->getPersonByID($personId);
				if($dataPerson){
					// new limit privilege

					if ($quantity > 0) {
						$mp_used_type = 'member_follower';
						$member_point_use = ($member_free_usage > 0 ? 0 : 1);
						$follower_use = $quantity;
						$follow_point_use = ($follow_free_usage > 0 ? ($follow_free_usage > $follower_use ? 0 : $follower_use - $follow_free_usage) : $follower_use);
					}else {
						$mp_used_type = 'member_only';
						$member_point_use = ($member_free_usage > 0 ? 0 : 1);
					}

					$point_redemp_person = $member_point_use * $resultCheck->conditionData->mpc_point_redeem;
					$point_redemp_follow = $follow_point_use * $resultCheck->conditionData->mpc_point_redeem;

					$point_use = $member_point_use + $follow_point_use;
					$totalPointCut = $point_use * $resultCheck->conditionData->mpc_point_redeem;
					
					$poinBalance =  $dataPerson->person_point_balance - $totalPointCut;
					$poinSpending = $dataPerson->person_point_spending + $totalPointCut;
					
					if ($poinBalance < 0) {
						echo  json_encode(array('status' => false,'messege' => 'คุณไม่สามารถใช้สิทธิพิเศษได้เนื่องจากคะแนนของคุณไม่เพียงพอ'));
						log_message('error', 'คุณไม่สามารถใช้สิทธิพิเศษได้เนื่องจากคะแนนของคุณไม่เพียงพอ');
						exit;
					}
				}else {
					echo  json_encode(array('status' => false,'messege' => 'ไม่พบข้อมูลผู้ใช้'));
					log_message('error', 'ไม่พบข้อมูลผู้ใช้');
					exit;
				}

				// insert data 
				$mp_code = $this->generateCode();
				$qrcodeImage = $this->generateQRCodeImage($privId, $tierId, $personId, $mp_code, $resultCheck->privilegeData->mpt_value, $resultCheck->conditionData->mpc_id);

				// member_privilege_code
				$dataInsertPrivilegeCode = array(
					'mp_code' => $mp_code,
					'privilegeType' => $resultCheck->privilegeData->mpt_value,
					'mp_point_redeem' => $totalPointCut,
					'follow_free_usage' => $follow_free_usage,
					'mp_used_by_free' => $member_free_usage > 0 ? 'Y' : NULL,
					'mp_used_follower' => $quantity,
					'mp_used_type' => $mp_used_type,
					'mp_point_reddem_person' => $point_redemp_person,
					'mp_point_redeem_follower' => $point_redemp_follow,
					'mp_used_by' => $personId,
					'mp_used_datetime' => $dateTimeNow,
					'checkinTime' => $resultCheck->privilegeData->mpt_type == 'Check-inCheck-out' ? $dateTimeNow : null,
					'mp_used_quantity' => $follow_point_use + 1,
					'mp_code_expired' => $resultCheck->codeExpire,
					'mp_status' => $active,
					'mp_qr_image' => $qrcodeImage,
					'mpc_id' => $resultCheck->conditionData ? $resultCheck->conditionData->mpc_id : NULL,
					'mpt_id' => $resultCheck->privilegeData ? $resultCheck->privilegeData->mpt_id : NULL,
					'ti_id' => $tierId,
					'now' => $dateTimeNow,
				);
				$this->db->trans_begin();
				$privilegeCodeID = $this->PrivilegeModel->insertPrivilegeCode($dataInsertPrivilegeCode);
				if ($this->db->trans_status() === FALSE)
				{
					$this->db->trans_rollback();
					$dataReuslt->status = 500;
					$dataReuslt->message = 'ไม่สามารถเช็คอินได้';
					log_message('error', $this->db->_error_message());
				}
				else
				{
					// $this->db->trans_commit();
					$status = true;
					log_message('info', 'insert member_privilege_code success');
					
					$dataUpdatePerson = array(
						'personId' => $personId,
						'poinBalance' => $poinBalance,
						'poinSpending' => $poinSpending,
						'dateTimeNow' => $dateTimeNow,
					);
					// $this->db->trans_begin();
					$dataPerson  = $this->PrivilegeModel->updatePointPerson($dataUpdatePerson);
					if ($this->db->trans_status() === FALSE)
					{
						$this->db->trans_rollback();
						$dataReuslt->status = 500;
						$dataReuslt->message = 'ไม่สามารถอัพเดทข้อมูลได้';
						log_message('error', $this->db->_error_message());
						echo  json_encode(array('status' => false,'messege' => 'ไม่สามารถอัพเดทข้อมูลได้'));
						exit;
					}
					else
					{
						// $this->db->trans_commit();
						$status = true;
						log_message('info', 'update person success');
					}
				}
				// member_privilege_code
				// person_history
				$dataInsertPeronHis = array(
					'personId' => $personId,
					'ref_type_id' => 5,
					'ref_id' => $privilegeCodeID,
					'dateTimeNow' => $dateTimeNow,
					'pers_status' => 'Existing',
				);
				// $this->db->trans_begin();
				$personHistoryID = $this->PrivilegeModel->insertPersonHistory($dataInsertPeronHis);
				if ($this->db->trans_status() === FALSE)
				{
					$this->db->trans_rollback();
					$dataReuslt->status = 500;
					$dataReuslt->message = 'ไม่สามารถเช็คอินได้';
					log_message('error', $this->db->_error_message());
				}
				else
				{
					// $this->db->trans_commit();
					$status = true;
					log_message('info', 'insert person_history success');
				}
				// person_history
				// person_point
				if($totalPointCut > 0){
					$dataInsertPeronPoint = array(
						'personId' => $personId,
						'personHistoryID' => $personHistoryID,
						'tierId' => $tierId,
						'ref_type_id' => 5,
						'ref_id' => $privilegeCodeID,
						'perp_type' => 'Burn', //P= Earn,A= Burn
						'perp_point' => $totalPointCut,
						'perp_status' => 'A',
						'dateTimeNow' => $dateTimeNow,
					);
					// $this->db->trans_begin();
					$personPointID = $this->PrivilegeModel->insertPersonPoint($dataInsertPeronPoint);
					if ($this->db->trans_status() === FALSE)
					{
						$this->db->trans_rollback();
						$dataReuslt->status = 500;
						$dataReuslt->message = 'ไม่สามารถเช็คอินได้';
						log_message('error', $this->db->_error_message());
					}
					else
					{
						$this->db->trans_commit();
						$status = true;
						log_message('info', 'insert person_point success');
					}
				}else {
					$this->db->trans_commit();
					$status = true;
				}
				// person_point
				// response
				if($status == true){
					$code	= $this->MainModel->Base64Encrypt($mp_code);
					echo json_encode(array(
						'status' => 'Successfully',
						'type' => 'checkin',
						'message' => 'เช็คอินสำเร็จ',
						'PVID' => $priviEnCode,
						'PID' => $personEnCode,
						'DATE' => 'เช็คอินสำเร็จ',
						'TID' => $tierEnCode,
						'ITYPE' => 'เช็คอินสำเร็จ',
						'CODE' => $code,
					));
				}else {
					echo json_encode(array(
						'status' => 'UnSuccessfully',
						'type' => 'checkin',
						'message' => 'เช็คอินไม่สำเร็จ',
					));
				}
				// response
			} // end 200
			else if($resultCheck->status == 202){
				$checkStatus = false;
				if ($resultCheck->privilegeData->mpt_type == 'Check-inCheck-out') {
					$dataUpdatePrivilegeCode = array(
						'mp_code' => $resultCheck->code,
						'personId' => $personId,
						'dateTimeNow' => $dateTimeNow,
					);
					$this->db->trans_begin();
					$privilegeCodeID = $this->PrivilegeModel->updateCheckOut($dataUpdatePrivilegeCode);
					if ($this->db->trans_status() === FALSE)
					{
						$this->db->trans_rollback();
						$dataReuslt->status = 500;
						$dataReuslt->message = 'ไม่สามารถเช็คเอาท์ได้';
						log_message('error', 'can not insert member_privilege_code');
					}
					else
					{
						$this->db->trans_commit();
						$checkStatus = true;
					}

					$dataHistory = array(
						'pers_id' => $personId,
						'ref_type_id' =>  5,
						'ref_id' => $resultCheck->privilegeData->mps_id,
						'perh_status' => 'A',
						'perh_createdatetime' => $dateTimeNow,
						'pers_status' => 'Existing',
						'perh_createby' => $personId
					);
		
					$this->db->insert('person_history',$dataHistory);
	
					if ($this->db->trans_status() === FALSE)
					{
						$this->db->trans_rollback();
						$dataReuslt->status = 500;
						$dataReuslt->message = 'ไม่สามารถเช็คเอาท์ได้';
						log_message('error', 'can not insert person_history');
					} else {
						$checkStatus = true;
						$this->db->trans_commit();
					}
					if($checkStatus){
						echo json_encode(array(
							'status' => 'Successfully',
							'type' => 'checkout',
							'message' => 'เช็คเอาท์สำเร็จ',
						));
					}else {
						echo json_encode(array(
							'status' => 'UnSuccessfully',
							'type' => 'checkout',
							'message' => 'เช็คเอาท์ไม่สำเร็จ',
						));
					}
					
				}else if ($resultCheck->privilegeData->mpt_type == 'Burn_point') {
					// ใช้ที่ admin เท่านั้น
				}
			}
		}catch(exception $e){
            if($ERR_STATUS == 400)
            {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
			echo json_encode($Err);            
        }

	}

	function checkDuplicateCode($amount=100,$limitchar=6,$privId=null){
        $active   = $this->config->item('status_active');

        $dataPrivCode = array();
        $dataDBCode = array();
        if($privId !=null || $privId != ''){
            $dataPrivCode = $this->Lists_model->getDistinctCodeLists(null, $privId, null, $active)->result_array();
            foreach((array) $dataPrivCode as $ac){
                $dataDBCode[] = $ac['code'];
            }
		}
		
        $arr = array();
        $i = 0;
        while ($i < $amount)
        {
            // format = privId."-".GEN CODE 6 Char
			$new = $privId."-".$this->MainModel->generateRandomString($limitchar,'lower');
			// format = lower + int 6 digits
			// $new = $this->MainModel->generateRandomString($limitchar,'lower');
            if (!in_array($new, $arr)) 
            { 
                // check duplicate in db 
                if (!in_array($new, $dataDBCode)) 
                { 
                    $arr[] = $new;
                }
            }

            $countArr = count($arr);
            if($countArr < $i){
                $i=$countArr;
            }
            $i++;
        }
        return $arr;
    }
	
	function userEvent(){
		$uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '', 
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true,
			"myModal"	      => true,
        );


		$data['result'] = '';
		$data['time']	= '';
		$data['mprivName'] = '';
		$imgQr = '';
		$img_qrcode	= '';
		$actionCreateTime2	= null;
		$dateTimeNow = date("Y-m-d H:i:s");
		$dateDay = date('Y-m-d', strtotime($dateTimeNow));
		$active = $this->config->item('status_active');

		$isUseAction = false;
		$isUseMessage = '';
		$mp_code = '';
		$mpc_id = null;
		$mpt_id = null;
		$point_redeem = 0;
		$expiredDate = '';

		$priviEnCode = $this->input->get('pvId');
		$personEnCode = $this->input->get('pId');
		$tierEnCode = $this->input->get('tId');
		$quantity = $this->input->get('qty');
		$quantity = $quantity ? $quantity : 0;

		$privId	= $this->MainModel->Base64Decrypt($priviEnCode);
		$tierId	= $this->MainModel->Base64Decrypt($tierEnCode);
		$personId	= $this->MainModel->Base64Decrypt($personEnCode);
		// $date	= $this->MainModel->Base64Decrypt($this->input->get('date'));
		// $itype	= $this->MainModel->Base64Decrypt($this->input->get('itype'));
		// $code	= $this->MainModel->Base64Decrypt($this->input->get('code'));
		// $ref	= $this->input->get('r');

		// $data['linkBack'] = 'privilege/event?r=Line&pvId='.$priviEnCode.'&pId='.$personEnCode.'&tId='.$tierEnCode;
		$data['linkBack'] = 'privilege';

		$message = '';
		$showBtn = false;
		$dateTimeNow = date('Y-m-d H:i:s');
		$dataLimit = null;

		$this->load->library('PrivilegeLib');
		// $resultCheck = $this->checkPrivilege($personId, $privId, $quantity, $tierId, $dateTimeNow);
		$resultCheck = $this->privilegelib->checkPrivilege($personId, $privId, $quantity, $tierId, $dateTimeNow);
		if($resultCheck->status == 500){
			redirect('privilege/event?r=Line&pvId='.$priviEnCode.'&pId='.$personEnCode.'&tId='.$tierEnCode, 'refresh');
		}else if($resultCheck->status == 200){
			$showBtn = true;
		}else if($resultCheck->status == 202){
			if($resultCheck->privilegeData->mpt_type == 'Check-inCheck-out'){
				if(isset($resultCheck->btnStaff)){
					$showBtnStaff = true;
				}else {
					$showBtnStaff = false;
				}
				$showBtn = true;
			}else {
				if ($resultCheck->privilegeData->mpt_value == 'Redeemed Point') {
					if(isset($resultCheck->btnShop)){
						$showBtnShop = true;
					}else {
						$showBtnShop = false;
					}
					$showBtn = false;
				}else {
					$showBtn = false;
					$resultCheck->message = '';
				}
			}
			// redirect('privilege/event?r=Line&pvId='.$priviEnCode.'&pId='.$personEnCode.'&tId='.$tierEnCode, 'refresh');
		}else {
			$showBtn = false;
		}

		if(!isset($resultCheck->code)){
			$resultCheck->message = 'ไม่สามารถใช้สิทธิ์ในช่วงเวลานี้ได้';
		}
		
		$data['showBtnStaff'] = isset($showBtnStaff) ? $showBtnStaff : false;
		$data['showBtnShop'] = isset($showBtnShop) ? $showBtnShop : false;
		$data['showBtnStaffMessage'] = "ใช้สิทธิ์ (สำหรับเจ้าหน้าที่กด)";
		$data['showBtn'] = $showBtn;
		$data['message'] = $resultCheck->message;
		$data['privilegeData'] = $resultCheck->privilegeData;
		$data['quantity'] = isset($resultCheck->quantity) ? $resultCheck->quantity : null;
		$data['hideData'] = isset($resultCheck->hideData) ? $resultCheck->hideData : false;

		$data['isUseAction'] = $isUseAction;
		$data['isUseMessage'] = $isUseMessage;
		$data['qrcodeImage'] = isset($resultCheck->qrcodeImage) ? $resultCheck->qrcodeImage : '';
		$data['codeExpired'] = isset($resultCheck->mp_code_expired) ? $resultCheck->mp_code_expired : '';
		$data['detail'] = isset($resultCheck->detail) ? $resultCheck->detail : '';
		$data['code'] = isset($resultCheck->code) ? $resultCheck->code : '';
		$data['useTime'] = isset($resultCheck->mp_used_datetime) ? date('d-m-Y H:i', strtotime($resultCheck->mp_used_datetime)) : '';
		$data['status'] = $resultCheck->status;
		$data['pvId'] = $priviEnCode;
		$data['pId'] = $personEnCode;
		$data['tId'] = $tierEnCode;

		$data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view('rewardPriv_from',$data);  
		$this->load->view('template/footer',$data_header);
	}

	

	function updateCheck_out(){
		$ERR_STATUS = 400; 
        $DATE_TIME = date("Y-m-d H:i:s");	 
		try{
            
			$mpCode = trim($this->input->post('mpCode'));
			$personId = $this->session->userdata('userfprid');

			// $newtimeExpired = strtotime($DATE_TIME.'+ 5 minute');
            
			if($personId == "")
			{
				$ERR_STATUS = 400; throw new exception('Err data personId is empty'); 
			}
			
			$rowPrivilegeCode = $this->PrivilegeModel->getPrivilegeCodeByID($mpCode);
			if($rowPrivilegeCode){

				$this->db->trans_start();
				$data = array(	
					'mp_updateby' => $personId,
					'mp_updatedatetime' => $DATE_TIME,
					'mp_used_check_out_datetime' => $DATE_TIME,
				);
				$this->db->where('mp_id', $mpCode);
				$this->db->update('member_privilege_code', $data);
	
				if(!$this->db->affected_rows()){
					$this->db->trans_rollback();
					$this->db->trans_complete();
					echo  json_encode(array('STATUS' => 'Successfully', 'message' => 'ข้อมูลไม่ถูกต้องกรุณาเข้าเมนูประวัติใหม่อีกครั้ง'));	
					$ERR_STATUS = 400; throw new exception('err update table member_privilege_code (check-out)bdata into database');
				}
	
				$dataHistory = array(
					'pers_id' => $personId,
					'ref_type_id' =>  5,
					'ref_id' => $rowPrivilegeCode->mp_id,
					'perh_status' => 'A',
					'perh_createdatetime' => $DATE_TIME,
					'pers_status' => 'Existing',
					'perh_createby' => $personId
				);
	
				$this->db->insert('person_history',$dataHistory);

				if(!$this->db->affected_rows()){
					$this->db->trans_rollback();
					$this->db->trans_complete();
					echo  json_encode(array('STATUS' => 'Successfully', 'message' => 'ข้อมูลไม่ถูกต้องกรุณาเข้าเมนูประวัติใหม่อีกครั้ง'));	
					$ERR_STATUS = 400; throw new exception('err insert table person_history (check-out)bdata into database');
				} else {
					$this->db->trans_commit();
					echo  json_encode(array('STATUS' => 'Successfully', 'message' => 'คุณได้เช็คเอาท์แล้ว'));	
				}
			}

			
		}catch(exception $e){
            if($ERR_STATUS == 400)
            {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
			echo json_encode($Err);            
        }
	}

	public function updateStaff()
	{
		// form_validation
		$dateTimeNow = date('Y-m-d H:i:s');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('code', 'code', 'required|trim');
		$this->form_validation->set_rules('staffCode', 'รหัสเจ้าหน้าที่', 'required|trim|max_length[20]');

		$this->form_validation->set_message('required', 'กรุณาระบุ %s');
		$this->form_validation->set_message('trim', 'กรุณาระบุ %s');
		$this->form_validation->set_message('max_length', '{field} ต้องไม่เกิน {param} หลัก.');

		if ($this->form_validation->run() == FALSE) {
			echo json_encode(array(
				'status' => 'UnSuccessfully',
				'type' => 'staff',
				'message' => $this->form_validation->error_string(),
			));
		} else {
			$personId = $this->session->userdata('userfprid');
			
			$code = $this->input->post('code');
			$staffCode = $this->input->post('staffCode');
			$remark = $this->input->post('remark');

			
			$rowData = $this->PrivilegeModel->checkCodePrivilege($code, $personId);
			if($rowData){
				if($dateTimeNow > $rowData->mp_code_expired){
					echo json_encode(array(
						'status' => 'UnSuccessfully',
						'type' => 'staff',
						'message' => 'รหัสนี้หมดอายุแล้ว',
					));
					exit;
				}else {
					
					$dataUpdate = array(
						'mp_id' => $rowData->mp_id,
						'personId' => $personId,
						'code' => $code,
						'staffCode' => $staffCode,
						'remark' => $remark,
						'dateTimeNow' => $dateTimeNow,
					);
					$this->db->trans_begin();
					$resultUpdate = $this->PrivilegeModel->updateStaffPrivilegeCode($dataUpdate);
					if ($this->db->trans_status() === FALSE)
					{
						$this->db->trans_rollback();
						echo json_encode(array(
							'status' => 'UnSuccessfully',
							'type' => 'staff',
							'message' => $this->db->_error_message(),
						));
					}
					else
					{
						$this->db->trans_commit();
						echo json_encode(array(
							'status' => 'Successfully',
							'type' => 'staff',
							'message' => 'ใช้สิทธิสำเร็จ',
						));
					}
				}
				
				
			}else {
				echo json_encode(array(
					'status' => 'UnSuccessfully',
					'type' => 'staff',
					'message' => 'ไม่พบข้อมูล',
				));
			}
			
		}
	}
	
	public function updateShopCode()
	{
		// form_validation
		$dateTimeNow = date('Y-m-d H:i:s');
		$this->load->library('form_validation');
		$this->form_validation->set_rules('code', 'รหัส', 'required|trim');
		$this->form_validation->set_rules('shopCode', 'รหัสร้านค้า', 'required|trim|max_length[20]');
		$this->form_validation->set_rules('balance', 'จำนวนเงิน', 'numeric|max_length[10]');
		$this->form_validation->set_rules('voucher', 'รหัส Voucher', 'max_length[20]');

		$this->form_validation->set_message('required', 'กรุณาระบุ %s');
		$this->form_validation->set_message('trim', 'กรุณาระบุ %s');
		$this->form_validation->set_message('numeric', '%s ต้องเป็นตัวเลข');
		$this->form_validation->set_message('max_length', '{field} ต้องไม่เกิน {param} หลัก.');

		if ($this->form_validation->run() == FALSE) {
			echo json_encode(array(
				'status' => 'UnSuccessfully',
				'type' => 'staff',
				'message' => $this->form_validation->error_string(),
			));
		} else {
			$personId = $this->session->userdata('userfprid');
			$code = $this->input->post('code');
			$shopCode = $this->input->post('shopCode');
			$balance = (int) $this->input->post('balance');
			$voucher = $this->input->post('voucher');

			if ($balance != null || $balance != '') {
				if ($balance <= 0) {
					echo json_encode(array(
						'status' => 'UnSuccessfully',
						'type' => 'staff',
						'message' => 'จำนวนเงินต้องมากกว่า 0',
					));
					exit;
				}
			}
				
			$rowMasterShop = $this->PrivilegeModel->getMaster_shop($shopCode);
			if(!$rowMasterShop){
				echo json_encode(array(
					'status' => 'UnSuccessfully',
					'type' => 'staff',
					'message' => 'รหัสร้านค้า ไม่ถูกต้อง',
				));
				exit;
			}

			$rowData = $this->PrivilegeModel->checkCodePrivilege($code, $personId);
			if($rowData){
				if($dateTimeNow > $rowData->mp_code_expired){
					echo json_encode(array(
						'status' => 'UnSuccessfully',
						'type' => 'staff',
						'message' => 'รหัสนี้หมดอายุแล้ว',
					));
					exit;
				}else {
					$dataUpdate = array(
						'mp_id' => $rowData->mp_id,
						'personId' => $personId,
						'code' => $code,
						'shopCode' => $shopCode,
						'balance' => $balance,
						'voucher' => $voucher,
						'dateTimeNow' => $dateTimeNow,
					);
					$this->db->trans_begin();
					$resultUpdate = $this->PrivilegeModel->updateShopPrivilegeCode($dataUpdate);
					if ($this->db->trans_status() === FALSE)
					{
						$this->db->trans_rollback();
						echo json_encode(array(
							'status' => 'UnSuccessfully',
							'type' => 'staff',
							'message' => $this->db->_error_message(),
						));
					}
					else
					{
						$this->db->trans_commit();
						echo json_encode(array(
							'status' => 'Successfully',
							'type' => 'staff',
							'message' => 'ใช้สิทธิสำเร็จ',
						));
					}
				}
				
				
			}else {
				echo json_encode(array(
					'status' => 'UnSuccessfully',
					'type' => 'staff',
					'message' => 'ไม่พบข้อมูล',
				));
			}
			
		}
	}

	// new privilege 
	private function generateCode($length = 6)
	{
		$dateStart = date('Y-m-d H:i:s');
		$dateEnd = date('Y-m-d H:i:s', strtotime($dateStart. ' + 10 minutes'));
		do {
			if($dateStart > $dateEnd){
				$length++;
				$code = $this->MainModel->generateRandomString($length,'lower');
				$rowCheckCode = $this->PrivilegeModel->checkDuplicateCode($code);
				$dateStart = date('Y-m-d H:i:s');
				$dateEnd = date('Y-m-d H:i:s', strtotime($dateStart. ' + 10 minutes'));
			}else {
				$code = $this->MainModel->generateRandomString($length,'lower');
				$rowCheckCode = $this->PrivilegeModel->checkDuplicateCode($code);
			}
		} while ($rowCheckCode);
		return $code;
	}
	
	private function generateQRCodeImage($mps_id = null, $ti_id = null, $personId = null, $mp_code = null, $type = null, $mpc_id = null)
	{
		$enCode_mps_id  = $this->MainModel->Base64Encrypt($mps_id);
		$enCode_ti_id  = $this->MainModel->Base64Encrypt($ti_id);
		$enCode_mp_code  = $this->MainModel->Base64Encrypt($mp_code);
		$enCode_personId  = $this->MainModel->Base64Encrypt($personId);
		$enCode_mpc_id  = $this->MainModel->Base64Encrypt($mpc_id);
		$enType    = $this->MainModel->Base64Encrypt('Privilege'); // fix word

		$textGenQr    = $enCode_mps_id.';'.$enCode_ti_id.';'.$enCode_mp_code.';'.$enCode_personId.';'.$enType.';'.$enCode_mpc_id;
		$encryptParam   = $this->MainModel->Base64Encrypt($textGenQr);
		if ($type == 'Redeemed Point' || $type == 'Exclusive Parking') {
			$urlGenCode   = PATHIMGCAMPAIGN.'store?c='.$encryptParam;
		}else {
			$urlGenCode   = $mp_code;
		}

		$privilegeCode = "P-".$mps_id;
		$filename_qr   = date('ymdhi-').$personId."_".$mp_code;
		$pathFilename_qr = "uploads/privilege/qrcode/".$privilegeCode."/".$filename_qr."-Qrcode.png";

		$qrcodeImage  = $this->QRCodeModel->qrcodeGeneratorPriv($urlGenCode,$privilegeCode,$filename_qr);	
		// $imgCodeQr = $qrcodeImage;
		$imgCodeQr = $pathFilename_qr;
		return $imgCodeQr;
	}

	private function _privilege_limit($person_id, $privilege_condition_id, $privilege_user_quantity, $datetime_now)
	{
		$data = new stdClass;

		try
		{
			$limit_check_temp = true;
			$limit_check = NULL;

			$limit_customer_maximum_participate = -1;
			$limit_customer_maximum_participate_time = -1;
			$limit_customer_maximum_free_participate = -1;
			$limit_customer_maximum_free_participate_time = -1;
			$limit_privilege_maximum_participate_time = -1;

			$limit_exceed_field = '';
			$limit_exceed_value = 0;
			$limit_exceed_used = 0;

			$privilege_limit = $this->PrivilegeModel->_get_privilege_limit(
				array(
					'type' => 'Privilege Limit',
					'privilege_condition_id' => $privilege_condition_id,
					'condition_status' => 'A'
				)
			);

			if($privilege_limit->num_rows() > 0)
			{
				foreach($privilege_limit->result_array() as $limit)
				{
					$transaction_start_datetime = NULL;
					$transaction_end_datetime = NULL;

					if($limit['limit_period'] == 'Day')
					{
						$transaction_start_datetime = date('Y-m-d', strtotime($datetime_now)) . ' 00:00:00';
						$transaction_start_datetime = date('Y-m-d', strtotime($datetime_now)) . ' 23:59:59';
					}
					else if($limit['limit_period'] == 'Month')
					{
						$transaction_start_datetime = date('Y-m-d', strtotime('first day of this month', strtotime($datetime_now))) . ' 00:00:00';
						$transaction_start_datetime = date('Y-m-d', strtotime('last day of this month', strtotime($datetime_now))) . ' 23:59:59';
					}
					else if($limit['limit_period'] == 'Period')
					{
						$_p =  $this->PrivilegeModel->_get_privilege_limit(
							array(
								'type' => 'Privilege Limit',
								'privilege_id' => $privilege_condition_id,
								'privilege_condition_id' => 'A'
							)
						)->row_array();

						$transaction_start_datetime = $_p['privilege_start_datetime'];
						$transaction_start_datetime = $_p['privilege_end_datetime'];
					}

					if($limit['limit_level'] == 'Customer')
					{
						if($limit['limit_type'] == 'Maximum')
						{
							if($limit['limit_variable'] == 'Participate')
							{
								if($limit['limit_period'] == 'Time')
								{
									$limit_customer_maximum_participate = intval($limit['limit_value']) - $privilege_user_quantity;
								}
								else
								{
									$total_participate = $this->PrivilegeModel->_get_privilege_limit_participate(
										array(
											'type' => 'Participate',
											'person_id' => ($person_id != '') ? $person_id : NULL,
											'privilege_condition_id' => ($privilege_condition_id != '') ? $privilege_condition_id : NULL,
											'transaction_start_datetime' => $transaction_start_datetime,
											'transaction_end_datetime' => $transaction_end_datetime,
											'condition_status' => 'A'
										)
									)->row_array();
	
									$limit_customer_maximum_participate = intval($limit['limit_value']) - intval($total_participate['total_participate']) - $privilege_user_quantity;
								}

								if($limit_customer_maximum_participate == 0)
								{
									$limit_exceed_field = 'customer_maximum_participate';
									$limit_exceed_value = intval($limit['limit_value']);
									$limit_exceed_used = intval($total_participate['total_participate']);

									$limit_check_temp = false;

									break;
								}
							}
							else if($limit['limit_variable'] == 'Participate Time')
							{
								if($limit['limit_period'] == 'Time')
								{
									$limit_customer_maximum_participate_time = intval($limit['limit_value']) - 0;
								}
								else
								{
									$total_participate_time = $this->PrivilegeModel->_get_privilege_limit_participate_time(
										array(
											'type' => 'Participate Time',
											'person_id' => ($person_id != '') ? $person_id : NULL,
											'privilege_condition_id' => ($privilege_condition_id != '') ? $privilege_condition_id : NULL,
											'transaction_start_datetime' => $transaction_start_datetime,
											'transaction_end_datetime' => $transaction_end_datetime,
											'condition_status' => 'A'
										)
									)->row_array();
	
									$limit_customer_maximum_participate_time = intval($limit['limit_value']) - intval($total_participate_time['total_participate_time']);
								}

								if($limit_customer_maximum_participate_time == 0)
								{
									$limit_exceed_field = 'customer_maximum_participate_time';
									$limit_exceed_value = intval($limit['limit_value']);
									$limit_exceed_used = intval($total_participate_time['total_participate_time']);

									$limit_check_temp = false;

									break;
								}
							}
							else if($limit['limit_variable'] == 'Free Participate')
							{
								if($limit['limit_period'] == 'Time')
								{
									$limit_customer_maximum_free_participate = intval($limit['limit_value']);
								}
								else
								{
									$total_free_participate = $this->PrivilegeModel->_get_privilege_limit_free_participate(
										array(
											'type' => 'Free Participate',
											'person_id' => ($person_id != '') ? $person_id : NULL,
											'privilege_condition_id' => ($privilege_condition_id != '') ? $privilege_condition_id : NULL,
											'transaction_start_datetime' => $transaction_start_datetime,
											'transaction_end_datetime' => $transaction_end_datetime,
											'condition_status' => 'A'
										)
									)->row_array();
	
									$limit_customer_maximum_free_participate = intval($limit['limit_value']) - intval($total_free_participate['total_free_participate']);
								}

								$limit_check_temp = true;
							}
							else if($limit['limit_variable'] == 'Free Participate Time')
							{
								if($limit['limit_period'] == 'Time')
								{
									$limit_customer_maximum_free_participate_time = intval($limit['limit_value']);
								}
								else
								{
									$total_free_participate_time = $this->PrivilegeModel->_get_privilege_limit_free_participate(
										array(
											'type' => 'Free Participate Time',
											'person_id' => ($person_id != '') ? $person_id : NULL,
											'privilege_condition_id' => ($privilege_condition_id != '') ? $privilege_condition_id : NULL,
											'transaction_start_datetime' => $transaction_start_datetime,
											'transaction_end_datetime' => $transaction_end_datetime,
											'condition_status' => 'A'
										)
									)->row_array();
	
									$limit_customer_maximum_free_participate_time = intval($limit['limit_value']) - intval($total_free_participate_time['total_free_participate_time']);
								}

								$limit_check_temp = true;
							}
						}
					}
					else if($limit['limit_level'] == 'Privilege')
					{
						if($limit['limit_type'] == 'Maximum')
						{
							if($limit['limit_variable'] == 'Participate Time')
							{
								if($limit['limit_period'] == 'Time')
								{
									$limit_privilege_maximum_participate_time = intval($limit['limit_value']);
								}
								else
								{
									$total_participate_time = $this->PrivilegeModel->_get_privilege_limit_participate_time(
										array(
											'type' => 'Participate Time',
											'person_id' => NULL,
											'privilege_condition_id' => ($privilege_condition_id != '') ? $privilege_condition_id : NULL,
											'transaction_start_datetime' => $transaction_start_datetime,
											'transaction_end_datetime' => $transaction_end_datetime,
											'condition_status' => 'A'
										)
									)->row_array();

									$limit_privilege_maximum_participate_time = intval($limit['limit_value']) - intval($total_participate_time['total_participate_time']);
								}

								if($limit_privilege_maximum_participate_time == 0)
								{
									$limit_exceed_field = 'privilege_maximum_participate_time';
									$limit_exceed_value = intval($limit['limit_value']);
									$limit_exceed_used = intval($total_participate_time['total_participate_time']);

									$limit_check_temp = false;

									break;
								}
							}
						}
					}

					if($limit_check == NULL)
					{
						$limit_check = $limit_check_temp;
					}
					else
					{
						$limit_check = ($limit_check && $limit_check_temp);
					}
				}

				if($limit_check == NULL)
				{
					$limit_check = $limit_check_temp;
				}
				else
				{
					$limit_check = ($limit_check && $limit_check_temp);
				}
			}
			else
			{
				$limit_check = true;
			}

			if($limit_check)
			{
				$data->status = 200;
				$data->limit = array(
					'customer_maximum_free_participate' => $limit_customer_maximum_free_participate,
					'customer_maximum_free_participate_time' => $limit_customer_maximum_free_participate_time
				);
			}
			else
			{
				$data->status = 500;
				$data->limit_exceed = array(
					'field' => $limit_exceed_field,
					'value' => $limit_exceed_value,
					'used' => $limit_exceed_used
				);
			}
		}
		catch(Exception $ex)
		{
			$data->status = 500;
			$data->message = $ex->getMessage();
		}

		return $data;
	}
	// new privilege 
}
