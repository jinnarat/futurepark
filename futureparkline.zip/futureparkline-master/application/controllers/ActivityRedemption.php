<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);

ini_set('max_execution_time', 0);
set_time_limit(1800);
ini_set('memory_limit','-1'); 
ini_set('sqlsrv.ClientBufferMaxKBSize','524288'); // Setting to 512M
ini_set('pdo_sqlsrv.client_buffer_max_kb_size','524288'); // Setting to 512M - for pdo_sqlsrv
defined('BASEPATH') OR exit('No direct script access allowed');

class ActivityRedemption extends DB_Controller {

    function __construct(){
        parent::__construct();
        $this->load->model('Main_function');
        $this->load->model('Select_data');
        $this->load->model('Lists_model');
        $this->load->model('RedemptionModel');
    }

    public function index(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true,
			"myModal"	      => true
        );

		$getParam	= $this->input->get('c');
		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$personId = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($personId);
			$data['param'] = $param;
			$data['person_id'] = $personId;
		}
		$DATE_TIME = date("Y-m-d H:i:s");

		$resultActivity = $this->RedemptionModel->getActivityRedemptionBurnPoint();
		foreach ($resultActivity as $rowData) {
			$imgBanner = htmlspecialchars_decode(trim($rowData->imgBanner));
			$activityId = htmlspecialchars_decode(trim($rowData->activityId));
			$activityName = htmlspecialchars_decode(trim($rowData->activityName));
			$startDate = htmlspecialchars_decode(trim($rowData->startDate));
			$endDate = htmlspecialchars_decode(trim($rowData->endDate));
			if(!empty($imgBanner)){
				if (getimagesize(PATHIMGCAMPAIGN.$imgBanner)){
					$imageDisplay = '<img src="'.PATHIMGCAMPAIGN.$imgBanner.'?v="'.date('his').' alt=" " class="responsive size-img">';
				}else {
					$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="responsive size-img default-img">';
				}
			}else{
				$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="responsive size-img default-img">';
			}

			$data['list_camp'] .= '<div class="borderBox">
										<div class="promo-img">
											<a href="'.$uri.'campaign/activity/'.$activityId.'">
												'.$imageDisplay.'
											</a>
										</div>
										<div class="container promo-detail">
											<p><b>'.$activityName.'</b></p>
											<p>'.$startDate.' - '.$endDate.'</p>
										</div>
									</div>';
		}
		exit;
		
        $this->load->view('template/header',$data_header);
        $this->load->view('camp_from',$data);  
		$this->load->view('template/footer',$data_header);
		
		
	}

	function event($campId = null){
		$uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

		$getParam	= $this->input->get('c');
		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			$data['param'] = $param;
			$data['person_id'] = $check_session;
		}

		$data['list_camp'] = '';
		$data['detail_camp'] = '';
		$data['campName']	= '';
		$DATE_TIME = date("Y-m-d H:i:s");
		

		$act = $this->Lists_model->SelectAct($campId)->result_array();
		if(count($act) > 0){
			foreach($act as $a){
				$campId = htmlspecialchars_decode(trim($a['campId']));
				$activityId = htmlspecialchars_decode(trim($a['activityId']));
				$activityCode = htmlspecialchars_decode(trim($a['activityCode']));
				$activityType = htmlspecialchars_decode(trim($a['activityType']));
				$activityName = htmlspecialchars_decode(trim($a['activityName']));
				$urlfriendly = htmlspecialchars_decode(trim($a['urlfriendly']));
				$imgBanner = htmlspecialchars_decode(trim($a['imgBanner']));
				$detail = htmlspecialchars_decode(trim($a['detail']));
				$limit = htmlspecialchars_decode(trim($a['limit']));
				$is_only_member = htmlspecialchars_decode(trim($a['is_only_member']));
				$startDate = htmlspecialchars_decode(trim($a['startDate']));
				$endDate = htmlspecialchars_decode(trim($a['endDate']));
				$endDisplay = htmlspecialchars_decode(trim($a['endDisplay']));



				if($endDisplay >= $DATE_TIME){
					if(!empty($imgBanner)){
						$data['list_camp'] .= '<div class="promo-img">
												<a href="'.$uri.'campaign/activity/'.$activityId.'">
													<img src="'.PATHIMGCAMPAIGN.$imgBanner.'?v="'.date('his').' alt=" " class="responsive size-img">
												</a>
											</div>
											<div class="container promo-detail">
												<p>'.$activityName.'</p>
												<p>'.$detail.'</p>
												<p>'.$startDate.' - '.$endDate.'</p>
											</div>';
					}else{
						$data['list_camp'] .= '<div class="promo-img">
												<a href="'.$uri.'campaign/activity/'.$activityId.'">
													<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="responsive size-img default-img">
												</a>
											</div>
											<div class="container promo-detail">
												<p>'.$activityName.'</p>
												<p>'.$detail.'</p>
												<p>'.$startDate.' - '.$endDate.'</p>
											</div>';
					}
				}
			}

		}else{
			$rs = $this->Lists_model->SelectCamp()->result_array();
			if(count($rs) > 0){
				foreach($rs as $r){
					$campId = htmlspecialchars_decode(trim($r['campId']));
					$campCode = htmlspecialchars_decode(trim($r['campCode']));
					$campName = htmlspecialchars_decode(trim($r['campName']));
					$detail = htmlspecialchars_decode(trim($r['detail']));
					$is_highlight = htmlspecialchars_decode(trim($r['is_highlight']));
					$imgBanner = htmlspecialchars_decode(trim($r['imgBanner']));
					$startDate = htmlspecialchars_decode(trim($r['startDate']));
					$endDate = htmlspecialchars_decode(trim($r['endDate']));

				

					if(!empty($imgBanner)){
						$data['detail_camp'] = '<div class="borderBox">
														<div class="promo-img">
														<img src="'.PATHIMGCAMPAIGN.$imgBanner.'?v='.date('his').'" alt=" " class="responsive size-img">
													</div>';
					}else{
						$data['detail_camp'] = '<div class="borderBox">
													<div class="promo-img">
														<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="responsive size-img default-img">
													</div>';
					}

					$data['detail_camp'] .= '	<div class="container top30">
													<p>'.$detail.'</p>
												</div>
											</div>';
											

					$data['campName'] = $campName;

				}
			}
		}

        
        $this->load->view('template/header',$data_header);
        $this->load->view('camp_detail',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function activity($actId = null){
		$uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true,
			"myModal"	      => true
        );

		$getParam	= $this->input->get('c');
		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			$data['param'] = $param;
			$data['person_id'] = $check_session;
		}

		$personId = $data['person_id'];

		$data['list_camp'] = '';
		$data['detail_camp'] = '';
		$data['campName']	= '';
		$btn_name = '';
		$mapLink	= '';

		$act = $this->Lists_model->SelectAct(null,$actId)->result_array();
		if(count($act) > 0){
			foreach($act as $a){
				$campId = htmlspecialchars_decode(trim($a['campId']));
				$activityId = htmlspecialchars_decode(trim($a['activityId']));
				$activityCode = htmlspecialchars_decode(trim($a['activityCode']));
				$activityType = htmlspecialchars_decode(trim($a['activityType']));
				$activityName = htmlspecialchars_decode(trim($a['activityName']));
				$urlfriendly = htmlspecialchars_decode(trim($a['urlfriendly']));
				$imgBanner = htmlspecialchars_decode(trim($a['imgBanner']));
				$detail = htmlspecialchars_decode(trim($a['detail']));
				$limit = htmlspecialchars_decode(trim($a['limit']));
				$is_only_member = htmlspecialchars_decode(trim($a['is_only_member']));
				$startDate = htmlspecialchars_decode(trim($a['startDate']));
				$btn_name = htmlspecialchars_decode(trim($a['btn_name']));

				$actU = $this->Lists_model->SelectActPath(null,$actId)->result_array();
				if(count($actU) > 0){
					foreach($actU as $u){
						$slCode = htmlspecialchars_decode(trim($u['slCode']));
						$activityType = htmlspecialchars_decode(trim($u['activityType']));
						$urlfriendly = htmlspecialchars_decode(trim($u['urlfriendly']));
						$mapLink = htmlspecialchars_decode(trim($u['mapLink']));
					}
				}

				$enAid = $this->MainModel->Base64Encrypt($activityId);
				$enPid = $this->MainModel->Base64Encrypt($personId);
				

				if(!empty($imgBanner)){
					$imageDisplay = '<img src="'.PATHIMGCAMPAIGN.$imgBanner.'?v='.date('his').'" alt=" " class="responsive size-img">';
				}else{
					$imageDisplay = '<img src="'.$uri.'assets/images/default_image.jpg?v="'.date('his').'" alt=" " class="responsive size-img default-img">';
				}

				if($activityType == 'Information' || $activityType == 'Redemption'){
					$link = '';
				}else{
					$link = '<div class="btn-joinCamp">
								<a href="'.PATHIMGCAMPAIGN.$mapLink.'/'.$urlfriendly.'?r=Line&aId='.$enAid.'&pId='.$enPid.'" class="btn btn-submit col-10" target="_blank">'.$btn_name.'</a>
							</div>';
				}

				$data['detail_camp'] .= '<div class="promo-img">'.$imageDisplay.'</div>
										<div class="container top30">
											<p>'.$detail.'</p>
											'.$link.'
										</div>';

				$data['campName'] = $activityName;

				
			}

		}

        
        $this->load->view('template/header',$data_header);
        $this->load->view('camp_detail',$data);  
		$this->load->view('template/footer',$data_header);
		
	}
}
