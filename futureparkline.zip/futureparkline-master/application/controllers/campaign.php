<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);

ini_set('max_execution_time', 0);
set_time_limit(1800);
ini_set('memory_limit', '-1');
ini_set('sqlsrv.ClientBufferMaxKBSize', '524288'); // Setting to 512M
ini_set('pdo_sqlsrv.client_buffer_max_kb_size', '524288'); // Setting to 512M - for pdo_sqlsrv
defined('BASEPATH') or exit('No direct script access allowed');

class Campaign extends DB_Controller
{
	protected $authDataPerson;

	function __construct()
	{
		parent::__construct();
		$this->load->model('Main_function');
		$this->load->model('Select_data');
		$this->load->model('Lists_model');
		$this->load->model('RedemptionModel');
		
		$this->load->model('PersonModel');
		$personID = $this->session->userdata('userfprid');
		if (!$personID) {
			redirect(URLFRONT_Login);
		}else {
			$resutlPerson = $this->PersonModel->getPersonData($personID);
			if ($resutlPerson) {
				$this->authDataPerson = $resutlPerson;
			}else {
				redirect(URLFRONT_Login);
			}
		}
	}
	public function index()
	{
		$uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,
			"META_DESC"       => META_DESC,
			"stylesheet"      => '',
			"javascript"      => '',
			"fb_title"        => OG_TITLE,
			"fb_image"        => OG_IMAGE,
			"fb_description"  => OG_DESC,
			"isHeader"        => true,
			"myModal"	      => true
		);

		$getParam	= $this->input->get('c');
		if (isset($getParam)) {
			$person_id	= $this->MainModel->Base64Decrypt($getParam);
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		} else {
			$personId = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($personId);

			$data['param'] = $param;
			$data['person_id'] = $personId;
		}

		$data['list_camp'] = '';
		$DATE_TIME = date("Y-m-d H:i:s");

		$act = $this->Lists_model->SelectAct(null, null, $DATE_TIME)->result_array();
		// print_r($act); 
		// echo '<br>'.count($act);
		// exit;
		if (count($act) > 0) {
			foreach ($act as $a) {
				$activityId = htmlspecialchars_decode(trim($a['activityId']));
				$is_only_member = trim($a['is_only_member']);
				$usedTargetCDP = trim($a['usedTargetCDP']);
				$regis_new_system = trim($a['regis_new_system']);
				$insertData = trim($a['insertData']);
				$subDetail = trim($a['subDetail']);
				$isShowAct = false;
				if ($a['campStatus'] != 'A' || $a['subcampStatus'] != 'A') {
					continue;
				}

				$regis_new_system = strtolower($regis_new_system);

				if ($usedTargetCDP == 'Y' || ($regis_new_system != '' && $regis_new_system != NULL)) {
					if ($insertData == 'Y') {
						$isShowAct = false;
					} else {
						$checkCdpTarget = $this->Lists_model->getActivityTargetPersonal($activityId, $personId);
						if ($checkCdpTarget) {
							$isShowAct = true;
						} else {
							$isShowAct = false;
						}
					}
				} else {
					if ($is_only_member == 'Y') {
						$actMember = $this->Lists_model->getActivityMember($a['activityId']);
						if ($actMember) {
							$personData = $this->Lists_model->getPerson($data['person_id']);
							foreach ($actMember as  $rowActMem) {
								if ($personData->ti_id == $rowActMem->tier_id) {
									$isShowAct = true;
								}
							}
						} else {
							$isShowAct = false;
						}
					} else {
						$isShowAct = true;
					}
				}

				if (!$isShowAct) {
					continue;
				}
				$campId = htmlspecialchars_decode(trim($a['campId']));
				$activityCode = htmlspecialchars_decode(trim($a['activityCode']));
				$activityType = htmlspecialchars_decode(trim($a['activityType']));
				$activityName = htmlspecialchars_decode(trim($a['activityName']));
				$urlfriendly = htmlspecialchars_decode(trim($a['urlfriendly']));
				$imgBanner = htmlspecialchars_decode(trim($a['imgBanner']));
				$detail = htmlspecialchars_decode(trim($a['detail']));
				$limit = htmlspecialchars_decode(trim($a['limit']));
				$startDate = htmlspecialchars_decode(trim($a['startDate']));
				$endDate = htmlspecialchars_decode(trim($a['endDate']));
				$endDisplay = htmlspecialchars_decode(trim($a['endDisplay']));

				if (!empty($imgBanner)) {
					if (getimagesize(PATHIMGCAMPAIGN . $imgBanner)) {
						$imageDisplay = '<img src="' . PATHIMGCAMPAIGN . $imgBanner . '?v="' . date('his') . ' alt=" " class="responsive size-img">';
					} else {
						$imageDisplay = '<img src="' . $uri . 'assets/images/default_image.jpg?v="' . date('his') . '" alt=" " class="responsive size-img default-img">';
					}
				} else {
					$imageDisplay = '<img src="' . $uri . 'assets/images/default_image.jpg?v="' . date('his') . '" alt=" " class="responsive size-img default-img">';
				}

				if ($endDisplay >= $DATE_TIME) {

					$data['list_camp'] .= '<div class="borderBox">
												<div class="promo-img">
													<a href="' . $uri . 'campaign/activity/' . $activityId . '">
														' . $imageDisplay . '
													</a>
												</div>
												<div class="container promo-detail">
													<p><b>' . $activityName . '</b></p>
													<p>' . date('d-m-Y',strtotime($startDate)) . ' - ' . date('d-m-Y',strtotime($endDate)) . '</p>
												</div>
											</div>';
				}
			}
		} else {
			$data['list_camp'] .= '<div class="container promo-detail text-center">
										<p><b>ไม่มีข้อมูล</b></p>
									</div>';
		}

		if ($data['list_camp'] == '') {
			$data['list_camp'] .= '<div class="container promo-detail text-center">
										<p><b>ไม่มีข้อมูล</b></p>
									</div>';
		}

		$resultActivity = $this->RedemptionModel->getActivityRedemptionBurnPoint();
		foreach ($resultActivity as $rowData) {
			$imgBanner = htmlspecialchars_decode(trim($rowData->imgBanner));
			$activityId = htmlspecialchars_decode(trim($rowData->activityId));
			$activityName = htmlspecialchars_decode(trim($rowData->activityName));
			$startDate = htmlspecialchars_decode(trim($rowData->startDisplay));
			$endDate = htmlspecialchars_decode(trim($rowData->endDisplay));
			$endDate = htmlspecialchars_decode(trim($rowData->endDisplay));
			$subDetail = htmlspecialchars_decode(trim($rowData->subDetail));
			if (!empty($imgBanner)) {
				if (getimagesize(PATHIMGCAMPAIGN . $imgBanner)) {
					$imageDisplay = '<img src="' . PATHIMGCAMPAIGN . $imgBanner . '?v="' . date('his') . ' alt=" " class="responsive size-img">';
				} else {
					$imageDisplay = '<img src="' . $uri . 'assets/images/default_image.jpg?v="' . date('his') . '" alt=" " class="responsive size-img default-img">';
				}
			} else {
				$imageDisplay = '<img src="' . $uri . 'assets/images/default_image.jpg?v="' . date('his') . '" alt=" " class="responsive size-img default-img">';
			}

			$data['list_camp'] .= '<div class="borderBox">
										<div class="promo-img">
											<a href="' . $uri . 'campaign/activity/' . $activityId . '">
												' . $imageDisplay . '
											</a>
										</div>
										<div class="container promo-detail">
											<p><b>' . $activityName . '</b></p>
											<p>' . date('d-m-Y',strtotime($startDate)) . ' - ' . date('d-m-Y',strtotime($endDate)) . '</p>
										</div>
									</div>';
		}

		$data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header', $data_header);
		$this->load->view('camp_from', $data);
		$this->load->view('template/footer', $data_header);
	}

	function event($campId = null)
	{
		$uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,
			"META_DESC"       => META_DESC,
			"stylesheet"      => '',
			"javascript"      => '',
			"fb_title"        => OG_TITLE,
			"fb_image"        => OG_IMAGE,
			"fb_description"  => OG_DESC,
			"isHeader"        => true
		);

		$getParam	= $this->input->get('c');
		if (isset($getParam)) {
			$person_id	= $this->MainModel->Base64Decrypt($getParam);
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		} else {
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			$data['param'] = $param;
			$data['person_id'] = $check_session;
		}

		$data['list_camp'] = '';
		$data['detail_camp'] = '';
		$data['campName']	= '';
		$DATE_TIME = date("Y-m-d H:i:s");


		$act = $this->Lists_model->SelectAct($campId)->result_array();
		if (count($act) > 0) {
			foreach ($act as $a) {
				$campId = htmlspecialchars_decode(trim($a['campId']));
				$activityId = htmlspecialchars_decode(trim($a['activityId']));
				$activityCode = htmlspecialchars_decode(trim($a['activityCode']));
				$activityType = htmlspecialchars_decode(trim($a['activityType']));
				$activityName = htmlspecialchars_decode(trim($a['activityName']));
				$urlfriendly = htmlspecialchars_decode(trim($a['urlfriendly']));
				$imgBanner = htmlspecialchars_decode(trim($a['imgBanner']));
				$detail = htmlspecialchars_decode(trim($a['detail']));
				$limit = htmlspecialchars_decode(trim($a['limit']));
				$is_only_member = htmlspecialchars_decode(trim($a['is_only_member']));
				$startDate = htmlspecialchars_decode(trim($a['startDate']));
				$endDate = htmlspecialchars_decode(trim($a['endDate']));
				$endDisplay = htmlspecialchars_decode(trim($a['endDisplay']));



				if ($endDisplay >= $DATE_TIME) {
					if (!empty($imgBanner)) {
						$data['list_camp'] .= '<div class="promo-img">
												<a href="' . $uri . 'campaign/activity/' . $activityId . '">
													<img src="' . PATHIMGCAMPAIGN . $imgBanner . '?v="' . date('his') . ' alt=" " class="responsive size-img">
												</a>
											</div>
											<div class="container promo-detail">
												<p>' . $activityName . '</p>
												<p>' . $detail . '</p>
												<p>' . $startDate . ' - ' . $endDate . '</p>
											</div>';
					} else {
						$data['list_camp'] .= '<div class="promo-img">
												<a href="' . $uri . 'campaign/activity/' . $activityId . '">
													<img src="' . $uri . 'assets/images/default_image.jpg?v="' . date('his') . '" alt=" " class="responsive size-img default-img">
												</a>
											</div>
											<div class="container promo-detail">
												<p>' . $activityName . '</p>
												<p>' . $detail . '</p>
												<p>' . $startDate . ' - ' . $endDate . '</p>
											</div>';
					}
				}
			}
		} else {
			$rs = $this->Lists_model->SelectCamp()->result_array();
			if (count($rs) > 0) {
				foreach ($rs as $r) {
					$campId = htmlspecialchars_decode(trim($r['campId']));
					$campCode = htmlspecialchars_decode(trim($r['campCode']));
					$campName = htmlspecialchars_decode(trim($r['campName']));
					$detail = htmlspecialchars_decode(trim($r['detail']));
					$is_highlight = htmlspecialchars_decode(trim($r['is_highlight']));
					$imgBanner = htmlspecialchars_decode(trim($r['imgBanner']));
					$startDate = htmlspecialchars_decode(trim($r['startDate']));
					$endDate = htmlspecialchars_decode(trim($r['endDate']));



					if (!empty($imgBanner)) {
						$data['detail_camp'] = '<div class="borderBox">
														<div class="promo-img">
														<img src="' . PATHIMGCAMPAIGN . $imgBanner . '?v=' . date('his') . '" alt=" " class="responsive size-img">
													</div>';
					} else {
						$data['detail_camp'] = '<div class="borderBox">
													<div class="promo-img">
														<img src="' . $uri . 'assets/images/default_image.jpg?v="' . date('his') . '" alt=" " class="responsive size-img default-img">
													</div>';
					}

					$data['detail_camp'] .= '	<div class="container top30">
													<p>' . $detail . '</p>
												</div>
											</div>';


					$data['campName'] = $campName;
				}
			}
		}


		$data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header', $data_header);
		$this->load->view('camp_detail', $data);
		$this->load->view('template/footer', $data_header);
	}

	function activity($actId = null)
	{
		$uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;

		$datetime_now = date("Y-m-d H:i:s");

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,
			"META_DESC"       => META_DESC,
			"stylesheet"      => '',
			"javascript"      => '',
			"fb_title"        => OG_TITLE,
			"fb_image"        => OG_IMAGE,
			"fb_description"  => OG_DESC,
			"isHeader"        => true,
			"myModal"	      => true
		);

		$getParam	= $this->input->get('c');
		if (isset($getParam)) {
			$person_id	= $this->MainModel->Base64Decrypt($getParam);
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		} else {
			$person_id = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($person_id);

			$data['param'] = $param;
			$data['person_id'] = $person_id;
		}

		$mapLink	= '';
		$showBtn	= false;

		$act = null;
		$actRedempBurnPoint = $this->RedemptionModel->getActivityRedemptionBurnPointByActitivityID($actId);
		if ($actRedempBurnPoint) {
			$act = $actRedempBurnPoint;
			// cehck limit redemption point
			$rowData = $this->RedemptionModel->getItemRedemption($actRedempBurnPoint->mec_id);
			if ($rowData) {
				$rowConditionPointOnly = $this->RedemptionModel->getConditionItemRedemption($actRedempBurnPoint->mec_id);
				if ($rowConditionPointOnly) {
					$this->load->library('RedemptionLib', 'redemptionlib');
					$resultCheck = $this->redemptionlib->_redeem_point_limit($person_id, $actRedempBurnPoint->mec_id, $rowData->item_id, $rowData->item_quantity, $datetime_now);
					if ($resultCheck) {
						if ($resultCheck->status == 200) {
							$showBtn = true;
						}
					}
				}
			}
		} else {
			$act = $this->Lists_model->SelectAct(null, $actId)->row();
		}

		if ($act) {
			$activityId = htmlspecialchars_decode(trim($act->activityId));
			$activityType = htmlspecialchars_decode(trim($act->activityType));
			$data['activityType'] = htmlspecialchars_decode(trim($act->activityType));
			$data['activityName'] = htmlspecialchars_decode(trim($act->activityName));
			$urlfriendly = htmlspecialchars_decode(trim($act->urlfriendly));
			$data['urlfriendly'] = htmlspecialchars_decode(trim($act->urlfriendly));
			$data['imgBanner'] = htmlspecialchars_decode(trim($act->imgBanner));
			$data['detail'] = htmlspecialchars_decode(trim($act->detail));
			$data['btn_name'] = htmlspecialchars_decode(trim($act->btn_name));

			$actU = $this->Lists_model->SelectActPath(null, $actId)->row();
			if ($actU) {
				$mapLink = htmlspecialchars_decode(trim($actU->mapLink));
			}

			$enAid = $this->MainModel->Base64Encrypt($activityId);
			$data['enAid'] = $enAid;
			$enPid = $this->MainModel->Base64Encrypt($person_id);

			if ($activityType == 'Information' || $activityType == 'Redemption') {
				$data['mapLink'] = '';
			} else {
				if ($mapLink) {
					$showBtn = true;
					$data['mapLink'] = PATHIMGCAMPAIGN . $mapLink . '/' . $urlfriendly . '?r=Line&aId=' . $enAid . '&pId=' . $enPid;
				}
			}
		}

		$data['showBtn'] = $showBtn;

		$data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header', $data_header);
		$this->load->view('camp_detail', $data);
		$this->load->view('template/footer', $data_header);
	}

	public function useRedemptionPoint()
	{
		// form_validation
		$this->load->library('form_validation');
		$this->form_validation->set_rules('acid', 'กิจกรรม', 'required|trim');
		// $this->form_validation->set_rules('idcard', 'เลขบัตรประชาชน (ID Card No.)', 'numeric|max_length[13]');
		// $this->form_validation->set_rules('passport', 'เลขหนังสือเดือนทาง (Passport No.)', 'max_length[13]');

		$this->form_validation->set_message('required', 'ไม่พบ %s');
		$this->form_validation->set_message('trim', 'ไม่พบ %s');
		// $this->form_validation->set_message('max_length', '{field} ต้องไม่เกิน {param} หลัก.');

		if ($this->form_validation->run() == FALSE) {
			echo json_encode(array('error' => $this->form_validation->error_string()));
		} else {
			$useAction = false;
			$dataPerson = $this->authDataPerson;
			$person_id = $dataPerson->personId;
			$datetime_now = date("Y-m-d H:i:s");
			$acid = $this->input->post('acid');
			if (!$acid) {
				echo json_encode(array('success' => false, 'message' => 'ไม่พบกิจกรรม'));
				exit;
			}

			// $dataPerson
			$activityId = $this->MainModel->Base64Decrypt($acid);
			$rowDataActivity = $this->RedemptionModel->getActivityRedemptionBurnPointByActitivityID($activityId);
			if ($rowDataActivity) {
				$rowConditionPointOnly = $this->RedemptionModel->getConditionItemRedemption($rowDataActivity->mec_id);
				if (!$rowConditionPointOnly) {
					echo json_encode(array('success' => false, 'message' => 'ไม่พบกิจกรรม'));
					log_message('error', "$acid ไม่พบกิจกรรม");
					exit;
				}

				$this->load->library('RedemptionLib', 'redemptionlib');
				$resultCheck = $this->redemptionlib->_redeem_point_limit($person_id, $rowConditionPointOnly->mec_id, $rowConditionPointOnly->item_id, $rowConditionPointOnly->item_quantity, $datetime_now);
				if ($resultCheck) {
					if ($resultCheck->status == 200) {
						$useAction = true;
					}
				}

				if ($useAction) {

					$textCode = $this->generateCode();
					$qrcode = $this->genereate_qr_code($textCode, CDPMKT_PHYSICAL_PATH, 'uploads/redeem_point/qrcode/P-' . $rowDataActivity->mec_id . '/', date('YmdHis') . '_' . $person_id . '.png');
					
					// check point person
					// $point_bonus = 0;
					// $point_accumulate = 0;
					// $point_spending = 0;
					// $point_balance = 0;

					$point_balance =  $dataPerson->person_point_balance - $rowConditionPointOnly->mcnd_redeem_point;
					$point_spending = $dataPerson->person_point_spending + $rowConditionPointOnly->mcnd_redeem_point;
					if ($point_balance < 0) {
						echo  json_encode(array('status' => false,'message' => 'คุณไม่สามารถใช้สิทธิพิเศษได้เนื่องจากคะแนนของคุณไม่เพียงพอ'));
						exit;
					}

					$expireCode = date('Y-m-d').' 23:59:59';
					$dataInsertUpdatePerson = array(
						'ti_id' => $dataPerson->ti_id,
						'person_id' => $person_id,
						'mec_id' => $rowDataActivity->mec_id,
						'item_id' => $rowConditionPointOnly->item_id,
						'mitm_id' => $rowConditionPointOnly->mitm_id,
						'mcnd_id' => $rowConditionPointOnly->mcnd_id,
						'redeem_point' => (int) $rowConditionPointOnly->mcnd_redeem_point,
						'item_quantity' => $rowConditionPointOnly->item_quantity,
						'textCode' => $textCode,
						'qrcode' => $qrcode,
						'expireCode' => $expireCode,
						'datetime_now' => $datetime_now,
						'status' => $this->config->item('status_active'),
						// 'point_bonus' => $point_bonus,
						// 'point_accumulate' => $point_accumulate,
						'point_spending' => $point_spending,
						'point_balance' => $point_balance,
					);
					$this->db->trans_begin();
					$insertRedempPointID = $this->RedemptionModel->insertRedemptionPoint($dataInsertUpdatePerson);
					// insert data 
					$updatePerson = $this->PersonModel->updatePointPerson($dataInsertUpdatePerson);
					// update cut point person

					$dataInsertPeronHis = array(
						'personId' => $person_id,
						'ref_type_id' => 10,
						'ref_id' => $insertRedempPointID,
						'dateTimeNow' => $datetime_now,
						'pers_status' => 'Existing',
					);
					$personHistoryID = $this->PersonModel->insertPersonHistory($dataInsertPeronHis);
					
					$dataInsertPeronPoint = array(
						'personId' => $person_id,
						'personHistoryID' => $personHistoryID,
						'tierId' => $dataPerson->ti_id,
						'ref_type_id' => 10,
						'ref_id' => $insertRedempPointID,
						'perp_type' => 'Burn', //P= Earn,A= Burn
						'perp_point' => (int) $rowConditionPointOnly->mcnd_redeem_point,
						'perp_status' => 'A',
						'dateTimeNow' => $datetime_now,
					);
					$personPointID = $this->PersonModel->insertPersonPoint($dataInsertPeronPoint);
					
					if ($this->db->trans_status() === FALSE)
					{
						$this->db->trans_rollback();
						echo json_encode(array(
							'status' => 'UnSuccessfully',
							'message' => $this->db->_error_message(),
						));
						log_message('error', $this->db->_error_message());
					}
					else
					{
						$this->db->trans_commit();
						echo json_encode(array(
							'status' => 'Successfully',
							'message' => 'ใช้สิทธิสำเร็จ',
							'refID' => $this->MainModel->Base64Encrypt($insertRedempPointID),
						));
					}
				}else {
					echo json_encode(array('success' => false, 'message' => 'คุณใช้สิทธิครบกำหนดแล้ว'));
					exit;
				}
			}else{
				echo json_encode(array('success' => false, 'message' => 'ไม่พบกิจกรรม'));
				exit;
			}
		}
	}

	public function detailCode()
	{
		$ref = $this->input->get('ref');
		if (!$ref) {
			echo json_encode(array('success' => false, 'message' => 'ไม่พบกิจกรรม'));
			exit;
		}
		$datetime_now = date('Y-m-d H:i:s');
		$pntt_id = $this->MainModel->Base64Decrypt($ref);
		$dataPerson = $this->authDataPerson;
		$person_id = $dataPerson->personId;
		$rowData = $this->RedemptionModel->getPointTransactionByID($pntt_id, $person_id);
		if ($rowData) {
			if ($rowData->pntt_admin_redeem_datetime != null || $rowData->pntt_admin_redeem_by != null) {
				$data['status'] = false;
				$data['message'] = 'คุณได้ใช้สิทธิไปแล้ว';
			} else if ($rowData->pntt_code_expire <= $datetime_now) {
				$data['status'] = false;
				$data['message'] = 'รหัสหมดอายุแล้ว';
			}else {
				$rowDataActivity = $this->RedemptionModel->getActivityByMachanicID($rowData->mec_id);
				$data['status'] = true;
				$data['imgBanner'] = $rowDataActivity->imgBanner;
				$data['activityName'] = $rowDataActivity->activityName;
				$data['qrcodeImage'] = $rowData->pntt_qr_image;
				$data['code'] = $rowData->pntt_code;
				$data['codeExpired'] = $rowData->pntt_code_expire;
				$data['useTime'] = $rowData->pntt_redeem_datetime;
			}
		}else {
			$data['status'] = false;
			$data['message'] = 'ข้อมูลไม่ถูกต้อง';
		}
		
		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,
			"META_DESC"       => META_DESC,
			"stylesheet"      => '',
			"javascript"      => '',
			"fb_title"        => OG_TITLE,
			"fb_image"        => OG_IMAGE,
			"fb_description"  => OG_DESC,
			"isHeader"        => true,
			"myModal"	      => true
		);

		$data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header', $data_header);
		$this->load->view('redempPointCode', $data);
		$this->load->view('template/footer', $data_header);
		
	}

	private function generateCode($length = 6)
	{
		$dateStart = date('Y-m-d H:i:s');
		$dateEnd = date('Y-m-d H:i:s', strtotime($dateStart. ' + 10 minutes'));
		do {
			if($dateStart > $dateEnd){
				$length++;
				$code = $this->MainModel->generateRandomString($length,'lower');
				$rowCheckCode = $this->RedemptionModel->checkDuplicateCode($code);
				$dateStart = date('Y-m-d H:i:s');
				$dateEnd = date('Y-m-d H:i:s', strtotime($dateStart. ' + 10 minutes'));
			}else {
				$code = $this->MainModel->generateRandomString($length,'lower');
				$rowCheckCode = $this->RedemptionModel->checkDuplicateCode($code);
			}
		} while ($rowCheckCode);
		return $code;
	}

	private function genereate_qr_code($text, $physical_path, $save_path, $file_name)
	{
		$this->load->library('phpqrcode/qrlib');
		if(is_dir($physical_path . $save_path) === false)
		{
			mkdir($physical_path . $save_path, 0777, true);
		}

		QRcode::png($text, $physical_path . $save_path . $file_name, $margin = 2);

		return $save_path . $file_name;
	}

}
