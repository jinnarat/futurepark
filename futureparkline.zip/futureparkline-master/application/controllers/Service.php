<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);
class Service extends DB_Controller {

	protected $authDataPerson;
    function __construct(){
        parent::__construct();
        $this->load->model('Main_function');
        $this->load->model('Select_data');
		$this->load->model('Lists_model');
		$this->load->model('ServiceModel');
		$this->load->library('oauth2'); 

		$this->load->model('PersonModel');
		$personID = $this->session->userdata('userfprid');
		if (!$personID) {
			redirect(URLFRONT_Login);
		}else {
			$resutlPerson = $this->PersonModel->getPersonData($personID);
			if ($resutlPerson) {
				$this->authDataPerson = $resutlPerson;
			}else {
				redirect(URLFRONT_Login);
			}
		}
    }
    public function index(){
        $uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		
		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true,
			"myModal"	      => true,
		);

		$sl_point = '';
		$memberNo = '';
		$idCardNo = '';
		$passportNo	= '';
		$mobileNo = '';
		$email = '';
		$firstname = '';
		$lastname = '';
		
		$getParam	= $this->input->get('c');
		if(isset($getParam))
		{	
			$person_id	= $this->MainModel->Base64Decrypt($getParam);		
			$data['person_id'] = $person_id;
			$data['param'] = $getParam;
		}else{
			$check_session = $this->session->userdata('userfprid');
			$param = $this->MainModel->Base64Encrypt($check_session);

			$data['param'] = $param;
			$data['person_id'] = $check_session;
		}

		$personId = $data['person_id'];

		// FIND member data

		// $personId=null,$mobileNo=null,$idCardNo=null,$email=null,$status=null,$ORDERBY=null,$unique=null 

		$sql = $this->PersonModel->getPerson($personId,null,null,null,'A',null,'Y')->result_array();
		if(count($sql) > 0){
			foreach($sql as $p){
				$memberNo = htmlspecialchars_decode(trim($p['memberNo']));
				$passportNo = htmlspecialchars_decode(trim($p['passportNo']));
				$idCardNo = htmlspecialchars_decode(trim($p['idCardNo']));
				$mobileNo = htmlspecialchars_decode(trim($p['mobileNo']));
				$email = htmlspecialchars_decode(trim($p['email']));
				$firstname = htmlspecialchars_decode(trim($p['firstname']));
				$lastname = htmlspecialchars_decode(trim($p['lastname']));
			}
		}

		// FIND pick up poin
		$sql_sl = $this->Lists_model->SelectMasterPickupPoint()->result_array();
		$sl_point = '<option value="" >...เลือก...</option>';
        foreach((array) $sql_sl as $s)
        {
            $selectDO = "";
			// if ($badge_status == $s['slValue']) { $selectDO = "selected"; }
			$sl_point .= '<option value="'.$s['puVale'].'" '.$selectDO.'> '.$s['puDisplay'].'</option>';
		}

		$data['sl_pickuppoint'] = $sl_point;

		if(empty($idCardNo)){
			$data['idCardNo'] = $passportNo;
		}else{
			$data['idCardNo'] = $idCardNo;
		}	
		$data['mobileNo'] = $mobileNo;
		$data['firstname'] = $firstname;
		$data['lastname'] = $lastname;
		$data['email'] = $email;

		$data['serviceContents'] = $this->ServiceModel->getServiceContents();
        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view('service_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function updateCase(){
        $ERR_STATUS = 400; 
		$DATE_TIME = date("Y-m-d H:i:s");	 
		$DATE_CRM = date("d/m/Y H:i:s");	
		try{
            $pId        = trim($this->input->post('pId'));
            $firstname 	= trim($this->input->post('f_name'));
            $lastname 	= trim($this->input->post('l_name'));
            $phone 		= trim($this->input->post('phone'));
            $caseType 	= trim($this->input->post('caseType'));
            $idcard 	= trim($this->input->post('idCard'));
            $amount 	= trim($this->input->post('amount'));
            $building 	= trim($this->input->post('pickup'));
			$inputDetail = trim($this->input->post('inputDetail'));
			$email = trim($this->input->post('email'));
			
			$channelId = 9;
			$source = 'LINE';

			if($pId == "")
			{
				$ERR_STATUS = 400; throw new exception('Err data personId is empty'); 
			}
			
			// "ChannelId": "'.$channelId.'",
			// "Source": "'.$source.'",
			
			$dataCRM = '{
				"FirstName": "'.$firstname.'",
				"LastName": "'.$lastname.'",
				"MemberID": "'.$pId.'",
				"CaseType2": "'.$caseType.'",
				"Opened": "'.$DATE_CRM.'",
				"Quantity": "'.$amount.'",
				"Building": "'.$building.'",
				"Mobile": "'.$phone.'",
				';

				if(!empty($inputDetail)){
					$dataCRM .= '"Remark": "'.$inputDetail.'",';
				}
	
				if(!empty($idcard)){
					$dataCRM .= '"IDCard": "'.$idcard.'",';
				}
	
				if(!empty($email)){
					$dataCRM .= '"Email": "'.$email.'"';
				}

			$dataCRM .= '}';
			
			// status	"2000 = successful
			// 		9999 = Error"

            $sendCase = $this->oauth2->sendService($dataCRM);
			$decodecheck = json_decode($sendCase);
			
			$caserefid    	= $decodecheck->Data->CaseRefID;
			$caseno    		= $decodecheck->Data->CaseNo;
			$personCRMID    = $decodecheck->Data->PersonCRMID;
			$status    		= $decodecheck->ResultMessage->Status;
			$Description    = $decodecheck->ResultMessage->Description;

            if($status == 2000){
                
                $dataUpdate = array(	
					'peronId' => $pId,
					'firstName' => $firstname,				
					'lastName' =>  $lastname,
					'idCard' => $idcard,
					'channelId' => $channelId,
					'source' => $source,
					'caseType'=> $caseType,
					'quantity' => $amount,
					'remark' => $inputDetail,
					'building' => $building,
					'email' => $email,
					'mobile' => $phone,
					'createby' => $pId,
					'createtime' => $DATE_TIME,
					'lastupdateby' => $pId,
					'lastupdatetime' => $DATE_TIME,

					'serv_caserefid' => $caserefid,
					'serv_caseno' => $caseno,
					'serv_personCRMID' => $personCRMID,
					'serv_status' => $status
				);

				// print_r($dataUpdate); exit;

	
				$this->db->insert('service_request',$dataUpdate);
	
				if(!$this->db->affected_rows()){
					$this->db->trans_rollback();
					$this->db->trans_complete();
					$ERR_STATUS = 400; throw new exception('err update table service_request data into database');
				} else {
					$this->db->trans_commit();
				}

				$serv_id	= $this->db->insert_id();	

				//11	Service Request

				$dataHistory = array(	
					'pers_id' => $pId,				
					'ref_type_id' =>  11,
					'ref_id' => $serv_id,
					'perh_createby' => $pId,
					'perh_createdatetime' => $DATE_TIME,
					'perh_status' => 'A',
					'pers_status' => 'Existing'
				);
	
				$this->db->insert('person_history',$dataHistory);
	
				if(!$this->db->affected_rows()){
					$this->db->trans_rollback();
					$this->db->trans_complete();
					$ERR_STATUS = 400; throw new exception('err update table person_history data into database');
				} else {
					$this->db->trans_commit();
				}

	
				// $dataRes['detail']	= array('message' => $message);
				$dataRes['status'] 	= array('STATUS' => 'successfully');

            }else if($status == 9999){
				$error    = $Description;
                $dataRes['status'] 	= array('STATUS' => 'Unsuccessfully', 'error' => $error);
			}else{
				$error    = $Description;
				$dataRes['status'] 	= array('STATUS' => 'Unsuccessfully', 'error' => $error);
			}
			
			echo  json_encode($dataRes);	
			
		}catch(exception $e){
            if($ERR_STATUS == 400)
            {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
			echo json_encode($Err);            
        }

    }
}
