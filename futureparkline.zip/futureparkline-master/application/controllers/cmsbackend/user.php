<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class User extends DB_Controller {

    function __construct()
    {
        parent::__construct();
		$this->load->model('Select_data');
		$this->load->model('Lists_model');
		// $chk_userlogin = $this->session->userdata('ufostatname');
        // if(!$chk_userlogin){
		// 	redirect(URL_Login);
        // }
    }

    function index(){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;

		$header['menu'] = '';
		$header['menu_sub'] = '';
		
		$data['uri'] = $this->Main_function->html_chars(base_url());
		$data['data_content'] = '';
		
		$this->load->view('cmsbackend/header', $header);
        $this->load->view('cmsbackend/mainpage', $data);  
		$this->load->view('cmsbackend/footer');
    }
    
	function user_list(){
		$id = $this->session->userdata('ufostatid');
		$roles = $this->session->userdata('ufostatauthorsize');
		
		$header['menu'] = 'user';
		$header['menu_sub'] = '';
		
		$data['uri'] = $this->Main_function->html_chars(base_url());
		$data['tablelist'] = "";
		// $no = 1;
		// if($roles == "Admin"){
		// 	$rs = $this->Select_data->select_data("*", "user", " AND status = 'A'")->result_array();
		// 	foreach($rs as $r)
		// 	{	
		// 		if($r['status'] == "A"){
		// 			$status = "Active";
		// 		}else{				
		// 			$status = "Inactive";
		// 		}
				
		// 		$uid = htmlspecialchars_decode(trim($r['id']));
		// 		$utype = htmlspecialchars_decode(trim($r['user_type']));
		// 		$update_date = htmlspecialchars_decode(trim($r['update_date']));
		// 		$lastupdate = explode(" ", $update_date);

		// 		$data['tablelist'] .= '
		// 			<tr>
		// 				<td style="text-align: center;">'.$no.'</td>
		// 				<td>'.htmlspecialchars_decode(trim($r['name']), ENT_QUOTES).'</td>
		// 				<td>'.htmlspecialchars_decode(trim($r['user_type']), ENT_QUOTES).'</td>
		// 				<td>'.$status.'</td>
		// 				<td>'.$lastupdate[0].'</td>
		// 				<td>
		// 					<a href="'.$data['uri'].'index.php/cmsbackend/user/user_manage/'.$uid.'/'.$utype.'" ><span data-feather="edit"></span> &nbsp&nbsp&nbsp&nbsp&nbsp</a>
		// 				</td>	
		// 				<td>
		// 					<a href="javascript:void(0)" onclick="DelAction('.$uid.');"><font color="red"><span data-feather="trash-2"></span></font></a>
		// 				</td>										
		// 			</tr>';
		// 		$no++;
		// 	}
		// }else{
		// 	$rs = $this->Select_data->select_data("*", "user","AND id = $id AND status = 'A'")->result_array();
		// 	foreach($rs as $r){	
		// 		if($r['status'] == "A"){
		// 			$status = "Active";
		// 		}else{				
		// 			$status = "Inactive";
		// 		}
				
		// 		$uid = htmlspecialchars_decode(trim($r['id']));
		// 		$update_date = htmlspecialchars_decode(trim($r['update_date']));
		// 		$lastupdate = explode(" ", $update_date);

		// 		$data['tablelist'] .= '
		// 			<tr>
		// 				<td>'.$no.'</td>
		// 				<td>'.htmlspecialchars_decode($r['name'],ENT_QUOTES).'</td>
		// 				<td>'.htmlspecialchars_decode($r['user_type'],ENT_QUOTES).'</td>
		// 				<td>'.$status.'</td>
		// 				<td>'.$lastupdate[0].'</td>
		// 				<td>
		// 					<a href="'.$data['uri'].'index.php/cmsbackend/user/user_manage/'.$uid.'" ><span data-feather="edit"></span></a>
		// 				</td>										
		// 			</tr>';
		// 		$no++;
		// 	}
		// }
		
		$this->load->view('cmsbackend/header', $header);
        $this->load->view('cmsbackend/user/user_list',$data);  
		$this->load->view('cmsbackend/footer');
	}

	function user_manage($id=null, $type=null){
		$header['menu'] = 'user';
		$header['menu_sub'] = '';
		
		$data['uri'] = $this->Main_function->html_chars(base_url());
		$data['text_action'] 	= "เพิ่ม User";
		$data['action'] 		= "Create User";
		
		$data['user_id'] 		= "";
		$data['name'] 			= "";
		$data['mail'] 			= "";
		$data['expire_date']	= "";
		$data['username'] 		= "";
		$data['pass']			= "";
		$data['password']		= "";
		$data['type_admin'] 	= "";
		$data['type_user'] 		= " checked ";
		
		$data['display_menu'] 	= "";
		$data['menu_list'] 		= "";

		if($type != ""){
			$data['checkbox'] = "pass";
		}else{
			$data['checkbox'] = "fail";
		}
		
		$menu_id = '';
		if($id != '' && $id != null){
			$data['user_id'] 	= $id;

			$rs = $this->Lists_model->user_list($id);
			if(count($rs)> 0){
				$data['username'] 		= $rs[0]['username'];
				$data['name'] 			= $rs[0]['name'];
				$data['mail'] 			= $rs[0]['email'];
				$data['type_admin'] 	= "";
				$data['type_user'] 		= "";
				$data['expire_date']	= $rs[0]['expire_date'];
				$data['password']		= sha1(htmlspecialchars_decode($rs[0]['password'],ENT_QUOTES));
				$data['text_action'] 	= "แก้ไข User";
				$data['action'] 		= "Edit User";
				$menu_id = explode("," , $rs[0]['menu_id']);

				if($rs[0]['user_type'] == "Admin"){
					$data['type_admin'] = " checked ";
					$data['display_menu'] = 'none';
				}else{
					$data['type_user'] = " checked ";
					$data['display_menu'] = '';
				}
			}
		}
		
		$rs_menu = $this->Select_data->select_data("*", "master_menu", "AND status = 'A'")->result_array();
		foreach($rs_menu as $m){	
			$checked = '';
			if($id != ''){
				if(in_array($m['id'], $menu_id)){
					$checked = 'checked';
				}		
			}
			$data['menu_list'] .= '<input  type="checkbox" name="menu[]" id="menu['.$m['id'].']" value="'.$m['id'].'" '.$checked.'> '.$m['name'].'<br>';
		}
	
		$this->load->view('cmsbackend/header', $header);
        $this->load->view('cmsbackend/user/user_add',$data);  
		$this->load->view('cmsbackend/footer');
	}

	function user_update(){
		$data['menu_id'] 	= '';
		$id 				= $this->input->post('user_id');
		$data['name'] 		= trim(htmlspecialchars(($this->input->post('name')),ENT_QUOTES));
		$data['email'] 		= htmlspecialchars(($this->input->post('mail')),ENT_QUOTES);
		$data['username'] 	= trim(htmlspecialchars(($this->input->post('username')),ENT_QUOTES));
		$pass 				= htmlspecialchars(($this->input->post('password')),ENT_QUOTES);
		$old_pass			= sha1($this->input->post('oldpass'));
		// echo $old_pass; exit;
		$re_pass 			= htmlspecialchars(($this->input->post('re_password')),ENT_QUOTES);
		$data['user_type'] 	= $this->input->post('user_type');
		$menu_id 			= $this->input->post('menu');

		
		$expire_date = $this->input->post('expire_date');
		$data['expire_date'] = $expire_date;
		
		$data['createby'] = $this->session->userdata('ufostatid');
		$data['create_date']	= date("Y-m-d H:i:s");
		$data['updateby'] = $this->session->userdata('ufostatid');
		$data['update_date']	= date("Y-m-d H:i:s");

		// print_r($_POST['memu[]']);
		// echo 'seve<br>';
		// print_r($menu_id); echo 'menu_id'; 	exit;
		
		if($expire_date != "N") {
            $todaydate  = date("Y-m-d H:i:s");
            $enddate    = strtotime($todaydate. ' + '.$expire_date.' month');
            // $enddate    = strtotime($todaydate. ' + 3 month');
            // echo date('Y-m-d',$enddate);
            $data['end_expire'] = date('Y-m-d',$enddate);
        } else {
            $enddate    = "";
            $data['end_expire'] = $enddate;
        }

		$data_menu_id = '';
		foreach($menu_id as $data_menu){
			$data_menu_id .= ",".$data_menu;
		}

		$data['menu_id'] = substr($data_menu_id, 1); 
		// echo $data['menu_id'];
		// exit;
			
		$sql_id = "";
		if($id != ""){
			$sql_id = "AND (id != '".$id."')";
		}
		
		$rs_username = $this->db->query("Select COUNT(*) as rnum_username From user Where (username = '".$data['username']."') ".$sql_id."")->row_array();
		if($rs_username['rnum_username'] > 0){
			$this->Main_function->showMessageThenBack('username have already, please fill username again');
		}
		
		$info = "User/".$data['name'];
		$action_table = "user";		
		
		if($id == "" || $id == null){
			$action_code = "เพิ่ม";
			$data['status']	= "A";

			if($pass == $re_pass){ 
				$data['password'] = sha1($pass); 
			}else{
				$this->Main_function->showMessageThenBack('password do not match, please fill password again');
				$data['password'] = ""; 
			}			
			if($this->db->insert('user', $data))
			{
				// $data['cre_by'] = $this->session->userdata('uivtid');
				$result = "pass";
				$res = $this->db->query("SELECT @@IDENTITY as insert_id")->row_array();
				$max_id = $res['insert_id'];
				echo "<script>alert('Insert Success.'); location.href='".base_url()."index.php/cmsbackend/user/user_list';</script>";	
			}else{
				echo "<script>alert('Can\'t save data.'); location.href='".base_url()."index.php/cmsbackend/user/user_manage/".$max_id."';</script>";
			}
		}else{

			$action_code = "แก้ไข";
			$max_id = $id;

			$rs = $this->Select_data->select_data("password", "user","AND id=$max_id")->result_array();
				foreach($rs as $r){
					$check_pass = $r['password'];
				}
			  if($old_pass == $check_pass){
					if(!empty($pass) && !empty($re_pass)){
						if($pass == $re_pass){ 
						$data['password'] = sha1($pass); 
					}else{
						$this->Main_function->showMessageThenBack('password do not match, please fill password again');
						$data['password'] = ""; 
						}	
					}
				}else{
					echo "<script>alert('Please check Old Password. !!'); location.href='".base_url()."index.php/cmsbackend/user/user_manage/".$max_id."';</script>";
					exit;
				}

			if($pass != "" && $re_pass != ""){
			  if($pass == $re_pass){ 
				$data['password'] = sha1($pass); 
			  }else{ 
				$this->Main_function->showMessageThenBack('password do not match, please fill password again');
				$data['password'] = ""; 
			  }
			}			
			$this->db->where('id', $id);
			if($this->db->update('user', $data))
			{
				$result = "pass";				
			}else{
				$result = "fail";
			}

		}
		if($result == "pass"){
			//$this->Main_function->addUserLog($info, $action_code, $action_table);
			echo "<script>alert('Update data already.'); location.href='".base_url()."index.php/cmsbackend/user/user_list';</script>";
			//redirect('/user/user_manage/'.$id.'', 'refresh');
		}else{
			echo "<script>alert('Can\'t save data.'); location.href='".base_url()."index.php/cmsbackend/user/user_manage/".$max_id."';</script>";
			//echo "<script>alert('Can\'t save data.')</script>";
		}
	}
	
	function user_delete(){
		$user_id = $this->input->post('user_id');
		$data['status'] = 'D';
		$this->db->where('id', $user_id);
		if($this->db->update('user', $data)){
			$result = "pass";				
		}else{
			$result = "fail";
		}
		echo $result;
	}
	
	function user_status($id=null, $status='A', $name){
		$data['status'] = $status;		
		
		$info = "Status/User/".$name;
		if($status == "D"){ $action_code = "ลบ"; }else{ $action_code = "แก้ไข"; }
		$action_table = "user";
		
		$this->db->where("id",$id);
		if($this->db->update('user', $data))
		{
			$this->Main_function->addUserLog($info, $action_code, $action_table);
			redirect('/cmsbackend/user/user_list/', 'refresh');
		}else{
			echo "<script>alert('Can\'t save data.')</script>";
		}		
	}
}
?>
