<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);
class Login extends DB_Controller {
	
	function __construct(){
        parent::__construct();
        $this->load->model('Main_function');
		$this->load->model('Select_data');
		$this->load->model('Lists_model');	
    }
	
	function index(){
		$this->session->sess_destroy();
        $uri = $this->Main_function->html_chars(base_url());
		
        $data['uri'] = $uri;
        
		$this->load->view('cmsbackend/Login/login', $data);
	}
	
	function check_login(){

        // echo "123"; exit;
		$username = trim($this->input->post('username'));
        $password = trim($this->input->post('password'));       
        $md5_password = sha1($this->input->post('password'));
		if(!empty($username) and !empty($password)){
            // $sql = "SELECT * FROM fo_users WHERE user_login = '$username' AND user_pass = '$md5_password' AND user_status = 'A'";
            $sql  	= "SELECT * FROM user WHERE username = '$username' AND password = '$md5_password' AND status = 'A'";
			$query = $this->db->query($sql);
			
			if($query->num_rows() > 0){
				$row = $query->row(); 
				// if($row->end_expire < date('Y-m-d H:i:s') && ($row->expire_date != 'N')){
				// 	echo 'expire';
				// 	exit;
				// }
                $menu_id = explode("," , $row->menu_id);
                $session = array(
                    'ufostatid' => $row->id,    
                    'ufostatname' => $row->name, 
                    'ufostatauthorsize' => $row->user_type,
                    'umenuid'  => $menu_id
                );                
               
                $this->session->sess_expiration = '14400';// expires in 4 hours
                //delete_cookie('username');
                //delete_cookie('password');                    
               
                $this->session->set_userdata($session);
                echo 'ok'; //correct
            }else{
                echo 'fail'; //don't has any this user or wrong username/password
            }
		}
	}
	
	function logout(){		
        $this->session->sess_destroy();
        redirect('cmsbackend/login');
    }
	
}
