<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);
class Shop extends DB_Controller {

	protected $authDataPerson;
    function __construct(){
        parent::__construct();
        $this->load->model('Main_function');
        $this->load->model('Select_data');
		$this->load->model('Lists_model');
		$this->load->model('MainModel');
		
		$this->load->model('PersonModel');
		$personID = $this->session->userdata('userfprid');
		if (!$personID) {
			redirect(URLFRONT_Login);
		}else {
			$resutlPerson = $this->PersonModel->getPersonData($personID);
			if ($resutlPerson) {
				$this->authDataPerson = $resutlPerson;
			}else {
				redirect(URLFRONT_Login);
			}
		}
    }
    public function index(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		$path_menu = "shop";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

		$cate_shop = '';
		$data['cate_shop'] = '';
		$head_image = '';
		$imgBanner = '';

		// $getParam	= $this->input->get('c');

		// if(isset($getParam))
		// {	
		// 	// $person_id	= $this->MainModel->Base64Decrypt($getParam);		
		// 	$data['person_id'] = $getParam;
		// }else{
		// 	$check_session = $this->session->userdata('userfprid');
		// 	$param = $this->MainModel->Base64Encrypt($check_session);

		// 	$data['person_id'] = $param;
		// }

		$cate = $this->Lists_model->SelectMastercate(null)->result_array();
		if(count($cate) > 0){
			foreach($cate as $c){
				$cat_id = htmlspecialchars_decode(trim($c['cat_id']));
				$nameTH = htmlspecialchars_decode(trim($c['cat_name_th']));
				$image = htmlspecialchars_decode(trim($c['cat_image']));
				$cat_alt = htmlspecialchars_decode(trim($c['cat_alt']));

				$path_image = "uploads/shopImg/category";

				$imgBanner .= '<div class="promo-img">
									<a href="'.$uri.'shop/cateshop/'.$cat_id.'">
										<div class="imgBoxcateshop" style="background: url('.PATHIMGCAMPAIGN.$path_image.'/'.$image.'?v='.date('his').') top no-repeat; background-position: center;background-size: cover;">
											<div class="inner-sub">
												<div class="text-center text-cat">'.$nameTH.'</div>
											</div>
										</div>
									</a>
								</div>';

				// echo $imgBanner;

				// $cate_shop .= '<div class="promo-img">
				// 				<a href="'.$uri.'shop/cateshop/'.$cat_id.'">
				// 					<div class="imgBoxcateshop">
				// 						<div class="text-center text-cat">'.$nameTH.'</div>
				// 					</div>
				// 				</a>
				// 			</div>';

				$data['cate_shop'] = $imgBanner;
			}

			
		}
        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
        $this->load->view($path_menu.'/cate_shop',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function cateshop($catId = null){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		$path_menu = "shop";
		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );
		$data['shop'] = '';
		$data['menu'] = 'SHOP';
		$data['type'] = '';
		$data['searchData'] = '';

		$shop = '';
		$shop_en = '';
		$shop_zone = '';
		$shop_floor = '';
		$alt = '';
		$condition = '';

		$type	= htmlspecialchars(trim($this->input->post('searchType')),ENT_QUOTES);
		$searchData = trim($this->input->post('searchData'));
		$building = trim($this->input->post('building'));
		$floor = trim($this->input->post('floor'));
		$category = trim($this->input->post('category'));

		if($searchData){
			$condition  .= "AND s.shop_name_en LIKE '%$searchData%' OR s.shop_name_th LIKE '%$searchData%'";
		}
		if($building){
			$condition  .= "AND s.shop_plaza = '$building'";
		}
		if($floor){
			$condition  .= "AND f.floor_ref_id = '$floor'";
		}
		if($category){
			$condition  .= "AND s.cat_id = '$category'";
		}
		$data['searchData']	= $searchData;
		$data['building']	= $building;
		$data['floor']	= $floor;
		$data['category']	= $category;

		$data['buildingShopResult'] = $this->Lists_model->getBuildingShops();
		$data['floorShopResult'] = $this->Lists_model->getFloorShops();
		$data['categoryShopResult'] = $this->Lists_model->getCategoryShops();


		$rs = $this->Lists_model->SelectMastershop($catId,null,$condition)->result_array();

		if(count($rs) > 0){
			foreach($rs as $s){
				$shopImage = '';
				$image = '';
				$cat_id = htmlspecialchars_decode(trim($s['cat_id']));
				$shop_id = htmlspecialchars_decode(trim($s['shop_id']));
				$shop_en = htmlspecialchars_decode(trim($s['shop_name_en']));
				$shop_th = htmlspecialchars_decode(trim($s['shop_name_th']));
				$shop_zone = htmlspecialchars_decode(trim($s['shop_zone']));
				$shop_floor = htmlspecialchars_decode(trim($s['floor_name_en']));
				$shop_room = htmlspecialchars_decode(trim($s['shop_room']));
				$image = htmlspecialchars_decode(trim($s['shop_image']));
				$alt = htmlspecialchars_decode(trim($s['shop_image_alt']));

				$path_image = "uploads/shopImg/shop";

				$check_img = "0";
				if ($image != "") {
					// echo '<br>img :'.PATHIMGCAMPAIGN.$path_image."/".$image. '<br>';
					// $ext_image = pathinfo($image, PATHINFO_EXTENSION);
					// if ($ext_image == "jpg" || $ext_image == "jpge" || $ext_image == "png") {
						// if (!file_exists(PATHIMGCAMPAIGN.$path_image."/".$image)) {
						if (file_exists(PATHIMGSHOP.$path_image.'/'.$image)) {
							$check_img = "1";
						}
					// }
				}

				// echo $shopImage; 
				if ($check_img == "1") {
					$image = htmlspecialchars_decode(trim($s['shop_image']));
					$shopImage = '<img src="'.PATHIMGCAMPAIGN.$path_image.'/'.$image.'" class="img-responsive img-shop" style="height: 120px;"/> ';
				} 

				if($shop_en == null || $shop_en == ''){
					$nameShop = $shop_th;
				}else{
					$nameShop = $shop_en;
				}

				$shop .= '	<div class="col-6 col-sm-4 col-md-3 box-4">
								<a href="'.$uri.'shop/shopDetail/'.$shop_id.'">
									<div class="card h-100">
										'.$shopImage.'
										<div class="card-body">
											<h5 class="card-title" style="font-size: 18px;"><strong>'.$nameShop.'</strong></h5>
											<p class="card-text" style="font-size: 19px;">'.$shop_floor.'  Floor</p>
										</div>
									</div>
								</a>
							</div>';
			}
		}else{
			$shop = '<div class="col-12 text-center">ไม่พบข้อมูล กรุณาเลือกตัวกรองการค้นหาอื่น</div>';
		}

		$data['shop'] = $shop;
        
        $data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
		$this->load->view($path_menu.'/shop_from',$data); 
		$this->load->view('template/footer',$data_header);
	}

	function shopDetail($shopId = null){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		$path_menu = "shop";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );
		$data['menu'] = 'DETAIL';

		$nameEN = '';

		$rs = $this->Lists_model->SelectMastershop(null,$shopId)->result_array();
		if(count($rs) > 0){
			foreach($rs as $s){
				$shopImage = '';
				$image = '';
				$cat_id = htmlspecialchars_decode(trim($s['cat_id']));
				$shop_id = htmlspecialchars_decode(trim($s['shop_id']));
				$shop_en = htmlspecialchars_decode(trim($s['shop_name_en']));
				$shop_th = htmlspecialchars_decode(trim($s['shop_name_th']));
				$shop_zone = htmlspecialchars_decode(trim($s['shop_zone']));
				$shop_floor = htmlspecialchars_decode(trim($s['floor_name_en']));
				// $shop_floor_th = htmlspecialchars_decode(trim($s['floor_name_th']));
				$shop_room = htmlspecialchars_decode(trim($s['shop_room']));
				$image = htmlspecialchars_decode(trim($s['shop_image']));
				$alt = htmlspecialchars_decode(trim($s['shop_image_alt']));
				$description = htmlspecialchars_decode(trim($s['shop_description']));
				$plazaName = htmlspecialchars_decode(trim($s['shop_plaza_name']));
				$cate = $this->Lists_model->SelectMastercate($cat_id)->result_array();

				if(count($cate) > 0){
					foreach($cate as $c){
						$cat_id = htmlspecialchars_decode(trim($c['cat_id']));
						$nameTH = htmlspecialchars_decode(trim($c['cat_name_th']));
						$nameEN = htmlspecialchars_decode(trim($c['cat_name_en']));
					}
				}

				$path_image = "uploads/shopImg/shop";

				$check_img = "0";
				if ($image != "") {
					if (file_exists(PATHIMGSHOP.$path_image.'/'.$image)) {
						$check_img = "1";
					}
				}

				if ($check_img == "1") {
					$image = htmlspecialchars_decode(trim($s['shop_image']));
					$shopImage = '<img src="'.PATHIMGCAMPAIGN.$path_image.'/'.$image.'" class="img-responsive" style="height: 120px;"/> ';
				} 

				
				$shopImage = PATHIMGCAMPAIGN.$path_image.'/'.$image;
				$nameShop_th = $shop_th ? $shop_th : $shop_en;
				$nameShop_en = $shop_en ? '('.$shop_en.')' : '';
				$buliding = $plazaName ? $plazaName : '';
				if(strtolower(trim($buliding)) == 'future park'){
					$imageLogo = '<img src="'.base_url('assets/images/future_park_logo.svg?v="'.date('s').'"').'" class="card-img" style="width: 50px; height: 50px; margin-top: -10px; margin-right: 0px;" alt="shop image">';
				}else {
					$imageLogo = '<img src="'.base_url('assets/images/logo-zpell.svg?v="'.date('s').'"').'" class="card-img" style="width: 60px; height: 50px; margin-top: -15px; margin-right: 0px;" alt="shop image">';
				}
				$descriptionShop = $description ? $description : '';
				if($nameTH){
					$htmlNameEn = $nameEN ? ' ('.$nameEN.')' : '';
					$catName = '<strong class="mr-3">หมวดหมู่ร้านค้า (Category): </strong><span> '.$nameTH.$htmlNameEn.'</span> </br>';
				}else {
					$catName = '';
				}
				if($shop_floor){
					$shopHtml = '<strong class="mr-3">ชั้น: </strong><span> '.$shop_floor.'</span> </br>';
				}else {
					$shopHtml = '';
				}
				if($shop_zone){
					$zoneHtml = '<strong class="mr-3">โซน: </strong><span> '.$shop_zone.'</span> </br>';
				}else {
					$zoneHtml = '';
				}
				$detail = '
				<div class="row mt-5">
					<div class="col-12">
						<div class="card mb-3">
							<div class="row no-gutters">
								<div class="col-md-4">
									<img src="'.$shopImage.'" class="card-img px-5 py-4" alt="shop image">
								</div>
								<div class="col-md-8">
									<div class="card-body px-5">
										<div class="row mb-3">
											<div class="col-8 d-flex justify-content-between">
												<strong>'.$nameShop_th.' '.$nameShop_en.'</strong>
											</div>
											<div class="col-4 text-right d-flex justify-content-end">
												'.$imageLogo.'
											</div>
										</div>
										<small class="card-text">'.$descriptionShop.'</small>
										<p class="">
											'.$shopHtml.'
											'.$zoneHtml.'
											'.$catName.'
										</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>';
				
			}

			$data['detail'] = $detail;
			$data['catId']	= $cat_id;

		}

        
		$data['backlist'] = $this->authDataPerson->personStatus == $this->config->item('status_ban') ? true : false;
		$this->load->view('template/header',$data_header);
		$this->load->view($path_menu.'/shop_from',$data); 
		// $this->load->view($path_menu.'/shopDetail_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}
}
