<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);
class Get_person extends DB_Controller {

    function __construct(){
        parent::__construct();
        $this->load->model('Select_data');
		$this->load->model('Lists_model');
		$this->load->model('PersonModel');
		$this->load->model('MainModel');
        $this->load->model('ActivityModel');    
        $this->load->model('SelectModel');   
        $this->load->model('PrivilegeModel'); 
    }

	function build()
	{
		$ERR_STATUS = 400;
		try{				
			// "REFID":"TWc9PQ==","REFCODE":"UVVOVU1qQXlNREEwTURFdE1nPT0=","REFCAMPID":"TVE9PQ==","REFCAMPCODE":"UXpJd01qQXdOREF4","REFPH":"0812083821","REFREFER":"j505"}; 
			$P_SHOW			= '';
			// $P_REFID		= $this->MainModel->Base64Decrypt(trim($this->input->post('REFID')));
			// $P_REFCODE		= $this->MainModel->Base64Decrypt(trim($this->input->post('REFCODE')));
			// $P_REFCAMPID	= $this->MainModel->Base64Decrypt(trim($this->input->post('REFCAMPID')));
			// $P_REFCAMPCODE	= $this->MainModel->Base64Decrypt(trim($this->input->post('REFCAMPCODE')));
			// $P_REFPH		= $this->input->post('REFPH');
			// $P_REFREFER		= $this->input->post('REFREFER');		
            // $P_PERSID		= $this->MainModel->Base64Decrypt(trim($this->input->post('PERSID')));
            
            
            $P_REFID		= $this->MainModel->Base64Decrypt('TWc9PQ==');
			$P_REFCODE		= $this->MainModel->Base64Decrypt('UVVOVU1qQXlNREEwTURFdE1nPT0=');
			$P_REFCAMPID	= $this->MainModel->Base64Decrypt('TVE9PQ==');
			$P_REFCAMPCODE	= $this->MainModel->Base64Decrypt('UXpJd01qQXdOREF4');
			$P_REFPH		= $this->MainModel->Base64Decrypt('0888566069');
			$P_REFREFER		= $this->MainModel->Base64Decrypt('j505');		
            $P_PERSID		= '';
			
			if($P_REFPH == ""){ $ERR_STATUS = 400; throw new exception('Err mobileNo is empty'); }
			
			$F_PHONE = 'mobileNo';	
			
			$mapObj	 = new stdClass();
			$mapObj->PERSID		= $this->input->post('PERSID');
			$mapObj->REFID		= $this->input->post('REFID');
			$mapObj->REFCODE	= $this->input->post('REFCODE');
			// $mapObj->REFCAMPID	= $this->input->post('REFCAMPID');
			// $mapObj->REFCAMPCODE= $this->input->post('REFCAMPCODE');			
			
			$resObj	= $this->ActivityModel->getActivityForm($P_REFCAMPID,$P_REFID,$P_SHOW)->result_array();	
			
			if(count($resObj) == 0){ $ERR_STATUS = 400; throw new exception('Err not found form'); }
			
			$master['nationCode'] 	= $this->SelectModel->SelectNationality(null,null,'A')->result_array();
			$master['province'] 	= $this->SelectModel->SelectProvince(null,null,'A')->result_array();			
			
			$selectOption['province']	= "";
			//$selectOption['district']	= "";
			//$selectOption['province']	= "";
			foreach($master['province'] as $k=>$v)
			{
				$selectOption['province'] .= "<option value='".$v['displayCode']."' ".($v['displayCode'] == 'TH' ? 'selected' : '').">".$v['displayNameLC']."</option>";
			} 				
			
			foreach($resObj as $r)
			{				
				if($r['required'] == 'Y'){ $class_required = 'required'; $text_required = "*"; }else{ $text_required = ""; $class_required = '';}
				
				if($r['is_show'] == 'Y'){
					
					if($P_REFPH != "")
					{
						$readonly = "readonly";
					}
					
					if($r['objType'] == 'Address')
					{
						$addType 	= $r['objValue'];
						$fieldname	= $addType.'_'.$r['mappingfield'];
						if($r['elementType'] == "paintext")
						{
							$dataField['Label'.$addType.'Addr']	= '<h5 class="font-bold" addrType="'.$addType.'">'.$r['elementLabel'].'</h5>';
						}else if($r['elementType'] == "textarea")
						{						
							$dataField[$fieldname] = '<div class="col-12 col-md-'.$r['colWidth'].' form-group">
															<label class="form-label">'.$r['elementLabel'].' '.$text_required.'</label>
															<div class="input-group">
																<textarea class="form-control" '.$class_required.' rows=1 id="'.$fieldname.'" name="'.$fieldname.'"></textarea>
															</div>
														  </div>';
						}else if($r['elementType'] == "select")
						{				
							$newname = str_replace("Code","",$r['mappingfield']);
							$dataField[$fieldname] = '<div class="col-12 col-md-'.$r['colWidth'].' form-group">
														<label class="form-label">'.$r['elementLabel'].' '.$text_required.'</label>
														<div class="input-group">
															<select class="custom-select select-'.$newname.'" '.$class_required.' name="'.$fieldname.'" id="'.$fieldname.'">
																<option value="">กรุณาเลือก'.$r['elementLabel'].'</option>
																'.(isset($selectOption[$newname])? $selectOption[$newname] : "").'
															</select>
														</div>
													</div>';
														  
						}else {
							$dataField[$fieldname] = '<div class="col-12 col-md-'.$r['colWidth'].' form-group">
																<label class="form-label">'.$r['elementLabel'].' '.$text_required.'</label>
																<div class="input-group '.$r['fieldType'].'"><input type="text" class="form-control" '.$class_required.' id="'.$fieldname.'" name="'.$fieldname.'" maxlength="'.$r['maxlength'].'"></div>
															</div>';
							
						}
					}else if($r['objType']	== 'Social')
					{
					
					}else{
						if($F_PHONE == $r['mappingfield']){ $readonly = ' readonly '; $value = $P_REFPH; }else{ $readonly = ""; $value = ""; }						
						if($r['elementType'] == "radio")
						{
							$element = '<div class="radio-tile-group">
											<div class="input-container">
											  <input class="radio-button" '.$class_required.' type="radio" name="gender" value="M"/>
											  <div class="radio-tile">
												<div class="icon text-center">
													<h3 class="mt-2"><i class="fas fa-male"></i>
													<i class="fas fa-mars" style="font-size:18px"></i></h3>
												</div>												
											  </div>
											</div>
											<div class="input-container">
											  <input class="radio-button" '.$class_required.' type="radio" name="gender" value="F"/>
											  <div class="radio-tile">
												<div class="icon text-center">
													<h3 class="mt-2"><i class="fas fa-female"></i> 
													<i class="fas fa-venus" style="font-size:18px"></i></h3>
												</div>												
											  </div>
											</div>
										</div>';							
						}else if($r['elementType'] == "select")
						{
							$option	= "";
							foreach($master[$r['mappingfield']] as $k=>$v)
							{
								$option .= "<option value='".$v['displayCode']."' ".($v['displayCode'] == 'TH' ? 'selected' : '').">".$v['displayNameLC']."</option>";
							} 
							$element	= '<select class="form-control custom-select" id="'.$r['mappingfield'].'" name="'.$r['mappingfield'].'" '.$class_required.' >
												<option value="">กรุณาเลือก'.$r['elementLabel'].'</option>
												'.$option.'
											</select>';
						}else if($r['elementType'] == "textarea")
						{
							$element	= '<textarea class="form-control" '.$class_required.$readonly.' id="'.$r['mappingfield'].'" name="'.$r['mappingfield'].'" maxlength='.$r['maxlength'].' >'.$value.'</textarea>';	
						}
						else{
							$element	= '<input type="text" class="form-control" '.$class_required.$readonly.' id="'.$r['mappingfield'].'" name="'.$r['mappingfield'].'" maxlength='.$r['maxlength'].' value="'.$value.'">';							
						}
						
						$dataField[$r['mappingfield']]	= '<div class="col-12 col-md-'.$r['colWidth'].' form-group">
															<label class="form-label">'.$r['elementLabel'].' '.$text_required.'</label>
															<div class="input-group '.$r['fieldType'].'">'.$element.'</div>
														   </div>';
					}
				}else{					
					// / Field not show 
				}				
			}			
			
			$dataRes['dataobj']		= $mapObj;
			$dataRes['datafield']	= $dataField;
			$dataRes['status'] 		= array('STATUS' => 'Successfully');
			echo json_encode($dataRes);		
		}
		catch(exception $e){
            if($ERR_STATUS == 400)
            {
                log_message('error', $e->getMessage());
            }
            $Err['status'] = array('STATUS' => 'Unsuccessfully', 'ERRDESC' => $e->getMessage());
			echo json_encode($Err);    
        }
	}	
}
