<style>
    .box-shop{
        background-color: #f0f0f2;
        /* box-shadow: 4px 5px 5px grey; */
        height: 200px;
        overflow: hidden;
        position: relative;
        width: 100%;
        border-style: solid;
        border-width: 1px;
        border-color: gray;
    }
    .box-4{
        padding: 0 10px 15px 10px;
    }
    {
        background-position: center;
        background-size: cover;
        height: 110px;
        background-color: cadetblue;
    }

    .imgBoxshop{
        background-position: center;
        background-size: cover;
        height: 120px;
        /* background-color: cadetblue; */
        width: 120px;
        background-color: #f9f7fb;
    }

    .imgBoxshop.boxImg{
        border: 1px solid;
        height: 122px;
    }

    .form-control[disabled]{
        background-color: #FFF;
    }

    .text-shop{
        padding: 10px;
    }

    i:focus ,i:active{
        color: red;
        outline: none;
    }
</style>

<div class="container boxPage">
    <div>
        <!-- <a href="<?php echo $uri; ?>">
            <img src="<?php echo $uri . "assets/images/icons/set_home.png?v=".date('his')."" ?>" alt=" " class="responsive top10">
        </a> -->

    </div>
    <div class="row">
        <div class="col-1">
            <?php 
                if($menu == 'SHOP'){
                    echo '<a href="'.$uri.'">
                        <i class="fa fa-chevron-left"></i>
                    </a>';
                }else{
                    echo '<a href="'.$uri.'shop/cateshop/'.$catId.'">
                        <i class="fa fa-chevron-left"></i>
                    </a>';
                }
            ?>
        </div>
        <div class="col-10">
            
            <?php 
                if($menu == 'SHOP'){
                    echo '<p class="text-title" id="head_page">ค้นหาร้านค้า (Shop search)</p>';
                }else{
                    echo '<p class="text-title" id="head_page">ร้านค้า (Shop)</p>';
                }
            ?>
        </div>
    </div>
    
    <?php if($menu == 'SHOP'){ ?>
        <form name="form_search" id="form_search" method="post" action="<?php echo base_url()?>shop/cateshop">
            <div class="row">
                <div class="col-5">
                    <div class="star-require">ประเภทตัวกรอง</div>
                    <select id="searchType" name="searchType" class="form-control form-control-sm boxInput" onchange="selectVal()" required>
                        <option value="">-- เลือก --</option>
                        <option value="all" <?php if($type == "all") echo 'selected'; ?>>ทั้งหมด</option>
                        <option value="name" <?php if($type == "name") echo 'selected'; ?>>ชื่อร้านค้า</option>
                        <option value="category" <?php if($type == "category") echo 'selected'; ?>>หมวดหมู่ร้านค้า</option>
                        <option value="zone" <?php if($type == "zone") echo 'selected'; ?>>โซน</option>
                        <option value="floor" <?php if($type == "floor") echo 'selected'; ?>>ชั้น</option>
                        <!-- <option value="promotion">โปรโมชั่น</option>
                        <option value="maxnet">แม็กเน็ต</option> -->
                    </select>
                </div>
                <div class="col-7">
                    <div>
                        <div class='boxSearch'>ค้นหา</div>
                        <div class='box d-none'></div>
                        <div class="row">
                            <div class="col-9">
                                <input class="form-control form-control-sm boxInput boxSearch" type="text" name="searchData" id="searchData" placeholder="" value="<?php echo $searchData; ?> ">
                            </div>
                            <div>
                                <span>
                                    <!-- <button class="btn btn-search" id="search"><i class="fa fa-search" style="font-size:24px"></i></button> -->
                                    <a id="search" href="javascript:void(0)">
                                        <i class="fa fa-search" style="font-size:24px"></i>
                                    </a>
                                </span>
                            </div>
                        </div>
                     </div>   
                    
                </div>
            </div>
        </form>
    <?php } ?>
    
        <?php 
            if($menu == 'SHOP'){
                if($shop){
                    echo '<div class="row top30">'.$shop.'</div>';
                }
            }else{
                if($detail){
                    echo $detail;
                } 
            }
        ?>
    <div>
</div>

<script>
    $( document ).ready(function() {
        var type = $('#searchType').val();
        var nameVal = $('#searchData').val();

        console.log(type,nameVal);
        
        selectVal();
    });

    $(document).on('keyup', '#searchData', function () {
        $("#searchData").removeClass('required');
    });

    function selectVal(){
        var type = $('#searchType').val();

        if(type == 'all'){
            $(".boxSearch").empty();
            $("#searchData").addClass('d-none');
            $(".fa-search").css({"margin-top": "30px"});
            
        }else{
            $(".boxSearch").html("ค้นหา");
            $("#searchData").removeClass('d-none');
            $(".fa-search").css({"margin-top": "0"}); 
        }
    }


    $(document).on('click', '#search', function () {
        var type = $('#searchType').val();
        var nameVal = $('#searchData').val();

        console.log(type,nameVal);
        if(isEmpty(type)||isEmpty(nameVal)){
            if (isEmpty(type)) {
                // console.log('1');
                $("#searchType").addClass('required');
            }else{
                // console.log('2');
                $("#searchType").removeClass('required');
            }
            console.log(nameVal);
            if(nameVal.trim() == '' && type != 'all'){
                // console.log('3');
                $("#searchData").addClass('required');
            }else{
                // console.log('4');
                $("#searchData").removeClass('required');
                
            }

            return false;
        }else{
            $("#searchType").removeClass('required');
            $("#searchData").removeClass('required');
        }
        // console.log('5');

        $('#form_search').submit();


        // var param = {type: type,data: data};

        // $.ajax({
        //     data: param,
        //     method: "post",
        //     datatype: "json",
        //     url: '<?php echo $uri; ?>shop/cateshop',
        // }).done(function (e) {
        //     console.log(e);
        //     // console.log(jQuery.parseJSON(e));
        //     // $('#national').html(jQuery.parseJSON(e));
        //     // loading('hide');
        // })
        
    });
</script>


