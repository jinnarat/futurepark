<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
// error_reporting(0);
class Shop extends DB_Controller {

    function __construct(){
        parent::__construct();
        $this->load->model('Main_function');
        $this->load->model('Select_data');
		$this->load->model('Lists_model');
		$this->load->model('MainModel');
		
		$check_session = $this->session->userdata('userfprid');
        if(!$check_session){						
            redirect(URLFRONT_Login);
        }
    }
    public function index(){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		$path_menu = "shop";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );

		$cate_shop = '';
		$data['cate_shop'] = '';
		$head_image = '';
		$imgBanner = '';

		// $getParam	= $this->input->get('c');

		// if(isset($getParam))
		// {	
		// 	// $person_id	= $this->MainModel->Base64Decrypt($getParam);		
		// 	$data['person_id'] = $getParam;
		// }else{
		// 	$check_session = $this->session->userdata('userfprid');
		// 	$param = $this->MainModel->Base64Encrypt($check_session);

		// 	$data['person_id'] = $param;
		// }

		$cate = $this->Lists_model->SelectMastercate(null)->result_array();
		if(count($cate) > 0){
			foreach($cate as $c){
				$cat_id = htmlspecialchars_decode(trim($c['cat_id']));
				$nameTH = htmlspecialchars_decode(trim($c['cat_name_th']));
				$image = htmlspecialchars_decode(trim($c['cat_image']));
				$cat_alt = htmlspecialchars_decode(trim($c['cat_alt']));

				$path_image = "uploads/shopImg/category";

				$imgBanner .= '<div class="promo-img">
									<a href="'.$uri.'shop/cateshop/'.$cat_id.'">
										<div class="imgBoxcateshop" style="background: url('.PATHIMGCAMPAIGN.$path_image.'/'.$image.'?v='.date('his').') top no-repeat; background-position: center;background-size: cover;">
											<div class="inner-sub">
												<div class="text-center text-cat">'.$nameTH.'</div>
											</div>
										</div>
									</a>
								</div>';

				// echo $imgBanner;

				// $cate_shop .= '<div class="promo-img">
				// 				<a href="'.$uri.'shop/cateshop/'.$cat_id.'">
				// 					<div class="imgBoxcateshop">
				// 						<div class="text-center text-cat">'.$nameTH.'</div>
				// 					</div>
				// 				</a>
				// 			</div>';

				$data['cate_shop'] = $imgBanner;
			}

			
		}
        
        $this->load->view('template/header',$data_header);
        $this->load->view($path_menu.'/cate_shop',$data);  
		$this->load->view('template/footer',$data_header);
		
	}

	function cateshop($catId = null){
		$uri = $this->Main_function->html_chars(base_url());
		
		$data['uri'] = $uri;
		$path_menu = "shop";
		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );
		$data['shop'] = '';
		$data['menu'] = 'SHOP';
		$data['type'] = '';
		$data['searchData'] = '';

		$shop = '';
		$shop_en = '';
		$shop_zone = '';
		$shop_floor = '';
		$alt = '';
		$condition = '';

		$type	= htmlspecialchars(trim($this->input->post('searchType')),ENT_QUOTES);
		$getData = trim($this->input->post('searchData'));
		$searchData	= $this->MainModel->trimKeyWord($getData);

		if(!empty($type) && !empty($searchData)){
			if($type == 'name'){
				$condition  .= "AND shop_name_en LIKE '%$searchData%' OR shop_name_th LIKE '%$searchData%'";  
			}
			if($type == 'category'){
				$condition  .= "AND (cat_name_th LIKE '%$searchData%' OR cat_name_en LIKE '%$searchData%')";  
			}
			if($type == 'zone'){
				$condition  .= "AND (shop_zone LIKE '%$searchData%')";  
			}
			if($type == 'floor'){
				$condition  .= "AND (floor_name_en LIKE '%$searchData%' OR floor_name_th LIKE '%$searchData%')";  
			}
			if($type == 'all'){
				$condition  .= ""; 
				$data['searchData']	= ''; 
			}
			$data['type']	= $type; 
			$data['searchData']	= trim($searchData); 
				   
		}

		$rs = $this->Lists_model->SelectMastershop($catId,null,$condition)->result_array();

		if(count($rs) > 0){
			foreach($rs as $s){
				$shopImage = '';
				$image = '';
				$cat_id = htmlspecialchars_decode(trim($s['cat_id']));
				$shop_id = htmlspecialchars_decode(trim($s['shop_id']));
				$shop_en = htmlspecialchars_decode(trim($s['shop_name_en']));
				$shop_th = htmlspecialchars_decode(trim($s['shop_name_th']));
				$shop_zone = htmlspecialchars_decode(trim($s['shop_zone']));
				$shop_floor = htmlspecialchars_decode(trim($s['floor_name_en']));
				$shop_room = htmlspecialchars_decode(trim($s['shop_room']));
				$image = htmlspecialchars_decode(trim($s['shop_image']));
				$alt = htmlspecialchars_decode(trim($s['shop_image_alt']));

				$path_image = "uploads/shopImg/shop";

				$check_img = "0";
				if ($image != "") {
					// echo '<br>img :'.PATHIMGCAMPAIGN.$path_image."/".$image. '<br>';
					// $ext_image = pathinfo($image, PATHINFO_EXTENSION);
					// if ($ext_image == "jpg" || $ext_image == "jpge" || $ext_image == "png") {
						// if (!file_exists(PATHIMGCAMPAIGN.$path_image."/".$image)) {
						if (file_exists(PATHIMGSHOP.$path_image.'/'.$image)) {
							$check_img = "1";
						}
					// }
				}

				// echo $shopImage; 
				if ($check_img == "1") {
					$image = htmlspecialchars_decode(trim($s['shop_image']));
					$shopImage = '<img src="'.PATHIMGCAMPAIGN.$path_image.'/'.$image.'" class="img-responsive" style="height: 120px;"/> ';
				} 

				if($shop_en == null || $shop_en == ''){
					$nameShop = $shop_th;
				}else{
					$nameShop = $shop_en;
				}

				$shop .= '<div class="col-4 box-4">
							<div class="box-shop">
								<a href="'.$uri.'shop/shopDetail/'.$shop_id.'">
									<div class="imgBoxshop">
										'.$shopImage.'
									</div>
								</a>
								<div class="text-shop">
									<p>'.$nameShop.'</p>
									<p>'.$shop_floor.'  Floor</p>
								</div>
							</div>
						</div>';
			}


		}else{
			$shop = '<div class="col-12 text-center">ไม่มีข้อมูล</div>';
		}

		$data['shop'] = $shop;
        
        $this->load->view('template/header',$data_header);
		$this->load->view($path_menu.'/shop_from',$data); 
		$this->load->view('template/footer',$data_header);
	}

	function shopDetail($shopId = null){
        $uri = $this->Main_function->html_chars(base_url());
		$data['uri'] = $uri;
		$path_menu = "shop";

		$data_header = array(
			"TITLE"           => TITLE,
			"META_KEYWORDS"   => META_KEYWORDS,  
			"META_DESC"       => META_DESC,             
			"stylesheet"      => '',  
			"javascript"      => '',  
			"fb_title"        => OG_TITLE,  
			"fb_image"        => OG_IMAGE,  
			"fb_description"  => OG_DESC,  
			"isHeader"        => true
        );
		$data['menu'] = 'DETAIL';

		$nameEN = '';

		$rs = $this->Lists_model->SelectMastershop(null,$shopId)->result_array();
		if(count($rs) > 0){
			foreach($rs as $s){
				$shopImage = '';
				$image = '';
				$cat_id = htmlspecialchars_decode(trim($s['cat_id']));
				$shop_id = htmlspecialchars_decode(trim($s['shop_id']));
				$shop_en = htmlspecialchars_decode(trim($s['shop_name_en']));
				$shop_th = htmlspecialchars_decode(trim($s['shop_name_th']));
				$shop_zone = htmlspecialchars_decode(trim($s['shop_zone']));
				$shop_floor = htmlspecialchars_decode(trim($s['floor_name_en']));
				$shop_room = htmlspecialchars_decode(trim($s['shop_room']));
				$image = htmlspecialchars_decode(trim($s['shop_image']));
				$alt = htmlspecialchars_decode(trim($s['shop_image_alt']));

				$cate = $this->Lists_model->SelectMastercate($cat_id)->result_array();
				if(count($cate) > 0){
					foreach($cate as $c){
						$cat_id = htmlspecialchars_decode(trim($c['cat_id']));
						$nameTH = htmlspecialchars_decode(trim($c['cat_name_th']));
						$nameEN = htmlspecialchars_decode(trim($c['cat_name_en']));
					}
				}

				if($shop_zone == null || $shop_zone == ''){
					$shop_zone = '-';
				}

				$path_image = "uploads/shopImg/shop";

				$check_img = "0";
				if ($image != "") {
					// echo '<br>img :'.PATHIMGCAMPAIGN.$path_image."/".$image. '<br>';
					// $ext_image = pathinfo($image, PATHINFO_EXTENSION);
					// if ($ext_image == "jpg" || $ext_image == "jpge" || $ext_image == "png") {
						// if (!file_exists(PATHIMGCAMPAIGN.$path_image."/".$image)) {
						if (file_exists(PATHIMGSHOP.$path_image.'/'.$image)) {
							$check_img = "1";
						}
					// }
				}

				// echo $shopImage; 
				if ($check_img == "1") {
					$image = htmlspecialchars_decode(trim($s['shop_image']));
					$shopImage = '<img src="'.PATHIMGCAMPAIGN.$path_image.'/'.$image.'" class="img-responsive" style="height: 120px;"/> ';
				} 

				if($shop_en == null || $shop_en == ''){
					$nameShop = $shop_th;
				}else{
					$nameShop = $shop_en;
				}

				$htmlZone = ($shop_zone || $shop_zone != '-')  ? '<div class="top10">
								<div class="textBold">โซน (Zone)</div>
								<div class="input-view">'.$shop_zone.'</div>
							</div>' : '';
				

				$detail = '<div class="row top50">
								<div class="col-md-5 col-xs-5 .offset-xs-1">
									<div class="imgBoxshop boxImg">
									'.$shopImage.'
									</div>
								</div>
								<div class="col-md-7 col-xs-7">
									<p><b>'.$nameShop.'</b></p>
									<span>'.$shop_floor.' Floor</span>
								</div>
							</div>
							<div>
								<div class="top50">
									<div class="textBold">หมวดหมู่ร้านค้า (Category)</div>
									<div class="input-view">'.$nameTH.'  ('.$nameEN.')</div>
								</div>
								'.$htmlZone.'
							</div>';
							// <div class="top10">
							// 		<div class="textBold">โปรโมชั่น (Promotion)</div>
							// 		<div class="input-view">-</div>
							// 	</div>
							// <div class="top10"> 
							// 		<div class="textBold">แม็คเน็ต (Magnet)</div>
							// 		<div class="input-view">-</div>
							// 	</div>
				
			}

			$data['detail'] = $detail;
			$data['catId']	= $cat_id;

		}

        
		$this->load->view('template/header',$data_header);
		$this->load->view($path_menu.'/shop_from',$data); 
		// $this->load->view($path_menu.'/shopDetail_from',$data);  
		$this->load->view('template/footer',$data_header);
		
	}
}
